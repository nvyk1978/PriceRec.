# Price Rec. v0.1.33

- versionCode 34
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`


## v0.1.33
- 店舗カードはサムネイルが3枚以下でも「全て表示」エリアを常時確保。
- 画像選択モードの選択枚数を左下へ配置し、「選択」開始直後は0枚選択。
- 画像追加確認の下部ボタンを「キャンセル」左／「画像追加」右へ変更。
- 画像追加確認に税表示補助Nトグルを追加。デフォルトON＝「表示なしは税抜」（ライトブルー）、OFF＝「表示なしは税込」。
- 税表示補助設定を画像ごとに保存し、ChatGPT共有プロンプトの価格種別判定へ反映。

## v0.1.32
- Store cards now have a persistent internal `store_key`. New keys use the human-readable `str.` prefix format and can be edited from the Card Name Change dialog without tying the key to the visible card name.
- Card Name Change now has clearer vertical spacing between the title area and its input fields, and exposes both card name and `store_key`.
- New product keys are normalized to the `prd.` prefix format. Japanese/full-width text is allowed after the prefix; comparison uses exact full-string matching, so periods inside product names do not change key semantics.
- CSV share prompt now explicitly requests `prd.` keys and only uses `.001`, `.002`, ... when different products would otherwise collide on the same key.
- Import/edit logic adds the same three-digit collision suffix only when a different product in the same store would reuse an existing key; ordinary duplicate observations keep the same key.
- Store-card photo area is now a fixed 3-column x 2-row (6-thumbnail) viewport. More photos scroll vertically inside that photo area instead of continuously expanding the card.
- The `全て表示` action area is taller and easier to tap.
- `全て表示` now supports long-press photo selection directly inside the full-image dialog. Selection uses the same `キャンセル / 削除 / 共有 / タグ編集` controls and ends automatically when the last selected image is cleared or when the dialog is canceled/closed.

## Carried forward
- Photo thumbnails remain square, three columns wide, left-aligned, and use the reduced corner radius.
- Selected photo text bands remain light blue with the same width/corner radius as the thumbnail and a small gap between image and band.
- Photos and products support multiple tags.
- Store N toggle uses the custom FinderlessCamera-style control; ON is orange and OFF is white. OFF cards remain read-only and excluded from product search.
- Draggable fast-scroll thumbs keep a fixed visible size while the transparent grip area is wider.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
