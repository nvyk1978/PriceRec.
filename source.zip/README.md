# Price Rec. v0.1.4

- applicationId: `com.pricerec.app`
- versionCode: 5
- versionName: 0.1.4
- stable signing key: `app/pricerec-debug.jks`
- target / compile SDK: 36
- Java 17

## v0.1.4
- スーパー陳列棚向けOCRを精度優先で再設計
- 全体画像＋高コントラスト＋重複タイルの複数パスOCR
- 値札の「価格」を先に検出し、位置関係から商品名を逆引きする価格アンカー方式
- 税込価格・￥表記・円表記を強く優先
- JANコード、日付、容量だけの行、割引・告知・販促文章を商品名候補から除外
- 長い説明文や文章調のOCR結果を低評価にして誤登録を抑制
- 同一位置を複数パスで読んだ結果を投票・統合し、商品名と価格の候補を選別
- OCRタグ（酒 / 肉 / 調味料）を商品名候補の補助スコアに利用
- 同一写真内の完全一致商品＋価格の重複行を除去
- 診断ログにOCR各パスの候補数と最終採用数を記録

## 既存仕様
- 検索欄の「検索モード」文言なし
- Android 16 IME Insets 対応
- 新規店舗＋は真円
- 新規店舗ダイアログは店舗名欄へ自動フォーカス
- ラウンドスクエア類は外周線なしのフラット表示
- 店舗・タグは三本線ハンドルで並べ替え
- 撮影 / Photo Picker画像追加
- OCR結果・店舗商品リスト・全リストは表形式
- 全リスト表示 / 診断ログ

## GitHub
`source.zip` をリポジトリ直下へ、`pricerec-build.yml` を `.github/workflows/` へ配置。
YMLは `workflow_dispatch` を持たず、push時に自動ビルドします。
