# Price Rec. v0.1.70

Version: 0.1.70
VersionCode: 71

## Changes
- 店舗カード長押しメニューを「店舗情報変更 / 店舗削除 / エクスポート」の順に固定。
- 三点リーダーを「全CSV一覧 / CSVインポート / 店舗をインポート / インポート履歴 / 全店舗をエクスポート / 診断ログ」の順に固定。
- 店舗データの共有シートに「保存」カスタムアクションを追加。Android 14+では共有先を選ぶのと同じ画面から保存先選択へ進める。単店舗／全店舗エクスポート共通。
- エクスポートの「参照画像を含める」とインポートの「画像もインポート」はON時をNオレンジ `#775500` に統一。画像なしインポートではOFF固定＋グレーアウトを維持。
- 複数店舗のまとめてインポート画面に左端「選択」を追加し、右端に「キャンセル / まとめてインポート」を配置。
- 「選択」を押すと選択モードへ入り、初期状態は0件選択。選択店舗カードはNダークグレー表示。1件以上選択時のみ「まとめてインポート」を有効化。
- 選択モード中の左端ボタンは固定サイズの「選択解除」に切替。0件選択ではグレーアウト、1件以上ではNダークレッド `#441100`。押すと全選択を解除し、選択モードは維持。
- 「マージ / 新規店舗として登録」等、状態で文言が変わるボタンは切替前後で外形サイズを変更しない。
- v0.1.69の `.prstore`、インポート履歴／パージ、新規店舗→後日Googleマップ解析→同一identity時の確認マージ、固定store_key基盤を維持。
- 編集不可store_keyは入力フィールド外観を残したロック表示を維持。
- インポート履歴の下部操作を左端「パージ済を削除」／右端「キャンセル」に変更し、「閉じる」を廃止。履歴メモは空欄でも `MEMO:` を常時表示。
- 商品リスト／画像画面は、ブルーの「選択」の左にダークグレーの「全て選択」を追加。カード内表示と全画面表示の双方で一括選択に対応。

## v0.1.70
- 上記 Changes と同一。DB schema変更なし。

## v0.1.69
- `.prstore` による単店舗／全店舗エクスポートと店舗インポートを追加。画像あり／なし、実サイズ・CSV/商品/画像件数表示に対応。
- インポート方法「マージ / 新規店舗として登録」、複数ファイル取り込み、インポート履歴・一行メモ・パージを追加。
- 新規店舗を後からGoogleマップ解析し、同一identityの既存店舗がある場合に確認してマージできるようにした。DBをv18へ更新。
- 編集不可store_keyは通常入力フィールド外観を残し、文字だけ抑えたロック表示へ変更。

## v0.1.55
- 店舗カード長押しメニューから「カード内商品リスト」を削除。
- GoogleマップURLをバックグラウンドで自動解析。短縮URLは内部で展開し、入力欄の文字列は書き換えない。
- カード情報変更／カード追加に「マップ解析」ボタンを追加。解析成功時は「解析済」（ダークオレンジ＋黒文字）。
- 解析済み店舗カードは題字左にCSV取得済みと同型の緑チェックを表示。
- Googleマップ解析結果として展開済みURL・緯度・経度をDBに保存（DB v17）。
- マップ解析成功時は緯度経度を正規化してSHA-256から決定的な `str.map.<20hex>` を生成。同じ解析結果から常に同じstore_keyになる。
- マップ解析済みのstore_keyは編集不可。GoogleマップURLを削除して保存すると解析情報を消し、次回カード情報変更を開いたときstore_key編集を再許可。

## v0.1.56
- 店舗カード長押しメニューは「カード情報変更」「カード削除」のみに固定し、「カード内商品リスト」を完全に除外。通常の店舗カード内「商品リスト」ボタンは維持。
- 店舗別商品リストの題字表記を「<店舗名> / 商品リスト」に統一。
- カード追加／カード情報変更の下部操作をAndroid標準AlertDialogボタンからカスタム操作列へ変更。左端に「マップ解析」、右端詰めで「キャンセル」「追加/変更」を配置。
- マップ自動解析、解析済みボタン状態、緑チェック、緯度経度保存、決定的store_key生成・解析中の編集ロックはv0.1.55仕様を維持。

## v0.1.57
- Googleマップ解析の診断ログを `MAP_PARSE_START/HOP/REDIRECT/HTML_REDIRECT/COORDINATES/NO_COORDINATES/ERROR/OK` まで段階化。
- Google Maps短縮URLのHTTPリダイレクトに加え、HTML内canonical / og:url / meta refresh / JavaScript location遷移も追跡。
- Google MapsページのHTML/JSONエスケープを展開して座標を探索し、URL・本文の双方から緯度経度を取得。
- 既存カードにGoogleマップURLが保存済みで未解析の場合、カード情報変更ダイアログを開いた時点で自動解析を開始。
- 手動「マップ解析」は常に強制再解析として動作。

## v0.1.58
- Googleマップ短縮URLの実機検証用として、解析工程の診断ログを含むビルドをリリース。
- 入力URL、HTTP/HTMLリダイレクト、座標抽出、最終URL、生成store_key、成功/失敗理由を診断ログで追跡可能。
- v0.1.57までのマップ自動解析、解析済み表示、緑チェック、決定的store_key生成・ロック仕様を維持。


## v0.1.59
- Google Maps place pages that omit `!3d/!4d` and `@lat,lng` are now parsed from `APP_INITIALIZATION_STATE` in the downloaded HTML.
- The parser reads the initialization-state center as longitude/latitude only inside the tightly scoped initialization block, avoiding arbitrary coordinate pairs elsewhere in the Maps shell.
- Google feature identity (`!1s` feature id, `ftid`, CID, Place-id segment, or kgmid) is extracted when available and used as the primary deterministic `store_key` seed.
- `store_key` therefore remains stable across repeated analysis of the same Google place even when URL formatting or viewport coordinates vary; coordinates remain the fallback seed.
- Added `MAP_PARSE_IDENTITY` and `MAP_PARSE_COORDINATES source=app_init` diagnostics for real-device verification.

## v0.1.60
- Google Maps登録店舗identityの特定を解析成功条件に変更。座標取得は任意。
- `feature:0x...:0x...` 等をURLから取得できた時点で解析を完了し、identityだけから決定的 `store_key` を生成。
- 緯度経度がnullでも解析済み状態・store_keyロック・カードの解析済みチェックを維持。
- 未解析URL保存やURL削除後は解析済みフラグを落とし、次回編集時にstore_keyを再編集可能。


## v0.1.61
- 上記 Changes と同一。Googleマップidentity由来store_keyの決定性と、認証後store_key固定を共有基盤の不変仕様として強化。

## v0.1.62
- アプリ内の主要サーフェス／アクセント色を最新Nカラーへ統一。
- 非Nアクセントだったダークオレンジとグリーンを廃止し、解析状態・チェック表示もNカラーで統一。
- v0.1.61までのGoogleマップidentity由来store_key固定、タグ選択統一、保存時のみタグ確定の仕様はそのまま維持。


## v0.1.63
- ユーザー指定の最新N配色を正本として焼き直し。D.Gray `#252020` / Gray `#454040` / L.Gray `#656060` / L.Red `#662211` / D.Orange `#553300` / White `#A9A999` を反映。
- Java定数、`colors.xml`、Nトグル、ランチャーアイコン、原寸画像ビュー背景から旧色・非N色を除去。
- Googleマップidentity由来の決定的store_key生成・認証後固定、タグ選択／保存仕様などv0.1.62の機能ロジックは変更なし。


## v0.1.64
- 通常テキストを純白 `#FFFFFF` に復帰。非テキストUIはN White `#A9A999`を維持。
- 解析済み／取得済みチェックバッジを専用グリーン `#225533` に変更。
- store_key固定・Googleマップidentity解析など共有基盤は変更なし。


## v0.1.65
- 入力エラー表示のテーマ色を N Red `#441100` に変更。
- v0.1.64の配色役割分離とチェック専用グリーン `#225533`、store_key共有基盤は維持。


## v0.1.66
- 商品選択時の一覧全再描画を廃止し、行背景・件数・操作ボタンだけをインプレース更新してスクロールのガタつきを抑制。
- 入力エラー表示をアプリ側で描画し、エラーアクセントを `#441100` に固定。
- Googleマップidentity解析、認証後store_key固定、N配色の役割分離は維持。


## v0.1.67
- チェック丸 `#227733` / チェック線 `#FFFFFF`。
- 入力エラーアクセントを N Light Red `#662211`。
- タグ／全商品リストの丸ボタン外径は維持し、内部絵柄のみ88%へ縮小。


## v0.1.68
- 編集不可の `store_key` 欄を N Gray `#454040` 背景＋N White `#A9A999` 文字でグレーアウト。
- 固定済み `store_key` の決定性・Googleマップidentity解析ロジックは変更なし。
