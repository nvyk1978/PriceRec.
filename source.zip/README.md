# Price Rec. v0.1.18

- versionCode 19
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.17
- Image multi-select highlight uses the N light-blue selection color; straight-line check remains.
- Product list default columns are `商品名 / 価格 / 店舗 / 容量 / タグ / 日付`.
- Store-scoped product lists keep `店舗` as the final column.
- `比較` column was removed. A magnifier icon now lives at the right edge of the product-name cell and opens same-product price comparison.
- Product-name body text is one step smaller and its column is narrower; header text size is unchanged.
- Column headers except fixed fields can be reordered by long-press then horizontal drag; order is persisted.
- Price cells append `込` for tax-included and `抜` for tax-excluded when `price_type` makes that explicit.
- ChatGPT CSV prompt now asks `price_type` to be `税込` / `税抜` only when readable.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.


## v0.1.18
- Narrowed the 店舗 column.
- Reduced the visual size of the product comparison magnifier while preserving its tap area.
- Removed the `PRICE REC.` title from the main overflow menu dialog.
