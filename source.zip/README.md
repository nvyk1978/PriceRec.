# Price Rec. v0.1.53

Version: 0.1.53
VersionCode: 54

## Changes
- Added a 48dp circular document icon beside the global tag-management icon. The document glyph is drawn directly with Canvas from the supplied stacked-document reference, so no bitmap asset is embedded.
- Tapping the new document icon opens `全商品リスト`.
- Removed `全商品リスト表示` from the overflow menu and added `全CSV一覧`; CSV import and diagnostic log remain there.
- Renamed store-card `リスト` controls to `商品リスト`.
- Changed the unsaved/default volume-column width to 80dp. A user-saved width still takes priority.
- Existing global column-order/width persistence, tag workflows, common layout rules, stable package id, and stable signing key are retained.
