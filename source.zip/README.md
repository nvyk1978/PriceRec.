# Price Rec. v0.1.51

Version: 0.1.51
VersionCode: 52

## Changes
- Added a dedicated `タグ追加` dialog for the `＋` action used by inline tag controls in single-photo/product editing flows. It reuses the Tag Manager layout and behavior rather than opening the global Tag Manager.
- `タグ追加` retains tag creation, deletion, rename, and drag sorting. Its footer keeps `削除` on the left and adds `キャンセル` immediately to the left of dark-blue `OK`.
- Tags selected inside `タグ追加` are applied only when `OK` is pressed; `キャンセル` or outside dismissal does not apply the pending assignment. Existing assigned tags are preserved and the selected tags are added to them.
- The global top-level `タグ管理` dialog remains management-only and is unchanged.
- Inline tag controls refresh after add/rename/delete/sort while retaining their horizontal scroll position.
- Existing global unique tag-name validation and the warning `重複したタグ名は作成できません` are retained.
- Existing v0.1.50 tag selection/manager behaviors, common UI margin rules, product-list column settings, stable package id, and stable signing key are retained.
