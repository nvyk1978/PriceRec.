# PRICE REC. v0.1.1

Private Android price-recording app scaffold.

## v0.1.1
- Fixed the dialog text-input rendering bug: custom 48dp input field, vertical centering, custom outline, no Android default underline.
- Store list can be reordered by long-press + drag. Order is stored in SQLite and survives restart.
- Store rename/delete moved to the `⋮` menu so long-press is reserved for reordering.
- Tag manager now has a `☰` drag handle on the left of each tag. Long-press the handle and drag to reorder.
- Tag order is stored and immediately used by shooting/import tag selectors and later tag lists.
- Existing images can be added from the device with `画像追加`; multi-select is supported.
- Imported images keep a persisted read permission and are referenced without deleting the user's original file.
- Deleting an imported image from Price Rec. removes only the registration; camera images created by Price Rec. are deleted from MediaStore as before.
- Database migration v1 -> v2 keeps existing stores, tags, photos and adds persistent ordering / image-origin metadata.

## Existing functions
- Register / rename / delete stores.
- Expand a store before shooting.
- Global user-managed tags. Defaults: 酒 / 肉 / 調味料.
- Add and delete tags.
- Select a tag before shooting/importing; the selected tag is retained per store.
- Shoot through the device camera and save to `Pictures/PriceRec/<store>` using MediaStore.
- Store-specific image roll.
- Tap an image to change its tag later or remove/delete it.
- Store list tab and cross-store search skeleton ready for OCR product data.
- SQLite schema includes `products` for later OCR/name/price storage.
- Long-press `PRICE REC.` to view/copy a diagnostic log.

## Build / update install
- applicationId: `com.pricerec.app`
- versionName: `0.1.1`
- versionCode: `2`
- target/compile SDK: 36
- min SDK: 29
- `app/pricerec-debug.jks` is intentionally bundled so GitHub builds keep the same signing key and can overwrite-install v0.1.0 and future APKs.
- Keep the same applicationId and keystore, and increment versionCode for each next build.

The bundled key is for this private-development workflow only, not for public Play Store distribution.
