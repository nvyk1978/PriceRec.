# Price Rec. v0.1.29

- versionCode 30
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.29
- Added a main-header tag-management icon to the left of the three-dot menu. It uses a gray circular background and a custom Canvas/Path-rendered white mirrored tag/bookmark glyph; tapping opens Tag Management.
- Removed tag chips and the tag `+` button from store cards. Tag management is now available from the new main-header icon.
- Photos now support multiple tags through a new `photo_tags` many-to-many relation (DB v12). Existing single photo tags migrate automatically.
- Photo detail and multi-photo tag editing now allow multiple tag chips to stay selected simultaneously and persist all selected photo tags.
- Added an add-confirmation step after both camera capture and Photo Picker import. Images are not registered until `画像追加` is pressed.
- Multi-image confirmation shows all selected images as thumbnails, defaults all to selected, lets each thumbnail be toggled, and keeps the image area independently scrollable when there are many images.
- Confirmation uses the common multi-select tag UI and registers only the still-selected images.
- Added a thumbnail-sized gap between the image and the light-blue selected text area while preserving equal widths and matching corner radii.

## Carried forward
- Store N toggle uses the FinderlessCamera v0.1.92-style custom control. ON is orange `#775500`; OFF is white. OFF card-name grayout, edit lock, and search exclusion remain unchanged.
- Draggable fast-scroll thumbs keep the same visible size while gripped; only color changes, with a widened transparent hit area.
- Full/card product lists use common horizontal chip filters; full list supports `全カード` plus multi-store selection.
- Products support multiple tags via `product_tags`.
- Photo thumbnails are square, three columns wide, and left-aligned.
- Photo selection controls are `キャンセル / 削除 / 共有 / タグ編集`.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
