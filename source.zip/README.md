# Price Rec. v0.1.52

Version: 0.1.52
VersionCode: 53

## Changes
- `タグ追加` now opens with the tags already assigned to the current image/product preselected.
- The same preselection applies to inline `＋` entry points used by the single-photo dialog and product editing/list flows that use the common tag area.
- Pressing `OK` writes back the complete pending selection, so deselecting an existing tag removes it from the current assignment; `キャンセル` or outside dismissal leaves the assignment unchanged.
- Tag creation, deletion, rename, sorting, unique-name validation, and horizontal-scroll retention inside `タグ追加` are retained from v0.1.51.
- The global `タグ管理` dialog remains management-only.
- Existing common UI margin rules, product-list column settings, stable package id, and stable signing key are retained.
