# Price Rec. v0.1.7

OCR中心の構成から、画像をChatGPTへ共有して解析する運用へ移行。

## 今回
- 店舗カード内に「ChatGPT共有」を追加
- 現在選択中のタグに属する店舗画像をまとめて共有
- 画像詳細から1枚だけChatGPT共有も可能
- 共有時に店舗名・タグ・画像登録日時・CSV列仕様を含む解析指示文を自動付与
- 同じ解析指示文をクリップボードにも自動コピー
- ChatGPTアプリが共有を受けられる場合は直接共有、難しい場合はAndroid共有シートへフォールバック
- 撮影/画像追加後の自動OCRを停止
- 画像詳細の「OCR結果 / OCR再解析」を「商品入力 / ChatGPT共有」へ置換
- ML Kit OCR依存を削除
- 既存の商品データはそのまま保持し、手動編集可能

## Build
- versionName: 0.1.7
- versionCode: 8
- applicationId / signing key は従来版を維持
- source.zip をリポジトリ直下へ配置
- .github/workflows/pricerec-build.yml を使用
- workflow_dispatch なし、pushで自動ビルド
