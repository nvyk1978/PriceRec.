# Price Rec. v0.1.11

- versionCode 12
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.11
- Store-card expand/collapse now has a short, lightweight animation. It only runs for the actual card tap, not every list refresh.
- Tag Manager was rebuilt around rounded tag cards with aligned grip/name/delete controls and stronger drag feedback: haptic start, whole-card drag shadow, lift/scale/alpha feedback, target reaction, and drop settling.
- Store `⋮` now includes `リスト一覧`; destructive list operations are not placed directly in the store menu.
- Store list and `全リスト` both support one unified product-management interaction: normal tap edits one product, long-press enters continuous multi-select, and multi-select is for `タグ移動` / `キャンセル` only. Bulk delete was removed from selection mode.
- Product edit now includes a changeable `店舗` field, tag selection with `＋ 新しいタグ`, single-product delete as the left-side dialog text action with confirmation, and direct same-product cross-store price comparison.
- Product store assignment is now stored per product (DB v6), so changing one product's store does not retag/reassign every product from the same source photo.
- Product lists include a direct `比較` cell for one-tap same-product price comparison across stores.
- `全リスト` and store `リスト一覧` now have store/tag/product-name filters and immediate refresh after edits or tag moves.
- CSV imports are recorded as import batches with internal batch IDs, actual import time, source CSV filename, added/updated counts, and per-row rollback data.
- `取込履歴` is available from both each store's list and `全リスト`. A selected imported list can be deleted later: newly added rows are removed, updated rows are restored to their pre-import values, while stores/tags/source images remain.
- Existing pre-v0.1.11 CSV-derived rows with `source_image` are migrated into legacy minute-based import batches so earlier imported lists can also be managed from history where possible.
- ChatGPT share prompt now requests a timestamped CSV name in the form `PriceRec_yyyyMMdd_HHmmss.csv` instead of a fixed `PriceRec_import.csv` name.
- Added diagnostic logs for store expand/collapse, stronger tag dragging, product edit/delete/store reassignment, CSV batch creation/import, and batch rollback.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
