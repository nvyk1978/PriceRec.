# Price Rec. v0.1.47

Version: 0.1.47
VersionCode: 48

## Changes
- Text-link buttons now separate visible text positioning from the tap slot: glyph-shifting horizontal padding is removed, left/right edge links are anchored to the shared content edge, while the existing larger clickable slot is retained. This applies to custom links such as `全て表示` / `閉じる` / CSV links / diagnostic links and system dialog text buttons.
- Dialog chrome is normalized globally: standard dialog titles use the same left/right content margin, title-top spacing is unified, and system button areas use the same edge margin. The diagnostic-log title top margin follows the same rule.
- Product editor and single-photo editor now have a larger bottom inset below the four capsule buttons, matched to the common dialog title-top edge spacing.
- Product-column headers: tap any column to show its current width in dp and edit/save it; `初期値` restores that column default. Width values are stored globally and persist across app restarts/updates.
- Product-column order is now one global persistent setting shared by store-specific and all-product lists. Structurally fixed columns remain fixed (product name first; store column stays fixed in the store-specific list) while movable columns inherit the same saved global order.
- Column reorder interaction now brightens the full long-pressed header cell and animates the dragged item plus displaced neighboring columns into their new positions before saving.
- Capacity/volume column default width is reduced from 95dp to 80dp.
- Wrapped list/table text that becomes two or more lines is top-aligned; single-line values remain vertically centered.
- Product editor volume field hint changes from `数字のみ` to `容量` while numeric-only input remains enforced.
- Product editor store selector displays only the store name; the `店舗:` prefix is removed, including after store changes.
- Tag-manager delete control keeps the dark-red circle and geometrically centered white ×, with the × visual size reduced by 70% from v0.1.46.
- Existing shared margins/spacing, scrollbar behavior, image/reference lifecycle, selection behavior, ml normalization, prompt-only recognition, stable package id and stable signing key are retained.
