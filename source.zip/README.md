# Price Rec. v0.1.22

- versionCode 23
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.22
- Unified text-entry fields to the capsule style, including new-tag, store-name, product-edit, and product-name search inputs.
- Store-name input is slightly narrower than other text fields.
- New-store dialog keeps an already-open IME in place and moves focus without intentionally hiding/reopening the keyboard.
- Product editor price type is now a fixed choice: 税抜 / 税込 / 不明.
- Product editor volume is labeled 容量（ml） and accepts digits only.
- CSV history now stores an extraction-quality score and original CSV row count, and shows 良好 / 普通 / 粗悪 before the count.
- Product-list selection actions use a fixed-height action slot and preserve scroll position to eliminate layout jumps when switching to 削除 / タグ移動 / キャンセル.
- Photo detail no longer has 商品入力. It now has 商品リスト, opening only products imported from that image with the same edit/select/tag-move/delete/compare/list-column behavior as normal product lists.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
