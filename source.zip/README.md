# Price Rec. v0.1.46

Version: 0.1.46
VersionCode: 47

## Changes
- Applies the shared UI layout rule across Price Rec. app-owned screens, cards and custom dialogs: parent-level content margins are centralized and competing per-widget horizontal offsets are removed where they caused visible edge drift.
- Shared layout constants now define screen margin, card content margin, dialog content margin, standard/tight vertical spacing and action-button gaps.
- Product editor fields, tag area and the four bottom capsule buttons now use one identical horizontal content edge; the action row no longer extends outside the form.
- Card photo selection footer aligns `N枚選択` to the left content edge and `全て表示` to the right content edge; the full-photo dialog and product-list footer use the same mirrored edge rule for selection count / `閉じる`.
- Dialog custom content for tag editing/management, photo detail/original view, image-add confirmation, OCR/CSV import, product lists, import history/detail, product editor, multi-product dialogs and diagnostic log uses the shared dialog content margin and a reduced set of vertical spacing values.
- Main header and store cards use parent-level shared margins; store card header/detail content now share the same horizontal baseline.
- Tag-manager delete control now draws the dark-red circle and white × directly on Canvas. The × is geometrically centered on the circle instead of relying on a font baseline, while keeping the existing visual size.
- Backgroundless text-link typography/color, scrollbar auto-fade, card performance/reorder fixes, reference-image behavior, ml normalization and prompt-only recognition remain unchanged from v0.1.45.
