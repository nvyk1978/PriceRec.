# Price Rec. v0.1.38

Experimental OCR + visual-recognition share pipeline.

Changes from v0.1.37:
- Sharing selected photos now prepares analysis data on a worker thread.
- Bundled ML Kit Latin + Japanese OCR runs locally on an enhanced copy of each selected image.
- Each original image is followed by an automatically generated analysis copy (adaptive upscale, contrast lift, mild sharpening).
- ChatGPT share prompt now explicitly combines OCR evidence with label/logo/package visual recognition.
- Blurred/crushed text may be conservatively reconstructed only when multiple visual cues converge.
- Prices remain strict: never infer from product identity or market knowledge; leave blank if digits stay ambiguous.
- Enhanced attachments map back to the original `photo_<id>` and must not create duplicate rows.
- Diagnostic log adds SHARE_ANALYSIS / SHARE_OCR / SHARE_ENHANCE timing and failure events.

Build identity:
- applicationId: com.pricerec.app
- versionName: 0.1.38
- versionCode: 39
- stable debug keystore retained for overwrite installation.
