# Price Rec. v0.1.35

- versionCode 35
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`


## v0.1.35
- アプリ内撮影はMediaStore仮URIへの直接書き込みをやめ、Price Rec.専用一時JPEGへ撮影して、追加確認で確定した時だけMediaStoreへ正式保存する方式へ変更。
- 撮影キャンセル時は一時ファイルを削除し、正式保存成功後にだけDBへ登録する。横向き撮影も元JPEGを再圧縮せずコピーし、EXIF Orientationを保持する。
- 店舗カード画像選択時の「○枚選択」は「全て表示」と同じフッター行の左側へ移動。「全て表示」は右側のダイアログ操作風位置へ配置。
- 画像追加確認の税区分Nトグルは右寄せ、テキストは左、ON色はオレンジ。テキストとトグルは縦センター揃え。
- 税区分はデフォルトON＝「表示なしは税抜」、OFF＝「表示なしは税込」を維持。

## v0.1.32
- Store cards now have a persistent internal `store_key`. New keys use the human-readable `str.` prefix format and can be edited from the Card Name Change dialog without tying the key to the visible card name.
- Card Name Change now has clearer vertical spacing between the title area and its input fields, and exposes both card name and `store_key`.
- New product keys are normalized to the `prd.` prefix format. Japanese/full-width text is allowed after the prefix; comparison uses exact full-string matching, so periods inside product names do not change key semantics.
- CSV share prompt now explicitly requests `prd.` keys and only uses `.001`, `.002`, ... when different products would otherwise collide on the same key.
- Import/edit logic adds the same three-digit collision suffix only when a different product in the same store would reuse an existing key; ordinary duplicate observations keep the same key.
- Store-card photo area is now a fixed 3-column x 2-row (6-thumbnail) viewport. More photos scroll vertically inside that photo area instead of continuously expanding the card.
- The `全て表示` action area is taller and easier to tap.
- `全て表示` now supports long-press photo selection directly inside the full-image dialog. Selection uses the same `キャンセル / 削除 / 共有 / タグ編集` controls and ends automatically when the last selected image is cleared or when the dialog is canceled/closed.

## Carried forward
- Photo thumbnails remain square, three columns wide, left-aligned, and use the reduced corner radius.
- Selected photo text bands remain light blue with the same width/corner radius as the thumbnail and a small gap between image and band.
- Photos and products support multiple tags.
- Store N toggle uses the custom FinderlessCamera-style control; ON is orange and OFF is white. OFF cards remain read-only and excluded from product search.
- Draggable fast-scroll thumbs keep a fixed visible size while the transparent grip area is wider.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
