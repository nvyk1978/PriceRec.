# PRICE REC. v0.1.2

Private Android price-recording app scaffold.

## v0.1.2
- Store-card triangle/arrow indicator removed.
- Store reordering no longer starts from a long-press on the whole card. Each store now has a `☰` handle on the left; long-press/drag the handle to reorder.
- The `☰ を長押しして…` explanatory line was removed from tag management.
- The title row now has a `⋮` app menu; it currently contains Diagnostic Log.
- Alert/dialog subwindows are rendered as rounded squares with the PriceRec dark palette.
- Existing-image import now uses AndroidX Photo Picker multi-select. On supported Android versions this opens the system Photo Picker; AndroidX falls back to the document picker on unsupported devices.
- Selected imported-image URI access is persisted when possible.
- Existing v0.1.1 store/tag/photo data is kept; database schema is unchanged.

## Existing functions
- Register / rename / delete stores.
- Expand/collapse a store by tapping its card header.
- Reorder stores with the left `☰` handle; order survives restart.
- Global user-managed tags. Defaults: 酒 / 肉 / 調味料.
- Add/delete/reorder tags; tag order is reflected in tag selectors.
- Select a tag before shooting/importing; selected tag is retained per store.
- Shoot through the device camera and save to `Pictures/PriceRec/<store>` using MediaStore.
- Add existing images from the device with multi-select.
- Store-specific image roll.
- Tap an image to change its tag later or remove/delete it.
- Store list tab and cross-store search skeleton ready for OCR product data.
- SQLite schema includes `products` for later OCR/name/price storage.
- `PRICE REC.` title-row `⋮` > `診断ログ` to view/copy the diagnostic log.

## Build / update install
- applicationId: `com.pricerec.app`
- versionName: `0.1.2`
- versionCode: `3`
- target/compile SDK: 36
- min SDK: 29
- `app/pricerec-debug.jks` remains bundled so GitHub builds keep the same signing key and can overwrite-install v0.1.0/v0.1.1 and later APKs.
- Keep the same applicationId and keystore, and increment versionCode for each next build.

The bundled key is for this private-development workflow only, not for public Play Store distribution.
