# Price Rec. v0.1.21

- versionCode 22
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.21
- Search-candidate chip reordering now uses a smooth provisional slide animation; order is saved only when the finger is released.
- Inline product-tag chip reordering uses the same provisional drag behavior and commits only on release.
- Tag-management grip dragging no longer jumps diagonally: the dragged card keeps its X position fixed and follows only the Y axis.
- Tag-management surrounding cards slide smoothly to preview the pending order; the database order is committed only on release.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
