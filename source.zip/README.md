# Price Rec. v0.1.26

- versionCode 27
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.26
- Product tags now support multiple tags per product using a many-to-many `product_tags` relation. Existing single-tag data is migrated automatically.
- Product edit and bulk tag editing use the same horizontal chip + fixed right-side `＋` tag UI as the store card tag row.
- Photo detail / selected-photo tag editing also use the same common tag UI, and selected tags are reflected immediately by chip color.
- Product lists display multiple tags together and tag filters match any assigned tag.
- Photo thumbnails now use one fixed size everywhere and remain left-aligned instead of stretching to fill each row.
- Thumbnail corner radius is reduced another step; the selected-photo light-blue text area keeps the exact same width and radius as the thumbnail.

## v0.1.25 carried forward
- Main product-name search field hint is `商品名検索`.
- Tapping outside a focused input clears focus/cursor and hides the IME naturally.
- Diagnostic log, product lists, CSV lists/content, and long photo lists use a draggable vertical fast-scroll thumb.
- Store-card long-press menu labels are `カード内商品リスト`, `カード名変更`, and `カード削除`.
- Main menu label is `全商品リスト表示`.
- Every store card has a persistent N toggle in the header, available even while collapsed. ON uses orange `#775500`; OFF uses dark orange `#553300`.
- N-toggle OFF puts that store into read-only mode and excludes its products from global product search/list/comparison results.
- Photo-selection controls are `キャンセル / 削除 / 共有 / タグ編集`; delete uses dark red.
- Photo-selection mode exits when tapping outside the selected store card or when the last selected photo is deselected.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
