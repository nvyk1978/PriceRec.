# Price Rec. v0.1.8

- versionCode 9 / versionName 0.1.8
- applicationId / signing key are unchanged for overwrite install.
- source archive name is always `source.zip`.

## v0.1.8
- Camera-roll share selection mode: choose multiple stored images before ChatGPT share.
- Original image resolution/quality is unchanged during sharing.
- Share diagnostics: URI, dimensions, byte size, preparation time, clipboard, direct ChatGPT/chooser path, Intent launch timing and errors.
- ChatGPT prompt uses stable `source_image=photo_<id>` values and stores the last image_N -> photo ID mapping for compatibility.
- CSV import from PRICE REC. app menu.
- CSV import by opening supported CSV MIME types with Price Rec.
- UTF-8/RFC4180-style CSV parsing with quoted commas/newlines and BOM handling.
- Import preview table with new/duplicate/price-change detection.
- Per-row action can be switched between Add / Update / Skip before import.
- CSV columns: store,tag,product_name,product_key,price,volume,price_type,captured_at,source_image.
- New stores/tags are created on confirmed import when needed.
- `photo_<id>` rows link back to the original stored image; legacy `image_N` is resolved using the last share mapping when possible.
- Imported product metadata retains product_key, volume, price_type and source_image.
