# Price Rec. v0.1.63

Version: 0.1.63
VersionCode: 64

## Changes
- Price Rec.全体の配色を最新N配色の正本値へ統一（BG `#303030` / D.Gray `#252020` / Gray `#454040` / L.Gray `#656060` / Blue `#223355` / L.Blue `#445577` / Red `#441100` / L.Red `#662211` / Orange `#775500` / D.Orange `#553300` / White `#A9A999`）。
- ダークオレンジ `#553300` をN配色の正式色として復帰。Googleマップ解析ボタンは既存どおりN Orange `#775500`を使用。
- 旧グリーン `#2E7D32` を廃止し、解析済み／取得済みチェックの塗りをN L.Blueへ統一。白チェックは維持。
- NトグルのtrackをD.Gray `#252020`へ同期し、OFF thumbをN White `#A9A999`へ統一。
- Googleマップ解析済み店舗カードのチェックを店舗名の右端へ移動。
- Googleマップ解析中は「マップ解析」ボタンの中央に回転シークサークルを表示し、処理中であることを明示。
- Googleマップ登録店舗identity（feature id / ftid / CID / Place-id segment / kgmid）→SHA-256の決定的 `str.map.<20hex>` 生成を維持。同一identityはユーザー・端末・時刻に依存せず同一store_keyになる。
- 一度 `str.map.*` が確定した店舗カードはstore_keyを永久ロック扱いに変更。GoogleマップURLの再解析・編集・削除、店舗名変更、再起動でもstore_keyを勝手に再生成しない。
- 「タグ追加」「タグ選択」のダイアログを、作成・削除・リネーム・グリップ並べ替え・複数選択を持つ単一の「タグ選択」仕様へ統一。
- タグ長押しで名前編集へ入る際は一時的に選択解除しても、編集画面を閉じた時点で長押し前の選択状態を復元。並べ替えでも選択状態を保持。
- タグ選択ダイアログのキャンセル／外側閉じでは割当変更を確定せず、開く前の選択状態を維持。OK時のみ割当を反映。
- 画像単体ダイアログの下部操作を「削除 / 共有 / 商品リスト / 保存」に変更。「商品リスト」はライトブルー、「保存」はダークブルー。
- 画像単体ダイアログのタグ変更はローカル保留とし、「保存」を押した場合だけDBへ反映。共有・商品リスト・戻る／外側閉じではタグ変更を破棄。
- 商品編集側のタグ変更も従来どおりローカル保留を維持し、「保存」時だけDBへ反映することを確認。
- 非N色の純白 `#FFFFFF`、旧secondary `#C9C4C4`、画像ビュー背景の純黒を除去し、N White / N BGへ統一。

## v0.1.55
- 店舗カード長押しメニューから「カード内商品リスト」を削除。
- GoogleマップURLをバックグラウンドで自動解析。短縮URLは内部で展開し、入力欄の文字列は書き換えない。
- カード情報変更／カード追加に「マップ解析」ボタンを追加。解析成功時は「解析済」（ダークオレンジ＋黒文字）。
- 解析済み店舗カードは題字左にCSV取得済みと同型の緑チェックを表示。
- Googleマップ解析結果として展開済みURL・緯度・経度をDBに保存（DB v17）。
- マップ解析成功時は緯度経度を正規化してSHA-256から決定的な `str.map.<20hex>` を生成。同じ解析結果から常に同じstore_keyになる。
- マップ解析済みのstore_keyは編集不可。GoogleマップURLを削除して保存すると解析情報を消し、次回カード情報変更を開いたときstore_key編集を再許可。

## v0.1.56
- 店舗カード長押しメニューは「カード情報変更」「カード削除」のみに固定し、「カード内商品リスト」を完全に除外。通常の店舗カード内「商品リスト」ボタンは維持。
- 店舗別商品リストの題字表記を「<店舗名> / 商品リスト」に統一。
- カード追加／カード情報変更の下部操作をAndroid標準AlertDialogボタンからカスタム操作列へ変更。左端に「マップ解析」、右端詰めで「キャンセル」「追加/変更」を配置。
- マップ自動解析、解析済みボタン状態、緑チェック、緯度経度保存、決定的store_key生成・解析中の編集ロックはv0.1.55仕様を維持。

## v0.1.57
- Googleマップ解析の診断ログを `MAP_PARSE_START/HOP/REDIRECT/HTML_REDIRECT/COORDINATES/NO_COORDINATES/ERROR/OK` まで段階化。
- Google Maps短縮URLのHTTPリダイレクトに加え、HTML内canonical / og:url / meta refresh / JavaScript location遷移も追跡。
- Google MapsページのHTML/JSONエスケープを展開して座標を探索し、URL・本文の双方から緯度経度を取得。
- 既存カードにGoogleマップURLが保存済みで未解析の場合、カード情報変更ダイアログを開いた時点で自動解析を開始。
- 手動「マップ解析」は常に強制再解析として動作。

## v0.1.58
- Googleマップ短縮URLの実機検証用として、解析工程の診断ログを含むビルドをリリース。
- 入力URL、HTTP/HTMLリダイレクト、座標抽出、最終URL、生成store_key、成功/失敗理由を診断ログで追跡可能。
- v0.1.57までのマップ自動解析、解析済み表示、緑チェック、決定的store_key生成・ロック仕様を維持。


## v0.1.59
- Google Maps place pages that omit `!3d/!4d` and `@lat,lng` are now parsed from `APP_INITIALIZATION_STATE` in the downloaded HTML.
- The parser reads the initialization-state center as longitude/latitude only inside the tightly scoped initialization block, avoiding arbitrary coordinate pairs elsewhere in the Maps shell.
- Google feature identity (`!1s` feature id, `ftid`, CID, Place-id segment, or kgmid) is extracted when available and used as the primary deterministic `store_key` seed.
- `store_key` therefore remains stable across repeated analysis of the same Google place even when URL formatting or viewport coordinates vary; coordinates remain the fallback seed.
- Added `MAP_PARSE_IDENTITY` and `MAP_PARSE_COORDINATES source=app_init` diagnostics for real-device verification.

## v0.1.60
- Google Maps登録店舗identityの特定を解析成功条件に変更。座標取得は任意。
- `feature:0x...:0x...` 等をURLから取得できた時点で解析を完了し、identityだけから決定的 `store_key` を生成。
- 緯度経度がnullでも解析済み状態・store_keyロック・カードの解析済みチェックを維持。
- 未解析URL保存やURL削除後は解析済みフラグを落とし、次回編集時にstore_keyを再編集可能。


## v0.1.61
- 上記 Changes と同一。Googleマップidentity由来store_keyの決定性と、認証後store_key固定を共有基盤の不変仕様として強化。

## v0.1.62
- アプリ内の主要サーフェス／アクセント色を最新Nカラーへ統一。
- 非Nアクセントだったダークオレンジとグリーンを廃止し、解析状態・チェック表示もNカラーで統一。
- v0.1.61までのGoogleマップidentity由来store_key固定、タグ選択統一、保存時のみタグ確定の仕様はそのまま維持。


## v0.1.63
- ユーザー指定の最新N配色を正本として焼き直し。D.Gray `#252020` / Gray `#454040` / L.Gray `#656060` / L.Red `#662211` / D.Orange `#553300` / White `#A9A999` を反映。
- Java定数、`colors.xml`、Nトグル、ランチャーアイコン、原寸画像ビュー背景から旧色・非N色を除去。
- Googleマップidentity由来の決定的store_key生成・認証後固定、タグ選択／保存仕様などv0.1.62の機能ロジックは変更なし。
