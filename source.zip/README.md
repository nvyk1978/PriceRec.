# Price Rec. v0.1.58

Version: 0.1.58
VersionCode: 59

## Changes
- Renamed the store-card menu action `カード名変更` to `カード情報変更`.
- Added an optional `GoogleマップURL` field to both new-store creation and existing-card information editing.
- Persisted the map URL in the stores table with a DB v16 migration; existing stores remain valid with an empty URL.
- Google Maps URL is stored only as card metadata for now; no Google API, billing, automatic lookup, or identity matching is introduced yet.
- Hardened GitHub Actions artifact delivery: the APK artifact now contains only the APK, upload is retried automatically on a stalled/failed first attempt, and source.zip is uploaded separately.
- Existing stable package id, signing key, global layout rules, tag workflows, and saved column preferences are retained.

## v0.1.55
- 店舗カード長押しメニューから「カード内商品リスト」を削除。
- GoogleマップURLをバックグラウンドで自動解析。短縮URLは内部で展開し、入力欄の文字列は書き換えない。
- カード情報変更／カード追加に「マップ解析」ボタンを追加。解析成功時は「解析済」（ダークオレンジ＋黒文字）。
- 解析済み店舗カードは題字左にCSV取得済みと同型の緑チェックを表示。
- Googleマップ解析結果として展開済みURL・緯度・経度をDBに保存（DB v17）。
- マップ解析成功時は緯度経度を正規化してSHA-256から決定的な `str.map.<20hex>` を生成。同じ解析結果から常に同じstore_keyになる。
- マップ解析済みのstore_keyは編集不可。GoogleマップURLを削除して保存すると解析情報を消し、次回カード情報変更を開いたときstore_key編集を再許可。

## v0.1.56
- 店舗カード長押しメニューは「カード情報変更」「カード削除」のみに固定し、「カード内商品リスト」を完全に除外。通常の店舗カード内「商品リスト」ボタンは維持。
- 店舗別商品リストの題字表記を「<店舗名> / 商品リスト」に統一。
- カード追加／カード情報変更の下部操作をAndroid標準AlertDialogボタンからカスタム操作列へ変更。左端に「マップ解析」、右端詰めで「キャンセル」「追加/変更」を配置。
- マップ自動解析、解析済みボタン状態、緑チェック、緯度経度保存、決定的store_key生成・解析中の編集ロックはv0.1.55仕様を維持。

## v0.1.57
- Googleマップ解析の診断ログを `MAP_PARSE_START/HOP/REDIRECT/HTML_REDIRECT/COORDINATES/NO_COORDINATES/ERROR/OK` まで段階化。
- Google Maps短縮URLのHTTPリダイレクトに加え、HTML内canonical / og:url / meta refresh / JavaScript location遷移も追跡。
- Google MapsページのHTML/JSONエスケープを展開して座標を探索し、URL・本文の双方から緯度経度を取得。
- 既存カードにGoogleマップURLが保存済みで未解析の場合、カード情報変更ダイアログを開いた時点で自動解析を開始。
- 手動「マップ解析」は常に強制再解析として動作。

## v0.1.58
- Googleマップ短縮URLの実機検証用として、解析工程の診断ログを含むビルドをリリース。
- 入力URL、HTTP/HTMLリダイレクト、座標抽出、最終URL、生成store_key、成功/失敗理由を診断ログで追跡可能。
- v0.1.57までのマップ自動解析、解析済み表示、緑チェック、決定的store_key生成・ロック仕様を維持。
