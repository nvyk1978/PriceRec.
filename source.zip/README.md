# Price Rec. v0.1.19

- versionCode 20
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.19
- Successful search terms are saved as reusable search chips above the search field.
- Search chips horizontally scroll when they overflow.
- Tapping a chip repeats that search.
- Long-pressing a search chip enters multi-select mode; tapping outside exits selection mode.
- A fixed light-red `削除` button appears at the right while selecting and removes only selected search-history chips.
- Store-card overflow menus were removed.
- Long-pressing a store card now opens the former store menu (`店舗全体リスト / 店舗名変更 / 店舗削除`).
- Store-card long press brightens the card and gives a short confirmation haptic before opening the menu.
- The left three-line handle remains dedicated to vertical store reordering.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
