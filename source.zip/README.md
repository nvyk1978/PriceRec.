# Price Rec. v0.1.59

Version: 0.1.59
VersionCode: 60

## Changes
- Added Google Maps `APP_INITIALIZATION_STATE` coordinate parsing for place pages whose resolved URLs omit `!3d/!4d` and `@lat,lng`.
- Added stable Google place-identity extraction (`!1s` feature id / `ftid` / CID / Place-id segment / kgmid) and use it as the primary deterministic `store_key` seed.
- Kept the original user-entered Google Maps URL unchanged while resolving short URLs only internally.
- Added `MAP_PARSE_IDENTITY` and `MAP_PARSE_COORDINATES source=app_init` diagnostics so real-device parsing can be verified from the diagnostic report.
- Existing automatic analysis, manual retry button, parsed-state UI, card green check, store-key lock/unlock behavior, signing key, package id, layout rules, and column settings are retained.

## v0.1.55
- 店舗カード長押しメニューから「カード内商品リスト」を削除。
- GoogleマップURLをバックグラウンドで自動解析。短縮URLは内部で展開し、入力欄の文字列は書き換えない。
- カード情報変更／カード追加に「マップ解析」ボタンを追加。解析成功時は「解析済」（ダークオレンジ＋黒文字）。
- 解析済み店舗カードは題字左にCSV取得済みと同型の緑チェックを表示。
- Googleマップ解析結果として展開済みURL・緯度・経度をDBに保存（DB v17）。
- マップ解析成功時は緯度経度を正規化してSHA-256から決定的な `str.map.<20hex>` を生成。同じ解析結果から常に同じstore_keyになる。
- マップ解析済みのstore_keyは編集不可。GoogleマップURLを削除して保存すると解析情報を消し、次回カード情報変更を開いたときstore_key編集を再許可。

## v0.1.56
- 店舗カード長押しメニューは「カード情報変更」「カード削除」のみに固定し、「カード内商品リスト」を完全に除外。通常の店舗カード内「商品リスト」ボタンは維持。
- 店舗別商品リストの題字表記を「<店舗名> / 商品リスト」に統一。
- カード追加／カード情報変更の下部操作をAndroid標準AlertDialogボタンからカスタム操作列へ変更。左端に「マップ解析」、右端詰めで「キャンセル」「追加/変更」を配置。
- マップ自動解析、解析済みボタン状態、緑チェック、緯度経度保存、決定的store_key生成・解析中の編集ロックはv0.1.55仕様を維持。

## v0.1.57
- Googleマップ解析の診断ログを `MAP_PARSE_START/HOP/REDIRECT/HTML_REDIRECT/COORDINATES/NO_COORDINATES/ERROR/OK` まで段階化。
- Google Maps短縮URLのHTTPリダイレクトに加え、HTML内canonical / og:url / meta refresh / JavaScript location遷移も追跡。
- Google MapsページのHTML/JSONエスケープを展開して座標を探索し、URL・本文の双方から緯度経度を取得。
- 既存カードにGoogleマップURLが保存済みで未解析の場合、カード情報変更ダイアログを開いた時点で自動解析を開始。
- 手動「マップ解析」は常に強制再解析として動作。

## v0.1.58
- Googleマップ短縮URLの実機検証用として、解析工程の診断ログを含むビルドをリリース。
- 入力URL、HTTP/HTMLリダイレクト、座標抽出、最終URL、生成store_key、成功/失敗理由を診断ログで追跡可能。
- v0.1.57までのマップ自動解析、解析済み表示、緑チェック、決定的store_key生成・ロック仕様を維持。


## v0.1.59
- Google Maps place pages that omit `!3d/!4d` and `@lat,lng` are now parsed from `APP_INITIALIZATION_STATE` in the downloaded HTML.
- The parser reads the initialization-state center as longitude/latitude only inside the tightly scoped initialization block, avoiding arbitrary coordinate pairs elsewhere in the Maps shell.
- Google feature identity (`!1s` feature id, `ftid`, CID, Place-id segment, or kgmid) is extracted when available and used as the primary deterministic `store_key` seed.
- `store_key` therefore remains stable across repeated analysis of the same Google place even when URL formatting or viewport coordinates vary; coordinates remain the fallback seed.
- Added `MAP_PARSE_IDENTITY` and `MAP_PARSE_COORDINATES source=app_init` diagnostics for real-device verification.
