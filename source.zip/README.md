# Price Rec. v0.1.16

- versionCode 17
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.12
- Store card keeps `撮影` / `画像追加` and adds direct `リスト` / `CSV一覧` actions. `ChatGPT共有` and the old `画像` tab button are removed.
- Store card always shows photo thumbnails immediately: newest first, up to 6 initially, with `選択` available from the start and `全て表示` at bottom-right for the full gallery.
- Each thumbnail is rounded and shows its Price Rec. added date/time. Photos that already have CSV-imported product data linked to them show a small green circle with a white check overlaid inside the image at the top-right.
- Tapping a thumbnail opens photo detail; tapping the image again opens an original-pixel viewer with pan/pinch zoom (double-tap resets to 1:1).
- Text input fields use the light-gray input background for consistent visual affordance.
- The `撮影タグ` heading is removed. Tag chips scroll horizontally while the round `＋` button remains fixed at the right; tapping `＋` opens Tag Manager.
- Product multi-select by long-press remains, and a visible `選択` button is available without requiring a long-press.
- CSV files can be sent to Price Rec. from Android Share as well as opened directly. Single-file CSV shares go straight to the import preview.
- CSV validation is strict before preview/import: UTF-8, exact Price Rec. header/column order, valid record shape, required `store` / `product_name`, integer-compatible `price` when present, and valid `captured_at` when present. Invalid CSV is rejected with the reason.
- Store `CSV一覧` opens that store's import batches. Tapping a batch shows its imported rows in a spreadsheet-like view and supports batch rollback/delete.
- Import-batch management remains available from the all-list view as well.
- ChatGPT share prompt continues to request timestamped filenames such as `PriceRec_yyyyMMdd_HHmmss.csv`.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.

- Build fix: corrected escaped newline literals in MainActivity.java and CsvImporter.java.

## v0.1.13
- Store menu `リスト一覧` renamed to `店舗全体リスト`; dialog title is `<店舗名> 店舗全体リスト`.
- Removed the top `選択` link beside CSV actions; list selection remains available in the list body and by long-press.
- Main `全リスト` now exposes `全CSV一覧` instead of the old import-history label.
- CSV rows open their contents by tapping the row; removed the `内容を見る` link.
- CSV-imported photo badge keeps its current size/position but uses a sharp two-line white check.

## v0.1.14
- Fixed the all-store CSV history crash caused by malformed SQL when no store filter was supplied.
- Main all-list `全CSV一覧` now uses the same CSV list UI/behavior as the store-scoped CSV list; only the scope differs.
- Store drag grip now uses a Y-axis-only visual drag: the card X position stays fixed and no longer jumps diagonally toward the finger.
- Store reorder previews are animated continuously: surrounding cards slide into the pending slot and the dragged card settles smoothly on drop.
- Store card expand/collapse now animates actual content height plus a light fade/vertical interpolation instead of reloading the whole store list, reducing layout jumps.


## v0.1.15
- Store cards now keep independent expand/collapse state. Opening another store no longer closes stores that are already open. Multiple store cards can remain expanded at the same time.
- Expanded-store state is saved/restored as a set so rotation/recreation keeps all currently open cards.
- Main `全リスト` -> `全CSV一覧` is back to the same nested/double-dialog behavior as store `店舗全体リスト` -> `CSV一覧`; the parent product-list dialog remains open underneath.
- All-store CSV history continues to use the fixed all-store query and the same row/content/rollback behavior as store-scoped CSV history.
- Removed the `原寸表示` title from the original-size image viewer while retaining pan/pinch zoom and close behavior.

## v0.1.16
- Image multi-select check mark now uses the same sharp two-line geometry as the CSV-imported status check.
- Rounded rectangular action buttons/chips are rendered as capsules; text links and icon-only controls keep their existing shapes.
- Product multi-select restores bulk `削除` to the left of `タグ移動`; deletion always asks for confirmation and keeps source images.
- Product-list columns keep `商品名` fixed at the left. Other column headers can be swiped left/right to reorder and the order is persisted. In `店舗全体リスト`, the `店舗` column is fixed at the far right.
- CSV batch action `このリストを消去` is renamed to `このCSVを消去`. A `再読み込み` text action is added on its left.
- CSV reload warns `編集したデータは削除されます` before restoring the batch from the original stored CSV content. Newly imported CSV text is retained in the database so reload remains available even if the original shared URI later becomes unavailable.
