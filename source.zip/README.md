# Price Rec. v0.1.41

Product editor reference-image update.

- Removed the "同じ商品の他店舗価格" action from the product edit screen.
- Added "参照画像を表示" in its place.
- The action opens the actual source photo linked to the product record.
- Reference-image display reuses the existing original-size image viewer, including pinch zoom, drag, black background, and Close action.
- If the product has no real source photo (for example a virtual CSV-only import), a "参照画像がありません" message is shown.
- Prompt-only recognition pipeline from v0.1.40 is unchanged: no app-side OCR and no enhanced-image generation.

Version: 0.1.41
VersionCode: 42
