# Price Rec. v0.1.3

- applicationId: `com.pricerec.app`
- versionCode: 4
- versionName: 0.1.3
- stable signing key: `app/pricerec-debug.jks`
- target / compile SDK: 36
- Java 17

## v0.1.3
- 検索欄の「検索モード」文言を削除
- Android 16 IME Insets 対応。検索欄をキーボードの上に保持
- 新規店舗「＋」を真円化
- 新規店舗ダイアログ表示時、店舗名入力へ自動フォーカス＋IME表示
- ラウンドスクエア類の外周線を廃止しフラット化
- ML Kit 日本語 OCR を実装（撮影・Photo Picker追加画像の双方を自動解析）
- OCR結果をスプレッドシート風UIで表示し、商品名・価格の手修正、行追加・削除、再解析に対応
- 店舗内商品リストを表形式化
- トップ右上 ⋮ に「全リスト表示」を追加
- 全リストは商品 / 店舗 / 価格 / タグ / 日付を全店舗横断で表示
- 検索結果も表形式で全店舗価格を表示
- 診断ログにOCR開始/結果/失敗を追加

## GitHub
`source.zip` をリポジトリ直下へ、`pricerec-build.yml` を `.github/workflows/` へ配置。
YMLは `workflow_dispatch` を持たず、push時に自動ビルドします。
