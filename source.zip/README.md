# Price Rec. v0.1.45

Version: 0.1.45
VersionCode: 46

## Changes
- Tapping the `PRICE REC.` title collapses every currently expanded store card; when no card is expanded it is a no-op.
- Top header alignment is unified: title, tag icon and overflow menu share one vertical center line; tag/menu circles are 48dp, matching the card-add circle size.
- Product editor four capsules use the full wide-dialog row with the same even outer/inner spacing as the single-photo four-button row.
- Tag-manager delete × is restored to the same 24sp size as the search-field ×, black, and centered in the existing dark-red 24dp circle.
- All backgroundless text-link actions use N light blue (#4D6B99), including dialog links, `全て表示`, `閉じる`, CSV links and comparison/add-item links.
- The card `全て表示` photo dialog is taller so the third thumbnail row including its text panel is visible on the target device.
- All native scrollbars explicitly use delayed fade; custom fast-scroll thumbs now appear during scroll/drag and fade naturally after inactivity.
- Previous v0.1.44 behavior remains: lightweight card expand/collapse, robust first/last reorder, stable photo-selection geometry, selection action layouts, reference-image relink, ml normalization, and prompt-only image recognition.
