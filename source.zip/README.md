# Price Rec. v0.1.9

- versionCode 10
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.9
- Image tab now always shows a `選択` button.
- Long-pressing a photo also enters multi-select mode and selects that photo.
- While selecting, tapping photos toggles selection, selected count is shown, and `共有 / キャンセル` are available.
- Only selected photos are sent to ChatGPT.
- Single-photo `ChatGPT共有` in the photo detail dialog remains unchanged.
- Added `SHARE_SELECT_START` source and `SHARE_SELECT_TOGGLE` diagnostic log entries.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
