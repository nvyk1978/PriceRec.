# Price Rec. v0.1.49

Version: 0.1.49
VersionCode: 50

## Changes
- Product Edit and single-photo Edit now use the same 18dp vertical spacing from the tag area to the four-button row, matching the existing 18dp inset below the four-button row.
- Original/reference-image viewing now uses the shared dialog content margins for the image viewport and a custom right-edge `閉じる` footer, so the image area and visible link align with the app-wide dialog guideline.
- Product-list initial movable column order is now `価格 → 容量 → 店舗 → タグ → 日付` after the fixed product-name anchor. Existing custom saved orders remain global and persistent; the untouched v0.1.47 auto-default is migrated once to the new default. Structurally fixed columns still keep their fixed positions in store-specific lists.
- New default column widths: 価格 90dp / 容量 70dp / 店舗 140dp / タグ 120dp / 日付 130dp. User-saved widths continue to take priority and persist globally.
- Product/table text rows can grow to the current font size for up to 3 lines. Wrapped text is top-aligned, the product-name font size is unchanged, and line 4+ is ellipsized.
- Product comparison uses the same saved/default shared dp widths (read-only in the comparison dialog). Tapping a comparison row opens Product Edit without dismissing the comparison dialog; save/delete refreshes the underlying comparison and closing Product Edit returns to it.
- CSV history, tag manager, and product comparison use a custom right-edge `閉じる` footer aligned to the shared dialog content guideline; the visible glyph position is independent of its larger tap slot.
- Product Edit and single-photo Edit increase the vertical space from tag area to the four-button row and below the row; the dialogs are allowed to grow naturally.
- Diagnostic Log moves `コピー` slightly to the right while preserving the other shared margins.
- The main store-card screen no longer shows a vertical scrollbar; scrolling remains enabled. Other useful scrollbars retain their existing auto-fade behavior.
- Tag-manager delete control keeps the 24dp dark-red circle and geometrically centered white ×; the × is corrected to 70% of its original visual size (not 30%).
- Existing text-link typography, shared content margins, selection/reorder animation, reference-image lifecycle, stable package id, and stable signing key are retained.
