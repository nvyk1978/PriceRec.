# Price Rec. v0.1.44

Version: 0.1.44
VersionCode: 44

## Changes
- Store card expand/collapse is lighter: card preview builds only the visible first six thumbnails, thumbnail decoding is asynchronous, and repeated per-frame height animation was removed.
- Store-card drag reorder now uses the whole store scroll area as the drop target, supports edge auto-scroll, and reliably maps positions above the first card / below the last card to the first / last index.
- Card photo selection keeps the same control/footer geometry before and after selection so thumbnails do not jump.
- Card photo selection count is mirrored against the right-side "全て表示" link; "全て表示" is moved farther to the right.
- The all-photos dialog uses a fixed title/action/grid/footer layout. Title→action and action→thumbnail gaps are equal, selection count stays on the same bottom line as "閉じる", and scroll position is preserved while selecting.
- The all-photos "選択" control now uses the same dark-gray capsule style/size as the card "選択" button.
- Text-link actions ("閉じる", "全て表示", CSV links, etc.) share the same typography as "全て表示".
- Product-list magnifier icon is N dark blue (#223355); selected product rows use N light blue (#4D6B99).
- "同一商品" is orange when active and uses the same 92x38dp size as "タグ移動".
- Product editor buttons are 92x38dp capsules: 削除=dark red, キャンセル=dark gray, 保存=dark blue.
- Tag manager "追加" is the same 48dp light-blue circular plus button as main card-add. Tag delete is a 24dp dark-red circle with a dark-gray ×.
- Search-field clear × is enlarged to the same 24sp size.
- Volume import/storage is normalized to ml integer values; list display is unified to "###ml". The ChatGPT share prompt now requests ml-converted integers without unit text.
- Previous reference-image missing/relink behavior and prompt-only image recognition remain in place.
