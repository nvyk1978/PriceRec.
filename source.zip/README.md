# Price Rec. v0.1.20

- versionCode 21
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.20
- Search-candidate selection-mode `削除` button is now dark red.
- Search-candidate chips can be reordered by long-press + horizontal drag; order is persisted.
- A stationary long press on a search candidate still enters the existing selection mode.
- Store-card tag chips can also be reordered directly by long-press + horizontal drag.
- Inline tag reordering persists to the shared tag sort order and is reflected in tag management.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
