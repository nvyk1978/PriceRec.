# Price Rec. v0.1.10

- versionCode 11
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.10
- Store product rows now support direct single-item editing on normal tap.
- Long-press a product row to enter multi-select mode; subsequent taps select/deselect continuously.
- Multi-select actions: `タグ移動`, `削除`, `キャンセル`.
- Bulk tag move supports existing tags, `タグなし`, and creating a new tag on the spot.
- Bulk delete requires confirmation and deletes product records only; source images are preserved.
- The same long-press multi-select/tag-move/delete interaction is available in `全リスト`.
- Product tags are now stored per product (DB v5), so moving one selected product does not retag every other product from the same source image. Existing product tags are migrated from their source-photo tag.
- Added product-selection/edit/tag-move/delete diagnostic log entries.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
