# Price Rec. v0.1.54

Version: 0.1.54
VersionCode: 55

## Changes
- Renamed the store-card menu action `カード名変更` to `カード情報変更`.
- Added an optional `GoogleマップURL` field to both new-store creation and existing-card information editing.
- Persisted the map URL in the stores table with a DB v16 migration; existing stores remain valid with an empty URL.
- Google Maps URL is stored only as card metadata for now; no Google API, billing, automatic lookup, or identity matching is introduced yet.
- Hardened GitHub Actions artifact delivery: the APK artifact now contains only the APK, upload is retried automatically on a stalled/failed first attempt, and source.zip is uploaded separately.
- Existing stable package id, signing key, global layout rules, tag workflows, and saved column preferences are retained.
