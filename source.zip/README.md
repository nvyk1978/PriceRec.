# Price Rec. v0.1.40

Share pipeline rollback / prompt-only recognition experiment.

- Removed enhanced/level-corrected image generation from sharing.
- Removed bundled ML Kit Latin/Japanese OCR and its dependencies.
- Sharing now sends only the original selected images directly to ChatGPT.
- Removed pre-share decode/OCR/enhancement/readback work to restore lightweight sharing behavior.
- Strengthened the prompt so product identification combines OCR/transcription with label/logo, typography, colors, bottle/package shape, layout, age statements and other visual cues.
- Blurred text may be conservatively reconstructed only when multiple independent visual cues agree.
- Price remains strict: never infer from product identity or market knowledge; leave ambiguous digits blank.

Version: 0.1.40
VersionCode: 41
