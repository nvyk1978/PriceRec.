# Price Rec. v0.1.13

- versionCode 14
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.12
- Store card keeps `撮影` / `画像追加` and adds direct `リスト` / `CSV一覧` actions. `ChatGPT共有` and the old `画像` tab button are removed.
- Store card always shows photo thumbnails immediately: newest first, up to 6 initially, with `選択` available from the start and `全て表示` at bottom-right for the full gallery.
- Each thumbnail is rounded and shows its Price Rec. added date/time. Photos that already have CSV-imported product data linked to them show a small green circle with a white check overlaid inside the image at the top-right.
- Tapping a thumbnail opens photo detail; tapping the image again opens an original-pixel viewer with pan/pinch zoom (double-tap resets to 1:1).
- Text input fields use the light-gray input background for consistent visual affordance.
- The `撮影タグ` heading is removed. Tag chips scroll horizontally while the round `＋` button remains fixed at the right; tapping `＋` opens Tag Manager.
- Product multi-select by long-press remains, and a visible `選択` button is available without requiring a long-press.
- CSV files can be sent to Price Rec. from Android Share as well as opened directly. Single-file CSV shares go straight to the import preview.
- CSV validation is strict before preview/import: UTF-8, exact Price Rec. header/column order, valid record shape, required `store` / `product_name`, integer-compatible `price` when present, and valid `captured_at` when present. Invalid CSV is rejected with the reason.
- Store `CSV一覧` opens that store's import batches. Tapping a batch shows its imported rows in a spreadsheet-like view and supports batch rollback/delete.
- Import-batch management remains available from the all-list view as well.
- ChatGPT share prompt continues to request timestamped filenames such as `PriceRec_yyyyMMdd_HHmmss.csv`.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.

- Build fix: corrected escaped newline literals in MainActivity.java and CsvImporter.java.

## v0.1.13
- Store menu `リスト一覧` renamed to `店舗全体リスト`; dialog title is `<店舗名> 店舗全体リスト`.
- Removed the top `選択` link beside CSV actions; list selection remains available in the list body and by long-press.
- Main `全リスト` now exposes `全CSV一覧` instead of the old import-history label.
- CSV rows open their contents by tapping the row; removed the `内容を見る` link.
- CSV-imported photo badge keeps its current size/position but uses a sharp two-line white check.
