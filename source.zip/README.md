# Price Rec. v0.1.27

- versionCode 28
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.27
- Store N toggle is rebuilt from the established FinderlessCamera v0.1.92 custom N-toggle behavior: custom-drawn 44x24dp track, 24dp OFF thumb, 26dp ON thumb, and 120ms decelerating slide animation. The track uses the current N dark gray; ON thumb uses orange `#775500`, OFF thumb uses dark orange `#553300`.
- OFF store-card names are grayed out. N toggle remains available while the card is collapsed.
- Main three-dot icon uses pure white dots on the dark-gray circular background.
- Fixed the store-specific product query by comparing the store id as INTEGER, restoring `カード内商品リスト` and related same-store lookup behavior.
- `カード内商品リスト` no longer shows a store selector. Its tag filters use the same horizontal chip UI as the store card, without a `＋` button.
- `全商品リスト` now has two horizontal chip rows: store selection and tag selection. Store selection starts with `全カード`, supports multiple stores, automatically leaves `全カード` when an individual store is selected, returns to `全カード` when all individuals are cleared, and tapping `全カード` clears all individual selections.
- Product-list tag filters use the common chip UI, support multiple selected tags, and omit the `＋` button.
- Product multi-tag editing remains enabled through the many-to-many `product_tags` relation and common multi-select tag UI.
- Photo thumbnails are three equal-width columns. Each cell is one third of the available row width and the image itself remains square; incomplete rows stay left-aligned.

## Carried forward
- Product tags support multiple tags per product using the `product_tags` relation.
- Photo selection controls are `キャンセル / 削除 / 共有 / タグ編集`; delete uses dark red. Selection ends on outside tap or when the last photo is deselected.
- Main product search hint is `商品名検索`.
- Tapping outside a focused input clears focus/cursor and hides the IME.
- Long vertical views use the draggable fast-scroll thumb.
- Menu labels are `カード内商品リスト`, `カード名変更`, `カード削除`, and `全商品リスト表示`.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
