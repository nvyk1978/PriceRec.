# Price Rec. v0.1.71

Version: 0.1.71
VersionCode: 72

## Changes
- PriceRec. の複数起動を禁止。`MainActivity` を `singleTask` にし、共有・CSV・`.prstore`・保存アクションは既存インスタンスの `onNewIntent()` で受ける。
- 複数店舗インポートはカード長押しでも選択モードへ入り、その店舗を選択する。
- 選択モードで最後の1件をタップ解除した場合も、「選択解除」ボタンで全解除した場合も通常モードへ戻る。
- 選択モード中の「キャンセル」は選択だけ解除して通常モードへ戻り、インポートダイアログは閉じない。通常モード中の「キャンセル」はダイアログを閉じる。
- 選択店舗カードは Nライトブルー `#445577` で反転。選択中でも取込方法トグルと画像トグルは操作可能。
- 取込方法はダイアログ式ボタンを廃止し、右端詰めの `マージ ↔ 新規店舗として登録` テキスト＋Nトグルへ変更。OFF=マージ、ON=新規店舗、ON色は Nレッド `#441100`。
- `画像もインポート` もテキストをトグル直左に置き、セットで右端詰め。ON色は Nオレンジ `#775500`。画像なしではOFF固定＋グレーアウト。
- 複数インポートの右端ボタンは選択0件=`インポート`グレーアウト、1件=`インポート`、2件以上=`まとめてインポート`。文言切替でも152dp固定。
- `選択 / 選択解除` は110dp固定。0件選択時の「選択解除」はグレーアウト。
- 商品リスト／画像画面など、状態切替で同じ位置に別ラベルが来るボタンは外形を固定。`選択 → タグ編集` の右端スロットを96dpで統一。
- グレーアウト状態のボタンは背景をNダークグレー、文字色をNライトグレー `#656060` に統一。
- インポート履歴の「パージ済を削除」はパージ済履歴が0件ならグレーアウト。
- v0.1.70までの `.prstore`、共有シート保存、インポート履歴／パージ、Google Maps identity由来store_key固定、N配色を維持。

## v0.1.71
- 上記 Changes と同一。DB schema変更なし。

## v0.1.70
- 店舗／アプリメニュー順、共有シート保存、画像トグル配色、まとめてインポートの初期選択UI、インポート履歴のMEMO表示、商品／画像画面の全て選択を追加。DB schema変更なし。

## v0.1.69
- `.prstore` による単店舗／全店舗エクスポートと店舗インポートを追加。画像あり／なし、実サイズ・CSV/商品/画像件数表示に対応。
- インポート方法「マージ / 新規店舗として登録」、複数ファイル取り込み、インポート履歴・一行メモ・パージを追加。
- 新規店舗を後からGoogleマップ解析し、同一identityの既存店舗がある場合に確認してマージできるようにした。DBをv18へ更新。
- 編集不可store_keyは通常入力フィールド外観を残し、文字だけ抑えたロック表示へ変更。

## v0.1.55
- 店舗カード長押しメニューから「カード内商品リスト」を削除。
- GoogleマップURLをバックグラウンドで自動解析。短縮URLは内部で展開し、入力欄の文字列は書き換えない。
- カード情報変更／カード追加に「マップ解析」ボタンを追加。解析成功時は「解析済」（ダークオレンジ＋黒文字）。
- 解析済み店舗カードは題字左にCSV取得済みと同型の緑チェックを表示。
- Googleマップ解析結果として展開済みURL・緯度・経度をDBに保存（DB v17）。
- マップ解析成功時は緯度経度を正規化してSHA-256から決定的な `str.map.<20hex>` を生成。同じ解析結果から常に同じstore_keyになる。
- マップ解析済みのstore_keyは編集不可。GoogleマップURLを削除して保存すると解析情報を消し、次回カード情報変更を開いたときstore_key編集を再許可。

## v0.1.56
- 店舗カード長押しメニューは「カード情報変更」「カード削除」のみに固定し、「カード内商品リスト」を完全に除外。通常の店舗カード内「商品リスト」ボタンは維持。
- 店舗別商品リストの題字表記を「<店舗名> / 商品リスト」に統一。
- カード追加／カード情報変更の下部操作をAndroid標準AlertDialogボタンからカスタム操作列へ変更。左端に「マップ解析」、右端詰めで「キャンセル」「追加/変更」を配置。
- マップ自動解析、解析済みボタン状態、緑チェック、緯度経度保存、決定的store_key生成・解析中の編集ロックはv0.1.55仕様を維持。

## v0.1.57
- Googleマップ解析の診断ログを `MAP_PARSE_START/HOP/REDIRECT/HTML_REDIRECT/COORDINATES/NO_COORDINATES/ERROR/OK` まで段階化。
- Google Maps短縮URLのHTTPリダイレクトに加え、HTML内canonical / og:url / meta refresh / JavaScript location遷移も追跡。
- Google MapsページのHTML/JSONエスケープを展開して座標を探索し、URL・本文の双方から緯度経度を取得。
- 既存カードにGoogleマップURLが保存済みで未解析の場合、カード情報変更ダイアログを開いた時点で自動解析を開始。
- 手動「マップ解析」は常に強制再解析として動作。

## v0.1.58
- Googleマップ短縮URLの実機検証用として、解析工程の診断ログを含むビルドをリリース。
- 入力URL、HTTP/HTMLリダイレクト、座標抽出、最終URL、生成store_key、成功/失敗理由を診断ログで追跡可能。
- v0.1.57までのマップ自動解析、解析済み表示、緑チェック、決定的store_key生成・ロック仕様を維持。


## v0.1.59
- Google Maps place pages that omit `!3d/!4d` and `@lat,lng` are now parsed from `APP_INITIALIZATION_STATE` in the downloaded HTML.
- The parser reads the initialization-state center as longitude/latitude only inside the tightly scoped initialization block, avoiding arbitrary coordinate pairs elsewhere in the Maps shell.
- Google feature identity (`!1s` feature id, `ftid`, CID, Place-id segment, or kgmid) is extracted when available and used as the primary deterministic `store_key` seed.
- `store_key` therefore remains stable across repeated analysis of the same Google place even when URL formatting or viewport coordinates vary; coordinates remain the fallback seed.
- Added `MAP_PARSE_IDENTITY` and `MAP_PARSE_COORDINATES source=app_init` diagnostics for real-device verification.

## v0.1.60
- Google Maps登録店舗identityの特定を解析成功条件に変更。座標取得は任意。
- `feature:0x...:0x...` 等をURLから取得できた時点で解析を完了し、identityだけから決定的 `store_key` を生成。
- 緯度経度がnullでも解析済み状態・store_keyロック・カードの解析済みチェックを維持。
- 未解析URL保存やURL削除後は解析済みフラグを落とし、次回編集時にstore_keyを再編集可能。


## v0.1.61
- 上記 Changes と同一。Googleマップidentity由来store_keyの決定性と、認証後store_key固定を共有基盤の不変仕様として強化。

## v0.1.62
- アプリ内の主要サーフェス／アクセント色を最新Nカラーへ統一。
- 非Nアクセントだったダークオレンジとグリーンを廃止し、解析状態・チェック表示もNカラーで統一。
- v0.1.61までのGoogleマップidentity由来store_key固定、タグ選択統一、保存時のみタグ確定の仕様はそのまま維持。


## v0.1.63
- ユーザー指定の最新N配色を正本として焼き直し。D.Gray `#252020` / Gray `#454040` / L.Gray `#656060` / L.Red `#662211` / D.Orange `#553300` / White `#A9A999` を反映。
- Java定数、`colors.xml`、Nトグル、ランチャーアイコン、原寸画像ビュー背景から旧色・非N色を除去。
- Googleマップidentity由来の決定的store_key生成・認証後固定、タグ選択／保存仕様などv0.1.62の機能ロジックは変更なし。


## v0.1.64
- 通常テキストを純白 `#FFFFFF` に復帰。非テキストUIはN White `#A9A999`を維持。
- 解析済み／取得済みチェックバッジを専用グリーン `#225533` に変更。
- store_key固定・Googleマップidentity解析など共有基盤は変更なし。


## v0.1.65
- 入力エラー表示のテーマ色を N Red `#441100` に変更。
- v0.1.64の配色役割分離とチェック専用グリーン `#225533`、store_key共有基盤は維持。


## v0.1.66
- 商品選択時の一覧全再描画を廃止し、行背景・件数・操作ボタンだけをインプレース更新してスクロールのガタつきを抑制。
- 入力エラー表示をアプリ側で描画し、エラーアクセントを `#441100` に固定。
- Googleマップidentity解析、認証後store_key固定、N配色の役割分離は維持。


## v0.1.67
- チェック丸 `#227733` / チェック線 `#FFFFFF`。
- 入力エラーアクセントを N Light Red `#662211`。
- タグ／全商品リストの丸ボタン外径は維持し、内部絵柄のみ88%へ縮小。


## v0.1.68
- 編集不可の `store_key` 欄を N Gray `#454040` 背景＋N White `#A9A999` 文字でグレーアウト。
- 固定済み `store_key` の決定性・Googleマップidentity解析ロジックは変更なし。
