# PRICE REC. v0.1.0

Initial Android scaffold for the private price-recording app.

## Implemented in this initial set
- Register / rename / delete stores.
- Expand a store before shooting.
- Global user-managed tags. Defaults: 酒 / 肉 / 調味料.
- Add and delete tags.
- Select a tag before shooting; the selected tag is retained per store.
- Shoot through the device camera and save to `Pictures/PriceRec/<store>` using MediaStore.
- Store-specific image roll.
- Tap a photo to change its tag later or delete the photo.
- Store list tab and cross-store search skeleton ready for OCR product data.
- SQLite schema already includes `products` for later OCR/name/price storage.
- Long-press `PRICE REC.` to view/copy a diagnostic log.

## Build / update install
- applicationId: `com.pricerec.app`
- versionName: `0.1.0`
- versionCode: `1`
- target/compile SDK: 36
- min SDK: 29
- `app/pricerec-debug.jks` is intentionally bundled so GitHub builds keep the same signing key and can overwrite-install future APKs.
- Keep the same applicationId and keystore, and increment versionCode for each next build.

The bundled key is for this private-development workflow only, not for public Play Store distribution.
