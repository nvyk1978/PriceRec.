# Price Rec. v0.1.28

- versionCode 29
- applicationId / stable signing key unchanged for overwrite install
- source archive name is always `source.zip`

## v0.1.28
- Store-card N toggle OFF color is now white; ON remains orange `#775500`. OFF card-name grayout, edit lock, and search exclusion remain unchanged.
- Fixed N-toggle vertical clipping without enlarging the store header: the historical 44x24dp track remains, while the custom toggle view reserves 26dp height for the 26dp ON thumb. The existing 48dp touch container/header layout remains unchanged.
- `店舗追加` is renamed to `カード追加`. The add-card dialog adds a clear 14dp vertical gap between the `カード追加` title and the store-name input field.
- Draggable fast-scroll thumbs now keep exactly the same visible size while gripped. Grip feedback changes color only; there is no scale/length/thickness animation.
- Fast-scroll grip hit area is widened to 32dp while the visible thumb remains 12x58dp, improving grab reliability without making the scrollbar look thicker.

## Carried forward
- Store N toggle uses the FinderlessCamera v0.1.92-style custom control: 44x24dp track, 24dp OFF thumb, 26dp ON thumb, 120ms slide.
- Full/card product lists use common horizontal chip filters; full list supports `全カード` plus multi-store selection.
- Products support multiple tags via the `product_tags` relation.
- Photo thumbnails are square, three columns wide, and left-aligned.
- Photo selection controls are `キャンセル / 削除 / 共有 / タグ編集`.

## Build
Place `source.zip` at repository root and `.github/workflows/pricerec-build.yml` under workflows. Push triggers the build automatically; no `workflow_dispatch` / Run workflow is required.
