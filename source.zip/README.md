# Price Rec. v0.1.50

Version: 0.1.50
VersionCode: 51

## Changes
- Tag Manager is redesigned around selection instead of per-row delete icons. The delete × icons are removed. The footer now has a left `削除` capsule and a right `OK` capsule; delete is disabled/greyed when nothing is selected.
- In Tag Manager, single-tap toggles tag selection and supports multiple selection. While one or more tags are selected, `削除` becomes live and the right `OK` changes to `キャンセル`. Deselecting the last selected tag automatically returns to the normal state.
- In Tag Manager, long-press on a tag row opens tag-name rename. The reorder handle remains dedicated to tag reordering, including the existing drag highlight/reorder animation.
- Bulk image/product `タグ編集` dialogs are replaced with the shared Tag Manager-style `タグ選択` dialog. It has no delete control; `キャンセル` sits immediately left of dark-blue `OK`. Single-tap toggles multiple tag selection and OK applies the selected tag set.
- In `タグ選択`, long-press opens rename. If tags are already selected, the selection is cleared before entering rename, as specified.
- Tag names remain globally unique (case-insensitive database uniqueness, trimmed UI input). Add/rename attempts that duplicate an existing tag are rejected with `重複したタグ名は作成できません`.
- Inline horizontal tag selectors now preserve their horizontal scroll position when a tag is selected/deselected or when returning from Tag Manager, instead of jumping back to the beginning.
- Existing global layout margins/spacing, product-list column settings, comparison behavior, 18dp edit-dialog action spacing, reference-image viewer alignment, stable package id, and stable signing key are retained.
