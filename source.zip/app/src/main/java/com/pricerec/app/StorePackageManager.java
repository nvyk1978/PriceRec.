package com.pricerec.app;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Portable PriceRec store-card package. The user-facing .prstore file is a ZIP container.
 * Store identity and product metadata are explicit JSON; original CSVs and reference images
 * are optional payloads. The importer never trusts a filename as identity.
 */
final class StorePackageManager {
    static final String MIME = "application/vnd.pricerec.store";
    static final int SCHEMA_VERSION = 1;
    private static final long MAX_METADATA_BYTES = 8L * 1024L * 1024L;
    private static final long MAX_PACKAGE_BYTES = 4L * 1024L * 1024L * 1024L;

    private StorePackageManager() { }

    static final class BuildResult {
        final File file;
        final long bytes;
        final int storeCount;
        final int csvCount;
        final int productCount;
        final int imageCount;
        final boolean withImages;

        BuildResult(File file, long bytes, int storeCount, int csvCount, int productCount, int imageCount, boolean withImages) {
            this.file = file;
            this.bytes = bytes;
            this.storeCount = storeCount;
            this.csvCount = csvCount;
            this.productCount = productCount;
            this.imageCount = imageCount;
            this.withImages = withImages;
        }
    }

    static final class ParsedPackage {
        final File localFile;
        final String sourceName;
        final String sourceUri;
        final List<ParsedStore> stores;

        ParsedPackage(File localFile, String sourceName, String sourceUri, List<ParsedStore> stores) {
            this.localFile = localFile;
            this.sourceName = sourceName;
            this.sourceUri = sourceUri;
            this.stores = stores;
        }
    }

    static final class CsvData {
        final String entryName;
        final String fileName;

        CsvData(String entryName, String fileName) {
            this.entryName = entryName;
            this.fileName = fileName;
        }
    }

    static final class ParsedStore {
        final File packageFile;
        final String sourceName;
        final String sourceUri;
        final String path;
        final String name;
        final String storeKey;
        final String mapUrl;
        final String mapResolvedUrl;
        final Double mapLat;
        final Double mapLng;
        final int csvCount;
        final List<CsvData> csvs;
        final List<PhotoData> photos;
        final List<ProductData> products;

        ParsedStore(File packageFile, String sourceName, String sourceUri, String path,
                    String name, String storeKey, String mapUrl, String mapResolvedUrl,
                    Double mapLat, Double mapLng, List<CsvData> csvs,
                    List<PhotoData> photos, List<ProductData> products) {
            this.packageFile = packageFile;
            this.sourceName = sourceName;
            this.sourceUri = sourceUri;
            this.path = path;
            this.name = name;
            this.storeKey = storeKey;
            this.mapUrl = mapUrl;
            this.mapResolvedUrl = mapResolvedUrl;
            this.mapLat = mapLat;
            this.mapLng = mapLng;
            this.csvs = csvs == null ? new ArrayList<>() : csvs;
            this.csvCount = this.csvs.size();
            this.photos = photos;
            this.products = products;
        }

        int imageCount() {
            int count = 0;
            for (PhotoData p : photos) if (p.imageEntry != null && !p.imageEntry.isEmpty()) count++;
            return count;
        }
    }

    static final class PhotoData {
        final String token;
        final long createdAt;
        final List<String> tags;
        final boolean defaultTaxExcluded;
        final String imageEntry;
        final String sourceName;

        PhotoData(String token, long createdAt, List<String> tags, boolean defaultTaxExcluded,
                  String imageEntry, String sourceName) {
            this.token = token;
            this.createdAt = createdAt;
            this.tags = tags;
            this.defaultTaxExcluded = defaultTaxExcluded;
            this.imageEntry = imageEntry;
            this.sourceName = sourceName;
        }
    }

    static final class ProductData {
        final String photoToken;
        final String name;
        final String productKey;
        final Integer priceYen;
        final String volume;
        final String priceType;
        final String sourceImage;
        final long createdAt;
        final List<String> tags;

        ProductData(String photoToken, String name, String productKey, Integer priceYen,
                    String volume, String priceType, String sourceImage, long createdAt, List<String> tags) {
            this.photoToken = photoToken;
            this.name = name;
            this.productKey = productKey;
            this.priceYen = priceYen;
            this.volume = volume;
            this.priceType = priceType;
            this.sourceImage = sourceImage;
            this.createdAt = createdAt;
            this.tags = tags;
        }
    }

    static BuildResult build(Context context, DatabaseHelper db, List<DatabaseHelper.Store> stores,
                             boolean includeImages, File outFile) throws Exception {
        if (stores == null || stores.isEmpty()) throw new IllegalArgumentException("店舗がありません");
        File parent = outFile.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IllegalStateException("出力フォルダを作成できません");
        if (outFile.exists() && !outFile.delete()) throw new IllegalStateException("旧一時ファイルを削除できません");

        ContentResolver resolver = context.getContentResolver();
        Map<Long, String> tagNames = new HashMap<>();
        for (DatabaseHelper.Tag tag : db.listTags()) tagNames.put(tag.id, tag.name);

        JSONArray manifestStores = new JSONArray();
        int totalCsv = 0;
        int totalProducts = 0;
        int totalImages = 0;
        long exportedAt = System.currentTimeMillis();

        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outFile)))) {
            zip.setLevel(6);
            for (int storeIndex = 0; storeIndex < stores.size(); storeIndex++) {
                DatabaseHelper.Store store = stores.get(storeIndex);
                String base = String.format(Locale.ROOT, "stores/%04d/", storeIndex);
                List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
                List<DatabaseHelper.ProductRecord> products = db.listProductsForStore(store.id);
                List<DatabaseHelper.ExportCsv> csvs = db.listExportCsvForStore(store.id);

                Map<Long, String> photoTokens = new LinkedHashMap<>();
                Map<Long, String> imageEntries = new HashMap<>();
                Map<Long, String> imageSourceNames = new HashMap<>();
                int imageIndex = 0;
                for (DatabaseHelper.Photo photo : photos) {
                    photoTokens.put(photo.id, "p" + photo.id);
                    if (!includeImages || db.isVirtualImportPhoto(photo)) continue;
                    Uri uri;
                    try { uri = Uri.parse(photo.uri); } catch (Exception e) { continue; }
                    String display = displayNameForUri(resolver, uri, "image_" + (++imageIndex));
                    String ext = extensionFor(display, resolver.getType(uri));
                    String entryName = base + "images/" + String.format(Locale.ROOT, "%04d%s", imageIndex, ext);
                    try (InputStream in = resolver.openInputStream(uri)) {
                        if (in == null) continue;
                        putStream(zip, entryName, in);
                        imageEntries.put(photo.id, entryName);
                        imageSourceNames.put(photo.id, display);
                        totalImages++;
                    } catch (Exception ignored) {
                        // Metadata remains exportable even when a stale image URI cannot be opened.
                    }
                }

                JSONArray photoJson = new JSONArray();
                for (DatabaseHelper.Photo photo : photos) {
                    JSONObject obj = new JSONObject();
                    obj.put("token", photoTokens.get(photo.id));
                    obj.put("created_at", photo.createdAt);
                    obj.put("tags", tagNameArray(photo.tagIds, tagNames, photo.tagName));
                    obj.put("default_tax_excluded", photo.defaultTaxExcluded);
                    String imageEntry = imageEntries.get(photo.id);
                    if (imageEntry == null) obj.put("image_entry", JSONObject.NULL); else obj.put("image_entry", imageEntry);
                    String sourceName = imageSourceNames.get(photo.id);
                    if (sourceName == null || sourceName.trim().isEmpty()) sourceName = sourceNameFromProduct(products, photo.id);
                    if (sourceName == null || sourceName.trim().isEmpty()) obj.put("source_name", JSONObject.NULL); else obj.put("source_name", sourceName);
                    photoJson.put(obj);
                }

                JSONArray productJson = new JSONArray();
                for (DatabaseHelper.ProductRecord product : products) {
                    JSONObject obj = new JSONObject();
                    String token = photoTokens.get(product.photoId);
                    if (token == null) token = "p" + product.photoId;
                    obj.put("photo_token", token);
                    obj.put("name", product.rawName == null ? "" : product.rawName);
                    obj.put("product_key", product.productKey == null ? "" : product.productKey);
                    if (product.priceYen == null) obj.put("price_yen", JSONObject.NULL); else obj.put("price_yen", product.priceYen);
                    putNullable(obj, "volume", product.volume);
                    putNullable(obj, "price_type", product.priceType);
                    putNullable(obj, "source_image", product.sourceImage);
                    obj.put("created_at", product.createdAt);
                    obj.put("tags", tagNameArray(product.tagIds, tagNames, product.tagName));
                    productJson.put(obj);
                }

                int csvIndex = 0;
                for (DatabaseHelper.ExportCsv csv : csvs) {
                    String csvName = safeName(csv.fileName == null ? "CSV" : csv.fileName);
                    if (!csvName.toLowerCase(Locale.ROOT).endsWith(".csv")) csvName += ".csv";
                    String entry = base + "csv/" + String.format(Locale.ROOT, "%04d_", ++csvIndex) + csvName;
                    putBytes(zip, entry, csv.rawCsv.getBytes(StandardCharsets.UTF_8));
                }

                JSONObject storeJson = new JSONObject();
                storeJson.put("name", store.name);
                storeJson.put("store_key", store.storeKey);
                putNullable(storeJson, "map_url", emptyToNull(store.mapUrl));
                putNullable(storeJson, "map_resolved_url", emptyToNull(store.mapResolvedUrl));
                if (store.mapLat == null) storeJson.put("map_lat", JSONObject.NULL); else storeJson.put("map_lat", store.mapLat);
                if (store.mapLng == null) storeJson.put("map_lng", JSONObject.NULL); else storeJson.put("map_lng", store.mapLng);
                storeJson.put("exported_at", exportedAt);
                storeJson.put("csv_count", csvs.size());
                storeJson.put("product_count", products.size());
                storeJson.put("image_count", imageEntries.size());
                putJson(zip, base + "store.json", storeJson);
                putJson(zip, base + "photos.json", photoJson);
                putJson(zip, base + "products.json", productJson);

                JSONObject summary = new JSONObject();
                summary.put("path", base.substring(0, base.length() - 1));
                summary.put("name", store.name);
                summary.put("store_key", store.storeKey);
                summary.put("csv_count", csvs.size());
                summary.put("product_count", products.size());
                summary.put("image_count", imageEntries.size());
                manifestStores.put(summary);
                totalCsv += csvs.size();
                totalProducts += products.size();
            }

            JSONObject manifest = new JSONObject();
            manifest.put("schema_version", SCHEMA_VERSION);
            manifest.put("format", "PriceRec Store Package");
            manifest.put("package_kind", stores.size() == 1 ? "single" : "multi");
            manifest.put("exported_at", exportedAt);
            manifest.put("with_images", includeImages);
            manifest.put("store_count", stores.size());
            manifest.put("csv_count", totalCsv);
            manifest.put("product_count", totalProducts);
            manifest.put("image_count", totalImages);
            manifest.put("stores", manifestStores);
            putJson(zip, "manifest.json", manifest);
        }
        return new BuildResult(outFile, outFile.length(), stores.size(), totalCsv, totalProducts, totalImages, includeImages);
    }

    static ParsedPackage copyAndParse(Context context, Uri uri) throws Exception {
        if (uri == null) throw new IllegalArgumentException("ファイルがありません");
        ContentResolver resolver = context.getContentResolver();
        String sourceName = displayNameForUri(resolver, uri, "PriceRec.prstore");
        File dir = new File(context.getCacheDir(), "store_import");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("一時フォルダを作成できません");
        File local = new File(dir, UUID.randomUUID().toString() + ".prstore");
        long total = 0;
        try (InputStream raw = resolver.openInputStream(uri);
             InputStream in = raw == null ? null : new BufferedInputStream(raw);
             OutputStream out = new BufferedOutputStream(new FileOutputStream(local))) {
            if (in == null) throw new IllegalStateException("ファイルを開けません");
            byte[] buf = new byte[128 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) {
                if (n == 0) continue;
                total += n;
                if (total > MAX_PACKAGE_BYTES) throw new IllegalStateException("店舗データが大きすぎます");
                out.write(buf, 0, n);
            }
        } catch (Exception e) {
            local.delete();
            throw e;
        }
        try {
            return parseLocal(local, sourceName, uri.toString());
        } catch (Exception e) {
            local.delete();
            throw e;
        }
    }

    static ParsedPackage parseLocal(File local, String sourceName, String sourceUri) throws Exception {
        ArrayList<ParsedStore> stores = new ArrayList<>();
        try (ZipFile zip = new ZipFile(local)) {
            JSONObject manifest = readJsonObject(zip, "manifest.json");
            int schema = manifest.optInt("schema_version", -1);
            if (schema != SCHEMA_VERSION) throw new IllegalStateException("未対応の店舗データ形式です (schema " + schema + ")");
            JSONArray summaries = manifest.optJSONArray("stores");
            if (summaries == null || summaries.length() == 0) throw new IllegalStateException("店舗データが空です");
            for (int i = 0; i < summaries.length(); i++) {
                JSONObject summary = summaries.getJSONObject(i);
                String path = summary.optString("path", "").trim();
                if (!validStorePath(path)) throw new IllegalStateException("不正な店舗パスです");
                JSONObject store = readJsonObject(zip, path + "/store.json");
                JSONArray photosRaw = readJsonArray(zip, path + "/photos.json");
                JSONArray productsRaw = readJsonArray(zip, path + "/products.json");
                ArrayList<PhotoData> photos = new ArrayList<>();
                for (int p = 0; p < photosRaw.length(); p++) {
                    JSONObject o = photosRaw.getJSONObject(p);
                    String imageEntry = nullableString(o, "image_entry");
                    if (imageEntry != null && (!imageEntry.startsWith(path + "/images/") || zip.getEntry(imageEntry) == null)) {
                        imageEntry = null;
                    }
                    photos.add(new PhotoData(
                            o.optString("token", "p" + p),
                            o.optLong("created_at", System.currentTimeMillis()),
                            stringList(o.optJSONArray("tags")),
                            o.optBoolean("default_tax_excluded", true),
                            imageEntry,
                            nullableString(o, "source_name")));
                }
                ArrayList<ProductData> products = new ArrayList<>();
                for (int p = 0; p < productsRaw.length(); p++) {
                    JSONObject o = productsRaw.getJSONObject(p);
                    Integer price = o.isNull("price_yen") ? null : o.optInt("price_yen");
                    products.add(new ProductData(
                            o.optString("photo_token", ""),
                            o.optString("name", ""),
                            o.optString("product_key", ""),
                            price,
                            nullableString(o, "volume"),
                            nullableString(o, "price_type"),
                            nullableString(o, "source_image"),
                            o.optLong("created_at", System.currentTimeMillis()),
                            stringList(o.optJSONArray("tags"))));
                }
                String name = store.optString("name", summary.optString("name", "店舗")).trim();
                String key = store.optString("store_key", summary.optString("store_key", "")).trim();
                if (name.isEmpty() || key.isEmpty()) throw new IllegalStateException("店舗名またはstore_keyがありません");
                Double lat = store.isNull("map_lat") ? null : store.optDouble("map_lat");
                Double lng = store.isNull("map_lng") ? null : store.optDouble("map_lng");
                List<CsvData> csvs = listCsvEntries(zip, path);
                stores.add(new ParsedStore(local, sourceName, sourceUri, path, name, key,
                        nullToEmpty(nullableString(store, "map_url")),
                        nullToEmpty(nullableString(store, "map_resolved_url")), lat, lng,
                        csvs, photos, products));
            }
        }
        return new ParsedPackage(local, sourceName, sourceUri, stores);
    }

    static void copyEntry(File packageFile, String entryName, OutputStream out) throws Exception {
        if (packageFile == null || entryName == null || out == null) throw new IllegalArgumentException("copyEntry");
        try (ZipFile zip = new ZipFile(packageFile)) {
            ZipEntry entry = zip.getEntry(entryName);
            if (entry == null || entry.isDirectory()) throw new IllegalStateException("画像エントリがありません");
            try (InputStream in = new BufferedInputStream(zip.getInputStream(entry))) {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) >= 0) if (n > 0) out.write(buf, 0, n);
            }
        }
    }

    static void cleanup(ParsedPackage parsed) {
        if (parsed != null && parsed.localFile != null) parsed.localFile.delete();
    }

    private static JSONObject readJsonObject(ZipFile zip, String name) throws Exception {
        return new JSONObject(readText(zip, name));
    }

    private static JSONArray readJsonArray(ZipFile zip, String name) throws Exception {
        return new JSONArray(readText(zip, name));
    }

    private static String readText(ZipFile zip, String name) throws Exception {
        ZipEntry entry = zip.getEntry(name);
        if (entry == null || entry.isDirectory()) throw new IllegalStateException("必要なデータがありません: " + name);
        if (entry.getSize() > MAX_METADATA_BYTES) throw new IllegalStateException("メタデータが大きすぎます");
        try (InputStream in = zip.getInputStream(entry); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[32 * 1024];
            int n;
            long total = 0;
            while ((n = in.read(buf)) >= 0) {
                if (n == 0) continue;
                total += n;
                if (total > MAX_METADATA_BYTES) throw new IllegalStateException("メタデータが大きすぎます");
                out.write(buf, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    static String readTextEntry(File packageFile, String entryName) throws Exception {
        if (packageFile == null || entryName == null || entryName.trim().isEmpty()) throw new IllegalArgumentException("CSV entry");
        try (ZipFile zip = new ZipFile(packageFile)) {
            return readText(zip, entryName);
        }
    }

    private static List<CsvData> listCsvEntries(ZipFile zip, String path) {
        ArrayList<CsvData> out = new ArrayList<>();
        String prefix = path + "/csv/";
        java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
        while (entries.hasMoreElements()) {
            ZipEntry e = entries.nextElement();
            String entry = e.getName();
            if (e.isDirectory() || !entry.startsWith(prefix) || !entry.toLowerCase(Locale.ROOT).endsWith(".csv")) continue;
            String leaf = entry.substring(prefix.length());
            if (leaf.contains("/") || leaf.contains("\\")) continue;
            String display = leaf.replaceFirst("^[0-9]{4}_", "");
            out.add(new CsvData(entry, display.isEmpty() ? "CSV.csv" : display));
        }
        return out;
    }

    private static boolean validStorePath(String path) {
        return path.matches("stores/[0-9]{4}");
    }

    private static JSONArray tagNameArray(List<Long> ids, Map<Long, String> names, String fallback) {
        JSONArray array = new JSONArray();
        if (ids != null) {
            for (Long id : ids) {
                String name = id == null ? null : names.get(id);
                if (name != null && !name.trim().isEmpty()) array.put(name);
            }
        }
        if (array.length() == 0 && fallback != null && !fallback.trim().isEmpty()) array.put(fallback.trim());
        return array;
    }

    private static List<String> stringList(JSONArray array) {
        ArrayList<String> out = new ArrayList<>();
        if (array == null) return out;
        for (int i = 0; i < array.length(); i++) {
            String value = array.optString(i, "").trim();
            if (!value.isEmpty() && !out.contains(value)) out.add(value);
        }
        return out;
    }

    private static String sourceNameFromProduct(List<DatabaseHelper.ProductRecord> products, long photoId) {
        if (products == null) return null;
        for (DatabaseHelper.ProductRecord product : products) {
            if (product.photoId == photoId && product.sourceImage != null && !product.sourceImage.trim().isEmpty()) return product.sourceImage.trim();
        }
        return null;
    }

    private static void putJson(ZipOutputStream zip, String name, Object json) throws Exception {
        putBytes(zip, name, String.valueOf(json).getBytes(StandardCharsets.UTF_8));
    }

    private static void putBytes(ZipOutputStream zip, String name, byte[] bytes) throws Exception {
        ZipEntry entry = new ZipEntry(name);
        entry.setTime(0L);
        zip.putNextEntry(entry);
        zip.write(bytes);
        zip.closeEntry();
    }

    private static void putStream(ZipOutputStream zip, String name, InputStream in) throws Exception {
        ZipEntry entry = new ZipEntry(name);
        entry.setTime(0L);
        zip.putNextEntry(entry);
        try {
            byte[] buffer = new byte[128 * 1024];
            int n;
            while ((n = in.read(buffer)) >= 0) if (n > 0) zip.write(buffer, 0, n);
        } finally {
            zip.closeEntry();
        }
    }

    private static String displayNameForUri(ContentResolver resolver, Uri uri, String fallback) {
        try (Cursor c = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) {
                String value = c.getString(0);
                if (value != null && !value.trim().isEmpty()) return value.trim();
            }
        } catch (Exception ignored) { }
        String last = uri.getLastPathSegment();
        return last == null || last.trim().isEmpty() ? fallback : last;
    }

    private static String extensionFor(String displayName, String mime) {
        if (displayName != null) {
            int dot = displayName.lastIndexOf('.');
            if (dot >= 0 && dot < displayName.length() - 1) {
                String ext = displayName.substring(dot).toLowerCase(Locale.ROOT);
                if (ext.matches("\\.[a-z0-9]{1,6}")) return ext;
            }
        }
        if (mime != null) {
            String m = mime.toLowerCase(Locale.ROOT);
            if (m.contains("png")) return ".png";
            if (m.contains("webp")) return ".webp";
            if (m.contains("heic") || m.contains("heif")) return ".heic";
            if (m.contains("avif")) return ".avif";
            if (m.contains("gif")) return ".gif";
        }
        return ".jpg";
    }

    private static String safeName(String value) {
        String s = value == null ? "data" : value.trim();
        s = s.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_");
        s = s.replaceAll("\\s+", " ").trim();
        if (s.isEmpty()) s = "data";
        return s.length() > 80 ? s.substring(0, 80) : s;
    }

    private static void putNullable(JSONObject obj, String key, String value) throws Exception {
        if (value == null || value.trim().isEmpty()) obj.put(key, JSONObject.NULL); else obj.put(key, value);
    }

    private static String nullableString(JSONObject obj, String key) {
        if (obj == null || !obj.has(key) || obj.isNull(key)) return null;
        String value = obj.optString(key, null);
        return value == null ? null : value;
    }

    private static String emptyToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
