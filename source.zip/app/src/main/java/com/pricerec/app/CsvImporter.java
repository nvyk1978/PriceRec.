package com.pricerec.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class CsvImporter {
    private CsvImporter() { }

    static Result parse(InputStream input) throws Exception {
        byte[] bytes = readAll(input);
        String text = new String(bytes, StandardCharsets.UTF_8);
        if (!text.isEmpty() && text.charAt(0) == '\uFEFF') text = text.substring(1);
        text = stripCodeFence(text);
        List<List<String>> records = parseRecords(text);
        if (records.isEmpty()) throw new IllegalArgumentException("CSVが空です");

        List<String> header = records.get(0);
        Map<String, Integer> index = new HashMap<>();
        for (int i = 0; i < header.size(); i++) index.put(normalizeHeader(header.get(i)), i);
        if (!index.containsKey("store") || !index.containsKey("product_name") || !index.containsKey("price")) {
            throw new IllegalArgumentException("必要な列 store, product_name, price が見つかりません");
        }

        ArrayList<Row> rows = new ArrayList<>();
        ArrayList<String> warnings = new ArrayList<>();
        for (int r = 1; r < records.size(); r++) {
            List<String> rec = records.get(r);
            if (isBlankRecord(rec)) continue;
            Row row = new Row();
            row.lineNumber = r + 1;
            row.store = get(rec, index, "store");
            row.tag = get(rec, index, "tag");
            row.productName = get(rec, index, "product_name");
            row.productKey = get(rec, index, "product_key");
            row.priceRaw = get(rec, index, "price");
            row.priceYen = parsePrice(row.priceRaw);
            row.volume = get(rec, index, "volume");
            row.priceType = get(rec, index, "price_type");
            row.capturedAtRaw = get(rec, index, "captured_at");
            row.capturedAt = parseDate(row.capturedAtRaw);
            row.sourceImage = get(rec, index, "source_image");

            if (row.store.isEmpty()) warnings.add("行" + row.lineNumber + ": store が空欄");
            if (row.productName.isEmpty()) warnings.add("行" + row.lineNumber + ": product_name が空欄");
            if (!row.priceRaw.isEmpty() && row.priceYen == null) warnings.add("行" + row.lineNumber + ": priceを整数として読めません: " + row.priceRaw);
            if (row.productKey.isEmpty()) row.productKey = row.productName;
            rows.add(row);
        }
        if (rows.isEmpty()) throw new IllegalArgumentException("データ行がありません");
        return new Result(rows, warnings, bytes.length);
    }

    private static String stripCodeFence(String text) {
        String trimmed = text.trim();
        if (!trimmed.startsWith("```")) return text;
        int firstNl = trimmed.indexOf('\n');
        int last = trimmed.lastIndexOf("```");
        if (firstNl >= 0 && last > firstNl) return trimmed.substring(firstNl + 1, last).trim();
        return text;
    }

    private static byte[] readAll(InputStream input) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = input.read(buf)) >= 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private static List<List<String>> parseRecords(String text) {
        ArrayList<List<String>> records = new ArrayList<>();
        ArrayList<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
                        field.append('"');
                        i++;
                    } else {
                        quoted = false;
                    }
                } else {
                    field.append(c);
                }
            } else {
                if (c == '"' && field.length() == 0) {
                    quoted = true;
                } else if (c == ',') {
                    row.add(field.toString().trim());
                    field.setLength(0);
                } else if (c == '\r' || c == '\n') {
                    row.add(field.toString().trim());
                    field.setLength(0);
                    records.add(row);
                    row = new ArrayList<>();
                    if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                } else {
                    field.append(c);
                }
            }
        }
        if (field.length() > 0 || !row.isEmpty()) {
            row.add(field.toString().trim());
            records.add(row);
        }
        return records;
    }

    private static boolean isBlankRecord(List<String> rec) {
        for (String s : rec) if (s != null && !s.trim().isEmpty()) return false;
        return true;
    }

    private static String normalizeHeader(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT).replace(" ", "_");
    }

    private static String get(List<String> rec, Map<String, Integer> index, String key) {
        Integer i = index.get(key);
        if (i == null || i < 0 || i >= rec.size()) return "";
        String s = rec.get(i);
        return s == null ? "" : s.trim();
    }

    static Integer parsePrice(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty() || "-".equals(s) || "—".equals(s)) return null;
        String digits = s.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return null;
        try {
            long v = Long.parseLong(digits);
            if (v < 0 || v > Integer.MAX_VALUE) return null;
            return (int) v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static long parseDate(String raw) {
        if (raw == null || raw.trim().isEmpty()) return System.currentTimeMillis();
        String s = raw.trim();
        String[] patterns = {
                "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm",
                "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss", "yyyy/MM/dd"
        };
        for (String p : patterns) {
            try {
                SimpleDateFormat f = new SimpleDateFormat(p, Locale.JAPAN);
                f.setLenient(false);
                Date d = f.parse(s);
                if (d != null) return d.getTime();
            } catch (ParseException ignored) { }
        }
        return System.currentTimeMillis();
    }

    static final class Result {
        final List<Row> rows;
        final List<String> warnings;
        final long byteCount;
        Result(List<Row> rows, List<String> warnings, long byteCount) {
            this.rows = rows;
            this.warnings = warnings;
            this.byteCount = byteCount;
        }
    }

    static final class Row {
        int lineNumber;
        String store = "";
        String tag = "";
        String productName = "";
        String productKey = "";
        String priceRaw = "";
        Integer priceYen;
        String volume = "";
        String priceType = "";
        String capturedAtRaw = "";
        long capturedAt;
        String sourceImage = "";
    }
}
