package com.pricerec.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

final class CsvImporter {
    private CsvImporter() { }

    private static final List<String> PRICE_REC_HEADER = Arrays.asList(
            "store", "tag", "product_name", "product_key", "price", "volume", "price_type", "captured_at", "source_image");

    static Result parse(InputStream input) throws Exception {
        byte[] bytes = readAll(input);
        if (bytes.length == 0) throw new IllegalArgumentException("CSVが空です");
        String text = decodeUtf8Strict(bytes);
        return parseDecoded(text, bytes.length);
    }

    static Result parseText(String text) throws Exception {
        if (text == null || text.isEmpty()) throw new IllegalArgumentException("CSVが空です");
        return parseDecoded(text, text.getBytes(StandardCharsets.UTF_8).length);
    }

    private static Result parseDecoded(String sourceText, long byteCount) throws Exception {
        String text = sourceText;
        if (!text.isEmpty() && text.charAt(0) == '﻿') text = text.substring(1);
        text = stripCodeFence(text);
        List<List<String>> records = parseRecords(text);
        if (records.isEmpty()) throw new IllegalArgumentException("CSVが空です");

        List<String> header = records.get(0);
        ArrayList<String> normalized = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (String h : header) {
            String n = normalizeHeader(h);
            if (!seen.add(n)) throw new IllegalArgumentException("CSVヘッダーに重複列があります: " + n);
            normalized.add(n);
        }
        if (!normalized.equals(PRICE_REC_HEADER)) {
            throw new IllegalArgumentException("Price Rec.用CSVではありません。\n必要な列順: " + String.join(",", PRICE_REC_HEADER));
        }

        Map<String, Integer> index = new HashMap<>();
        for (int i = 0; i < normalized.size(); i++) index.put(normalized.get(i), i);

        ArrayList<Row> rows = new ArrayList<>();
        ArrayList<String> warnings = new ArrayList<>();
        for (int r = 1; r < records.size(); r++) {
            List<String> rec = records.get(r);
            if (isBlankRecord(rec)) continue;
            if (rec.size() != PRICE_REC_HEADER.size()) {
                throw new IllegalArgumentException("行" + (r + 1) + "の列数が不正です（" + rec.size() + "列）");
            }
            Row row = new Row();
            row.lineNumber = r + 1;
            row.store = get(rec, index, "store");
            row.tag = get(rec, index, "tag");
            row.productName = get(rec, index, "product_name");
            row.productKey = get(rec, index, "product_key");
            row.priceRaw = get(rec, index, "price");
            row.priceYen = parsePrice(row.priceRaw);
            row.volume = normalizeVolume(get(rec, index, "volume"));
            row.priceType = get(rec, index, "price_type");
            row.capturedAtRaw = get(rec, index, "captured_at");
            Long parsedCapturedAt = parseDateOrNull(row.capturedAtRaw);
            row.capturedAt = parsedCapturedAt == null ? System.currentTimeMillis() : parsedCapturedAt;
            row.sourceImage = get(rec, index, "source_image");

            if (row.store.isEmpty()) throw new IllegalArgumentException("行" + row.lineNumber + ": store が空欄です");
            if (row.productName.isEmpty()) throw new IllegalArgumentException("行" + row.lineNumber + ": product_name が空欄です");
            if (!row.priceRaw.isEmpty() && row.priceYen == null) {
                throw new IllegalArgumentException("行" + row.lineNumber + ": price が不正です: " + row.priceRaw);
            }
            if (!row.capturedAtRaw.isEmpty() && parsedCapturedAt == null) {
                throw new IllegalArgumentException("行" + row.lineNumber + ": captured_at が不正です: " + row.capturedAtRaw);
            }
            if (row.productKey.isEmpty()) row.productKey = row.productName;
            rows.add(row);
        }
        if (rows.isEmpty()) throw new IllegalArgumentException("データ行がありません");
        return new Result(rows, warnings, byteCount, sourceText);
    }

    private static String normalizeVolume(String value) {
        if (value == null) return "";
        String raw = value.trim();
        if (raw.isEmpty()) return "";
        String n = raw.replace('０', '0').replace('１', '1').replace('２', '2')
                .replace('３', '3').replace('４', '4').replace('５', '5').replace('６', '6')
                .replace('７', '7').replace('８', '8').replace('９', '9')
                .replace('．', '.').replace('，', ',').toLowerCase(Locale.ROOT)
                .replace(",", "").replace(" ", "");
        try {
            if (n.matches("[0-9]+(?:\\.[0-9]+)?l")) {
                double liters = Double.parseDouble(n.substring(0, n.length() - 1));
                return String.valueOf(Math.round(liters * 1000.0));
            }
            if (n.matches("[0-9]+(?:\\.[0-9]+)?(?:ml|ｍｌ)")) {
                String number = n.replaceAll("(?:ml|ｍｌ)$", "");
                return String.valueOf(Math.round(Double.parseDouble(number)));
            }
            if (n.matches("[0-9]+")) return n;
        } catch (Exception ignored) { }
        return n.replaceAll("[^0-9]", "");
    }

    private static String decodeUtf8Strict(byte[] bytes) throws CharacterCodingException {
        CharBuffer chars = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes));
        return chars.toString();
    }

    private static String stripCodeFence(String text) {
        String trimmed = text.trim();
        if (!trimmed.startsWith("```")) return text;
        int firstNl = trimmed.indexOf('\n');
        int last = trimmed.lastIndexOf("```");
        if (firstNl >= 0 && last > firstNl) return trimmed.substring(firstNl + 1, last).trim();
        return text;
    }

    private static byte[] readAll(InputStream input) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = input.read(buf)) >= 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private static List<List<String>> parseRecords(String text) {
        ArrayList<List<String>> records = new ArrayList<>();
        ArrayList<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        boolean justClosedQuote = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
                        field.append('"');
                        i++;
                    } else {
                        quoted = false;
                        justClosedQuote = true;
                    }
                } else {
                    field.append(c);
                }
            } else {
                if (c == '"' && field.length() == 0 && !justClosedQuote) {
                    quoted = true;
                } else if (c == ',') {
                    row.add(field.toString().trim());
                    field.setLength(0);
                    justClosedQuote = false;
                } else if (c == '\n' || c == '\r') {
                    row.add(field.toString().trim());
                    field.setLength(0);
                    records.add(row);
                    row = new ArrayList<>();
                    justClosedQuote = false;
                    if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                } else if (justClosedQuote) {
                    if (!Character.isWhitespace(c)) throw new IllegalArgumentException("引用符の後に不正な文字があります");
                } else {
                    field.append(c);
                }
            }
        }
        if (quoted) throw new IllegalArgumentException("CSVの引用符が閉じられていません");
        if (field.length() > 0 || !row.isEmpty() || justClosedQuote) {
            row.add(field.toString().trim());
            records.add(row);
        }
        return records;
    }

    private static boolean isBlankRecord(List<String> rec) {
        for (String s : rec) if (s != null && !s.trim().isEmpty()) return false;
        return true;
    }

    private static String normalizeHeader(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT).replace(" ", "_");
    }

    private static String get(List<String> rec, Map<String, Integer> index, String key) {
        Integer i = index.get(key);
        if (i == null || i < 0 || i >= rec.size()) return "";
        String s = rec.get(i);
        return s == null ? "" : s.trim();
    }

    static Integer parsePrice(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty() || "-".equals(s) || "—".equals(s)) return null;
        if (!s.matches("[0-9,￥¥円\s]+")) return null;
        String digits = s.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return null;
        try {
            long v = Long.parseLong(digits);
            if (v < 0 || v > Integer.MAX_VALUE) return null;
            return (int) v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Long parseDateOrNull(String raw) {
        if (raw == null || raw.trim().isEmpty()) return null;
        String s = raw.trim();
        String[] patterns = {
                "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm",
                "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss", "yyyy/MM/dd", "yyyy-MM-dd"
        };
        for (String p : patterns) {
            try {
                SimpleDateFormat f = new SimpleDateFormat(p, Locale.JAPAN);
                f.setLenient(false);
                Date d = f.parse(s);
                if (d != null) return d.getTime();
            } catch (ParseException ignored) { }
        }
        return null;
    }

    static final class Result {
        final List<Row> rows;
        final List<String> warnings;
        final long byteCount;
        final String rawText;
        Result(List<Row> rows, List<String> warnings, long byteCount, String rawText) {
            this.rows = rows;
            this.warnings = warnings;
            this.byteCount = byteCount;
            this.rawText = rawText;
        }
    }

    static final class Row {
        int lineNumber;
        String store = "";
        String tag = "";
        String productName = "";
        String productKey = "";
        String priceRaw = "";
        Integer priceYen;
        String volume = "";
        String priceType = "";
        String capturedAtRaw = "";
        long capturedAt;
        String sourceImage = "";
    }
}
