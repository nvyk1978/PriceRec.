package com.pricerec.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.animation.DecelerateInterpolator;
import android.widget.CompoundButton;

/**
 * Price Rec. N toggle, based on the established FinderlessCamera v0.1.92 control.
 * It is fully custom drawn: no platform Switch track/thumb is used.
 */
public final class NToggleSwitch extends CompoundButton {
    private static final int TRACK_COLOR = Color.rgb(37, 32, 32); // #252020
    private static final long ANIMATION_MS = 120L;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DecelerateInterpolator interpolator = new DecelerateInterpolator();

    private int onThumbColor = Color.rgb(119, 85, 0);   // #775500
    private int offThumbColor = Color.rgb(85, 51, 0);   // #553300
    private float progress;
    private ValueAnimator animator;
    private boolean attached;
    private boolean downInside;

    public NToggleSwitch(Context context) {
        this(context, null);
    }

    public NToggleSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
        setButtonDrawable(null);
        setText(null);
        setPadding(0, 0, 0, 0);
        setMinWidth(dp(44));
        setMinHeight(dp(24));
        setMinimumWidth(dp(44));
        setMinimumHeight(dp(24));
        setClickable(true);
        setFocusable(true);
        trackPaint.setStyle(Paint.Style.FILL);
        thumbPaint.setStyle(Paint.Style.FILL);
        progress = isChecked() ? 1f : 0f;
    }

    public void setNColors(int onColor, int offColor) {
        onThumbColor = onColor;
        offThumbColor = offColor;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        progress = isChecked() ? 1f : 0f;
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        attached = false;
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    public void setChecked(boolean checked) {
        boolean changed = checked != isChecked();
        super.setChecked(checked);
        float target = checked ? 1f : 0f;
        if (!attached || !changed) {
            progress = target;
            invalidate();
            return;
        }
        if (animator != null) animator.cancel();
        animator = ValueAnimator.ofFloat(progress, target);
        animator.setDuration(ANIMATION_MS);
        animator.setInterpolator(interpolator);
        animator.addUpdateListener(a -> {
            progress = (Float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(resolveSize(dp(44), widthMeasureSpec), resolveSize(dp(24), heightMeasureSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float trackW = dp(44);
        final float trackH = dp(24);
        final float left = (getWidth() - trackW) / 2f;
        final float top = (getHeight() - trackH) / 2f;
        final float radius = trackH / 2f;

        trackPaint.setColor(TRACK_COLOR);
        canvas.drawRoundRect(left, top, left + trackW, top + trackH, radius, radius, trackPaint);

        final float thumbD = dp(isChecked() ? 26 : 24);
        final float x = left + (trackW - thumbD) * progress;
        final float cy = top + trackH / 2f;
        thumbPaint.setColor(isChecked() ? onThumbColor : offThumbColor);
        canvas.drawCircle(x + thumbD / 2f, cy, thumbD / 2f, thumbPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downInside = true;
                setPressed(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                downInside = event.getX() >= 0 && event.getX() <= getWidth()
                        && event.getY() >= 0 && event.getY() <= getHeight();
                setPressed(downInside);
                return true;
            case MotionEvent.ACTION_UP:
                setPressed(false);
                if (downInside) {
                    playSoundEffect(SoundEffectConstants.CLICK);
                    performClick();
                }
                downInside = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                setPressed(false);
                downInside = false;
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
