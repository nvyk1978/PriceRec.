package com.pricerec.app;

import android.content.Context;
import android.graphics.Rect;
import android.net.Uri;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class OcrEngine {
    interface Callback {
        void onSuccess(String rawText, List<DatabaseHelper.ProductInput> products);
        void onError(Exception error);
    }

    private static final Pattern CURRENCY_PRICE = Pattern.compile(
            "(?:[¥￥]|\\b(?:JPY)\\b)\\s*([0-9０-９][0-9０-９,，.．\\s]{1,9})|([0-9０-９][0-9０-９,，.．\\s]{1,9})\\s*円",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern BARE_NUMBER = Pattern.compile("(?<![0-9０-９])([0-9０-９][0-9０-９,，]{2,8})(?![0-9０-９])");
    private static final Pattern NON_PRODUCT_HINT = Pattern.compile("(?i)(税込|税抜|本体価格|特価|価格|円|ポイント|OFF|%|ml|mL|L|g|kg|個|本|枚|年)");

    private OcrEngine() { }

    static void recognize(Context context, Uri uri, Callback callback) {
        try {
            InputImage image = InputImage.fromFilePath(context, uri);
            TextRecognizer recognizer = TextRecognition.getClient(
                    new JapaneseTextRecognizerOptions.Builder().build());
            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        try {
                            callback.onSuccess(result.getText(), parse(result));
                        } catch (Exception e) {
                            callback.onError(e);
                        } finally {
                            recognizer.close();
                        }
                    })
                    .addOnFailureListener(e -> {
                        recognizer.close();
                        callback.onError(e);
                    });
        } catch (Exception e) {
            callback.onError(e);
        }
    }

    private static List<DatabaseHelper.ProductInput> parse(Text result) {
        ArrayList<LineInfo> lines = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String t = clean(line.getText());
                Rect box = line.getBoundingBox();
                if (!t.isEmpty() && box != null) lines.add(new LineInfo(t, new Rect(box)));
            }
        }
        lines.sort(Comparator.comparingInt((LineInfo l) -> l.box.top).thenComparingInt(l -> l.box.left));

        ArrayList<DatabaseHelper.ProductInput> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < lines.size(); i++) {
            LineInfo priceLine = lines.get(i);
            PriceHit hit = findPrice(priceLine.text);
            if (hit == null) continue;

            String inlineName = clean(priceLine.text.substring(0, hit.start) + " " + priceLine.text.substring(hit.end));
            inlineName = stripPriceNoise(inlineName);
            String name = looksLikeProductName(inlineName) ? inlineName : chooseNearbyName(lines, i, priceLine);
            if (name == null || name.isEmpty()) continue;

            String key = DatabaseHelper.normalizeName(name) + "#" + hit.price;
            if (!seen.add(key)) continue;
            out.add(new DatabaseHelper.ProductInput(name, hit.price, null));
        }

        if (out.isEmpty()) {
            // Fallback: OCR rows that look like product names are kept without a price so the user can correct them.
            int count = 0;
            for (LineInfo line : lines) {
                String t = stripPriceNoise(line.text);
                if (looksLikeProductName(t) && findPrice(line.text) == null) {
                    String key = DatabaseHelper.normalizeName(t) + "#null";
                    if (seen.add(key)) {
                        out.add(new DatabaseHelper.ProductInput(t, null, null));
                        if (++count >= 20) break;
                    }
                }
            }
        }
        return out;
    }

    private static String chooseNearbyName(List<LineInfo> lines, int priceIndex, LineInfo priceLine) {
        double bestScore = Double.MAX_VALUE;
        String best = null;
        int pcx = priceLine.box.centerX();
        int pcy = priceLine.box.centerY();
        int ph = Math.max(1, priceLine.box.height());

        for (int i = Math.max(0, priceIndex - 8); i <= Math.min(lines.size() - 1, priceIndex + 4); i++) {
            if (i == priceIndex) continue;
            LineInfo candidate = lines.get(i);
            String t = stripPriceNoise(candidate.text);
            if (!looksLikeProductName(t) || findPrice(candidate.text) != null) continue;

            int cx = candidate.box.centerX();
            int cy = candidate.box.centerY();
            int vertical = Math.abs(pcy - cy);
            if (vertical > ph * 7 + 120) continue;

            boolean above = candidate.box.bottom <= priceLine.box.bottom;
            double horizontal = Math.abs(pcx - cx) * 0.35;
            double score = vertical + horizontal + (above ? 0 : ph * 2.5);
            if (score < bestScore) {
                bestScore = score;
                best = t;
            }
        }
        return best;
    }

    private static PriceHit findPrice(String original) {
        String text = normalizeDigits(original);
        Matcher currency = CURRENCY_PRICE.matcher(text);
        if (currency.find()) {
            String number = currency.group(1) != null ? currency.group(1) : currency.group(2);
            Integer price = parsePrice(number);
            if (price != null) return new PriceHit(price, currency.start(), currency.end());
        }

        if (NON_PRODUCT_HINT.matcher(text).find() && !text.matches(".*(?:税込|税抜|本体価格|特価|価格).*")) {
            return null;
        }
        Matcher bare = BARE_NUMBER.matcher(text);
        while (bare.find()) {
            Integer price = parsePrice(bare.group(1));
            if (price != null && price >= 100 && price <= 9_999_999) {
                String around = text.substring(Math.max(0, bare.start() - 4), Math.min(text.length(), bare.end() + 4));
                if (!around.matches("(?i).*(?:ml|mL|kg|g|年|%|本|個).*")) {
                    return new PriceHit(price, bare.start(), bare.end());
                }
            }
        }
        return null;
    }

    private static Integer parsePrice(String s) {
        if (s == null) return null;
        String digits = normalizeDigits(s).replaceAll("[^0-9]", "");
        if (digits.length() < 3 || digits.length() > 7) return null;
        try {
            int value = Integer.parseInt(digits);
            return value >= 100 && value <= 9_999_999 ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static boolean looksLikeProductName(String s) {
        if (s == null) return false;
        String t = clean(s);
        if (t.length() < 2 || t.length() > 70) return false;
        if (t.matches("^[0-9０-９,，.．¥￥円\\s%]+$")) return false;
        if (t.matches("(?i)^(税込|税抜|本体価格|特価|価格|SALE|OFF|おすすめ|広告の品)$")) return false;
        int letters = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (Character.isLetter(c) || (c >= 0x3040 && c <= 0x30ff) || (c >= 0x4e00 && c <= 0x9fff)) letters++;
        }
        return letters >= 2;
    }

    private static String stripPriceNoise(String s) {
        String t = clean(s)
                .replaceAll("(?i)税込|税抜|本体価格|特価|価格|SALE|OFF", " ")
                .replaceAll("[¥￥]", " ")
                .replaceAll("\\s+", " ")
                .trim();
        return t;
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\u3000', ' ').replaceAll("\\s+", " ").trim();
    }

    private static String normalizeDigits(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '０' && c <= '９') b.append((char) ('0' + (c - '０')));
            else if (c == '，') b.append(',');
            else if (c == '．') b.append('.');
            else b.append(c);
        }
        return b.toString();
    }

    private static final class LineInfo {
        final String text;
        final Rect box;
        LineInfo(String text, Rect box) { this.text = text; this.box = box; }
    }

    private static final class PriceHit {
        final int price;
        final int start;
        final int end;
        PriceHit(int price, int start, int end) { this.price = price; this.start = start; this.end = end; }
    }
}
