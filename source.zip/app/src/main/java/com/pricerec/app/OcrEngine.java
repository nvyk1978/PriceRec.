package com.pricerec.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.util.Size;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Price Rec shelf-photo OCR pipeline.
 *
 * v0.1.6 changes the strategy from "read everything and pair nearby text" to
 * "find stable price anchors first, then OCR a small shelf-label region around
 * each anchor".  The goal is precision rather than recall: a doubtful row is
 * discarded instead of being promoted to a product.
 */
final class OcrEngine {
    interface Callback {
        void onSuccess(String rawText, List<DatabaseHelper.ProductInput> products);
        void onError(Exception error);
    }

    private static final int MAX_DECODE_LONG_EDGE = 4096;
    private static final int MAX_COARSE_LONG_EDGE = 3200;
    private static final int MAX_LABEL_LONG_EDGE = 1700;
    private static final int MAX_LABEL_JOBS = 24;
    private static final int MAX_PRODUCTS = 60;

    private static final Pattern TAX_INCLUDED_PRICE = Pattern.compile(
            "(?:税込|税込価格|総額)[^0-9０-９¥￥]{0,5}[¥￥]?\\s*([0-9０-９OoIl|][0-9０-９OoIl|,，.．\\s]{0,9})",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern CURRENCY_PRICE = Pattern.compile(
            "[¥￥]\\s*([0-9０-９OoIl|][0-9０-９OoIl|,，.．\\s]{0,9})|"
                    + "([0-9０-９OoIl|][0-9０-９OoIl|,，.．\\s]{0,9})\\s*円",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern LABELED_PRICE = Pattern.compile(
            "(?:本体価格|本体|税抜価格|税抜|価格|特価|売価)\\s*[:：]?\\s*[¥￥]?\\s*"
                    + "([0-9０-９OoIl|][0-9０-９OoIl|,，.．\\s]{0,9})",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern BARE_NUMBER = Pattern.compile(
            "(?<![0-9０-９])([0-9０-９][0-9０-９,，]{1,6})(?![0-9０-９])");

    private static final Pattern BARCODE = Pattern.compile("(?<!\\d)\\d{8,14}(?!\\d)");
    private static final Pattern DATE_LIKE = Pattern.compile(
            "(?:20\\d{2}[年/.-]\\d{1,2}|\\d{1,2}\\s*月\\s*\\d{0,2}\\s*日|"
                    + "\\d{1,2}[/-]\\d{1,2}|(?:月|火|水|木|金|土|日)曜)");
    private static final Pattern DAY_FRAGMENT = Pattern.compile("^[\\s日月火水木金土曜()（）]+$");
    private static final Pattern CAPACITY_ONLY = Pattern.compile(
            "(?i)^\\s*\\d+(?:[.,]\\d+)?\\s*(?:ml|mL|cl|l|L|g|kg|個|本|枚|袋|缶|本入|個入)\\s*$");

    private static final Pattern PROMO_OR_NOTICE = Pattern.compile(
            "(?:割引|値引|引き|OFF|%引|ポイント|クーポン|セール|SALE|"
                    + "広告の品|お買得|お買い得|おすすめ|限定|今週|本日|\\d{1,3}\\s*引|"
                    + "変更いた|変更し|ご了承ください|ご了承|ご容赦|"
                    + "より変更|まで|レジにて|会員価格|通常価格|参考価格|"
                    + "品切|売切|入荷|予約|サービス|キャンペーン|販売|売価|売場)",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern SENTENCE_END = Pattern.compile(
            "(?:ます[。.!！]?|です[。.!！]?|ください[。.!！]?|いたします[。.!！]?|"
                    + "となります[。.!！]?|願います[。.!！]?)$");

    private static final Pattern GENERIC_PACKAGING = Pattern.compile(
            "(?i)^(?:BLENDED\\s+)?SCOTCH\\s+WHISKY$|^(?:SCOTCH|BLENDED)\\s+WHISKY$|"
                    + "^[A-Z]{3,10}ED\\s+SCOTCH\\s+WHISKY$|"
                    + "^スコッチウイスキー(?:ブランド)?$|^ウイスキーブランド$|"
                    + "^(?:原産国|販売者|輸入者|製造者|アルコール分|ALC\\.?)[\\s:：0-9.%％]*$");

    private static final Pattern COMMON_PRODUCT_WORDS = Pattern.compile(
            "(?:ウイスキー|whisky|whiskey|ワイン|wine|ビール|beer|日本酒|清酒|焼酎|"
                    + "ジン|gin|ラム|rum|テキーラ|tequila|リキュール|ブランデー|シャンパン|"
                    + "ブリュット|ロゼ|カベルネ|シャルドネ|メルロー|ピノ|"
                    + "醤油|しょうゆ|味噌|みそ|ソース|ドレッシング|オイル|油|酢|塩|砂糖|"
                    + "牛|豚|鶏|ロース|バラ|モモ|もも|ひき肉|挽肉|ステーキ)",
            Pattern.CASE_INSENSITIVE);

    private OcrEngine() { }

    static void recognize(Context context, Uri uri, Callback callback) {
        recognize(context, uri, null, callback);
    }

    static void recognize(Context context, Uri uri, String tagName, Callback callback) {
        final TextRecognizer recognizer = TextRecognition.getClient(
                new JapaneseTextRecognizerOptions.Builder().build());

        Bitmap base = null;
        try {
            base = decodeBaseBitmap(context, uri);
        } catch (Exception e) {
            DiagLog.write(context, "OCR_DECODE_FALLBACK err=" + e.getClass().getSimpleName());
        }

        if (base == null) {
            recognizeFallback(context, uri, tagName, recognizer, callback);
            return;
        }

        PipelineState state = new PipelineState(context, callback, recognizer, base, tagName);
        state.coarseSpecs.addAll(buildCoarsePasses(base.getWidth(), base.getHeight()));
        DiagLog.write(context, "OCR_PIPELINE_START mode=label-anchor-v2 size="
                + base.getWidth() + "x" + base.getHeight()
                + " coarsePasses=" + state.coarseSpecs.size() + " tag=" + safe(tagName));
        runNextCoarsePass(state);
    }

    private static Bitmap decodeBaseBitmap(Context context, Uri uri) throws Exception {
        ImageDecoder.Source source = ImageDecoder.createSource(context.getContentResolver(), uri);
        return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            Size size = info.getSize();
            int w = size.getWidth();
            int h = size.getHeight();
            int longest = Math.max(w, h);
            if (longest > MAX_DECODE_LONG_EDGE) {
                float scale = MAX_DECODE_LONG_EDGE / (float) longest;
                decoder.setTargetSize(Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)));
            }
        });
    }

    private static void recognizeFallback(
            Context context,
            Uri uri,
            String tagName,
            TextRecognizer recognizer,
            Callback callback) {
        try {
            InputImage image = InputImage.fromFilePath(context, uri);
            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        try {
                            ArrayList<LineInfo> lines = linesFrom(result, null);
                            ArrayList<DatabaseHelper.ProductInput> products = new ArrayList<>();
                            for (LineInfo priceLine : lines) {
                                PriceHit p = findBestPrice(priceLine.text);
                                if (p == null || (!p.explicit && (p.price < 50 || p.price > 9999))) continue;
                                NameHit n = chooseProductName(lines, priceLine, p, tagName, true);
                                if (n == null) continue;
                                String name = cleanupProductName(n.name);
                                float q = nameQuality(name, tagName);
                                if (q < 4.2f) continue;
                                products.add(new DatabaseHelper.ProductInput(name, p.price, 0.40f));
                                if (products.size() >= 12) break;
                            }
                            DiagLog.write(context, "OCR_FALLBACK_OK accepted=" + products.size());
                            callback.onSuccess(result.getText(), products);
                        } catch (Exception e) {
                            callback.onError(e);
                        } finally {
                            recognizer.close();
                        }
                    })
                    .addOnFailureListener(e -> {
                        recognizer.close();
                        callback.onError(e);
                    });
        } catch (Exception e) {
            recognizer.close();
            callback.onError(e);
        }
    }

    private static List<PassSpec> buildCoarsePasses(int width, int height) {
        ArrayList<PassSpec> out = new ArrayList<>();
        out.add(new PassSpec("full", 0f, 0f, 1f, 1f, false));
        out.add(new PassSpec("full-contrast", 0f, 0f, 1f, 1f, true));

        if (width < 700 || height < 700) return out;

        if (height > width * 1.15f) {
            float[] xs0 = {0f, 0.42f};
            float[] xs1 = {0.58f, 1f};
            float[] ys0 = {0f, 0.29f, 0.58f};
            float[] ys1 = {0.42f, 0.71f, 1f};
            int n = 1;
            for (int y = 0; y < ys0.length; y++) {
                for (int x = 0; x < xs0.length; x++) {
                    out.add(new PassSpec("tile-" + n++, xs0[x], ys0[y], xs1[x], ys1[y], true));
                }
            }
        } else {
            out.add(new PassSpec("tile-1", 0f, 0f, 0.58f, 0.58f, true));
            out.add(new PassSpec("tile-2", 0.42f, 0f, 1f, 0.58f, true));
            out.add(new PassSpec("tile-3", 0f, 0.42f, 0.58f, 1f, true));
            out.add(new PassSpec("tile-4", 0.42f, 0.42f, 1f, 1f, true));
        }
        return out;
    }

    private static void runNextCoarsePass(PipelineState state) {
        if (state.coarseIndex >= state.coarseSpecs.size()) {
            finishCoarseStage(state);
            return;
        }

        PassSpec spec = state.coarseSpecs.get(state.coarseIndex++);
        Bitmap passBitmap = null;
        try {
            passBitmap = renderPass(state.base, spec, MAX_COARSE_LONG_EDGE);
            final Bitmap bitmapForTask = passBitmap;
            final CoordinateMapper mapper = new CoordinateMapper(
                    spec,
                    state.base.getWidth(),
                    state.base.getHeight(),
                    bitmapForTask.getWidth(),
                    bitmapForTask.getHeight());

            state.recognizer.process(InputImage.fromBitmap(bitmapForTask, 0))
                    .addOnSuccessListener(result -> {
                        try {
                            state.successfulCoarsePasses++;
                            state.raw.append("[").append(spec.name).append("]\n")
                                    .append(result.getText()).append("\n\n");
                            ArrayList<PriceAnchor> found = collectPriceAnchors(result, mapper, spec.name);
                            state.anchors.addAll(found);
                            DiagLog.write(state.context, "OCR_ANCHOR_PASS_OK " + spec.name
                                    + " anchors=" + found.size());
                        } catch (Exception e) {
                            state.lastError = e;
                            DiagLog.write(state.context, "OCR_ANCHOR_PASS_PARSE_ERROR " + spec.name
                                    + " err=" + e.getClass().getSimpleName());
                        } finally {
                            if (!bitmapForTask.isRecycled()) bitmapForTask.recycle();
                            runNextCoarsePass(state);
                        }
                    })
                    .addOnFailureListener(e -> {
                        state.lastError = e;
                        DiagLog.write(state.context, "OCR_ANCHOR_PASS_ERROR " + spec.name
                                + " err=" + e.getClass().getSimpleName());
                        if (!bitmapForTask.isRecycled()) bitmapForTask.recycle();
                        runNextCoarsePass(state);
                    });
        } catch (Exception e) {
            state.lastError = e;
            if (passBitmap != null && !passBitmap.isRecycled()) passBitmap.recycle();
            DiagLog.write(state.context, "OCR_ANCHOR_PASS_BUILD_ERROR " + spec.name
                    + " err=" + e.getClass().getSimpleName());
            runNextCoarsePass(state);
        }
    }

    private static void finishCoarseStage(PipelineState state) {
        if (state.successfulCoarsePasses == 0) {
            finishError(state, state.lastError != null ? state.lastError
                    : new IllegalStateException("No coarse OCR pass completed"));
            return;
        }

        List<VerifiedAnchor> verified = verifyAnchors(
                state.anchors, state.base.getWidth(), state.base.getHeight(), state.context);

        int count = Math.min(MAX_LABEL_JOBS, verified.size());
        for (int i = 0; i < count; i++) {
            VerifiedAnchor anchor = verified.get(i);
            RectF crop = makeLabelCrop(anchor.box, state.base.getWidth(), state.base.getHeight());
            state.labelJobs.add(new LabelJob(i + 1, anchor, crop));
        }

        DiagLog.write(state.context, "OCR_LABEL_STAGE anchorsRaw=" + state.anchors.size()
                + " anchorsVerified=" + verified.size()
                + " labelJobs=" + state.labelJobs.size());

        if (state.labelJobs.isEmpty()) {
            finishSuccess(state, new ArrayList<>());
            return;
        }
        runNextLabelPass(state);
    }

    private static void runNextLabelPass(PipelineState state) {
        if (state.labelIndex >= state.labelJobs.size()) {
            List<DatabaseHelper.ProductInput> products = finalizeLabelJobs(state.labelJobs, state.context, state.tagName);
            finishSuccess(state, products);
            return;
        }

        LabelJob job = state.labelJobs.get(state.labelIndex);
        boolean contrast = job.localPass == 1;
        String passName = contrast ? "contrast" : "color";
        Bitmap cropBitmap = null;

        try {
            cropBitmap = renderCrop(state.base, job.crop, contrast);
            final Bitmap bitmapForTask = cropBitmap;
            final CropMapper mapper = new CropMapper(job.crop,
                    bitmapForTask.getWidth(), bitmapForTask.getHeight());

            if (job.localPass == 0) {
                DiagLog.write(state.context, "OCR_LABEL_START id=" + job.id
                        + " anchor=" + job.anchor.price
                        + " support=" + job.anchor.priceSupport
                        + " crop=" + rectString(job.crop));
            }

            state.recognizer.process(InputImage.fromBitmap(bitmapForTask, 0))
                    .addOnSuccessListener(result -> {
                        try {
                            state.raw.append("[label-").append(job.id).append('-').append(passName).append("]\n")
                                    .append(result.getText()).append("\n\n");
                            ArrayList<LocalDetection> found = collectLocalDetections(
                                    result, mapper, job, passName, state.tagName);
                            job.candidates.addAll(found);
                            DiagLog.write(state.context, "OCR_LABEL_PASS_OK id=" + job.id
                                    + " pass=" + passName + " candidates=" + found.size());
                        } catch (Exception e) {
                            state.lastError = e;
                            DiagLog.write(state.context, "OCR_LABEL_PASS_PARSE_ERROR id=" + job.id
                                    + " pass=" + passName + " err=" + e.getClass().getSimpleName());
                        } finally {
                            if (!bitmapForTask.isRecycled()) bitmapForTask.recycle();
                            advanceLabelPass(state, job);
                        }
                    })
                    .addOnFailureListener(e -> {
                        state.lastError = e;
                        DiagLog.write(state.context, "OCR_LABEL_PASS_ERROR id=" + job.id
                                + " pass=" + passName + " err=" + e.getClass().getSimpleName());
                        if (!bitmapForTask.isRecycled()) bitmapForTask.recycle();
                        advanceLabelPass(state, job);
                    });
        } catch (Exception e) {
            state.lastError = e;
            if (cropBitmap != null && !cropBitmap.isRecycled()) cropBitmap.recycle();
            DiagLog.write(state.context, "OCR_LABEL_PASS_BUILD_ERROR id=" + job.id
                    + " pass=" + passName + " err=" + e.getClass().getSimpleName());
            advanceLabelPass(state, job);
        }
    }

    private static void advanceLabelPass(PipelineState state, LabelJob job) {
        job.localPass++;
        if (job.localPass >= 2) {
            state.labelIndex++;
        }
        runNextLabelPass(state);
    }

    private static void finishSuccess(PipelineState state, List<DatabaseHelper.ProductInput> products) {
        try {
            DiagLog.write(state.context, "OCR_PIPELINE_OK mode=label-anchor-v2 coarsePasses="
                    + state.successfulCoarsePasses
                    + " anchorsRaw=" + state.anchors.size()
                    + " labels=" + state.labelJobs.size()
                    + " accepted=" + products.size()
                    + " tag=" + safe(state.tagName));
            state.callback.onSuccess(state.raw.toString(), products);
        } finally {
            state.recognizer.close();
            if (!state.base.isRecycled()) state.base.recycle();
        }
    }

    private static void finishError(PipelineState state, Exception error) {
        try {
            state.callback.onError(error);
        } finally {
            state.recognizer.close();
            if (!state.base.isRecycled()) state.base.recycle();
        }
    }

    private static ArrayList<PriceAnchor> collectPriceAnchors(
            Text result, CoordinateMapper mapper, String passName) {
        ArrayList<PriceAnchor> out = new ArrayList<>();
        for (LineInfo line : linesFrom(result, mapper)) {
            PriceHit hit = findBestPrice(line.text);
            if (hit == null) continue;

            if (!hit.explicit) {
                // Bare numbers are only allowed in ordinary shelf-price range.  Five-digit
                // naked numbers are overwhelmingly JAN fragments or OCR concatenations.
                if (hit.price < 50 || hit.price > 9999) continue;
                String compact = normalizeDigitsOnly(line.text).replaceAll("[^0-9]", "");
                if (compact.length() < 2 || compact.length() > 4) continue;
            }

            RectF priceBox = approximatePriceBox(line.box, line.text, hit);
            out.add(new PriceAnchor(hit.price, hit.strength, hit.explicit, priceBox, passName));
        }
        return out;
    }

    private static List<VerifiedAnchor> verifyAnchors(
            List<PriceAnchor> anchors, int imageWidth, int imageHeight, Context context) {
        ArrayList<AnchorCluster> clusters = new ArrayList<>();
        float closeDistance = Math.max(42f, Math.min(imageWidth, imageHeight) * 0.042f);

        ArrayList<PriceAnchor> ordered = new ArrayList<>(anchors);
        ordered.sort(Comparator.comparingDouble((PriceAnchor a) -> a.box.top)
                .thenComparingDouble(a -> a.box.left));

        for (PriceAnchor a : ordered) {
            AnchorCluster target = null;
            for (AnchorCluster c : clusters) {
                if (sameAnchorObservation(c, a, closeDistance)) {
                    target = c;
                    break;
                }
            }
            if (target == null) {
                target = new AnchorCluster();
                clusters.add(target);
            }
            target.items.add(a);
        }

        ArrayList<VerifiedAnchor> out = new ArrayList<>();
        int rejectedAmbiguous = 0;
        int rejectedWeak = 0;

        for (AnchorCluster c : clusters) {
            Map<Integer, Float> votes = new HashMap<>();
            Map<Integer, Set<String>> passVotes = new HashMap<>();
            Map<Integer, Boolean> explicitVotes = new HashMap<>();

            for (PriceAnchor a : c.items) {
                float vote = a.strength + (a.explicit ? 1.7f : 0f);
                votes.put(a.price, votes.getOrDefault(a.price, 0f) + vote);
                passVotes.computeIfAbsent(a.price, k -> new HashSet<>()).add(a.passName);
                if (a.explicit) explicitVotes.put(a.price, true);
            }

            int chosenPrice = -1;
            float bestVote = -1f;
            for (Map.Entry<Integer, Float> e : votes.entrySet()) {
                if (e.getValue() > bestVote) {
                    bestVote = e.getValue();
                    chosenPrice = e.getKey();
                }
            }
            if (chosenPrice < 0) continue;

            int support = passVotes.get(chosenPrice).size();
            boolean explicit = explicitVotes.getOrDefault(chosenPrice, false);

            // A bare price must independently survive at least two coarse passes.
            // An explicit ¥/円/税込 price may survive a single pass.
            if (!explicit && support < 2) {
                rejectedWeak++;
                continue;
            }

            // If two different naked prices occupy the same location with equal support,
            // treat the label as ambiguous instead of guessing.
            int secondSupport = 0;
            for (Map.Entry<Integer, Set<String>> e : passVotes.entrySet()) {
                if (e.getKey() == chosenPrice) continue;
                secondSupport = Math.max(secondSupport, e.getValue().size());
            }
            if (!explicit && secondSupport >= support) {
                rejectedAmbiguous++;
                continue;
            }

            RectF merged = null;
            float strength = 0f;
            for (PriceAnchor a : c.items) {
                if (a.price != chosenPrice) continue;
                merged = merged == null ? copyRect(a.box) : unionRect(merged, a.box);
                strength = Math.max(strength, a.strength);
            }
            if (merged == null) continue;

            out.add(new VerifiedAnchor(chosenPrice, explicit, support, strength, merged));
        }

        out.sort(Comparator.comparingDouble((VerifiedAnchor a) -> a.box.top)
                .thenComparingDouble(a -> a.box.left));

        DiagLog.write(context, "OCR_ANCHOR_CLUSTER clusters=" + clusters.size()
                + " verified=" + out.size()
                + " rejectedWeak=" + rejectedWeak
                + " rejectedAmbiguous=" + rejectedAmbiguous);
        return out;
    }

    private static boolean sameAnchorObservation(AnchorCluster cluster, PriceAnchor a, float closeDistance) {
        for (PriceAnchor b : cluster.items) {
            float dx = b.box.centerX() - a.box.centerX();
            float dy = b.box.centerY() - a.box.centerY();
            float distance = (float) Math.sqrt(dx * dx + dy * dy);
            if (distance > closeDistance) continue;

            if (b.price == a.price) return true;
            float max = Math.max(b.price, a.price);
            float diff = Math.abs(b.price - a.price) / Math.max(1f, max);
            if (diff <= 0.18f) return true;
        }
        return false;
    }

    private static RectF makeLabelCrop(RectF priceBox, int imageWidth, int imageHeight) {
        float ph = Math.max(20f, priceBox.height());
        float pw = Math.max(40f, priceBox.width());

        float leftPad = Math.max(420f, Math.min(imageWidth * 0.26f, pw * 7.2f));
        float rightPad = Math.max(120f, Math.min(imageWidth * 0.08f, pw * 1.8f));
        float topPad = Math.max(150f, Math.min(imageHeight * 0.15f, ph * 5.2f));
        float bottomPad = Math.max(80f, Math.min(imageHeight * 0.08f, ph * 2.3f));

        float left = Math.max(0f, priceBox.left - leftPad);
        float right = Math.min(imageWidth, priceBox.right + rightPad);
        float top = Math.max(0f, priceBox.top - topPad);
        float bottom = Math.min(imageHeight, priceBox.bottom + bottomPad);

        return new RectF(left, top, Math.max(left + 1f, right), Math.max(top + 1f, bottom));
    }

    private static ArrayList<LocalDetection> collectLocalDetections(
            Text result,
            CropMapper mapper,
            LabelJob job,
            String localPass,
            String tagName) {
        ArrayList<LineInfo> lines = linesFrom(result, mapper);
        ArrayList<LocalDetection> out = new ArrayList<>();

        for (LineInfo priceLine : lines) {
            PriceHit price = findBestPrice(priceLine.text);
            if (price == null) continue;
            if (!price.explicit && (price.price < 50 || price.price > 9999)) continue;

            RectF localPriceBox = approximatePriceBox(priceLine.box, priceLine.text, price);
            float distance = centerDistance(localPriceBox, job.anchor.box);
            float allowed = Math.max(180f, Math.max(job.anchor.box.height() * 7f, job.crop.width() * 0.34f));
            if (distance > allowed) continue;

            float priceAgreement = priceAgreement(job.anchor.price, price.price);
            if (!price.explicit && priceAgreement < 0.35f) continue;
            if (price.explicit && priceAgreement < -0.4f) continue;

            NameHit nameHit = chooseProductName(lines, priceLine, price, tagName, true);
            if (nameHit == null) continue;

            String name = cleanupProductName(nameHit.name);
            float q = nameQuality(name, tagName);
            if (q < 3.8f) continue;

            float score = q * 1.45f
                    + nameHit.geometryScore
                    + price.strength
                    + priceAgreement
                    + (price.explicit ? 0.8f : 0f);
            if (score < 9.0f) continue;

            out.add(new LocalDetection(
                    name,
                    price.price,
                    price.explicit,
                    q,
                    score,
                    localPriceBox,
                    localPass));
        }
        return out;
    }

    private static float priceAgreement(int anchor, int candidate) {
        if (anchor == candidate) return 3.0f;
        float max = Math.max(anchor, candidate);
        float diff = Math.abs(anchor - candidate) / Math.max(1f, max);
        if (diff <= 0.01f) return 2.0f;
        if (diff <= 0.03f) return 1.0f;
        if (diff <= 0.08f) return 0.35f;
        if (diff <= 0.20f) return -0.35f;
        return -1.5f;
    }

    private static List<DatabaseHelper.ProductInput> finalizeLabelJobs(
            List<LabelJob> jobs, Context context, String tagName) {
        ArrayList<AcceptedProduct> accepted = new ArrayList<>();
        Set<String> seen = new HashSet<>();

        for (LabelJob job : jobs) {
            AcceptedProduct p = chooseLabelResult(job, tagName);
            if (p == null) {
                DiagLog.write(context, "OCR_LABEL_REJECT id=" + job.id
                        + " anchor=" + job.anchor.price
                        + " candidates=" + job.candidates.size());
                continue;
            }

            String key = DatabaseHelper.normalizeName(p.name) + "#" + p.price;
            if (!seen.add(key)) continue;

            accepted.add(p);
            DiagLog.write(context, "OCR_LABEL_ACCEPT id=" + job.id
                    + " name=" + safeLog(p.name)
                    + " price=" + p.price
                    + " confidence=" + String.format(Locale.US, "%.2f", p.confidence));
        }

        accepted.sort(Comparator.comparingDouble((AcceptedProduct p) -> p.top)
                .thenComparingDouble(p -> p.left));

        ArrayList<DatabaseHelper.ProductInput> out = new ArrayList<>();
        for (AcceptedProduct p : accepted) {
            out.add(new DatabaseHelper.ProductInput(p.name, p.price, p.confidence));
            if (out.size() >= MAX_PRODUCTS) break;
        }
        return out;
    }

    private static AcceptedProduct chooseLabelResult(LabelJob job, String tagName) {
        if (job.candidates.isEmpty()) return null;

        Map<Integer, Float> priceVotes = new LinkedHashMap<>();
        Map<Integer, Set<String>> pricePasses = new HashMap<>();
        Map<Integer, Boolean> explicitMap = new HashMap<>();

        for (LocalDetection d : job.candidates) {
            float vote = d.score * 0.20f
                    + (d.price == job.anchor.price ? 2.0f : 0f)
                    + (d.explicit ? 1.1f : 0f);
            priceVotes.put(d.price, priceVotes.getOrDefault(d.price, 0f) + vote);
            pricePasses.computeIfAbsent(d.price, k -> new HashSet<>()).add(d.localPass);
            if (d.explicit) explicitMap.put(d.price, true);
        }

        int chosenPrice = -1;
        float chosenVote = -1f;
        for (Map.Entry<Integer, Float> e : priceVotes.entrySet()) {
            if (e.getValue() > chosenVote) {
                chosenVote = e.getValue();
                chosenPrice = e.getKey();
            }
        }
        if (chosenPrice < 0) return null;

        Set<String> priceSupportPasses = pricePasses.get(chosenPrice);
        int localSupport = priceSupportPasses == null ? 0 : priceSupportPasses.size();
        boolean explicit = explicitMap.getOrDefault(chosenPrice, false);

        LocalDetection bestName = null;
        float bestNameVote = -100f;
        for (LocalDetection d : job.candidates) {
            if (d.price != chosenPrice && priceAgreement(chosenPrice, d.price) < 1.0f) continue;

            float agreement = 0f;
            for (LocalDetection other : job.candidates) {
                if (other == d) continue;
                agreement += nameSimilarity(d.name, other.name);
            }
            float vote = d.nameQuality * 1.8f + d.score * 0.45f + agreement;
            if (d.price == chosenPrice) vote += 1.0f;
            if (vote > bestNameVote) {
                bestNameVote = vote;
                bestName = d;
            }
        }
        if (bestName == null) return null;

        String name = cleanupProductName(bestName.name);
        float quality = nameQuality(name, tagName);
        if (quality < 4.0f) return null;

        // Two local passes agreeing is the normal path.  A single local pass is only
        // accepted if the coarse anchor itself was very stable or the price was explicit.
        if (localSupport < 2) {
            boolean veryStableAnchor = job.anchor.priceSupport >= 3;
            if (!explicit && !veryStableAnchor) return null;
            if (quality < 4.7f || bestName.score < 10.5f) return null;
        }

        if (!explicit && chosenPrice > 9999) return null;
        if (Math.abs(chosenPrice - job.anchor.price) > Math.max(80, job.anchor.price * 0.20f)
                && !explicit) return null;

        float confidence = 0.44f
                + Math.min(0.18f, job.anchor.priceSupport * 0.05f)
                + Math.min(0.16f, localSupport * 0.08f)
                + Math.min(0.14f, Math.max(0f, quality - 4f) * 0.05f)
                + (explicit ? 0.08f : 0f);
        confidence = Math.max(0.05f, Math.min(0.98f, confidence));

        return new AcceptedProduct(name, chosenPrice, confidence,
                job.anchor.box.top, job.anchor.box.left);
    }

    private static ArrayList<LineInfo> linesFrom(Text result, CoordinateMap mapper) {
        ArrayList<LineInfo> lines = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String text = clean(line.getText());
                Rect box = line.getBoundingBox();
                if (text.isEmpty() || box == null) continue;
                RectF mapped = mapper == null ? new RectF(box) : mapper.map(box);
                lines.add(new LineInfo(text, mapped));
            }
        }
        lines.sort(Comparator.comparingDouble((LineInfo l) -> l.box.top)
                .thenComparingDouble(l -> l.box.left));
        return lines;
    }

    private static NameHit chooseProductName(
            List<LineInfo> lines,
            LineInfo priceLine,
            PriceHit priceHit,
            String tagName,
            boolean strictLocal) {
        String inline = clean(priceLine.text.substring(0, priceHit.start)
                + " " + priceLine.text.substring(priceHit.end));
        inline = cleanupProductName(inline);
        float inlineQuality = nameQuality(inline, tagName);

        NameHit best = null;
        if (inlineQuality >= (strictLocal ? 3.8f : 3.2f)) {
            best = new NameHit(inline, 4.0f);
        }

        float ph = Math.max(1f, priceLine.box.height());
        float pcx = priceLine.box.centerX();

        for (LineInfo candidate : lines) {
            if (candidate == priceLine) continue;
            if (findBestPrice(candidate.text) != null) continue;

            String name = cleanupProductName(candidate.text);
            float quality = nameQuality(name, tagName);
            if (quality < (strictLocal ? 3.5f : 2.8f)) continue;

            float yOverlap = overlapRatioY(candidate.box, priceLine.box);
            float candidateCx = candidate.box.centerX();
            float geom = -100f;

            if (yOverlap >= 0.28f && candidateCx < pcx) {
                float gap = Math.max(0f, priceLine.box.left - candidate.box.right);
                if (gap <= ph * (strictLocal ? 8f : 10f) + (strictLocal ? 90f : 180f)) {
                    geom = 4.6f - Math.min(1.6f, gap / Math.max(1f, ph * 6f));
                }
            }

            if (candidate.box.bottom <= priceLine.box.centerY()) {
                float verticalGap = Math.max(0f, priceLine.box.top - candidate.box.bottom);
                float horizontalOverlap = overlapRatioX(candidate.box, priceLine.box);
                float centerDistance = Math.abs(candidateCx - pcx);
                boolean aligned = horizontalOverlap >= 0.12f
                        || centerDistance <= Math.max(candidate.box.width(), priceLine.box.width()) * 0.78f;
                float maxGap = ph * (strictLocal ? 4.2f : 5.5f) + (strictLocal ? 60f : 110f);
                if (aligned && verticalGap <= maxGap) {
                    float aboveGeom = 4.0f - Math.min(1.8f, verticalGap / Math.max(1f, ph * 3f));
                    geom = Math.max(geom, aboveGeom);
                }
            }

            if (!strictLocal && candidate.box.top >= priceLine.box.centerY()) {
                float verticalGap = Math.max(0f, candidate.box.top - priceLine.box.bottom);
                float horizontalOverlap = overlapRatioX(candidate.box, priceLine.box);
                if (horizontalOverlap >= 0.18f && verticalGap <= ph * 2.2f + 45f) {
                    float belowGeom = 1.8f - Math.min(1.0f, verticalGap / Math.max(1f, ph * 2f));
                    geom = Math.max(geom, belowGeom);
                }
            }

            if (geom < 0f) continue;
            float combined = quality * 1.35f + geom;
            float bestCombined = best == null ? -100f
                    : nameQuality(best.name, tagName) * 1.35f + best.geometryScore;
            if (combined > bestCombined) best = new NameHit(name, geom);
        }
        return best;
    }

    private static PriceHit findBestPrice(String original) {
        if (original == null) return null;
        String text = normalizeDigitsOnly(original);

        PriceHit hit = matchPrice(TAX_INCLUDED_PRICE, text, 5.2f, true);
        if (hit != null) return hit;
        hit = matchPrice(CURRENCY_PRICE, text, 4.6f, true);
        if (hit != null) return hit;
        hit = matchPrice(LABELED_PRICE, text, 3.9f, true);
        if (hit != null) return hit;

        if (PROMO_OR_NOTICE.matcher(text).find()
                || DATE_LIKE.matcher(text).find()
                || CAPACITY_ONLY.matcher(text).matches()) {
            return null;
        }

        Matcher bare = BARE_NUMBER.matcher(text);
        PriceHit best = null;
        while (bare.find()) {
            String token = bare.group(1);
            Integer price = parsePrice(token, false);
            if (price == null || price < 50 || price > 9999) continue;

            String before = text.substring(0, bare.start()).trim();
            String after = text.substring(bare.end()).trim();
            String compact = (before + after).replaceAll("\\s+", "");
            int letters = countLetters(compact);
            int digits = countDigits(token);

            // Naked shelf prices should be almost the entire OCR line.
            if (letters > 1 || compact.length() > 5 || digits < 2 || digits > 4) continue;
            if (price >= 1900 && price <= 2099 && text.contains("年")) continue;

            PriceHit candidate = new PriceHit(price, bare.start(), bare.end(), 2.0f, false);
            if (best == null || candidate.strength > best.strength) best = candidate;
        }
        return best;
    }

    private static PriceHit matchPrice(Pattern pattern, String text, float strength, boolean explicit) {
        Matcher matcher = pattern.matcher(text);
        PriceHit best = null;
        while (matcher.find()) {
            String number = null;
            for (int i = 1; i <= matcher.groupCount(); i++) {
                if (matcher.group(i) != null) {
                    number = matcher.group(i);
                    break;
                }
            }
            Integer price = parsePrice(number, true);
            if (price == null) continue;

            float s = strength;
            String nearby = text.substring(Math.max(0, matcher.start() - 8),
                    Math.min(text.length(), matcher.end() + 8));
            if (nearby.contains("税込") || nearby.contains("総額")) s += 0.8f;
            if (nearby.contains("税抜") || nearby.contains("本体")) s -= 0.2f;

            PriceHit candidate = new PriceHit(price, matcher.start(), matcher.end(), s, explicit);
            if (best == null || candidate.strength > best.strength) best = candidate;
        }
        return best;
    }

    private static Integer parsePrice(String raw, boolean allowOcrDigitFixes) {
        if (raw == null) return null;
        String text = allowOcrDigitFixes ? normalizePriceChars(raw) : normalizeDigitsOnly(raw);
        String digits = text.replaceAll("[^0-9]", "");
        if (digits.length() < 2 || digits.length() > 7) return null;
        try {
            int value = Integer.parseInt(digits);
            if (value < 10 || value > 9_999_999) return null;
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static float nameQuality(String input, String tagName) {
        String t = cleanupProductName(input);
        if (t.length() < 2 || t.length() > 44) return -100f;
        if (PROMO_OR_NOTICE.matcher(t).find()) return -100f;
        if (DATE_LIKE.matcher(t).find()) return -100f;
        if (DAY_FRAGMENT.matcher(t).matches()) return -100f;
        if (SENTENCE_END.matcher(t).find()) return -100f;
        if (GENERIC_PACKAGING.matcher(t).find()) return -100f;
        if (BARCODE.matcher(normalizeDigitsOnly(t).replaceAll("[^0-9]", "")).find()) return -100f;
        if (CAPACITY_ONLY.matcher(t).matches()) return -100f;
        if (t.matches(".*(?:\\d\\s*円|円\\s*\\d).*")) return -100f;
        if (t.matches("^[0-9０-９,，.．¥￥円\\s%+\\-]+$")) return -100f;
        if (t.matches("(?i)^(税込|税抜|本体価格|本体|特価|価格|SALE|OFF|おすすめ|広告の品|円)$")) return -100f;
        if (t.length() <= 9 && t.matches(".*[!！?？].*")) return -100f;

        int letters = countLetters(t);
        int digits = countDigits(t);
        int hira = countRange(t, 0x3040, 0x309f);
        int kata = countRange(t, 0x30a0, 0x30ff);
        int kanji = countRange(t, 0x4e00, 0x9fff);
        int punctuation = countPunctuation(t);

        if (letters < 2) return -100f;
        if (digits >= 7 && digits > letters) return -100f;
        if (punctuation > Math.max(2, t.length() / 4)) return -100f;

        boolean commonWord = COMMON_PRODUCT_WORDS.matcher(t).find();
        if (t.matches("^[0-9０-９].*") && !commonWord) return -100f;
        if (digits > 0 && t.length() <= 10 && !commonWord
                && !t.matches("(?i).*(?:ml|cl|L|年).*")) return -100f;

        float q = 2.0f;
        if (t.length() >= 3 && t.length() <= 28) q += 1.3f;
        else if (t.length() > 34) q -= 1.6f;

        if (kata + kanji >= Math.max(2, letters / 2)) q += 1.0f;
        if (digits <= Math.max(3, letters / 2)) q += 0.6f;
        if (commonWord) q += 1.2f;

        if (t.length() <= 4 && kanji > 0 && kata > 0 && !commonWord) q -= 1.4f;
        if (t.length() <= 4 && t.startsWith("一") && kata >= 2 && !commonWord) return -100f;
        if (t.length() >= 16 && hira > letters * 0.38f) q -= 1.9f;
        if (t.length() >= 16 && hira >= 4) q -= 1.7f;
        if (t.length() >= 24 && hira >= 4) q -= 1.2f;
        if (t.length() >= 16 && t.matches(".*(?:で|が|を|に|より|から|なので|ため).*")) q -= 1.1f;
        if (t.endsWith("。") || t.endsWith("、") || t.endsWith(":") || t.endsWith("：")) q -= 1.3f;

        String lowerTag = tagName == null ? "" : tagName.toLowerCase(Locale.ROOT);
        if (lowerTag.contains("酒") && t.matches("(?i).*(?:ml|cl|L|年|ウイスキー|ワイン|ビール|焼酎|清酒|ジン|ラム|テキーラ|リキュール|ブリュット|ロゼ).*")) {
            q += 0.9f;
        } else if (lowerTag.contains("肉") && t.matches(".*(?:牛|豚|鶏|肉|ロース|バラ|モモ|もも|挽肉|ひき肉|ステーキ).*")) {
            q += 0.8f;
        } else if (lowerTag.contains("調味") && t.matches(".*(?:醤油|しょうゆ|味噌|みそ|ソース|酢|油|オイル|塩|砂糖|たれ|ドレッシング).*")) {
            q += 0.8f;
        }
        return q;
    }

    private static String cleanupProductName(String input) {
        if (input == null) return "";
        String t = clean(input);
        t = t.replaceAll("(?i)(?:税込|税抜|本体価格|本体|特価|価格|SALE|OFF)", " ");
        t = t.replaceAll("[¥￥]", " ");
        t = t.replaceAll("^\\s*[=:：・|]+", "");
        t = t.replaceAll("[=:：|]+\\s*$", "");

        // OCR frequently glues the 700/750 ml capacity or a neighbouring bare price
        // to the end of the product name.  Keep explicit units for now, but strip a
        // naked 3-5 digit suffix from otherwise textual names.
        if (countLetters(t) >= 2) {
            t = t.replaceAll("\\s*[0-9０-９]{3,5}\\s*$", "");
        }

        t = t.replaceAll("\\s+", " ").trim();
        return t;
    }

    private static Bitmap renderPass(Bitmap base, PassSpec spec, int maxLongEdge) {
        int baseW = base.getWidth();
        int baseH = base.getHeight();
        int left = clamp(Math.round(spec.x0 * baseW), 0, Math.max(0, baseW - 1));
        int top = clamp(Math.round(spec.y0 * baseH), 0, Math.max(0, baseH - 1));
        int right = clamp(Math.round(spec.x1 * baseW), left + 1, baseW);
        int bottom = clamp(Math.round(spec.y1 * baseH), top + 1, baseH);

        int cropW = Math.max(1, right - left);
        int cropH = Math.max(1, bottom - top);
        int cropLong = Math.max(cropW, cropH);
        float desired = spec.isTile() ? maxLongEdge : Math.min(maxLongEdge, cropLong * 1.20f);
        float scale = desired / cropLong;
        scale = Math.max(0.55f, Math.min(spec.isTile() ? 1.85f : 1.25f, scale));

        return drawCrop(base, new Rect(left, top, right, bottom),
                Math.max(1, Math.round(cropW * scale)),
                Math.max(1, Math.round(cropH * scale)), spec.contrast);
    }

    private static Bitmap renderCrop(Bitmap base, RectF crop, boolean contrast) {
        int left = clamp(Math.round(crop.left), 0, Math.max(0, base.getWidth() - 1));
        int top = clamp(Math.round(crop.top), 0, Math.max(0, base.getHeight() - 1));
        int right = clamp(Math.round(crop.right), left + 1, base.getWidth());
        int bottom = clamp(Math.round(crop.bottom), top + 1, base.getHeight());

        int w = right - left;
        int h = bottom - top;
        int longest = Math.max(w, h);
        float scale = Math.min(2.8f, Math.max(1.0f, MAX_LABEL_LONG_EDGE / (float) Math.max(1, longest)));
        int outW = Math.max(1, Math.round(w * scale));
        int outH = Math.max(1, Math.round(h * scale));
        return drawCrop(base, new Rect(left, top, right, bottom), outW, outH, contrast);
    }

    private static Bitmap drawCrop(Bitmap base, Rect src, int outW, int outH, boolean contrast) {
        Bitmap out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        if (contrast) {
            ColorMatrix gray = new ColorMatrix();
            gray.setSaturation(0f);
            float c = 1.48f;
            float t = 128f * (1f - c);
            ColorMatrix contrastMatrix = new ColorMatrix(new float[]{
                    c, 0, 0, 0, t,
                    0, c, 0, 0, t,
                    0, 0, c, 0, t,
                    0, 0, 0, 1, 0
            });
            gray.postConcat(contrastMatrix);
            paint.setColorFilter(new ColorMatrixColorFilter(gray));
        }

        canvas.drawBitmap(base, src, new Rect(0, 0, outW, outH), paint);
        return out;
    }

    private static RectF approximatePriceBox(RectF lineBox, String lineText, PriceHit hit) {
        int length = Math.max(1, lineText == null ? 0 : lineText.length());
        float start = Math.max(0f, Math.min(1f, hit.start / (float) length));
        float end = Math.max(start + 0.05f, Math.min(1f, hit.end / (float) length));
        float left = lineBox.left + lineBox.width() * start;
        float right = lineBox.left + lineBox.width() * end;
        return new RectF(left, lineBox.top, Math.max(left + 1f, right), lineBox.bottom);
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\u3000', ' ').replaceAll("[\\t\\r\\n ]+", " ").trim();
    }

    private static String normalizePriceChars(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '０' && c <= '９') b.append((char) ('0' + (c - '０')));
            else if (c == '，') b.append(',');
            else if (c == '．') b.append('.');
            else if (c == 'Ｏ' || c == 'O' || c == 'ｏ' || c == 'o') b.append('0');
            else if (c == 'Ｉ' || c == 'I' || c == 'ｌ' || c == 'l' || c == '|') b.append('1');
            else b.append(c);
        }
        return b.toString();
    }

    private static String normalizeDigitsOnly(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '０' && c <= '９') b.append((char) ('0' + (c - '０')));
            else if (c == '，') b.append(',');
            else if (c == '．') b.append('.');
            else b.append(c);
        }
        return b.toString();
    }

    private static int countLetters(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) if (Character.isLetter(s.charAt(i))) count++;
        return count;
    }

    private static int countDigits(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) if (Character.isDigit(s.charAt(i))) count++;
        return count;
    }

    private static int countRange(String s, int low, int high) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            int c = s.charAt(i);
            if (c >= low && c <= high) count++;
        }
        return count;
    }

    private static int countPunctuation(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            int type = Character.getType(s.charAt(i));
            if (type == Character.CONNECTOR_PUNCTUATION
                    || type == Character.DASH_PUNCTUATION
                    || type == Character.START_PUNCTUATION
                    || type == Character.END_PUNCTUATION
                    || type == Character.OTHER_PUNCTUATION) count++;
        }
        return count;
    }

    private static float overlapRatioX(RectF a, RectF b) {
        float overlap = Math.max(0f, Math.min(a.right, b.right) - Math.max(a.left, b.left));
        return overlap / Math.max(1f, Math.min(a.width(), b.width()));
    }

    private static float overlapRatioY(RectF a, RectF b) {
        float overlap = Math.max(0f, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
        return overlap / Math.max(1f, Math.min(a.height(), b.height()));
    }

    private static float centerDistance(RectF a, RectF b) {
        float dx = a.centerX() - b.centerX();
        float dy = a.centerY() - b.centerY();
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static float nameSimilarity(String a, String b) {
        String x = DatabaseHelper.normalizeName(a);
        String y = DatabaseHelper.normalizeName(b);
        if (x.isEmpty() || y.isEmpty()) return 0f;
        if (x.equals(y)) return 1f;
        if (x.contains(y) || y.contains(x)) {
            int min = Math.min(x.length(), y.length());
            int max = Math.max(x.length(), y.length());
            return 0.72f + 0.28f * (min / (float) max);
        }
        int maxLen = Math.max(x.length(), y.length());
        if (maxLen > 44) return 0f;
        int distance = levenshtein(x, y);
        return Math.max(0f, 1f - distance / (float) maxLen);
    }

    private static int levenshtein(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] curr = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            curr[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                curr[j] = Math.min(Math.min(curr[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] swap = prev;
            prev = curr;
            curr = swap;
        }
        return prev[b.length()];
    }

    private static RectF copyRect(RectF r) {
        return new RectF(r.left, r.top, r.right, r.bottom);
    }

    private static RectF unionRect(RectF a, RectF b) {
        return new RectF(Math.min(a.left, b.left), Math.min(a.top, b.top),
                Math.max(a.right, b.right), Math.max(a.bottom, b.bottom));
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String safe(String s) {
        return s == null ? "-" : s.replaceAll("\\s+", "_");
    }

    private static String safeLog(String s) {
        if (s == null) return "-";
        String t = s.replaceAll("[\\r\\n]+", " ").trim();
        return t.length() > 36 ? t.substring(0, 36) : t;
    }

    private static String rectString(RectF r) {
        return Math.round(r.left) + "," + Math.round(r.top) + ","
                + Math.round(r.right) + "," + Math.round(r.bottom);
    }

    private interface CoordinateMap {
        RectF map(Rect box);
    }

    private static final class PipelineState {
        final Context context;
        final Callback callback;
        final TextRecognizer recognizer;
        final Bitmap base;
        final String tagName;
        final ArrayList<PassSpec> coarseSpecs = new ArrayList<>();
        final ArrayList<PriceAnchor> anchors = new ArrayList<>();
        final ArrayList<LabelJob> labelJobs = new ArrayList<>();
        final StringBuilder raw = new StringBuilder();
        int coarseIndex;
        int successfulCoarsePasses;
        int labelIndex;
        Exception lastError;

        PipelineState(Context context, Callback callback, TextRecognizer recognizer, Bitmap base, String tagName) {
            this.context = context;
            this.callback = callback;
            this.recognizer = recognizer;
            this.base = base;
            this.tagName = tagName;
        }
    }

    private static final class PassSpec {
        final String name;
        final float x0;
        final float y0;
        final float x1;
        final float y1;
        final boolean contrast;

        PassSpec(String name, float x0, float y0, float x1, float y1, boolean contrast) {
            this.name = name;
            this.x0 = x0;
            this.y0 = y0;
            this.x1 = x1;
            this.y1 = y1;
            this.contrast = contrast;
        }

        boolean isTile() {
            return x0 > 0f || y0 > 0f || x1 < 1f || y1 < 1f;
        }
    }

    private static final class CoordinateMapper implements CoordinateMap {
        final PassSpec spec;
        final int baseW;
        final int baseH;
        final int outW;
        final int outH;

        CoordinateMapper(PassSpec spec, int baseW, int baseH, int outW, int outH) {
            this.spec = spec;
            this.baseW = baseW;
            this.baseH = baseH;
            this.outW = outW;
            this.outH = outH;
        }

        @Override
        public RectF map(Rect box) {
            float cropLeft = spec.x0 * baseW;
            float cropTop = spec.y0 * baseH;
            float cropW = (spec.x1 - spec.x0) * baseW;
            float cropH = (spec.y1 - spec.y0) * baseH;
            return new RectF(
                    cropLeft + box.left * cropW / Math.max(1f, outW),
                    cropTop + box.top * cropH / Math.max(1f, outH),
                    cropLeft + box.right * cropW / Math.max(1f, outW),
                    cropTop + box.bottom * cropH / Math.max(1f, outH));
        }
    }

    private static final class CropMapper implements CoordinateMap {
        final RectF crop;
        final int outW;
        final int outH;

        CropMapper(RectF crop, int outW, int outH) {
            this.crop = crop;
            this.outW = outW;
            this.outH = outH;
        }

        @Override
        public RectF map(Rect box) {
            return new RectF(
                    crop.left + box.left * crop.width() / Math.max(1f, outW),
                    crop.top + box.top * crop.height() / Math.max(1f, outH),
                    crop.left + box.right * crop.width() / Math.max(1f, outW),
                    crop.top + box.bottom * crop.height() / Math.max(1f, outH));
        }
    }

    private static final class LineInfo {
        final String text;
        final RectF box;
        LineInfo(String text, RectF box) { this.text = text; this.box = box; }
    }

    private static final class PriceHit {
        final int price;
        final int start;
        final int end;
        final float strength;
        final boolean explicit;
        PriceHit(int price, int start, int end, float strength, boolean explicit) {
            this.price = price;
            this.start = start;
            this.end = end;
            this.strength = strength;
            this.explicit = explicit;
        }
    }

    private static final class NameHit {
        final String name;
        final float geometryScore;
        NameHit(String name, float geometryScore) { this.name = name; this.geometryScore = geometryScore; }
    }

    private static final class PriceAnchor {
        final int price;
        final float strength;
        final boolean explicit;
        final RectF box;
        final String passName;
        PriceAnchor(int price, float strength, boolean explicit, RectF box, String passName) {
            this.price = price;
            this.strength = strength;
            this.explicit = explicit;
            this.box = box;
            this.passName = passName;
        }
    }

    private static final class AnchorCluster {
        final ArrayList<PriceAnchor> items = new ArrayList<>();
    }

    private static final class VerifiedAnchor {
        final int price;
        final boolean explicit;
        final int priceSupport;
        final float strength;
        final RectF box;
        VerifiedAnchor(int price, boolean explicit, int priceSupport, float strength, RectF box) {
            this.price = price;
            this.explicit = explicit;
            this.priceSupport = priceSupport;
            this.strength = strength;
            this.box = box;
        }
    }

    private static final class LabelJob {
        final int id;
        final VerifiedAnchor anchor;
        final RectF crop;
        final ArrayList<LocalDetection> candidates = new ArrayList<>();
        int localPass;
        LabelJob(int id, VerifiedAnchor anchor, RectF crop) {
            this.id = id;
            this.anchor = anchor;
            this.crop = crop;
        }
    }

    private static final class LocalDetection {
        final String name;
        final int price;
        final boolean explicit;
        final float nameQuality;
        final float score;
        final RectF priceBox;
        final String localPass;
        LocalDetection(String name, int price, boolean explicit, float nameQuality,
                       float score, RectF priceBox, String localPass) {
            this.name = name;
            this.price = price;
            this.explicit = explicit;
            this.nameQuality = nameQuality;
            this.score = score;
            this.priceBox = priceBox;
            this.localPass = localPass;
        }
    }

    private static final class AcceptedProduct {
        final String name;
        final int price;
        final Float confidence;
        final float top;
        final float left;
        AcceptedProduct(String name, int price, Float confidence, float top, float left) {
            this.name = name;
            this.price = price;
            this.confidence = confidence;
            this.top = top;
            this.left = left;
        }
    }
}
