package com.pricerec.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.util.Size;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Shelf-photo oriented OCR parser.
 *
 * v0.1.4 deliberately favors precision over recall:
 *  - multi-pass OCR (full image + contrast + overlapping tiles)
 *  - price-anchor extraction
 *  - spatial product-name pairing
 *  - promotion/date/barcode rejection
 *  - cross-pass spatial voting
 */
final class OcrEngine {
    interface Callback {
        void onSuccess(String rawText, List<DatabaseHelper.ProductInput> products);
        void onError(Exception error);
    }

    private static final int MAX_DECODE_LONG_EDGE = 4096;
    private static final int MAX_PASS_LONG_EDGE = 3200;
    private static final int MAX_PRODUCTS = 80;

    private static final Pattern TAX_INCLUDED_PRICE = Pattern.compile(
            "(?:税込|税込価格|総額)[^0-9０-９¥￥]{0,5}[¥￥]?\\s*([0-9０-９OoIl|][0-9０-９OoIl|,，.．\\s]{0,9})",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern CURRENCY_PRICE = Pattern.compile(
            "[¥￥]\\s*([0-9０-９OoIl|][0-9０-９OoIl|,，.．\\s]{0,9})|"
                    + "([0-9０-９OoIl|][0-9０-９OoIl|,，.．\\s]{0,9})\\s*円",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern LABELED_PRICE = Pattern.compile(
            "(?:本体価格|本体|税抜価格|税抜|価格|特価)\\s*[:：]?\\s*[¥￥]?\\s*"
                    + "([0-9０-９OoIl|][0-9０-９OoIl|,，.．\\s]{0,9})",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern BARE_NUMBER = Pattern.compile(
            "(?<![0-9０-９])([0-9０-９][0-9０-９,，]{1,6})(?![0-9０-９])");

    private static final Pattern BARCODE = Pattern.compile("(?<!\\d)\\d{8,14}(?!\\d)");
    private static final Pattern DATE_LIKE = Pattern.compile(
            "(?:20\\d{2}[年/.-]\\d{1,2}|\\d{1,2}\\s*月\\s*\\d{0,2}\\s*日|"
                    + "\\d{1,2}[/-]\\d{1,2}|(?:月|火|水|木|金|土|日)曜)");
    private static final Pattern CAPACITY_ONLY = Pattern.compile(
            "(?i)^\\s*\\d+(?:[.,]\\d+)?\\s*(?:ml|mL|l|L|g|kg|個|本|枚|袋|缶|本入|個入)\\s*$");

    private static final Pattern PROMO_OR_NOTICE = Pattern.compile(
            "(?:割引|値引|引き|OFF|%引|ポイント|クーポン|セール|SALE|"
                    + "広告の品|お買得|お買い得|おすすめ|限定|今週|本日|\\d{1,3}\\s*引|"
                    + "変更いた|変更し|ご了承ください|ご了承|ご容赦|"
                    + "より変更|まで|レジにて|会員価格|通常価格|参考価格|"
                    + "品切|売切|入荷|予約|サービス|キャンペーン)",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern SENTENCE_END = Pattern.compile(
            "(?:ます[。.!！]?|です[。.!！]?|ください[。.!！]?|いたします[。.!！]?|"
                    + "となります[。.!！]?|願います[。.!！]?)$");

    private static final Pattern COMMON_PRODUCT_WORDS = Pattern.compile(
            "(?:ウイスキー|whisky|whiskey|ワイン|wine|ビール|beer|日本酒|清酒|焼酎|"
                    + "ジン|gin|ラム|rum|テキーラ|tequila|リキュール|ブランデー|シャンパン|"
                    + "醤油|しょうゆ|味噌|みそ|ソース|ドレッシング|オイル|油|酢|塩|砂糖|"
                    + "牛|豚|鶏|ロース|バラ|モモ|もも|ひき肉|挽肉|ステーキ)",
            Pattern.CASE_INSENSITIVE);

    private OcrEngine() { }

    static void recognize(Context context, Uri uri, Callback callback) {
        recognize(context, uri, null, callback);
    }

    static void recognize(Context context, Uri uri, String tagName, Callback callback) {
        final TextRecognizer recognizer = TextRecognition.getClient(
                new JapaneseTextRecognizerOptions.Builder().build());

        Bitmap base = null;
        try {
            base = decodeBaseBitmap(context, uri);
        } catch (Exception e) {
            DiagLog.write(context, "OCR_DECODE_FALLBACK err=" + e.getClass().getSimpleName());
        }

        if (base == null) {
            recognizeFallback(context, uri, tagName, recognizer, callback);
            return;
        }

        PipelineState state = new PipelineState(context, callback, recognizer, base, tagName);
        state.specs.addAll(buildPasses(base.getWidth(), base.getHeight()));
        DiagLog.write(context, "OCR_PIPELINE_START size=" + base.getWidth() + "x" + base.getHeight()
                + " passes=" + state.specs.size() + " tag=" + safe(tagName));
        runNextPass(state);
    }

    private static Bitmap decodeBaseBitmap(Context context, Uri uri) throws Exception {
        ImageDecoder.Source source = ImageDecoder.createSource(context.getContentResolver(), uri);
        return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            Size size = info.getSize();
            int w = size.getWidth();
            int h = size.getHeight();
            int longest = Math.max(w, h);
            if (longest > MAX_DECODE_LONG_EDGE) {
                float scale = MAX_DECODE_LONG_EDGE / (float) longest;
                decoder.setTargetSize(Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)));
            }
        });
    }

    private static void recognizeFallback(
            Context context,
            Uri uri,
            String tagName,
            TextRecognizer recognizer,
            Callback callback) {
        try {
            InputImage image = InputImage.fromFilePath(context, uri);
            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        try {
                            ArrayList<Detection> detections = collectDetections(
                                    result, null, "fallback", tagName);
                            List<DatabaseHelper.ProductInput> products =
                                    finalizeDetections(detections, guessWidth(detections), guessHeight(detections));
                            DiagLog.write(context, "OCR_FALLBACK_OK candidates=" + detections.size()
                                    + " accepted=" + products.size());
                            callback.onSuccess(result.getText(), products);
                        } catch (Exception e) {
                            callback.onError(e);
                        } finally {
                            recognizer.close();
                        }
                    })
                    .addOnFailureListener(e -> {
                        recognizer.close();
                        callback.onError(e);
                    });
        } catch (Exception e) {
            recognizer.close();
            callback.onError(e);
        }
    }

    private static List<PassSpec> buildPasses(int width, int height) {
        ArrayList<PassSpec> out = new ArrayList<>();
        out.add(new PassSpec("full", 0f, 0f, 1f, 1f, false));
        out.add(new PassSpec("full-contrast", 0f, 0f, 1f, 1f, true));

        if (width < 700 || height < 700) return out;

        if (height > width * 1.15f) {
            // Portrait shelf photos: 2 columns x 3 rows, with overlap so labels on seams survive.
            float[] xs0 = {0f, 0.42f};
            float[] xs1 = {0.58f, 1f};
            float[] ys0 = {0f, 0.29f, 0.58f};
            float[] ys1 = {0.42f, 0.71f, 1f};
            int n = 1;
            for (int y = 0; y < ys0.length; y++) {
                for (int x = 0; x < xs0.length; x++) {
                    out.add(new PassSpec("tile-" + n++, xs0[x], ys0[y], xs1[x], ys1[y], true));
                }
            }
        } else {
            // Landscape / near-square shelf photos: overlapping 2 x 2 tiles.
            out.add(new PassSpec("tile-1", 0f, 0f, 0.58f, 0.58f, true));
            out.add(new PassSpec("tile-2", 0.42f, 0f, 1f, 0.58f, true));
            out.add(new PassSpec("tile-3", 0f, 0.42f, 0.58f, 1f, true));
            out.add(new PassSpec("tile-4", 0.42f, 0.42f, 1f, 1f, true));
        }
        return out;
    }

    private static void runNextPass(PipelineState state) {
        if (state.index >= state.specs.size()) {
            finishPipeline(state);
            return;
        }

        PassSpec spec = state.specs.get(state.index++);
        Bitmap passBitmap = null;
        try {
            passBitmap = renderPass(state.base, spec);
            final Bitmap bitmapForTask = passBitmap;
            final CoordinateMapper mapper = new CoordinateMapper(
                    spec,
                    state.base.getWidth(),
                    state.base.getHeight(),
                    bitmapForTask.getWidth(),
                    bitmapForTask.getHeight());

            InputImage input = InputImage.fromBitmap(bitmapForTask, 0);
            state.recognizer.process(input)
                    .addOnSuccessListener(result -> {
                        try {
                            state.successfulPasses++;
                            state.raw.append("[").append(spec.name).append("]\n")
                                    .append(result.getText()).append("\n\n");
                            List<Detection> found = collectDetections(result, mapper, spec.name, state.tagName);
                            state.detections.addAll(found);
                            DiagLog.write(state.context, "OCR_PASS_OK " + spec.name
                                    + " candidates=" + found.size());
                        } catch (Exception e) {
                            state.lastError = e;
                            DiagLog.write(state.context, "OCR_PASS_PARSE_ERROR " + spec.name + " err=" + e);
                        } finally {
                            if (!bitmapForTask.isRecycled()) bitmapForTask.recycle();
                            runNextPass(state);
                        }
                    })
                    .addOnFailureListener(e -> {
                        state.lastError = e;
                        DiagLog.write(state.context, "OCR_PASS_ERROR " + spec.name + " err=" + e);
                        if (!bitmapForTask.isRecycled()) bitmapForTask.recycle();
                        runNextPass(state);
                    });
        } catch (Exception e) {
            state.lastError = e;
            if (passBitmap != null && !passBitmap.isRecycled()) passBitmap.recycle();
            DiagLog.write(state.context, "OCR_PASS_BUILD_ERROR " + spec.name + " err=" + e);
            runNextPass(state);
        }
    }

    private static void finishPipeline(PipelineState state) {
        try {
            if (state.successfulPasses == 0) {
                Exception e = state.lastError != null ? state.lastError
                        : new IllegalStateException("No OCR pass completed");
                state.callback.onError(e);
                return;
            }

            List<DatabaseHelper.ProductInput> products = finalizeDetections(
                    state.detections, state.base.getWidth(), state.base.getHeight());
            DiagLog.write(state.context, "OCR_PIPELINE_OK passes=" + state.successfulPasses
                    + " candidates=" + state.detections.size() + " accepted=" + products.size()
                    + " tag=" + safe(state.tagName));
            state.callback.onSuccess(state.raw.toString(), products);
        } catch (Exception e) {
            state.callback.onError(e);
        } finally {
            state.recognizer.close();
            if (!state.base.isRecycled()) state.base.recycle();
        }
    }

    private static Bitmap renderPass(Bitmap base, PassSpec spec) {
        int baseW = base.getWidth();
        int baseH = base.getHeight();

        int left = clamp(Math.round(spec.x0 * baseW), 0, Math.max(0, baseW - 1));
        int top = clamp(Math.round(spec.y0 * baseH), 0, Math.max(0, baseH - 1));
        int right = clamp(Math.round(spec.x1 * baseW), left + 1, baseW);
        int bottom = clamp(Math.round(spec.y1 * baseH), top + 1, baseH);

        int cropW = Math.max(1, right - left);
        int cropH = Math.max(1, bottom - top);
        int cropLong = Math.max(cropW, cropH);

        float desired = spec.isTile() ? MAX_PASS_LONG_EDGE : Math.min(MAX_PASS_LONG_EDGE, cropLong * 1.20f);
        float scale = desired / cropLong;
        scale = Math.max(0.55f, Math.min(spec.isTile() ? 1.85f : 1.25f, scale));

        int outW = Math.max(1, Math.round(cropW * scale));
        int outH = Math.max(1, Math.round(cropH * scale));

        Bitmap out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        if (spec.contrast) {
            ColorMatrix gray = new ColorMatrix();
            gray.setSaturation(0f);
            float c = 1.42f;
            float t = 128f * (1f - c);
            ColorMatrix contrast = new ColorMatrix(new float[]{
                    c, 0, 0, 0, t,
                    0, c, 0, 0, t,
                    0, 0, c, 0, t,
                    0, 0, 0, 1, 0
            });
            gray.postConcat(contrast);
            paint.setColorFilter(new ColorMatrixColorFilter(gray));
        }

        Rect src = new Rect(left, top, right, bottom);
        Rect dst = new Rect(0, 0, outW, outH);
        canvas.drawBitmap(base, src, dst, paint);
        return out;
    }

    private static ArrayList<Detection> collectDetections(
            Text result,
            CoordinateMapper mapper,
            String passName,
            String tagName) {
        ArrayList<LineInfo> lines = new ArrayList<>();

        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String text = clean(line.getText());
                Rect box = line.getBoundingBox();
                if (text.isEmpty() || box == null) continue;
                RectF mapped = mapper == null ? new RectF(box) : mapper.map(box);
                lines.add(new LineInfo(text, mapped));
            }
        }

        lines.sort(Comparator
                .comparingDouble((LineInfo l) -> l.box.top)
                .thenComparingDouble(l -> l.box.left));

        ArrayList<Detection> out = new ArrayList<>();
        for (LineInfo priceLine : lines) {
            PriceHit priceHit = findBestPrice(priceLine.text);
            if (priceHit == null) continue;

            NameHit nameHit = chooseProductName(lines, priceLine, priceHit, tagName);
            if (nameHit == null) continue;

            float q = nameQuality(nameHit.name, tagName);
            if (q < 2.8f) continue;

            float score = q + priceHit.strength + nameHit.geometryScore;
            if (!priceHit.explicit && score < 8.3f) continue;
            if (priceHit.explicit && score < 7.2f) continue;

            RectF priceBox = approximatePriceBox(priceLine.box, priceLine.text, priceHit);
            out.add(new Detection(
                    cleanupProductName(nameHit.name),
                    priceHit.price,
                    priceHit.strength,
                    priceHit.explicit,
                    score,
                    q,
                    priceBox,
                    passName));
        }
        return out;
    }

    private static NameHit chooseProductName(
            List<LineInfo> lines,
            LineInfo priceLine,
            PriceHit priceHit,
            String tagName) {
        String inline = clean(priceLine.text.substring(0, priceHit.start)
                + " " + priceLine.text.substring(priceHit.end));
        inline = cleanupProductName(inline);
        float inlineQuality = nameQuality(inline, tagName);

        NameHit best = null;
        if (inlineQuality >= 3.1f) {
            best = new NameHit(inline, 3.6f);
        }

        float ph = Math.max(1f, priceLine.box.height());
        float pcx = priceLine.box.centerX();

        for (LineInfo candidate : lines) {
            if (candidate == priceLine) continue;
            if (findBestPrice(candidate.text) != null) continue;

            String name = cleanupProductName(candidate.text);
            float quality = nameQuality(name, tagName);
            if (quality < 2.8f) continue;

            float yOverlap = overlapRatioY(candidate.box, priceLine.box);
            float candidateCx = candidate.box.centerX();
            float geom = -100f;

            // Common supermarket pattern: product text left of a price on the same shelf-label row.
            if (yOverlap >= 0.28f && candidateCx < pcx) {
                float gap = Math.max(0f, priceLine.box.left - candidate.box.right);
                if (gap <= ph * 10f + 180f) {
                    geom = 4.2f - Math.min(1.4f, gap / Math.max(1f, ph * 8f));
                }
            }

            // Another common pattern: item name immediately above the large price.
            if (candidate.box.bottom <= priceLine.box.centerY()) {
                float verticalGap = Math.max(0f, priceLine.box.top - candidate.box.bottom);
                float horizontalOverlap = overlapRatioX(candidate.box, priceLine.box);
                float centerDistance = Math.abs(candidateCx - pcx);
                boolean aligned = horizontalOverlap >= 0.12f
                        || centerDistance <= Math.max(candidate.box.width(), priceLine.box.width()) * 0.72f;
                if (aligned && verticalGap <= ph * 5.5f + 110f) {
                    float aboveGeom = 3.5f - Math.min(1.8f, verticalGap / Math.max(1f, ph * 3f));
                    geom = Math.max(geom, aboveGeom);
                }
            }

            // Some labels place the product name just below the price; allow, but with a lower prior.
            if (candidate.box.top >= priceLine.box.centerY()) {
                float verticalGap = Math.max(0f, candidate.box.top - priceLine.box.bottom);
                float horizontalOverlap = overlapRatioX(candidate.box, priceLine.box);
                if (horizontalOverlap >= 0.18f && verticalGap <= ph * 2.2f + 45f) {
                    float belowGeom = 1.8f - Math.min(1.0f, verticalGap / Math.max(1f, ph * 2f));
                    geom = Math.max(geom, belowGeom);
                }
            }

            if (geom < 0f) continue;
            float combined = quality * 1.25f + geom;
            float bestCombined = best == null ? -100f
                    : nameQuality(best.name, tagName) * 1.25f + best.geometryScore;
            if (combined > bestCombined) {
                best = new NameHit(name, geom);
            }
        }

        return best;
    }

    private static PriceHit findBestPrice(String original) {
        if (original == null) return null;
        String text = normalizeDigitsOnly(original);

        PriceHit hit = matchPrice(TAX_INCLUDED_PRICE, text, 5.0f, true);
        if (hit != null) return hit;

        hit = matchPrice(CURRENCY_PRICE, text, 4.3f, true);
        if (hit != null) return hit;

        hit = matchPrice(LABELED_PRICE, text, 3.6f, true);
        if (hit != null) return hit;

        // Bare prices are intentionally strict. Shelf photos contain dates, capacities,
        // JAN codes, years and discount rates that otherwise become false prices.
        if (PROMO_OR_NOTICE.matcher(text).find()
                || DATE_LIKE.matcher(text).find()
                || CAPACITY_ONLY.matcher(text).matches()
                || BARCODE.matcher(text.replaceAll("[^0-9]", "")).find()) {
            return null;
        }

        Matcher bare = BARE_NUMBER.matcher(text);
        PriceHit best = null;
        while (bare.find()) {
            String token = bare.group(1);
            Integer price = parsePrice(token, false);
            if (price == null) continue;

            String before = text.substring(0, bare.start()).trim();
            String after = text.substring(bare.end()).trim();
            String compact = (before + after).replaceAll("\\s+", "");

            // A bare numeric price should occupy most of its OCR line.
            int letters = countLetters(compact);
            int digits = countDigits(token);
            if (letters > 2 || compact.length() > 8 || digits < 2) continue;

            if (price >= 1900 && price <= 2099 && (text.contains("年") || compact.isEmpty())) continue;
            if (price < 50 || price > 999_999) continue;

            PriceHit candidate = new PriceHit(price, bare.start(), bare.end(), 1.8f, false);
            if (best == null || candidate.strength > best.strength) best = candidate;
        }
        return best;
    }

    private static PriceHit matchPrice(Pattern pattern, String text, float strength, boolean explicit) {
        Matcher matcher = pattern.matcher(text);
        PriceHit best = null;
        while (matcher.find()) {
            String number = null;
            for (int i = 1; i <= matcher.groupCount(); i++) {
                if (matcher.group(i) != null) {
                    number = matcher.group(i);
                    break;
                }
            }
            Integer price = parsePrice(number, true);
            if (price == null) continue;

            float s = strength;
            String nearby = text.substring(Math.max(0, matcher.start() - 8),
                    Math.min(text.length(), matcher.end() + 8));
            if (nearby.contains("税込") || nearby.contains("総額")) s += 0.8f;
            if (nearby.contains("税抜") || nearby.contains("本体")) s -= 0.2f;

            PriceHit candidate = new PriceHit(price, matcher.start(), matcher.end(), s, explicit);
            if (best == null || candidate.strength > best.strength) best = candidate;
        }
        return best;
    }

    private static Integer parsePrice(String raw, boolean allowOcrDigitFixes) {
        if (raw == null) return null;
        String text = allowOcrDigitFixes ? normalizePriceChars(raw) : normalizeDigitsOnly(raw);
        String digits = text.replaceAll("[^0-9]", "");
        if (digits.length() < 2 || digits.length() > 7) return null;
        try {
            int value = Integer.parseInt(digits);
            if (value < 10 || value > 9_999_999) return null;
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static float nameQuality(String input, String tagName) {
        String t = cleanupProductName(input);
        if (t.length() < 2 || t.length() > 48) return -100f;
        if (PROMO_OR_NOTICE.matcher(t).find()) return -100f;
        if (DATE_LIKE.matcher(t).find()) return -100f;
        if (SENTENCE_END.matcher(t).find()) return -100f;
        if (BARCODE.matcher(normalizeDigitsOnly(t).replaceAll("[^0-9]", "")).find()) return -100f;
        if (CAPACITY_ONLY.matcher(t).matches()) return -100f;
        if (t.matches(".*(?:\\d\\s*円|円\\s*\\d).*")) return -100f;
        if (t.matches("^[0-9０-９,，.．¥￥円\\s%+\\-]+$")) return -100f;
        if (t.matches("(?i)^(税込|税抜|本体価格|本体|特価|価格|SALE|OFF|おすすめ|広告の品|円)$")) return -100f;

        int letters = countLetters(t);
        int digits = countDigits(t);
        int hira = countRange(t, 0x3040, 0x309f);
        int kata = countRange(t, 0x30a0, 0x30ff);
        int kanji = countRange(t, 0x4e00, 0x9fff);

        if (letters < 2) return -100f;
        if (digits >= 7 && digits > letters) return -100f;

        float q = 2.0f;
        if (t.length() >= 3 && t.length() <= 26) q += 1.2f;
        else if (t.length() > 34) q -= 1.4f;

        if (kata + kanji >= Math.max(2, letters / 2)) q += 1.0f;
        if (digits <= Math.max(3, letters / 2)) q += 0.6f;
        if (COMMON_PRODUCT_WORDS.matcher(t).find()) q += 1.1f;

        // Long grammatical Japanese is much more likely to be POP copy than a product name.
        if (t.length() >= 16 && hira > letters * 0.38f) q -= 1.8f;
        if (t.length() >= 16 && hira >= 4) q -= 1.8f;
        if (t.length() >= 24 && hira >= 4) q -= 1.2f;
        if (t.length() >= 16 && t.matches(".*(?:で|が|を|に|より|から|なので|ため).*")) q -= 1.1f;
        if (t.length() >= 13 && (t.endsWith(":") || t.endsWith("："))) return -100f;
        if (t.endsWith("。") || t.endsWith("、") || t.endsWith(":") || t.endsWith("：")) q -= 1.3f;

        String lowerTag = tagName == null ? "" : tagName.toLowerCase(Locale.ROOT);
        if (lowerTag.contains("酒") && t.matches("(?i).*(?:ml|cl|L|年|ウイスキー|ワイン|ビール|焼酎|清酒|ジン|ラム|テキーラ|リキュール).*")) {
            q += 0.7f;
        } else if (lowerTag.contains("肉") && t.matches(".*(?:牛|豚|鶏|肉|ロース|バラ|モモ|もも|挽肉|ひき肉|ステーキ).*")) {
            q += 0.7f;
        } else if (lowerTag.contains("調味") && t.matches(".*(?:醤油|しょうゆ|味噌|みそ|ソース|酢|油|オイル|塩|砂糖|たれ|ドレッシング).*")) {
            q += 0.7f;
        }

        return q;
    }

    private static List<DatabaseHelper.ProductInput> finalizeDetections(
            List<Detection> detections,
            int imageWidth,
            int imageHeight) {
        ArrayList<Cluster> clusters = new ArrayList<>();
        float closeDistance = Math.max(42f, Math.min(imageWidth, imageHeight) * 0.055f);

        ArrayList<Detection> ordered = new ArrayList<>(detections);
        ordered.sort(Comparator.comparingDouble((Detection d) -> d.priceBox.top)
                .thenComparingDouble(d -> d.priceBox.left));

        for (Detection d : ordered) {
            Cluster target = null;
            for (Cluster c : clusters) {
                if (sameObservation(c, d, closeDistance)) {
                    target = c;
                    break;
                }
            }
            if (target == null) {
                target = new Cluster();
                clusters.add(target);
            }
            target.items.add(d);
        }

        ArrayList<FinalProduct> finals = new ArrayList<>();
        Set<String> exactSeen = new HashSet<>();

        for (Cluster cluster : clusters) {
            FinalProduct p = chooseClusterResult(cluster);
            if (p == null) continue;

            String exactKey = DatabaseHelper.normalizeName(p.name) + "#" + p.price;
            if (!exactSeen.add(exactKey)) {
                // If exactly the same product/price appears elsewhere in the same photo,
                // one row is enough for price comparison.
                continue;
            }
            finals.add(p);
        }

        finals.sort(Comparator.comparingDouble((FinalProduct p) -> p.top)
                .thenComparingDouble(p -> p.left));

        ArrayList<DatabaseHelper.ProductInput> out = new ArrayList<>();
        for (FinalProduct p : finals) {
            out.add(new DatabaseHelper.ProductInput(p.name, p.price, p.confidence));
            if (out.size() >= MAX_PRODUCTS) break;
        }
        return out;
    }

    private static boolean sameObservation(Cluster cluster, Detection d, float closeDistance) {
        for (Detection e : cluster.items) {
            float dx = e.priceBox.centerX() - d.priceBox.centerX();
            float dy = e.priceBox.centerY() - d.priceBox.centerY();
            float distance = (float) Math.sqrt(dx * dx + dy * dy);
            float similarity = nameSimilarity(e.name, d.name);

            if (distance <= closeDistance && (e.price == d.price || similarity >= 0.52f)) return true;
            if (e.price == d.price && similarity >= 0.80f) return true;
        }
        return false;
    }

    private static FinalProduct chooseClusterResult(Cluster cluster) {
        if (cluster.items.isEmpty()) return null;

        Set<String> passes = new HashSet<>();
        Map<Integer, Float> priceVotes = new HashMap<>();
        for (Detection d : cluster.items) {
            passes.add(d.passName);
            float vote = d.priceStrength + (d.explicitPrice ? 1.2f : 0f) + d.score * 0.08f;
            priceVotes.put(d.price, priceVotes.getOrDefault(d.price, 0f) + vote);
        }

        int chosenPrice = cluster.items.get(0).price;
        float bestPriceVote = -1f;
        for (Map.Entry<Integer, Float> e : priceVotes.entrySet()) {
            if (e.getValue() > bestPriceVote) {
                chosenPrice = e.getKey();
                bestPriceVote = e.getValue();
            }
        }

        Detection bestName = null;
        float bestNameVote = -100f;
        for (Detection d : cluster.items) {
            float agreement = 0f;
            for (Detection other : cluster.items) {
                if (other == d) continue;
                agreement += nameSimilarity(d.name, other.name);
            }
            float vote = d.nameQuality * 1.6f + d.score * 0.45f + agreement;
            if (d.price == chosenPrice) vote += 0.6f;
            if (vote > bestNameVote) {
                bestNameVote = vote;
                bestName = d;
            }
        }
        if (bestName == null) return null;

        int support = passes.size();
        boolean anyExplicit = false;
        float bestScore = -100f;
        float bestQuality = -100f;
        float top = Float.MAX_VALUE;
        float left = Float.MAX_VALUE;
        for (Detection d : cluster.items) {
            anyExplicit |= d.explicitPrice;
            bestScore = Math.max(bestScore, d.score);
            bestQuality = Math.max(bestQuality, d.nameQuality);
            top = Math.min(top, d.priceBox.top);
            left = Math.min(left, d.priceBox.left);
        }

        // Precision-first acceptance. A single-pass row must be especially convincing.
        if (bestQuality < 3.0f) return null;
        if (support <= 1) {
            if (!anyExplicit && bestScore < 9.8f) return null;
            if (anyExplicit && bestScore < 8.2f) return null;
        } else {
            if (bestScore < 6.8f) return null;
        }

        String cleaned = cleanupProductName(bestName.name);
        if (cleaned.length() < 2) return null;

        float confidence = 0.40f
                + Math.min(0.28f, support * 0.07f)
                + Math.min(0.20f, Math.max(0f, bestQuality - 3f) * 0.05f)
                + (anyExplicit ? 0.08f : 0f);
        confidence = Math.max(0.05f, Math.min(0.99f, confidence));

        return new FinalProduct(cleaned, chosenPrice, confidence, top, left);
    }

    private static float nameSimilarity(String a, String b) {
        String x = DatabaseHelper.normalizeName(a);
        String y = DatabaseHelper.normalizeName(b);
        if (x.isEmpty() || y.isEmpty()) return 0f;
        if (x.equals(y)) return 1f;
        if (x.contains(y) || y.contains(x)) {
            int min = Math.min(x.length(), y.length());
            int max = Math.max(x.length(), y.length());
            return 0.72f + 0.28f * (min / (float) max);
        }

        int maxLen = Math.max(x.length(), y.length());
        if (maxLen > 44) return 0f;
        int distance = levenshtein(x, y);
        return Math.max(0f, 1f - distance / (float) maxLen);
    }

    private static int levenshtein(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] curr = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            curr[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                curr[j] = Math.min(Math.min(curr[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] swap = prev;
            prev = curr;
            curr = swap;
        }
        return prev[b.length()];
    }

    private static RectF approximatePriceBox(RectF lineBox, String lineText, PriceHit hit) {
        int length = Math.max(1, lineText == null ? 0 : lineText.length());
        float start = Math.max(0f, Math.min(1f, hit.start / (float) length));
        float end = Math.max(start + 0.05f, Math.min(1f, hit.end / (float) length));
        float left = lineBox.left + lineBox.width() * start;
        float right = lineBox.left + lineBox.width() * end;
        return new RectF(left, lineBox.top, Math.max(left + 1f, right), lineBox.bottom);
    }

    private static String cleanupProductName(String input) {
        if (input == null) return "";
        String t = clean(input);
        t = t.replaceAll("(?i)(?:税込|税抜|本体価格|本体|特価|価格|SALE|OFF)", " ");
        t = t.replaceAll("[¥￥]", " ");
        t = t.replaceAll("^\\s*[=:：・|]+", "");
        t = t.replaceAll("[=:：|]+\\s*$", "");
        t = t.replaceAll("\\s+", " ").trim();
        return t;
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\u3000', ' ').replaceAll("[\\t\\r\\n ]+", " ").trim();
    }

    private static String normalizePriceChars(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '０' && c <= '９') b.append((char) ('0' + (c - '０')));
            else if (c == '，') b.append(',');
            else if (c == '．') b.append('.');
            else if (c == 'Ｏ' || c == 'O' || c == 'ｏ' || c == 'o') b.append('0');
            else if (c == 'Ｉ' || c == 'I' || c == 'ｌ' || c == 'l' || c == '|') b.append('1');
            else b.append(c);
        }
        return b.toString();
    }

    private static String normalizeDigitsOnly(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '０' && c <= '９') b.append((char) ('0' + (c - '０')));
            else if (c == '，') b.append(',');
            else if (c == '．') b.append('.');
            else b.append(c);
        }
        return b.toString();
    }

    private static int countLetters(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) if (Character.isLetter(s.charAt(i))) count++;
        return count;
    }

    private static int countDigits(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) if (Character.isDigit(s.charAt(i))) count++;
        return count;
    }

    private static int countRange(String s, int low, int high) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            int c = s.charAt(i);
            if (c >= low && c <= high) count++;
        }
        return count;
    }

    private static float overlapRatioX(RectF a, RectF b) {
        float overlap = Math.max(0f, Math.min(a.right, b.right) - Math.max(a.left, b.left));
        return overlap / Math.max(1f, Math.min(a.width(), b.width()));
    }

    private static float overlapRatioY(RectF a, RectF b) {
        float overlap = Math.max(0f, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
        return overlap / Math.max(1f, Math.min(a.height(), b.height()));
    }

    private static int guessWidth(List<Detection> detections) {
        float max = 1080f;
        for (Detection d : detections) max = Math.max(max, d.priceBox.right);
        return Math.max(1, Math.round(max));
    }

    private static int guessHeight(List<Detection> detections) {
        float max = 1920f;
        for (Detection d : detections) max = Math.max(max, d.priceBox.bottom);
        return Math.max(1, Math.round(max));
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String safe(String s) {
        return s == null ? "-" : s.replaceAll("\\s+", "_");
    }

    private static final class PipelineState {
        final Context context;
        final Callback callback;
        final TextRecognizer recognizer;
        final Bitmap base;
        final String tagName;
        final ArrayList<PassSpec> specs = new ArrayList<>();
        final ArrayList<Detection> detections = new ArrayList<>();
        final StringBuilder raw = new StringBuilder();
        int index = 0;
        int successfulPasses = 0;
        Exception lastError;

        PipelineState(Context context, Callback callback, TextRecognizer recognizer, Bitmap base, String tagName) {
            this.context = context;
            this.callback = callback;
            this.recognizer = recognizer;
            this.base = base;
            this.tagName = tagName;
        }
    }

    private static final class PassSpec {
        final String name;
        final float x0;
        final float y0;
        final float x1;
        final float y1;
        final boolean contrast;

        PassSpec(String name, float x0, float y0, float x1, float y1, boolean contrast) {
            this.name = name;
            this.x0 = x0;
            this.y0 = y0;
            this.x1 = x1;
            this.y1 = y1;
            this.contrast = contrast;
        }

        boolean isTile() {
            return x0 > 0f || y0 > 0f || x1 < 1f || y1 < 1f;
        }
    }

    private static final class CoordinateMapper {
        final PassSpec spec;
        final int baseW;
        final int baseH;
        final int outW;
        final int outH;

        CoordinateMapper(PassSpec spec, int baseW, int baseH, int outW, int outH) {
            this.spec = spec;
            this.baseW = baseW;
            this.baseH = baseH;
            this.outW = outW;
            this.outH = outH;
        }

        RectF map(Rect box) {
            float cropLeft = spec.x0 * baseW;
            float cropTop = spec.y0 * baseH;
            float cropW = (spec.x1 - spec.x0) * baseW;
            float cropH = (spec.y1 - spec.y0) * baseH;
            return new RectF(
                    cropLeft + box.left * cropW / Math.max(1f, outW),
                    cropTop + box.top * cropH / Math.max(1f, outH),
                    cropLeft + box.right * cropW / Math.max(1f, outW),
                    cropTop + box.bottom * cropH / Math.max(1f, outH));
        }
    }

    private static final class LineInfo {
        final String text;
        final RectF box;

        LineInfo(String text, RectF box) {
            this.text = text;
            this.box = box;
        }
    }

    private static final class PriceHit {
        final int price;
        final int start;
        final int end;
        final float strength;
        final boolean explicit;

        PriceHit(int price, int start, int end, float strength, boolean explicit) {
            this.price = price;
            this.start = start;
            this.end = end;
            this.strength = strength;
            this.explicit = explicit;
        }
    }

    private static final class NameHit {
        final String name;
        final float geometryScore;

        NameHit(String name, float geometryScore) {
            this.name = name;
            this.geometryScore = geometryScore;
        }
    }

    private static final class Detection {
        final String name;
        final int price;
        final float priceStrength;
        final boolean explicitPrice;
        final float score;
        final float nameQuality;
        final RectF priceBox;
        final String passName;

        Detection(
                String name,
                int price,
                float priceStrength,
                boolean explicitPrice,
                float score,
                float nameQuality,
                RectF priceBox,
                String passName) {
            this.name = name;
            this.price = price;
            this.priceStrength = priceStrength;
            this.explicitPrice = explicitPrice;
            this.score = score;
            this.nameQuality = nameQuality;
            this.priceBox = priceBox;
            this.passName = passName;
        }
    }

    private static final class Cluster {
        final ArrayList<Detection> items = new ArrayList<>();
    }

    private static final class FinalProduct {
        final String name;
        final int price;
        final Float confidence;
        final float top;
        final float left;

        FinalProduct(String name, int price, Float confidence, float top, float left) {
            this.name = name;
            this.price = price;
            this.confidence = confidence;
            this.top = top;
            this.left = left;
        }
    }
}
