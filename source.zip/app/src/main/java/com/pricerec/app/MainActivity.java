package com.pricerec.app;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Insets;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.service.chooser.ChooserAction;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.KeyListener;
import android.util.LruCache;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.GestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.core.content.FileProvider;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;

import org.json.JSONArray;


import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.UUID;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends ComponentActivity {
    private static final int REQ_CAMERA = 4101;
    private static final String ACTION_SAVE_STORE_PACKAGE = "com.pricerec.app.action.SAVE_STORE_PACKAGE";
    private static final String EXTRA_STORE_PACKAGE_PATH = "store_package_path";
    private static final String EXTRA_STORE_PACKAGE_NAME = "store_package_name";

    private static final int BG = Color.parseColor("#303030");
    private static final int DGRAY = Color.parseColor("#252020");
    private static final int GRAY = Color.parseColor("#454040");
    private static final int LGRAY = Color.parseColor("#656060");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int LBLUE = Color.parseColor("#445577");
    private static final int RED = Color.parseColor("#441100");
    private static final int LRED = Color.parseColor("#662211");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int DORANGE = Color.parseColor("#553300");
    private static final int WHITE = Color.parseColor("#FFFFFF");
    private static final int NWHITE = Color.parseColor("#A9A999");
    private static final int SECONDARY = Color.parseColor("#A9A999");
    private static final int CHECK_GREEN = Color.parseColor("#227733");
    private static final int THUMB_RADIUS_DP = 6;

    // Shared layout rhythm. Keep parent-level margins consistent instead of per-widget offsets.
    private static final int UI_SCREEN_MARGIN_DP = 14;
    private static final int UI_CARD_MARGIN_DP = 12;
    private static final int UI_DIALOG_MARGIN_DP = 14;
    // Top title inset and the visual bottom inset below the last action row share one edge rhythm.
    private static final int UI_DIALOG_EDGE_MARGIN_DP = 14;
    private static final int UI_SPACING_DP = 8;
    private static final int UI_TIGHT_SPACING_DP = 4;
    private static final int UI_ACTION_GAP_DP = 5;
    private static final int UI_DIALOG_ACTION_SPACING_DP = 18;
    private static final int UI_DIALOG_ACTION_BOTTOM_DP = 18;

    private static final String PREF_PRODUCT_COLUMNS_GLOBAL = "product_columns_global_v3";
    private static final String PREF_PRODUCT_COLUMN_WIDTH_PREFIX = "product_column_width_v1_";

    private DatabaseHelper db;
    private LinearLayout storeContainer;
    private ScrollView storeScroll;
    private EditText searchInput;
    private LinearLayout searchCandidateRow;
    private LinearLayout searchCandidateChips;
    private TextView searchCandidateDelete;
    private boolean searchCandidateSelectionMode = false;
    private final Set<String> selectedSearchCandidates = new HashSet<>();
    private static final String PREF_SEARCH_CANDIDATES = "search_candidates_v1";
    private long expandedStoreId = -1L; // last-opened store, kept for backward state compatibility
    private final Set<Long> expandedStoreIds = new HashSet<>();
    private final Map<Long, String> activeTab = new HashMap<>();
    private final Map<Long, LinearLayout> storeCardViews = new HashMap<>();
    private final Map<Long, LinearLayout> storeDetailViews = new HashMap<>();
    private View draggingStoreCard;
    private long draggingStoreId = -1L;
    private int draggingStoreSourceIndex = -1;
    private int draggingStoreTargetIndex = -1;
    private float draggingStoreGrabOffsetY = 0f;
    private int draggingStoreSlotHeight = 0;
    private boolean draggingStoreDropCommitted = false;

    private Uri pendingPhotoUri;
    private String pendingCameraTempPath;
    private long pendingStoreId = -1L;
    private Long pendingTagId = null;

    private long pendingImportStoreId = -1L;
    private Long pendingImportTagId = null;

    private File pendingStorePackageSaveFile;
    private File pendingManualCsvFile;

    private long shareSelectionStoreId = -1L;
    private final Set<Long> shareSelectedPhotoIds = new HashSet<>();

    private long productSelectionStoreId = -1L;
    private final Set<Long> selectedProductIds = new HashSet<>();

    private final Map<EditText, PopupWindow> activeFieldErrorPopups = new HashMap<>();
    private final Map<EditText, TextWatcher> activeFieldErrorWatchers = new HashMap<>();
    private final Map<EditText, Drawable[]> activeFieldErrorOriginalDrawables = new HashMap<>();

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);

    private final ExecutorService thumbnailExecutor = Executors.newFixedThreadPool(2);
    private final ExecutorService mapExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService packageExecutor = Executors.newSingleThreadExecutor();

    private final LruCache<String, Bitmap> thumbnailCache = new LruCache<String, Bitmap>(16 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) {
            return value == null ? 0 : value.getByteCount();
        }
    };

    private final ActivityResultLauncher<PickVisualMediaRequest> photoPicker =
            registerForActivityResult(new ActivityResultContracts.PickMultipleVisualMedia(100), this::handlePhotoPickerUris);

    private final ActivityResultLauncher<String[]> csvPicker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::handleCsvPicked);

    private final ActivityResultLauncher<String[]> storePackagePicker =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::handleStorePackageUris);

    private final ActivityResultLauncher<String> storePackageSaveLauncher =
            registerForActivityResult(new ActivityResultContracts.CreateDocument(StorePackageManager.MIME), this::handleStorePackageSaveUri);

    private final ActivityResultLauncher<String> manualCsvSaveLauncher =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("text/csv"), this::handleManualCsvSaveUri);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DatabaseHelper(this);
        DiagLog.write(this, "APP_START version=" + DiagLog.versionName(this));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        if (state != null) {
            String uri = state.getString("pending_uri");
            if (uri != null) pendingPhotoUri = Uri.parse(uri);
            pendingCameraTempPath = state.getString("pending_camera_temp_path");
            pendingStoreId = state.getLong("pending_store", -1L);
            long tag = state.getLong("pending_tag", Long.MIN_VALUE);
            pendingTagId = tag == Long.MIN_VALUE ? null : tag;
            pendingImportStoreId = state.getLong("pending_import_store", -1L);
            long importTag = state.getLong("pending_import_tag", Long.MIN_VALUE);
            pendingImportTagId = importTag == Long.MIN_VALUE ? null : importTag;
            expandedStoreId = state.getLong("expanded_store", -1L);
            long[] expandedIds = state.getLongArray("expanded_store_ids");
            if (expandedIds != null) {
                for (long id : expandedIds) expandedStoreIds.add(id);
            } else if (expandedStoreId >= 0) {
                expandedStoreIds.add(expandedStoreId);
            }
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(UI_SCREEN_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_SCREEN_MARGIN_DP), dp(UI_SPACING_DP));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                top = bars.top;
                bottom = Math.max(bars.bottom, ime.bottom);
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(UI_SCREEN_MARGIN_DP), top + dp(UI_SPACING_DP), dp(UI_SCREEN_MARGIN_DP), bottom + dp(UI_SPACING_DP));
            return insets;
        });

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, 0, 0, dp(UI_SPACING_DP));

        TextView title = text("PRICE REC.", 25, NWHITE, true);
        title.setLetterSpacing(0.08f);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setIncludeFontPadding(false);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));
        title.setContentDescription("展開中のカードをすべて閉じる");
        title.setOnClickListener(v -> collapseAllExpandedStores());

        TagManageIconView tagManage = new TagManageIconView(this);
        tagManage.setBackground(circle(GRAY));
        tagManage.setContentDescription("タグ管理");
        tagManage.setOnClickListener(v -> showTagManager());
        LinearLayout.LayoutParams tagManageLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        tagManageLp.rightMargin = dp(UI_SPACING_DP);
        titleRow.addView(tagManage, tagManageLp);

        DocumentListIconView allProducts = new DocumentListIconView(this);
        allProducts.setBackground(circle(GRAY));
        allProducts.setContentDescription("全商品リスト");
        allProducts.setOnClickListener(v -> showAllList());
        LinearLayout.LayoutParams allProductsLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        allProductsLp.rightMargin = dp(UI_SPACING_DP);
        titleRow.addView(allProducts, allProductsLp);

        TextView appMenu = text("⋮", 26, NWHITE, true);
        appMenu.setGravity(Gravity.CENTER);
        appMenu.setIncludeFontPadding(false);
        appMenu.setBackground(circle(DGRAY));
        appMenu.setContentDescription("アプリメニュー");
        appMenu.setOnClickListener(v -> showAppMenu());
        titleRow.addView(appMenu, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(titleRow);

        storeScroll = newAutoFadeScrollView();
        // Main store-card screen intentionally has no visible scrollbar; scrolling itself remains enabled.
        storeScroll.setVerticalScrollBarEnabled(false);
        storeScroll.setFillViewport(true);
        storeContainer = new LinearLayout(this);
        storeContainer.setOrientation(LinearLayout.VERTICAL);
        storeScroll.addView(storeContainer, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        storeScroll.setOnDragListener(this::handleStoreScrollDrag);
        root.addView(storeScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(makeBottomBar());
        setContentView(root);
        root.requestApplyInsets();
        reloadStores();
        Intent launchIntent = getIntent();
        if (!handleStorePackageSaveIntent(launchIntent) && !handleIncomingGoogleMapsShare(launchIntent)) {
            handleIncomingCsvIntent(launchIntent);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (!handleStorePackageSaveIntent(intent) && !handleIncomingGoogleMapsShare(intent)) {
            handleIncomingCsvIntent(intent);
        }
    }

    @Override
    protected void onDestroy() {
        thumbnailExecutor.shutdownNow();
        mapExecutor.shutdownNow();
        packageExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            if (searchCandidateSelectionMode && !isTouchInside(event, searchCandidateRow)) {
                exitSearchCandidateSelection();
            }
            if (shareSelectionStoreId >= 0) {
                View selectionCard = storeCardViews.get(shareSelectionStoreId);
                if (selectionCard == null || !isTouchInside(event, selectionCard)) {
                    long exitingStore = shareSelectionStoreId;
                    int count = shareSelectedPhotoIds.size();
                    shareSelectionStoreId = -1L;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_END_OUTSIDE store=" + exitingStore + " selected=" + count);
                    reloadStores();
                }
            }
            View focused = getCurrentFocus();
            if (focused instanceof EditText) {
                EditText touchedInput = findEditTextAt(getWindow().getDecorView(), event.getRawX(), event.getRawY());
                if (touchedInput == null) {
                    focused.clearFocus();
                    hideKeyboard(focused);
                }
            }
        }
        return super.dispatchTouchEvent(event);
    }

    private EditText findEditTextAt(View root, float rawX, float rawY) {
        if (root == null || root.getVisibility() != View.VISIBLE) return null;
        if (!pointInsideView(root, rawX, rawY)) return null;
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = group.getChildCount() - 1; i >= 0; i--) {
                EditText found = findEditTextAt(group.getChildAt(i), rawX, rawY);
                if (found != null) return found;
            }
        }
        return root instanceof EditText ? (EditText) root : null;
    }

    private boolean pointInsideView(View view, float rawX, float rawY) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        return rawX >= location[0] && rawX <= location[0] + view.getWidth()
                && rawY >= location[1] && rawY <= location[1] + view.getHeight();
    }

    private boolean isTouchInside(MotionEvent event, View view) {
        if (view == null || view.getVisibility() != View.VISIBLE) return false;
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        float x = event.getRawX();
        float y = event.getRawY();
        return x >= location[0] && x <= location[0] + view.getWidth()
                && y >= location[1] && y <= location[1] + view.getHeight();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (pendingPhotoUri != null) out.putString("pending_uri", pendingPhotoUri.toString());
        if (pendingCameraTempPath != null) out.putString("pending_camera_temp_path", pendingCameraTempPath);
        out.putLong("pending_store", pendingStoreId);
        out.putLong("pending_tag", pendingTagId == null ? Long.MIN_VALUE : pendingTagId);
        out.putLong("pending_import_store", pendingImportStoreId);
        out.putLong("pending_import_tag", pendingImportTagId == null ? Long.MIN_VALUE : pendingImportTagId);
        out.putLong("expanded_store", expandedStoreId);
        long[] expandedIds = new long[expandedStoreIds.size()];
        int expandedIndex = 0;
        for (Long id : expandedStoreIds) expandedIds[expandedIndex++] = id;
        out.putLongArray("expanded_store_ids", expandedIds);
    }

    private View makeBottomBar() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(UI_SPACING_DP), 0, 0);

        searchCandidateRow = new LinearLayout(this);
        searchCandidateRow.setGravity(Gravity.CENTER_VERTICAL);
        searchCandidateRow.setPadding(0, 0, 0, dp(UI_SPACING_DP));

        HorizontalScrollView candidateScroll = newAutoFadeHorizontalScrollView();
        candidateScroll.setHorizontalScrollBarEnabled(false);
        candidateScroll.setFillViewport(false);
        searchCandidateChips = new LinearLayout(this);
        searchCandidateChips.setOrientation(LinearLayout.HORIZONTAL);
        searchCandidateChips.setGravity(Gravity.CENTER_VERTICAL);
        candidateScroll.addView(searchCandidateChips, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));
        searchCandidateRow.addView(candidateScroll, new LinearLayout.LayoutParams(0, dp(36), 1f));

        searchCandidateDelete = button("削除", RED, 13);
        searchCandidateDelete.setVisibility(View.GONE);
        searchCandidateDelete.setOnClickListener(v -> deleteSelectedSearchCandidates());
        LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(dp(72), dp(36));
        deleteLp.leftMargin = dp(8);
        searchCandidateRow.addView(searchCandidateDelete, deleteLp);
        box.addView(searchCandidateRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(DGRAY);
        searchInput.setTextSize(16);
        searchInput.setHint("商品名検索");
        searchInput.setHintTextColor(GRAY);
        searchInput.setGravity(Gravity.CENTER_VERTICAL);
        searchInput.setIncludeFontPadding(false);
        searchInput.setPadding(dp(16), 0, dp(16), 0);
        searchInput.setBackground(roundRect(NWHITE, 999));
        applyDarkInputCursor(searchInput);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setOnFocusChangeListener((v, focused) -> searchInput.setBackground(roundRect(NWHITE, 999)));
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        searchLp.rightMargin = dp(12);
        row.addView(productSearchInputHolder(searchInput), searchLp);

        ImageView add = roundPlusIcon(LBLUE, NWHITE, "新規店舗");
        add.setOnClickListener(v -> showAddStoreDialog());
        row.addView(add, new LinearLayout.LayoutParams(dp(48), dp(48)));
        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        refreshSearchCandidates();
        return box;
    }

    private List<String> loadSearchCandidates() {
        ArrayList<String> out = new ArrayList<>();
        String raw = getPreferences(MODE_PRIVATE).getString(PREF_SEARCH_CANDIDATES, "");
        if (raw == null || raw.isEmpty()) return out;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i, "").trim();
                if (!value.isEmpty() && !out.contains(value)) out.add(value);
            }
        } catch (Exception e) {
            DiagLog.write(this, "SEARCH_CANDIDATE_LOAD_ERROR " + e);
        }
        return out;
    }

    private void saveSearchCandidates(List<String> values) {
        JSONArray array = new JSONArray();
        for (String value : values) array.put(value);
        getPreferences(MODE_PRIVATE).edit()
                .putString(PREF_SEARCH_CANDIDATES, array.toString())
                .apply();
    }

    private void rememberSearchCandidate(String query) {
        String q = query == null ? "" : query.trim();
        if (q.isEmpty()) return;
        List<String> values = loadSearchCandidates();
        for (int i = values.size() - 1; i >= 0; i--) {
            if (values.get(i).equalsIgnoreCase(q)) values.remove(i);
        }
        values.add(0, q);
        saveSearchCandidates(values);
        refreshSearchCandidates();
        DiagLog.write(this, "SEARCH_CANDIDATE_SAVE q=" + q + " total=" + values.size());
    }

    private void refreshSearchCandidates() {
        if (searchCandidateRow == null || searchCandidateChips == null) return;
        List<String> values = loadSearchCandidates();
        searchCandidateChips.removeAllViews();
        for (String value : values) {
            boolean selected = selectedSearchCandidates.contains(value);
            TextView candidate = chip(value, selected, false);
            candidate.setTag(value);
            attachSearchCandidateGesture(candidate, value);
            candidate.setOnClickListener(v -> {
                if (searchCandidateSelectionMode) {
                    if (!selectedSearchCandidates.add(value)) selectedSearchCandidates.remove(value);
                    DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_TOGGLE q=" + value + " selected="
                            + selectedSearchCandidates.contains(value) + " count=" + selectedSearchCandidates.size());
                    refreshSearchCandidates();
                } else {
                    searchInput.setText(value);
                    searchInput.setSelection(searchInput.length());
                    runSearch(value);
                }
            });
            searchCandidateChips.addView(candidate);
        }
        searchCandidateDelete.setVisibility(searchCandidateSelectionMode ? View.VISIBLE : View.GONE);
        searchCandidateDelete.setAlpha(selectedSearchCandidates.isEmpty() ? 0.45f : 1f);
        searchCandidateRow.setVisibility(values.isEmpty() && !searchCandidateSelectionMode ? View.GONE : View.VISIBLE);
    }

    private void deleteSelectedSearchCandidates() {
        if (selectedSearchCandidates.isEmpty()) return;
        List<String> values = loadSearchCandidates();
        int before = values.size();
        values.removeIf(selectedSearchCandidates::contains);
        int removed = before - values.size();
        saveSearchCandidates(values);
        DiagLog.write(this, "SEARCH_CANDIDATE_DELETE count=" + removed);
        exitSearchCandidateSelection();
    }

    private void exitSearchCandidateSelection() {
        if (!searchCandidateSelectionMode && selectedSearchCandidates.isEmpty()) return;
        searchCandidateSelectionMode = false;
        selectedSearchCandidates.clear();
        refreshSearchCandidates();
        DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_CANCEL");
    }

    private void attachSearchCandidateGesture(TextView candidate, String value) {
        final boolean[] armed = {false};
        final boolean[] dragging = {false};
        final float[] downRawX = {0f};
        final int[] sourceIndex = {-1};
        final int[] targetIndex = {-1};

        candidate.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX[0] = event.getRawX();
                    sourceIndex[0] = searchCandidateChips.indexOfChild(v);
                    targetIndex[0] = sourceIndex[0];
                    armed[0] = false;
                    dragging[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (!armed[0]) return false;
                    float dx = event.getRawX() - downRawX[0];
                    if (!dragging[0] && Math.abs(dx) < dp(10)) return true;
                    dragging[0] = true;
                    v.setTranslationX(dx);
                    v.setTranslationY(0f);
                    int target = nearestChildIndexByRawX(searchCandidateChips, event.getRawX(), false);
                    if (target >= 0 && target != targetIndex[0]) {
                        targetIndex[0] = target;
                        animateHorizontalReorderPreview(searchCandidateChips, v, sourceIndex[0], targetIndex[0], false);
                        DiagLog.write(this, "SEARCH_CANDIDATE_REORDER_MOVE q=" + value + " index=" + target);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!armed[0]) return false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    boolean wasDragging = dragging[0];
                    int from = sourceIndex[0];
                    int to = targetIndex[0];
                    resetHorizontalReorderPreview(searchCandidateChips, v);
                    v.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(130).setInterpolator(new DecelerateInterpolator()).start();
                    if (commit) {
                        if (wasDragging && from >= 0 && to >= 0 && from != to) {
                            List<String> ordered = loadSearchCandidates();
                            moveListItem(ordered, from, to);
                            saveSearchCandidates(ordered);
                            DiagLog.write(this, "SEARCH_CANDIDATE_REORDER_SAVE from=" + from + " to=" + to + " total=" + ordered.size());
                            searchCandidateChips.postDelayed(this::refreshSearchCandidates, 120);
                        } else if (!wasDragging) {
                            if (!searchCandidateSelectionMode) {
                                searchCandidateSelectionMode = true;
                                selectedSearchCandidates.clear();
                            }
                            selectedSearchCandidates.add(value);
                            DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_START q=" + value);
                            refreshSearchCandidates();
                        }
                    }
                    armed[0] = false;
                    dragging[0] = false;
                    sourceIndex[0] = -1;
                    targetIndex[0] = -1;
                    return true;
                default:
                    return armed[0];
            }
        });

        candidate.setOnLongClickListener(v -> {
            armed[0] = true;
            dragging[0] = false;
            sourceIndex[0] = searchCandidateChips.indexOfChild(v);
            targetIndex[0] = sourceIndex[0];
            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            v.animate().scaleX(1.04f).scaleY(1.04f).alpha(0.86f).setDuration(80).start();
            DiagLog.write(this, "SEARCH_CANDIDATE_REORDER_ARM q=" + value);
            return true;
        });
    }

    private int nearestChildIndexByRawX(LinearLayout row, float rawX, boolean tagOnly) {
        int best = -1;
        float bestDistance = Float.MAX_VALUE;
        int[] rowLoc = new int[2];
        row.getLocationOnScreen(rowLoc);
        float localX = rawX - rowLoc[0];
        for (int i = 0; i < row.getChildCount(); i++) {
            View child = row.getChildAt(i);
            if (tagOnly && !(child.getTag() instanceof Long)) continue;
            float center = child.getLeft() + child.getWidth() / 2f;
            float distance = Math.abs(localX - center);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = i;
            }
        }
        return best;
    }

    private int horizontalOuterSize(View view) {
        int size = view.getWidth();
        ViewGroup.LayoutParams lp = view.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
            size += mlp.leftMargin + mlp.rightMargin;
        }
        return Math.max(dp(1), size);
    }

    private void animateHorizontalReorderPreview(LinearLayout row, View dragged, int sourceIndex, int targetIndex, boolean tagOnly) {
        if (sourceIndex < 0 || targetIndex < 0) return;
        int shift = horizontalOuterSize(dragged);
        for (int i = 0; i < row.getChildCount(); i++) {
            View child = row.getChildAt(i);
            if (child == dragged) continue;
            if (tagOnly && !(child.getTag() instanceof Long)) continue;
            float tx = 0f;
            if (targetIndex > sourceIndex && i > sourceIndex && i <= targetIndex) {
                tx = -shift;
            } else if (targetIndex < sourceIndex && i >= targetIndex && i < sourceIndex) {
                tx = shift;
            }
            child.animate().translationX(tx).translationY(0f).setDuration(135)
                    .setInterpolator(new DecelerateInterpolator(1.5f)).start();
        }
    }

    private void resetHorizontalReorderPreview(LinearLayout row, View dragged) {
        for (int i = 0; i < row.getChildCount(); i++) {
            View child = row.getChildAt(i);
            if (child == dragged) continue;
            child.animate().translationX(0f).translationY(0f).setDuration(120)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private <T> void moveListItem(List<T> list, int from, int to) {
        if (from < 0 || to < 0 || from >= list.size() || to >= list.size() || from == to) return;
        T item = list.remove(from);
        list.add(to, item);
    }

    private void reloadStores() {
        if (storeContainer == null) return;
        storeCardViews.clear();
        storeDetailViews.clear();
        storeContainer.removeAllViews();
        List<DatabaseHelper.Store> stores = db.listStores();
        if (stores.isEmpty()) {
            TextView empty = text("右下の＋から店舗を追加", 16, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(80), 0, 0);
            storeContainer.addView(empty);
            return;
        }
        for (DatabaseHelper.Store store : stores) storeContainer.addView(makeStoreCard(store));
    }

    private View makeStoreCard(DatabaseHelper.Store store) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundRect(GRAY, 18));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(12);
        card.setLayoutParams(cardLp);
        storeCardViews.put(store.id, card);
        card.setTag(Long.valueOf(store.id));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(UI_CARD_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_CARD_MARGIN_DP), dp(UI_SPACING_DP));

        TextView handle = text("☰", 22, SECONDARY, false);
        handle.setGravity(Gravity.CENTER);
        handle.setContentDescription("店舗を並べ替え");
        final float[] handleTouchY = {dp(24)};
        handle.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                handleTouchY[0] = event.getY();
            }
            return false;
        });
        handle.setOnLongClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            draggingStoreCard = card;
            draggingStoreId = store.id;
            draggingStoreSourceIndex = storeContainer.indexOfChild(card);
            draggingStoreTargetIndex = draggingStoreSourceIndex;
            draggingStoreGrabOffsetY = header.getTop() + handle.getTop() + handleTouchY[0];
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) card.getLayoutParams();
            draggingStoreSlotHeight = card.getHeight() + mlp.topMargin + mlp.bottomMargin;
            draggingStoreDropCommitted = false;
            card.setElevation(dp(12));
            card.animate().scaleX(1.015f).scaleY(1.015f).alpha(0.94f).setDuration(90).start();
            DragPayload payload = new DragPayload("store", store.id);
            ClipData data = ClipData.newPlainText("store_id", String.valueOf(store.id));
            DiagLog.write(this, "STORE_DRAG_START id=" + store.id + " name=" + store.name + " axis=y");
            v.startDragAndDrop(data, new InvisibleDragShadowBuilder(v), payload, 0);
            return true;
        });

        TextView name = text(store.name, 18, store.enabled ? WHITE : LGRAY, true);
        name.setGravity(Gravity.CENTER_VERTICAL);

        header.addView(handle, new LinearLayout.LayoutParams(dp(48), dp(48)));
        header.addView(name, new LinearLayout.LayoutParams(0, dp(48), 1f));
        if (store.hasMapAnalysis()) {
            StraightCheckBadgeView mapCheck = new StraightCheckBadgeView(this);
            mapCheck.setContentDescription("Googleマップ解析済み");
            LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(dp(22), dp(22));
            checkLp.rightMargin = dp(6);
            header.addView(mapCheck, checkLp);
        }

        FrameLayout toggleHit = new FrameLayout(this);
        toggleHit.setClickable(true);
        toggleHit.setFocusable(true);
        toggleHit.setClipChildren(false);
        toggleHit.setClipToPadding(false);
        toggleHit.setContentDescription(store.enabled ? "Nトグル オン" : "Nトグル オフ");
        NToggleSwitch nToggle = new NToggleSwitch(this);
        nToggle.setChecked(store.enabled);
        nToggle.setNColors(ORANGE, NWHITE);
        nToggle.setContentDescription(store.enabled ? "Nトグル オン" : "Nトグル オフ");
        nToggle.setOnCheckedChangeListener((buttonView, checked) -> {
            if (checked == store.enabled) return;
            db.setStoreEnabled(store.id, checked);
            buttonView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            DiagLog.write(this, "STORE_N_TOGGLE id=" + store.id + " enabled=" + checked);
            buttonView.postDelayed(this::reloadStores, 130L);
        });
        FrameLayout.LayoutParams switchLp = new FrameLayout.LayoutParams(dp(44), dp(26), Gravity.CENTER);
        toggleHit.addView(nToggle, switchLp);
        toggleHit.setOnClickListener(v -> nToggle.performClick());
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(dp(58), dp(48));
        toggleLp.leftMargin = dp(8);
        header.addView(toggleHit, toggleLp);

        View.OnLongClickListener storeMenuLongPress = v -> {
            if (draggingStoreId >= 0) return true;
            card.setBackground(roundRect(LGRAY, 18));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                card.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            } else {
                card.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            }
            DiagLog.write(this, "STORE_MENU_LONG_PRESS id=" + store.id + " name=" + store.name);
            showStoreMenu(store, card);
            return true;
        };
        header.setOnLongClickListener(storeMenuLongPress);
        card.setOnLongClickListener(storeMenuLongPress);
        card.addView(header);

        if (expandedStoreIds.contains(store.id)) {
            LinearLayout details = buildStoreDetails(store);
            card.addView(details);
            storeDetailViews.put(store.id, details);
        }

        header.setOnClickListener(v -> {
            if (draggingStoreId >= 0) return;
            if (expandedStoreIds.contains(store.id)) {
                if (shareSelectionStoreId == store.id) {
                    shareSelectionStoreId = -1L;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_END_COLLAPSE store=" + store.id);
                }
                animateCollapseStore(store.id, null);
            } else {
                animateExpandStore(store, card);
            }
        });
        return card;
    }

    private LinearLayout buildStoreDetails(DatabaseHelper.Store store) {
        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(UI_CARD_MARGIN_DP), 0, dp(UI_CARD_MARGIN_DP), dp(UI_CARD_MARGIN_DP));
        details.addView(makeActionRow(store));
        details.addView(makePhotoGrid(store));
        return details;
    }

    private void animateExpandStore(DatabaseHelper.Store store, LinearLayout card) {
        if (expandedStoreIds.contains(store.id) && storeDetailViews.containsKey(store.id)) return;
        expandedStoreIds.add(store.id);
        expandedStoreId = store.id;
        DiagLog.write(this, "STORE_EXPAND id=" + store.id + " mode=lightweight");
        LinearLayout details = buildStoreDetails(store);
        storeDetailViews.put(store.id, details);
        details.setAlpha(0f);
        details.setTranslationY(-dp(5));
        card.addView(details, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        details.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(145)
                .setInterpolator(new DecelerateInterpolator(1.4f))
                .start();
    }

    private void animateCollapseStore(long storeId, Runnable after) {
        LinearLayout card = storeCardViews.get(storeId);
        LinearLayout details = storeDetailViews.get(storeId);
        if (card == null || details == null) {
            expandedStoreIds.remove(storeId);
            if (expandedStoreId == storeId) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
            if (after != null) after.run();
            return;
        }
        details.animate()
                .alpha(0f)
                .translationY(-dp(5))
                .setDuration(120)
                .setInterpolator(new DecelerateInterpolator(1.25f))
                .withEndAction(() -> {
                    card.removeView(details);
                    storeDetailViews.remove(storeId);
                    expandedStoreIds.remove(storeId);
                    if (expandedStoreId == storeId) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
                    DiagLog.write(MainActivity.this, "STORE_COLLAPSE id=" + storeId + " mode=lightweight");
                    if (after != null) after.run();
                })
                .start();
    }

    private void collapseAllExpandedStores() {
        if (expandedStoreIds.isEmpty()) return;
        if (shareSelectionStoreId >= 0 && expandedStoreIds.contains(shareSelectionStoreId)) {
            DiagLog.write(this, "SHARE_SELECT_END_COLLAPSE_ALL store=" + shareSelectionStoreId);
            shareSelectionStoreId = -1L;
            shareSelectedPhotoIds.clear();
        }
        ArrayList<Long> ids = new ArrayList<>(expandedStoreIds);
        DiagLog.write(this, "STORE_COLLAPSE_ALL count=" + ids.size());
        for (Long id : ids) {
            if (id != null) animateCollapseStore(id, null);
        }
    }

    private void refreshExpandedStoreDetails(DatabaseHelper.Store store) {
        if (store == null) return;
        LinearLayout card = storeCardViews.get(store.id);
        LinearLayout oldDetails = storeDetailViews.get(store.id);
        if (card == null || oldDetails == null || !expandedStoreIds.contains(store.id)) {
            reloadStores();
            return;
        }
        int index = card.indexOfChild(oldDetails);
        if (index < 0) {
            reloadStores();
            return;
        }
        LinearLayout fresh = buildStoreDetails(store);
        card.removeViewAt(index);
        card.addView(fresh, index, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        storeDetailViews.put(store.id, fresh);
    }

    private boolean handleStoreScrollDrag(View targetView, DragEvent event) {
        Object local = event.getLocalState();
        if (!(local instanceof DragPayload) || !"store".equals(((DragPayload) local).type)) {
            return event.getAction() != DragEvent.ACTION_DRAG_STARTED;
        }
        ScrollView scroll = targetView instanceof ScrollView ? (ScrollView) targetView : storeScroll;
        switch (event.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_LOCATION:
                if (draggingStoreCard == null || draggingStoreId < 0 || scroll == null) return true;
                float localY = event.getY();
                int edge = dp(72);
                int step = dp(24);
                if (localY < edge) scroll.scrollBy(0, -step);
                else if (localY > scroll.getHeight() - edge) scroll.scrollBy(0, step);
                float contentY = scroll.getScrollY() + localY;
                float translationY = contentY - draggingStoreCard.getTop() - draggingStoreGrabOffsetY;
                draggingStoreCard.setTranslationX(0f);
                draggingStoreCard.setTranslationY(translationY);
                float draggedCenterY = draggingStoreCard.getTop() + translationY + draggingStoreCard.getHeight() / 2f;
                int nextTarget = computeStoreDragTargetIndex(draggedCenterY);
                if (nextTarget != draggingStoreTargetIndex) {
                    draggingStoreTargetIndex = nextTarget;
                    animateStoreDragSlots(nextTarget);
                    DiagLog.write(this, "STORE_DRAG_TARGET id=" + draggingStoreId + " index=" + nextTarget);
                }
                return true;
            case DragEvent.ACTION_DROP:
                // ACTION_DRAG_ENDED follows immediately; mark the drop handled even when the
                // final index is unchanged so the settle animation is not started twice.
                draggingStoreDropCommitted = true;
                finishStoreDrag(true);
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                if (!draggingStoreDropCommitted) finishStoreDrag(false);
                return true;
            default:
                return true;
        }
    }

    private int computeStoreDragTargetIndex(float draggedCenterY) {
        int count = storeContainer.getChildCount();
        int candidate = 0;
        for (int i = 0; i < count; i++) {
            if (i == draggingStoreSourceIndex) continue;
            View child = storeContainer.getChildAt(i);
            float mid = child.getTop() + child.getHeight() / 2f;
            if (draggedCenterY > mid) candidate++;
        }
        return Math.max(0, Math.min(count - 1, candidate));
    }

    private void animateStoreDragSlots(int targetIndex) {
        if (draggingStoreCard == null || draggingStoreSourceIndex < 0) return;
        for (int i = 0; i < storeContainer.getChildCount(); i++) {
            View child = storeContainer.getChildAt(i);
            if (child == draggingStoreCard) continue;
            float targetY = 0f;
            if (targetIndex > draggingStoreSourceIndex && i > draggingStoreSourceIndex && i <= targetIndex) {
                targetY = -draggingStoreSlotHeight;
            } else if (targetIndex < draggingStoreSourceIndex && i >= targetIndex && i < draggingStoreSourceIndex) {
                targetY = draggingStoreSlotHeight;
            }
            child.animate()
                    .translationY(targetY)
                    .setDuration(150)
                    .setInterpolator(new DecelerateInterpolator(1.55f))
                    .start();
        }
    }

    private void finishStoreDrag(boolean commit) {
        if (draggingStoreCard == null || draggingStoreId < 0) return;
        final View source = draggingStoreCard;
        final long sourceId = draggingStoreId;
        final int sourceIndex = draggingStoreSourceIndex;
        final int targetIndex = draggingStoreTargetIndex;
        if (commit && targetIndex >= 0 && targetIndex < storeContainer.getChildCount() && targetIndex != sourceIndex) {
            View targetView = storeContainer.getChildAt(targetIndex);
            Object tag = targetView.getTag();
            if (tag instanceof Long) {
                long targetId = (Long) tag;
                boolean after = targetIndex > sourceIndex;
                db.moveStore(sourceId, targetId, after);
                DiagLog.write(this, "STORE_REORDER dragged=" + sourceId + " target=" + targetId + " after=" + after);
                draggingStoreDropCommitted = true;
                float settleY = targetView.getTop() - source.getTop();
                source.animate()
                        .translationX(0f)
                        .translationY(settleY)
                        .scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(145)
                        .setInterpolator(new DecelerateInterpolator(1.6f))
                        .withEndAction(() -> {
                            clearStoreDragState();
                            reloadStores();
                        })
                        .start();
                return;
            }
        }
        for (int i = 0; i < storeContainer.getChildCount(); i++) {
            View child = storeContainer.getChildAt(i);
            if (child == source) continue;
            child.animate().translationY(0f).setDuration(130).setInterpolator(new DecelerateInterpolator()).start();
        }
        source.animate()
                .translationX(0f).translationY(0f)
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(145)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(this::clearStoreDragState)
                .start();
    }

    private void clearStoreDragState() {
        if (draggingStoreCard != null) draggingStoreCard.setElevation(0f);
        draggingStoreCard = null;
        draggingStoreId = -1L;
        draggingStoreSourceIndex = -1;
        draggingStoreTargetIndex = -1;
        draggingStoreGrabOffsetY = 0f;
        draggingStoreSlotHeight = 0;
        draggingStoreDropCommitted = false;
    }

    private static final class InvisibleDragShadowBuilder extends View.DragShadowBuilder {
        InvisibleDragShadowBuilder(View view) { super(view); }
        @Override public void onProvideShadowMetrics(android.graphics.Point size, android.graphics.Point touch) {
            size.set(1, 1);
            touch.set(0, 0);
        }
        @Override public void onDrawShadow(Canvas canvas) { }
    }

    private View makeTagSelector(DatabaseHelper.Store store) {
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(0, 0, 0, dp(4));

        HorizontalScrollView hsv = newAutoFadeHorizontalScrollView();
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setFillViewport(false);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        boolean photoSelecting = shareSelectionStoreId == store.id && !shareSelectedPhotoIds.isEmpty();
        long selected = photoSelecting ? commonSelectedPhotoTagId(store.id) : selectedTagForStore(store.id);
        for (DatabaseHelper.Tag tag : db.listTags()) {
            TextView chip = chip(tag.name, selected == tag.id, false);
            chip.setTag(tag.id);
            if (store.enabled) {
                attachInlineTagReorderGesture(chip, row, tag);
                chip.setOnClickListener(v -> {
                    if (shareSelectionStoreId == store.id && !shareSelectedPhotoIds.isEmpty()) {
                        applyTagToSelectedPhotos(store, tag.id);
                    } else {
                        saveSelectedTag(store.id, tag.id);
                        reloadStores();
                    }
                });
            } else {
                chip.setEnabled(false);
                chip.setAlpha(1f);
                chip.setTextColor(LGRAY);
            }
            row.addView(chip);
        }
        TextView none = chip("タグなし", selected == -1L, true);
        if (store.enabled) {
            none.setOnClickListener(v -> {
                if (shareSelectionStoreId == store.id && !shareSelectedPhotoIds.isEmpty()) {
                    applyTagToSelectedPhotos(store, null);
                } else {
                    saveSelectedTag(store.id, -1L);
                    reloadStores();
                }
            });
        } else {
            none.setEnabled(false);
            none.setAlpha(1f);
            none.setTextColor(LGRAY);
        }
        row.addView(none);
        hsv.addView(row);
        line.addView(hsv, new LinearLayout.LayoutParams(0, dp(42), 1f));

        ImageView manage = roundPlusIcon(store.enabled ? ORANGE : DGRAY,
                store.enabled ? WHITE : LGRAY, "タグ管理");
        if (store.enabled) {
            manage.setOnClickListener(v -> showTagManager());
        } else {
            manage.setEnabled(false);
            manage.setAlpha(1f);
        }
        LinearLayout.LayoutParams plusLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        plusLp.leftMargin = dp(8);
        line.addView(manage, plusLp);
        return line;
    }

    private long commonSelectedPhotoTagId(long storeId) {
        boolean found = false;
        long common = Long.MIN_VALUE;
        for (DatabaseHelper.Photo photo : db.listPhotos(storeId)) {
            if (!shareSelectedPhotoIds.contains(photo.id)) continue;
            long value = photo.tagId == null ? -1L : photo.tagId;
            if (!found) {
                common = value;
                found = true;
            } else if (common != value) {
                return Long.MIN_VALUE;
            }
        }
        return found ? common : Long.MIN_VALUE;
    }

    private void applyTagToSelectedPhotos(DatabaseHelper.Store store, Long tagId) {
        if (!store.enabled) {
            Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            return;
        }
        if (shareSelectionStoreId != store.id || shareSelectedPhotoIds.isEmpty()) return;
        int changed = 0;
        for (Long photoId : new ArrayList<>(shareSelectedPhotoIds)) {
            if (photoId == null) continue;
            db.updatePhotoTag(photoId, tagId);
            changed++;
        }
        DiagLog.write(this, "PHOTO_MULTI_TAG store=" + store.id + " tag=" + tagId + " count=" + changed);
        reloadStores();
    }

    private Set<Long> commonSelectedPhotoTagIds(long storeId) {
        Set<Long> common = null;
        for (DatabaseHelper.Photo photo : db.listPhotos(storeId)) {
            if (!shareSelectedPhotoIds.contains(photo.id)) continue;
            Set<Long> current = new HashSet<>(photo.tagIds);
            if (common == null) common = current;
            else common.retainAll(current);
        }
        return common == null ? new HashSet<>() : common;
    }

    private ArrayList<Long> orderedTagIds(Set<Long> tagIds) {
        ArrayList<Long> ordered = new ArrayList<>();
        if (tagIds == null || tagIds.isEmpty()) return ordered;
        for (DatabaseHelper.Tag tag : db.listTags()) {
            if (tagIds.contains(tag.id)) ordered.add(tag.id);
        }
        return ordered;
    }

    private void applyTagsToSelectedPhotos(DatabaseHelper.Store store, Set<Long> tagIds) {
        if (!store.enabled) {
            Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            return;
        }
        if (shareSelectionStoreId != store.id || shareSelectedPhotoIds.isEmpty()) return;
        ArrayList<Long> ids = new ArrayList<>(shareSelectedPhotoIds);
        ArrayList<Long> tags = orderedTagIds(tagIds);
        db.updatePhotosTags(ids, tags);
        DiagLog.write(this, "PHOTO_MULTI_TAGS store=" + store.id + " tags=" + tags + " count=" + ids.size());
        reloadStores();
    }

    private interface TagSelectionListener {
        void onChanged(Set<Long> selectedTags);
    }


    private View makeCommonTagSelectionArea(Set<Long> selectedTags, boolean multiSelect,
                                            boolean editable, TagSelectionListener listener) {
        LinearLayout host = new LinearLayout(this);
        host.setGravity(Gravity.BOTTOM);
        host.setMinimumHeight(dp(34));
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            host.removeAllViews();
            TagFlowLayout flow = new TagFlowLayout(this);
            flow.setPadding(0, 0, 0, 0);
            for (DatabaseHelper.Tag tag : db.listTags()) {
                boolean selected = selectedTags.contains(tag.id);
                TextView tagChip = tagChip(tag.name, selected, false);
                tagChip.setTag(tag.id);
                if (editable) {
                    tagChip.setOnClickListener(v -> {
                        if (multiSelect) {
                            if (!selectedTags.add(tag.id)) selectedTags.remove(tag.id);
                        } else {
                            selectedTags.clear();
                            selectedTags.add(tag.id);
                        }
                        if (listener != null) listener.onChanged(new HashSet<>(selectedTags));
                        render[0].run();
                    });
                    tagChip.setOnLongClickListener(v -> {
                        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                        showRenameTagDialog(tag, () -> {
                            if (listener != null) listener.onChanged(new HashSet<>(selectedTags));
                            render[0].run();
                        });
                        return true;
                    });
                } else {
                    tagChip.setEnabled(false);
                    tagChip.setAlpha(1f);
                    tagChip.setTextColor(LGRAY);
                }
                flow.addView(tagChip);
            }
            TextView none = tagChip("タグなし", selectedTags.isEmpty(), true);
            if (editable) {
                none.setOnClickListener(v -> {
                    selectedTags.clear();
                    if (listener != null) listener.onChanged(new HashSet<>(selectedTags));
                    render[0].run();
                });
            } else {
                none.setEnabled(false);
                none.setAlpha(1f);
                none.setTextColor(LGRAY);
            }
            flow.addView(none);
            host.addView(flow, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            ImageView plus = roundPlusIcon(editable ? ORANGE : DGRAY,
                    editable ? WHITE : LGRAY, "タグ選択");
            if (editable) {
                plus.setOnClickListener(v -> showTagAddDialog(new HashSet<>(selectedTags), chosen -> {
                    selectedTags.clear();
                    if (chosen != null) selectedTags.addAll(chosen);
                    if (listener != null) listener.onChanged(new HashSet<>(selectedTags));
                    render[0].run();
                }, () -> {
                    HashSet<Long> valid = new HashSet<>();
                    for (DatabaseHelper.Tag tag : db.listTags()) valid.add(tag.id);
                    selectedTags.retainAll(valid);
                    render[0].run();
                }));
            } else {
                plus.setEnabled(false);
                plus.setAlpha(1f);
            }
            LinearLayout.LayoutParams plusLp = new LinearLayout.LayoutParams(dp(34), dp(34));
            plusLp.leftMargin = dp(8);
            host.addView(plus, plusLp);
        };
        render[0].run();
        return host;
    }
    private View makeStoreFilterArea(Set<Long> selectedStoreIds, Runnable onChanged) {
        LinearLayout host = new LinearLayout(this);
        host.setGravity(Gravity.CENTER_VERTICAL);
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            host.removeAllViews();
            HorizontalScrollView hsv = newAutoFadeHorizontalScrollView();
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.setFillViewport(false);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView all = chip("全カード", selectedStoreIds.isEmpty(), false);
            all.setOnClickListener(v -> {
                if (!selectedStoreIds.isEmpty()) {
                    selectedStoreIds.clear();
                    DiagLog.write(this, "PRODUCT_FILTER_STORE all=true");
                    render[0].run();
                    if (onChanged != null) onChanged.run();
                }
            });
            row.addView(all);

            for (DatabaseHelper.Store store : db.listStores()) {
                if (!store.enabled) continue;
                TextView storeChip = chip(store.name, selectedStoreIds.contains(store.id), false);
                storeChip.setTag(store.id);
                storeChip.setOnClickListener(v -> {
                    if (!selectedStoreIds.add(store.id)) selectedStoreIds.remove(store.id);
                    // Empty means "全カード", so removing the final individual choice restores it automatically.
                    DiagLog.write(this, "PRODUCT_FILTER_STORE ids=" + selectedStoreIds);
                    render[0].run();
                    if (onChanged != null) onChanged.run();
                });
                row.addView(storeChip);
            }
            hsv.addView(row);
            host.addView(hsv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        };
        render[0].run();
        return host;
    }

    private View makeProductTagFilterArea(Set<Long> selectedTagIds, Runnable onChanged) {
        LinearLayout host = new LinearLayout(this);
        host.setGravity(Gravity.CENTER_VERTICAL);
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            host.removeAllViews();
            HorizontalScrollView hsv = newAutoFadeHorizontalScrollView();
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.setFillViewport(false);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);

            for (DatabaseHelper.Tag tag : db.listTags()) {
                TextView tagChip = chip(tag.name, selectedTagIds.contains(tag.id), false);
                tagChip.setTag(tag.id);
                tagChip.setOnClickListener(v -> {
                    if (!selectedTagIds.add(tag.id)) selectedTagIds.remove(tag.id);
                    DiagLog.write(this, "PRODUCT_FILTER_TAG ids=" + selectedTagIds);
                    render[0].run();
                    if (onChanged != null) onChanged.run();
                });
                row.addView(tagChip);
            }

            TextView none = chip("タグなし", selectedTagIds.contains(-1L), true);
            none.setOnClickListener(v -> {
                if (!selectedTagIds.add(-1L)) selectedTagIds.remove(-1L);
                DiagLog.write(this, "PRODUCT_FILTER_TAG ids=" + selectedTagIds);
                render[0].run();
                if (onChanged != null) onChanged.run();
            });
            row.addView(none);

            hsv.addView(row);
            host.addView(hsv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        };
        render[0].run();
        return host;
    }

    private void attachInlineTagReorderGesture(TextView chip, LinearLayout row, DatabaseHelper.Tag tag) {
        final boolean[] armed = {false};
        final boolean[] dragging = {false};
        final float[] downRawX = {0f};
        final int[] sourceIndex = {-1};
        final int[] targetIndex = {-1};

        chip.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX[0] = event.getRawX();
                    sourceIndex[0] = row.indexOfChild(v);
                    targetIndex[0] = sourceIndex[0];
                    armed[0] = false;
                    dragging[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (!armed[0]) return false;
                    float dx = event.getRawX() - downRawX[0];
                    if (!dragging[0] && Math.abs(dx) < dp(10)) return true;
                    dragging[0] = true;
                    v.setTranslationX(dx);
                    v.setTranslationY(0f);
                    int target = nearestChildIndexByRawX(row, event.getRawX(), true);
                    if (target >= 0 && target != targetIndex[0]) {
                        targetIndex[0] = target;
                        animateHorizontalReorderPreview(row, v, sourceIndex[0], targetIndex[0], true);
                        DiagLog.write(this, "TAG_INLINE_REORDER_MOVE id=" + tag.id + " index=" + target);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!armed[0]) return false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    int from = sourceIndex[0];
                    int to = targetIndex[0];
                    boolean wasDragging = dragging[0];
                    resetHorizontalReorderPreview(row, v);
                    v.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(130).setInterpolator(new DecelerateInterpolator()).start();
                    if (commit && wasDragging && from >= 0 && to >= 0 && from != to) {
                        ArrayList<Long> ordered = new ArrayList<>();
                        for (DatabaseHelper.Tag t : db.listTags()) ordered.add(t.id);
                        int logicalFrom = ordered.indexOf(tag.id);
                        int logicalTo = logicalTagIndexForChild(row, to);
                        if (logicalFrom >= 0 && logicalTo >= 0) {
                            moveListItem(ordered, logicalFrom, logicalTo);
                            db.setTagOrder(ordered);
                            DiagLog.write(this, "TAG_INLINE_REORDER_SAVE id=" + tag.id + " from=" + logicalFrom + " to=" + logicalTo);
                            row.postDelayed(this::reloadStores, 120);
                        }
                    }
                    armed[0] = false;
                    dragging[0] = false;
                    sourceIndex[0] = -1;
                    targetIndex[0] = -1;
                    return true;
                default:
                    return armed[0];
            }
        });

        chip.setOnLongClickListener(v -> {
            armed[0] = true;
            dragging[0] = false;
            sourceIndex[0] = row.indexOfChild(v);
            targetIndex[0] = sourceIndex[0];
            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            v.animate().scaleX(1.04f).scaleY(1.04f).alpha(0.86f).setDuration(80).start();
            DiagLog.write(this, "TAG_INLINE_REORDER_ARM id=" + tag.id + " name=" + tag.name);
            return true;
        });
    }

    private int logicalTagIndexForChild(LinearLayout row, int childIndex) {
        int logical = -1;
        for (int i = 0; i <= childIndex && i < row.getChildCount(); i++) {
            if (row.getChildAt(i).getTag() instanceof Long) logical++;
        }
        return Math.max(0, logical);
    }

    private View makeActionRow(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(0, dp(8), 0, dp(8));

        LinearLayout row1 = new LinearLayout(this);
        TextView camera = button("撮影", BLUE, 16);
        TextView addImage = button("画像追加", BLUE, 15);
        if (store.enabled) {
            camera.setOnClickListener(v -> takePhoto(store));
            addImage.setOnClickListener(v -> importImages(store));
        } else {
            setButtonEnabledStyle(camera, false, BLUE);
            setButtonEnabledStyle(addImage, false, BLUE);
        }
        LinearLayout.LayoutParams r1a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r1a.rightMargin = dp(4);
        LinearLayout.LayoutParams r1b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r1b.leftMargin = dp(4);
        row1.addView(camera, r1a);
        row1.addView(addImage, r1b);
        outer.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setPadding(0, dp(8), 0, 0);
        TextView list = button("商品リスト", DGRAY, 15);
        list.setOnClickListener(v -> showProductTableDialog(store.name + " / 商品リスト", store.id, ""));
        TextView csv = button("CSV一覧", DGRAY, 15);
        csv.setOnClickListener(v -> showImportHistoryDialog(store.id));
        LinearLayout.LayoutParams r2a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r2a.rightMargin = dp(4);
        LinearLayout.LayoutParams r2b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r2b.leftMargin = dp(4);
        row2.addView(list, r2a);
        row2.addView(csv, r2b);
        outer.addView(row2);
        return outer;
    }

    private View makeTabs(DatabaseHelper.Store store) {
        String tab = activeTab.getOrDefault(store.id, "list");
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, 0, 0, dp(8));
        TextView list = button("商品リスト", "list".equals(tab) ? LBLUE : DGRAY, 15);
        list.setOnClickListener(v -> { activeTab.put(store.id, "list"); reloadStores(); });
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp1.rightMargin = dp(4);
        row.addView(list, lp1);
        TextView images = button("画像", "images".equals(tab) ? LBLUE : DGRAY, 15);
        images.setOnClickListener(v -> { activeTab.put(store.id, "images"); reloadStores(); });
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp2.leftMargin = dp(4);
        row.addView(images, lp2);
        return row;
    }

    private View makeStoreBody(DatabaseHelper.Store store) {
        return "images".equals(activeTab.getOrDefault(store.id, "list")) ? makePhotoGrid(store) : makeProductSheet(store);
    }

    private View makeProductSheet(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.ProductRecord> products = db.listProductsForStore(store.id);
        boolean selecting = productSelectionStoreId == store.id;
        final TextView[] selectionCountView = {null};
        final TextView[] selectionDeleteView = {null};
        final TextView[] selectionSameView = {null};
        final TextView[] selectionMoveView = {null};

        if (!selecting) {
            LinearLayout bar = new LinearLayout(this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setPadding(0, 0, 0, dp(UI_SPACING_DP));

            ImageView addManual = makeManualProductAddIcon(store.id, this::reloadStores);
            bar.addView(addManual, new LinearLayout.LayoutParams(dp(38), dp(38)));
            bar.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));

            TextView selectAll = button("全て選択", DGRAY, 13);
            selectAll.setOnClickListener(v -> {
                if (products.isEmpty()) {
                    Toast.makeText(this, "選択する商品がありません", Toast.LENGTH_SHORT).show();
                    return;
                }
                productSelectionStoreId = store.id;
                selectedProductIds.clear();
                for (DatabaseHelper.ProductRecord product : products) selectedProductIds.add(product.id);
                DiagLog.write(this, "PRODUCT_SELECT_ALL store=" + store.id + " count=" + selectedProductIds.size() + " source=card");
                reloadStores();
            });
            LinearLayout.LayoutParams allLp = new LinearLayout.LayoutParams(dp(96), dp(38));
            allLp.rightMargin = dp(UI_ACTION_GAP_DP);
            bar.addView(selectAll, allLp);

            TextView select = button("選択", BLUE, 13);
            select.setOnClickListener(v -> {
                productSelectionStoreId = store.id;
                selectedProductIds.clear();
                DiagLog.write(this, "PRODUCT_SELECT_START store=" + store.id + " source=button");
                reloadStores();
            });
            bar.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
            outer.addView(bar);
        }

        if (selecting) {
            LinearLayout bar = new LinearLayout(this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setPadding(0, 0, 0, dp(UI_SPACING_DP));

            TextView count = text(selectedProductIds.size() + "件選択", 14, SECONDARY, true);
            selectionCountView[0] = count;
            bar.addView(count, new LinearLayout.LayoutParams(0, dp(40), 1f));

            TextView delete = button("削除", selectedProductIds.isEmpty() ? DGRAY : RED, 13);
            selectionDeleteView[0] = delete;
            setButtonEnabledStyle(delete, !selectedProductIds.isEmpty(), RED);
            delete.setOnClickListener(v -> {
                if (!selectedProductIds.isEmpty()) {
                    confirmDeleteProducts(new ArrayList<>(selectedProductIds), () -> {
                        cancelProductSelection();
                        reloadStores();
                    });
                }
            });
            LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(72), dp(38));
            delLp.rightMargin = dp(6);
            bar.addView(delete, delLp);

            TextView same = button("同一商品", selectedProductIds.size() < 2 ? DGRAY : ORANGE, 13);
            selectionSameView[0] = same;
            setButtonEnabledStyle(same, selectedProductIds.size() >= 2, ORANGE);
            same.setOnClickListener(v -> {
                if (selectedProductIds.size() >= 2) {
                    showUnifyProductsDialog(new ArrayList<>(selectedProductIds), () -> {
                        cancelProductSelection();
                        reloadStores();
                    });
                }
            });
            LinearLayout.LayoutParams sameLp = new LinearLayout.LayoutParams(dp(92), dp(38));
            sameLp.leftMargin = dp(6);
            bar.addView(same, sameLp);

            TextView cancel = button("キャンセル", DGRAY, 13);
            cancel.setOnClickListener(v -> {
                cancelProductSelection();
                reloadStores();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(88), dp(38));
            cp.leftMargin = dp(6);
            bar.addView(cancel, cp);

            TextView move = button("タグ編集", selectedProductIds.isEmpty() ? DGRAY : BLUE, 13);
            selectionMoveView[0] = move;
            setButtonEnabledStyle(move, !selectedProductIds.isEmpty(), BLUE);
            move.setOnClickListener(v -> {
                if (!selectedProductIds.isEmpty()) {
                    showMoveProductsTagDialog(new ArrayList<>(selectedProductIds), () -> {
                        cancelProductSelection();
                        reloadStores();
                    });
                }
            });
            LinearLayout.LayoutParams moveLp = new LinearLayout.LayoutParams(dp(96), dp(38));
            moveLp.leftMargin = dp(6);
            bar.addView(move, moveLp);
            outer.addView(bar);
        }

        if (products.isEmpty()) {
            TextView empty = text("商品データはまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        // Keep this fallback sheet aligned with the active product-list columns; comparison lives on the magnifier path.
        sheet.addView(sheetHeader(new String[]{"商品名", "価格", "容量", "タグ"}, new int[]{240, 100, 90, 100}));
        for (DatabaseHelper.ProductRecord p : products) {
            LinearLayout row = sheetRow(new String[]{p.rawName, p.priceYen == null ? "—" : yen(p.priceYen),
                            formatVolumeDisplay(p.volume), ""},
                    new int[]{240, 100, 90, 100});
            if (row.getChildCount() > 3) {
                row.removeViewAt(3);
                row.addView(makeProductTagCell(p, this::reloadStores), 3,
                        new LinearLayout.LayoutParams(dp(100), ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            if (selecting && selectedProductIds.contains(p.id)) row.setBackgroundColor(BLUE);
            row.setOnClickListener(v -> {
                if (productSelectionStoreId == store.id) {
                    toggleProductSelection(p.id);
                    if (productSelectionStoreId == store.id) {
                        row.setBackgroundColor(selectedProductIds.contains(p.id) ? BLUE : Color.TRANSPARENT);
                        refreshStoreProductSelectionBar(selectionCountView[0], selectionDeleteView[0],
                                selectionSameView[0], selectionMoveView[0]);
                    } else {
                        reloadStores();
                    }
                } else {
                    DatabaseHelper.ProductRecord fresh = db.getProduct(p.id);
                    showProductEditor(fresh == null ? p : fresh, this::reloadStores);
                }
            });
            row.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                if (productSelectionStoreId != store.id) {
                    productSelectionStoreId = store.id;
                    selectedProductIds.clear();
                    selectedProductIds.add(p.id);
                    DiagLog.write(this, "PRODUCT_SELECT_START store=" + store.id + " product=" + p.id + " source=long_press");
                    reloadStores();
                } else {
                    toggleProductSelection(p.id);
                    if (productSelectionStoreId == store.id) {
                        row.setBackgroundColor(selectedProductIds.contains(p.id) ? BLUE : Color.TRANSPARENT);
                        refreshStoreProductSelectionBar(selectionCountView[0], selectionDeleteView[0],
                                selectionSameView[0], selectionMoveView[0]);
                    } else {
                        reloadStores();
                    }
                }
                return true;
            });
            sheet.addView(row);
        }
        outer.addView(wrapHorizontal(sheet));
        return outer;
    }

    private void toggleProductSelection(long productId) {
        boolean selected;
        if (selectedProductIds.contains(productId)) {
            selectedProductIds.remove(productId);
            selected = false;
        } else {
            selectedProductIds.add(productId);
            selected = true;
        }
        DiagLog.write(this, "PRODUCT_SELECT_TOGGLE product=" + productId + " selected=" + selected + " count=" + selectedProductIds.size());
        // Match photo selection: clearing the final selected row is the same as Cancel.
        if (!selected && selectedProductIds.isEmpty()) {
            long storeId = productSelectionStoreId;
            cancelProductSelection();
            DiagLog.write(this, "PRODUCT_SELECT_END_EMPTY store=" + storeId);
        }
    }

    private void cancelProductSelection() {
        if (productSelectionStoreId >= 0) {
            DiagLog.write(this, "PRODUCT_SELECT_CANCEL store=" + productSelectionStoreId + " count=" + selectedProductIds.size());
        }
        productSelectionStoreId = -1L;
        selectedProductIds.clear();
    }

    private void refreshStoreProductSelectionBar(TextView count, TextView delete, TextView same, TextView move) {
        if (count != null) count.setText(selectedProductIds.size() + "件選択");
        if (delete != null) setButtonEnabledStyle(delete, !selectedProductIds.isEmpty(), RED);
        if (same != null) setButtonEnabledStyle(same, selectedProductIds.size() >= 2, ORANGE);
        if (move != null) setButtonEnabledStyle(move, !selectedProductIds.isEmpty(), BLUE);
    }

    private View makePhotoGrid(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);

        boolean selecting = shareSelectionStoreId == store.id;
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, 0, 0, dp(UI_SPACING_DP));
        if (selecting) {
            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.CENTER_VERTICAL);

            boolean canEdit = store.enabled && !shareSelectedPhotoIds.isEmpty();
            TextView delete = button("削除", canEdit ? RED : DGRAY, 12);
            setButtonEnabledStyle(delete, canEdit, RED);
            delete.setOnClickListener(v -> {
                if (canEdit) confirmDeleteSelectedPhotos(store);
            });
            actions.addView(delete, new LinearLayout.LayoutParams(0, dp(38), 1f));

            TextView share = button("共有", shareSelectedPhotoIds.isEmpty() ? DGRAY : ORANGE, 12);
            setButtonEnabledStyle(share, !shareSelectedPhotoIds.isEmpty(), ORANGE);
            share.setOnClickListener(v -> { if (!shareSelectedPhotoIds.isEmpty()) shareSelectedPhotos(store); });
            LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            shareLp.leftMargin = dp(UI_ACTION_GAP_DP);
            actions.addView(share, shareLp);

            TextView cancel = button("キャンセル", DGRAY, 12);
            cancel.setOnClickListener(v -> {
                shareSelectionStoreId = -1L;
                shareSelectedPhotoIds.clear();
                DiagLog.write(this, "SHARE_SELECT_CANCEL store=" + store.id + " source=card");
                refreshExpandedStoreDetails(store);
            });
            LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            cancelLp.leftMargin = dp(UI_ACTION_GAP_DP);
            actions.addView(cancel, cancelLp);

            TextView tagEdit = button("タグ編集", canEdit ? BLUE : DGRAY, 12);
            setButtonEnabledStyle(tagEdit, canEdit, BLUE);
            tagEdit.setOnClickListener(v -> {
                if (canEdit) showSelectedPhotoTagEditor(store);
            });
            LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(dp(96), dp(38));
            tagLp.leftMargin = dp(UI_ACTION_GAP_DP);
            actions.addView(tagEdit, tagLp);

            bar.addView(actions, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        } else {
            bar.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            bar.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));

            TextView selectAll = button("全て選択", DGRAY, 13);
            selectAll.setOnClickListener(v -> {
                if (photos.isEmpty()) {
                    Toast.makeText(this, "選択する画像がありません", Toast.LENGTH_SHORT).show();
                    return;
                }
                shareSelectionStoreId = store.id;
                shareSelectedPhotoIds.clear();
                for (DatabaseHelper.Photo photo : photos) shareSelectedPhotoIds.add(photo.id);
                DiagLog.write(this, "SHARE_SELECT_ALL store=" + store.id + " count=" + shareSelectedPhotoIds.size() + " source=card");
                refreshExpandedStoreDetails(store);
            });
            LinearLayout.LayoutParams allLp = new LinearLayout.LayoutParams(dp(96), dp(38));
            allLp.rightMargin = dp(UI_ACTION_GAP_DP);
            bar.addView(selectAll, allLp);

            TextView select = button("選択", BLUE, 13);
            select.setOnClickListener(v -> {
                if (photos.isEmpty()) {
                    Toast.makeText(this, "共有する画像がありません", Toast.LENGTH_SHORT).show();
                    return;
                }
                shareSelectionStoreId = store.id;
                shareSelectedPhotoIds.clear();
                DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" + photos.size() + " source=card_button");
                refreshExpandedStoreDetails(store);
            });
            bar.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
        }
        outer.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        if (photos.isEmpty()) {
            TextView empty = text("画像はまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }

        // The card only ever shows two rows. Building every historical thumbnail here made
        // expand/collapse progressively heavier as images accumulated, so render just six.
        List<DatabaseHelper.Photo> previewPhotos = photos.size() > 6
                ? new ArrayList<>(photos.subList(0, 6)) : photos;
        LinearLayout grid = buildPhotoGridRows(previewPhotos, store, selecting,
                () -> refreshExpandedStoreDetails(store), true);
        CardPhotoScrollView scroll = new CardPhotoScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(grid, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        outer.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Stable mirror footer. The selection count and "全て表示" occupy the same 92dp
        // slot from opposite edges so neither mode changes thumbnail geometry.
        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(0, dp(UI_TIGHT_SPACING_DP), 0, 0);
        TextView count = text(selecting ? (shareSelectedPhotoIds.size() + "枚選択") : "", 13, SECONDARY, true);
        count.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        count.setVisibility(selecting ? View.VISIBLE : View.INVISIBLE);
        footer.addView(count, new LinearLayout.LayoutParams(dp(92), dp(54)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(54), 1f));
        TextView all = makeDialogAction("全て表示");
        all.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        all.setOnClickListener(v -> showAllPhotosDialog(store));
        footer.addView(all, new LinearLayout.LayoutParams(dp(92), dp(54)));
        outer.addView(footer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        return outer;
    }

    private LinearLayout buildPhotoGridRows(List<DatabaseHelper.Photo> photos, DatabaseHelper.Store store,
                                            boolean selecting, Runnable selectionRefresh, boolean allowLongSelect) {
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < photos.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                row.setGravity(Gravity.TOP | Gravity.START);
                grid.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            DatabaseHelper.Photo photo = photos.get(i);
            boolean selected = shareSelectedPhotoIds.contains(photo.id);
            LinearLayout tile = makePhotoTile(photo, store, selecting, selected, allowLongSelect, selectionRefresh);
            row.addView(tile, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        int remainder = photos.size() % 3;
        if (row != null && remainder != 0) {
            for (int i = remainder; i < 3; i++) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(1), 1f));
            }
        }
        return grid;
    }

    private LinearLayout makePhotoTile(DatabaseHelper.Photo photo, DatabaseHelper.Store store,
                                       boolean selecting, boolean selected, boolean allowLongSelect) {
        return makePhotoTile(photo, store, selecting, selected, allowLongSelect, null);
    }

    private LinearLayout makePhotoTile(DatabaseHelper.Photo photo, DatabaseHelper.Store store,
                                       boolean selecting, boolean selected, boolean allowLongSelect, Runnable selectionRefresh) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(3), dp(3), dp(3), dp(5));

        SquareFrameLayout imageFrame = new SquareFrameLayout(this);
        imageFrame.setBackground(roundRect(DGRAY, THUMB_RADIUS_DP));
        imageFrame.setClipToOutline(true);
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundColor(DGRAY);
        bindThumbnailAsync(image, Uri.parse(photo.uri), 360, 360);
        imageFrame.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        if (photo.csvImported) {
            View imported = new StraightCheckBadgeView(this);
            imported.setContentDescription("CSV取り込み済み");
            FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP | Gravity.END);
            badgeLp.topMargin = dp(5);
            badgeLp.rightMargin = dp(5);
            imageFrame.addView(imported, badgeLp);
        }
        tile.addView(imageFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String label = photo.tagNames == null || photo.tagNames.trim().isEmpty() ? "タグなし" : photo.tagNames;
        LinearLayout textPanel = new LinearLayout(this);
        textPanel.setOrientation(LinearLayout.VERTICAL);
        textPanel.setGravity(Gravity.CENTER);
        textPanel.setBackground(roundRect(selecting && selected ? LBLUE : Color.TRANSPARENT, THUMB_RADIUS_DP));

        FrameLayout tagRow = new FrameLayout(this);
        TextView tag = text(label, 12, selected ? WHITE : SECONDARY, selected);
        tag.setGravity(Gravity.CENTER);
        tag.setSingleLine(true);
        tagRow.addView(tag, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(24), Gravity.CENTER));
        if (selecting && selected) {
            View check = new StraightSelectionCheckView(this);
            FrameLayout.LayoutParams checkLp = new FrameLayout.LayoutParams(dp(14), dp(14), Gravity.START | Gravity.CENTER_VERTICAL);
            checkLp.leftMargin = dp(5);
            tagRow.addView(check, checkLp);
        }
        textPanel.addView(tagRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        TextView added = text(dateFormat.format(new Date(photo.createdAt)), 10, SECONDARY, false);
        added.setGravity(Gravity.CENTER);
        added.setSingleLine(true);
        textPanel.addView(added, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(20)));

        LinearLayout.LayoutParams textPanelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        textPanelLp.topMargin = dp(6);
        tile.addView(textPanel, textPanelLp);

        tile.setOnClickListener(v -> {
            if (shareSelectionStoreId == store.id) {
                boolean selectedNow;
                if (shareSelectedPhotoIds.contains(photo.id)) {
                    shareSelectedPhotoIds.remove(photo.id);
                    selectedNow = false;
                } else {
                    shareSelectedPhotoIds.add(photo.id);
                    selectedNow = true;
                }
                DiagLog.write(this, "SHARE_SELECT_TOGGLE store=" + store.id + " photo=" + photo.id +
                        " selected=" + selectedNow + " total=" + shareSelectedPhotoIds.size());
                if (!selectedNow && shareSelectedPhotoIds.isEmpty()) {
                    shareSelectionStoreId = -1L;
                    DiagLog.write(this, "SHARE_SELECT_END_EMPTY store=" + store.id);
                }
                if (selectionRefresh != null) selectionRefresh.run(); else reloadStores();
            } else {
                showPhotoDetail(photo, store);
            }
        });
        if (allowLongSelect) {
            tile.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                if (shareSelectionStoreId != store.id) {
                    shareSelectionStoreId = store.id;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" +
                            db.listPhotos(store.id).size() + " source=long_press");
                }
                shareSelectedPhotoIds.add(photo.id);
                DiagLog.write(this, "SHARE_SELECT_TOGGLE store=" + store.id + " photo=" + photo.id +
                        " selected=true total=" + shareSelectedPhotoIds.size());
                if (selectionRefresh != null) selectionRefresh.run(); else reloadStores();
                return true;
            });
        }
        return tile;
    }

    private void confirmDeleteSelectedPhotos(DatabaseHelper.Store store) {
        confirmDeleteSelectedPhotos(store, null);
    }

    private void confirmDeleteSelectedPhotos(DatabaseHelper.Store store, Runnable afterDelete) {
        if (!store.enabled || shareSelectionStoreId != store.id || shareSelectedPhotoIds.isEmpty()) return;
        int count = shareSelectedPhotoIds.size();
        AlertDialog confirm = new AlertDialog.Builder(this)
                .setTitle("画像削除")
                .setMessage("選択した" + count + "枚を削除します。\n撮影画像は端末から削除し、追加画像はPrice Rec.からのみ外します。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    int deleted = 0;
                    for (DatabaseHelper.Photo photo : db.listPhotos(store.id)) {
                        if (!shareSelectedPhotoIds.contains(photo.id)) continue;
                        Uri uri = Uri.parse(photo.uri);
                        if (photo.managed) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                        } else {
                            releaseImportedPermission(uri);
                        }
                        db.deletePhoto(photo.id);
                        deleted++;
                    }
                    DiagLog.write(this, "PHOTO_MULTI_DELETE store=" + store.id + " count=" + deleted);
                    shareSelectionStoreId = -1L;
                    shareSelectedPhotoIds.clear();
                    Toast.makeText(this, deleted + "枚削除しました", Toast.LENGTH_SHORT).show();
                    if (afterDelete != null) afterDelete.run(); else reloadStores();
                })
                .create();
        showRoundedDialog(confirm);
    }

    private void showSelectedPhotoTagEditor(DatabaseHelper.Store store) {
        showSelectedPhotoTagEditor(store, null);
    }


    private void showSelectedPhotoTagEditor(DatabaseHelper.Store store, Runnable afterClose) {
        if (!store.enabled || shareSelectionStoreId != store.id || shareSelectedPhotoIds.isEmpty()) return;
        Set<Long> selectedTags = commonSelectedPhotoTagIds(store.id);
        showTagSelectionDialog(selectedTags, chosen -> applyTagsToSelectedPhotos(store, chosen), () -> {
            reloadStores();
            if (afterClose != null) afterClose.run();
        });
    }
    private void showAllPhotosDialog(DatabaseHelper.Store store) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP));

        TextView dialogTitle = text(store.name + " 画像", 22, WHITE, false);
        dialogTitle.setGravity(Gravity.CENTER_VERTICAL);
        dialogTitle.setIncludeFontPadding(false);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        titleLp.bottomMargin = dp(UI_SPACING_DP);
        content.addView(dialogTitle, titleLp);

        LinearLayout topHost = new LinearLayout(this);
        topHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        LinearLayout.LayoutParams topHostLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        topHostLp.bottomMargin = dp(UI_SPACING_DP);
        content.addView(topHost, topHostLp);

        FrameLayout photoHost = new FrameLayout(this);
        content.addView(photoHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(600)));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView footerSelectionCount = text("", 13, SECONDARY, true);
        footerSelectionCount.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        footer.addView(footerSelectionCount, new LinearLayout.LayoutParams(dp(92), dp(48)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView closeAction = makeDialogAction("閉じる");
        closeAction.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        footer.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        footerLp.topMargin = dp(UI_SPACING_DP);
        content.addView(footer, footerLp);

        final AlertDialog[] dialogHolder = new AlertDialog[1];
        final ScrollView[] photoScroll = {null};
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            int keepY = photoScroll[0] == null ? 0 : photoScroll[0].getScrollY();
            List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
            boolean selecting = shareSelectionStoreId == store.id;

            topHost.removeAllViews();
            topHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            if (selecting) {
                LinearLayout actions = new LinearLayout(this);
                actions.setGravity(Gravity.CENTER_VERTICAL);
                boolean canEdit = store.enabled && !shareSelectedPhotoIds.isEmpty();
                TextView delete = button("削除", canEdit ? RED : DGRAY, 12);
                setButtonEnabledStyle(delete, canEdit, RED);
                delete.setOnClickListener(v -> {
                    if (canEdit) confirmDeleteSelectedPhotos(store, render[0]);
                });
                actions.addView(delete, new LinearLayout.LayoutParams(0, dp(38), 1f));

                TextView share = button("共有", shareSelectedPhotoIds.isEmpty() ? DGRAY : ORANGE, 12);
                setButtonEnabledStyle(share, !shareSelectedPhotoIds.isEmpty(), ORANGE);
                share.setOnClickListener(v -> {
                    if (shareSelectedPhotoIds.isEmpty()) return;
                    if (dialogHolder[0] != null) dialogHolder[0].dismiss();
                    shareSelectedPhotos(store);
                });
                LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
                shareLp.leftMargin = dp(UI_ACTION_GAP_DP);
                actions.addView(share, shareLp);

                TextView cancel = button("キャンセル", DGRAY, 12);
                cancel.setOnClickListener(v -> {
                    shareSelectionStoreId = -1L;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_CANCEL store=" + store.id + " source=all_photos");
                    render[0].run();
                    refreshExpandedStoreDetails(store);
                });
                LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
                cancelLp.leftMargin = dp(UI_ACTION_GAP_DP);
                actions.addView(cancel, cancelLp);

                TextView tagEdit = button("タグ編集", canEdit ? BLUE : DGRAY, 12);
                setButtonEnabledStyle(tagEdit, canEdit, BLUE);
                tagEdit.setOnClickListener(v -> {
                    if (canEdit) showSelectedPhotoTagEditor(store, render[0]);
                });
                LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(dp(96), dp(38));
                tagLp.leftMargin = dp(UI_ACTION_GAP_DP);
                actions.addView(tagEdit, tagLp);
                topHost.addView(actions, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
            } else {
                TextView selectAll = button("全て選択", DGRAY, 13);
                selectAll.setOnClickListener(v -> {
                    if (photos.isEmpty()) {
                        Toast.makeText(this, "選択する画像がありません", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    shareSelectionStoreId = store.id;
                    shareSelectedPhotoIds.clear();
                    for (DatabaseHelper.Photo photo : photos) shareSelectedPhotoIds.add(photo.id);
                    DiagLog.write(this, "SHARE_SELECT_ALL store=" + store.id + " count=" + shareSelectedPhotoIds.size() + " source=all_photos");
                    render[0].run();
                    refreshExpandedStoreDetails(store);
                });
                LinearLayout.LayoutParams allLp = new LinearLayout.LayoutParams(dp(96), dp(38));
                allLp.rightMargin = dp(UI_ACTION_GAP_DP);
                topHost.addView(selectAll, allLp);

                TextView select = button("選択", BLUE, 13);
                select.setOnClickListener(v -> {
                    shareSelectionStoreId = store.id;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" + photos.size() + " source=all_photos_button");
                    render[0].run();
                });
                topHost.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
            }

            footerSelectionCount.setText(selecting ? (shareSelectedPhotoIds.size() + "枚選択") : "");
            footerSelectionCount.setVisibility(selecting ? View.VISIBLE : View.INVISIBLE);

            photoHost.removeAllViews();
            if (photos.isEmpty()) {
                TextView empty = text("画像はまだありません", 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                photoHost.addView(empty, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                photoScroll[0] = null;
                return;
            }

            LinearLayout grid = buildPhotoGridRows(photos, store, selecting, render[0], true);
            ScrollView scroll = newAutoFadeScrollView();
            scroll.setFillViewport(false);
            scroll.addView(grid);
            photoScroll[0] = scroll;
            photoHost.addView(withFastScroll(scroll), new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            if (keepY > 0) scroll.post(() -> scroll.scrollTo(0, keepY));
        };

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(content)
                .create();
        dialogHolder[0] = dialog;
        closeAction.setOnClickListener(v -> {
            if (shareSelectionStoreId == store.id) {
                shareSelectionStoreId = -1L;
                shareSelectedPhotoIds.clear();
                DiagLog.write(this, "SHARE_SELECT_END_OUTSIDE store=" + store.id + " source=all_photos_close");
                refreshExpandedStoreDetails(store);
            }
            dialog.dismiss();
        });
        dialog.setOnCancelListener(d -> {
            if (shareSelectionStoreId == store.id) {
                shareSelectionStoreId = -1L;
                shareSelectedPhotoIds.clear();
                DiagLog.write(this, "SHARE_SELECT_END_OUTSIDE store=" + store.id + " source=all_photos_outside");
                refreshExpandedStoreDetails(store);
            }
        });
        render[0].run();
        showRoundedDialog(dialog, true);
    }

    private void beginShareSelection(DatabaseHelper.Store store) {
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
        if (photos.isEmpty()) {
            Toast.makeText(this, "共有する画像がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        shareSelectionStoreId = store.id;
        shareSelectedPhotoIds.clear();
        DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" + photos.size() + " source=button");
        refreshExpandedStoreDetails(store);
    }

    private void cancelShareSelection() {
        long storeId = shareSelectionStoreId;
        if (storeId >= 0) DiagLog.write(this, "SHARE_SELECT_CANCEL store=" + storeId + " selected=" + shareSelectedPhotoIds.size());
        shareSelectionStoreId = -1L;
        shareSelectedPhotoIds.clear();
        DatabaseHelper.Store store = storeId >= 0 ? db.getStore(storeId) : null;
        if (store != null) refreshExpandedStoreDetails(store); else reloadStores();
    }

    private void shareSelectedPhotos(DatabaseHelper.Store store) {
        ArrayList<DatabaseHelper.Photo> selected = new ArrayList<>();
        for (DatabaseHelper.Photo photo : db.listPhotos(store.id)) {
            if (shareSelectedPhotoIds.contains(photo.id)) selected.add(photo);
        }
        if (selected.isEmpty()) {
            Toast.makeText(this, "画像を選択してください", Toast.LENGTH_SHORT).show();
            return;
        }
        shareSelectionStoreId = -1L;
        shareSelectedPhotoIds.clear();
        sharePhotosWithChatGpt(store, selected, commonTagLabel(selected));
        reloadStores();
    }

    private String commonTagLabel(List<DatabaseHelper.Photo> photos) {
        String common = null;
        for (DatabaseHelper.Photo p : photos) {
            String tag = p.tagName == null ? "タグなし" : p.tagName;
            if (common == null) common = tag;
            else if (!common.equals(tag)) return "複数タグ";
        }
        return common == null ? "タグなし" : common;
    }

    private interface MapAnalysisSuccess {
        void onSuccess(MapAnalysisResult result);
    }

    private static final class MapAnalysisResult {
        final String inputUrl;
        final String resolvedUrl;
        final Double lat;
        final Double lng;
        final String storeKey;

        MapAnalysisResult(String inputUrl, String resolvedUrl, Double lat, Double lng, String storeKey) {
            this.inputUrl = inputUrl == null ? "" : inputUrl.trim();
            this.resolvedUrl = resolvedUrl == null ? "" : resolvedUrl;
            this.lat = lat;
            this.lng = lng;
            this.storeKey = storeKey;
        }

        boolean hasCoordinates() {
            return lat != null && lng != null;
        }
    }

    private static final class MapCoordinates {
        final double lat;
        final double lng;
        MapCoordinates(double lat, double lng) { this.lat = lat; this.lng = lng; }
    }

    private static final class SimpleTextWatcher implements TextWatcher {
        private final Runnable changed;
        SimpleTextWatcher(Runnable changed) { this.changed = changed; }
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
        @Override public void afterTextChanged(Editable s) { if (changed != null) changed.run(); }
    }

    private void lockStoreKeyField(EditText keyInput) {
        if (keyInput == null) return;
        keyInput.setKeyListener(null);
        keyInput.setCursorVisible(false);
        keyInput.setLongClickable(false);
        keyInput.setFocusable(false);
        keyInput.setFocusableInTouchMode(false);
        keyInput.clearFocus();
        // Keep the normal input-field shape/surface visible while making the immutable value subdued.
        // The field is locked by interaction state, not by turning the whole control into a gray slab.
        keyInput.setTextColor(GRAY);
        keyInput.setHintTextColor(GRAY);
        keyInput.setBackground(roundRect(NWHITE, 999));
    }

    private void setMapAnalysisButtonState(TextView button, boolean parsed, boolean busy) {
        if (button == null) return;
        ProgressBar spinner = button.getTag() instanceof ProgressBar ? (ProgressBar) button.getTag() : null;
        button.setEnabled(!busy);
        if (spinner != null) spinner.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (busy) {
            // Keep the loading state unambiguous: the seek circle occupies the exact button center.
            button.setText("");
            button.setTextColor(WHITE);
            button.setBackground(roundRect(ORANGE, 999));
        } else if (parsed) {
            button.setText("解析済");
            button.setTextColor(WHITE);
            button.setBackground(roundRect(ORANGE, 999));
        } else {
            button.setText("マップ解析");
            button.setTextColor(WHITE);
            button.setBackground(roundRect(ORANGE, 999));
        }
    }

    private FrameLayout wrapMapAnalysisButton(TextView button) {
        FrameLayout holder = new FrameLayout(this);
        holder.addView(button, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ProgressBar spinner = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        spinner.setIndeterminate(true);
        if (spinner.getIndeterminateDrawable() != null) {
            spinner.getIndeterminateDrawable().setTint(NWHITE);
        }
        spinner.setVisibility(View.GONE);
        spinner.setClickable(false);
        spinner.setFocusable(false);
        FrameLayout.LayoutParams spinnerLp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER);
        holder.addView(spinner, spinnerLp);
        button.setTag(spinner);
        return holder;
    }

    private LinearLayout makeStoreInfoActionRow(TextView mapButton, TextView cancelButton, TextView commitButton) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(wrapMapAnalysisButton(mapButton), new LinearLayout.LayoutParams(dp(92), dp(38)));
        row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(dp(92), dp(38));
        cancelLp.rightMargin = dp(UI_ACTION_GAP_DP);
        row.addView(cancelButton, cancelLp);
        row.addView(commitButton, new LinearLayout.LayoutParams(dp(92), dp(38)));
        return row;
    }

    private void runMapAnalysis(String rawUrl, int token, int[] tokenHolder, MapAnalysisResult[] resultHolder,
                                EditText mapInput, TextView mapButton, boolean manual, MapAnalysisSuccess success) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) return;
        setMapAnalysisButtonState(mapButton, false, true);
        final String input = rawUrl.trim();
        DiagLog.write(this, "MAP_PARSE_START mode=" + (manual ? "manual" : "auto") + " " + mapUrlForLog(input));
        mapExecutor.execute(() -> {
            MapAnalysisResult result = null;
            try {
                result = resolveMapAnalysis(input);
            } catch (Exception e) {
                DiagLog.write(this, "MAP_PARSE_ERROR type=" + e.getClass().getSimpleName() +
                        " message=" + safeDiagValue(String.valueOf(e.getMessage()), 220));
            }
            final MapAnalysisResult finalResult = result;
            runOnUiThread(() -> {
                if (token != tokenHolder[0]) {
                    DiagLog.write(this, "MAP_PARSE_STALE reason=token");
                    return;
                }
                if (!input.equals(mapInput.getText().toString().trim())) {
                    DiagLog.write(this, "MAP_PARSE_STALE reason=url_changed");
                    return;
                }
                if (finalResult == null) {
                    resultHolder[0] = null;
                    setMapAnalysisButtonState(mapButton, false, false);
                    if (manual) Toast.makeText(this, "Googleマップ情報を取得できませんでした", Toast.LENGTH_SHORT).show();
                    return;
                }
                resultHolder[0] = finalResult;
                setMapAnalysisButtonState(mapButton, true, false);
                DiagLog.write(this, "MAP_PARSE_OK registered=true coordinates=" + finalResult.hasCoordinates() +
                        " lat=" + finalResult.lat + " lng=" + finalResult.lng +
                        " key=" + finalResult.storeKey + " resolved=" + mapUrlForLog(finalResult.resolvedUrl));
                if (success != null) success.onSuccess(finalResult);
            });
        });
    }

    private MapAnalysisResult resolveMapAnalysis(String rawInput) throws Exception {
        String current = normalizeMapInputUrl(rawInput);
        String responseBody = "";
        String stableIdentity = extractGoogleMapIdentity(current);
        Set<String> visited = new HashSet<>();

        for (int hop = 0; hop < 10; hop++) {
            if (!visited.add(current)) {
                DiagLog.write(this, "MAP_PARSE_REDIRECT_LOOP hop=" + hop + " " + mapUrlForLog(current));
                break;
            }

            String urlIdentity = extractGoogleMapIdentity(current);
            if (urlIdentity != null && !urlIdentity.isEmpty()) {
                stableIdentity = urlIdentity;
                DiagLog.write(this, "MAP_PARSE_IDENTITY source=url hop=" + hop +
                        " id=" + safeDiagValue(stableIdentity, 120));
            }

            MapCoordinates direct = extractMapCoordinates(current);
            if (stableIdentity != null && !stableIdentity.isEmpty()) {
                if (direct != null) {
                    DiagLog.write(this, "MAP_PARSE_COORDINATES source=url hop=" + hop +
                            " lat=" + direct.lat + " lng=" + direct.lng);
                }
                DiagLog.write(this, "MAP_PARSE_REGISTERED_STORE source=url hop=" + hop +
                        " id=" + safeDiagValue(stableIdentity, 120) +
                        " coordinates=" + (direct != null));
                return new MapAnalysisResult(rawInput.trim(), current,
                        direct == null ? null : direct.lat,
                        direct == null ? null : direct.lng,
                        buildDeterministicMapStoreKey(stableIdentity,
                                direct == null ? null : direct.lat,
                                direct == null ? null : direct.lng));
            }
            if (direct != null) {
                DiagLog.write(this, "MAP_PARSE_COORDINATES source=url hop=" + hop +
                        " lat=" + direct.lat + " lng=" + direct.lng);
                return new MapAnalysisResult(rawInput.trim(), current, direct.lat, direct.lng,
                        buildDeterministicMapStoreKey(null, direct.lat, direct.lng));
            }

            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(current).openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(9000);
                connection.setReadTimeout(9000);
                connection.setUseCaches(false);
                connection.setRequestProperty("User-Agent",
                        "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 " +
                                "(KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36");
                connection.setRequestProperty("Accept",
                        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8");
                connection.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en-US;q=0.7,en;q=0.6");
                connection.setRequestProperty("Cache-Control", "no-cache");
                connection.setRequestMethod("GET");

                int code = connection.getResponseCode();
                String contentType = connection.getContentType();
                DiagLog.write(this, "MAP_PARSE_HOP hop=" + hop + " code=" + code +
                        " type=" + safeDiagValue(contentType, 80) + " " + mapUrlForLog(current));

                if (code >= 300 && code < 400) {
                    String location = connection.getHeaderField("Location");
                    if (location == null || location.trim().isEmpty()) {
                        DiagLog.write(this, "MAP_PARSE_REDIRECT_MISSING hop=" + hop);
                        break;
                    }
                    String next = resolveMapCandidateUrl(current, location);
                    if (next == null || next.isEmpty()) {
                        DiagLog.write(this, "MAP_PARSE_REDIRECT_INVALID hop=" + hop +
                                " location=" + safeDiagValue(location, 180));
                        break;
                    }
                    DiagLog.write(this, "MAP_PARSE_REDIRECT hop=" + hop + " to=" + mapUrlForLog(next));
                    current = next;
                    continue;
                }

                InputStream stream = code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream();
                responseBody = readMapResponseBody(stream, 2_500_000);
                DiagLog.write(this, "MAP_PARSE_BODY hop=" + hop + " chars=" + responseBody.length());

                // Do not accept an arbitrary feature id found in the full Maps HTML as the selected store.
                // Only URL/canonical destination identities are authoritative for registration-store matching.

                // Prefer a canonical/redirect Maps URL over arbitrary coordinates embedded in the page shell.
                String candidate = extractMapDestinationUrl(current, responseBody);
                if (candidate != null && !candidate.isEmpty() && !candidate.equals(current)) {
                    DiagLog.write(this, "MAP_PARSE_HTML_REDIRECT hop=" + hop + " to=" + mapUrlForLog(candidate));
                    current = candidate;
                    String candidateIdentity = extractGoogleMapIdentity(candidate);
                    if (candidateIdentity != null && !candidateIdentity.isEmpty()) stableIdentity = candidateIdentity;
                    responseBody = "";
                    continue;
                }

                // Current Google Maps place pages often keep their initial center in APP_INITIALIZATION_STATE
                // rather than exposing !3d/!4d or @lat,lng in the resolved URL. For a selected place,
                // this initial center is the best non-API coordinate source available in the static HTML.
                MapCoordinates initializationCoordinates = extractGoogleInitializationCoordinates(responseBody);
                if (initializationCoordinates != null) {
                    DiagLog.write(this, "MAP_PARSE_COORDINATES source=app_init hop=" + hop +
                            " lat=" + initializationCoordinates.lat + " lng=" + initializationCoordinates.lng);
                    return new MapAnalysisResult(rawInput.trim(), current, initializationCoordinates.lat, initializationCoordinates.lng,
                            buildDeterministicMapStoreKey(stableIdentity, initializationCoordinates.lat, initializationCoordinates.lng));
                }

                MapCoordinates bodyCoordinates = extractMapCoordinates(responseBody);
                if (bodyCoordinates != null) {
                    DiagLog.write(this, "MAP_PARSE_COORDINATES source=body hop=" + hop +
                            " lat=" + bodyCoordinates.lat + " lng=" + bodyCoordinates.lng);
                    return new MapAnalysisResult(rawInput.trim(), current, bodyCoordinates.lat, bodyCoordinates.lng,
                            buildDeterministicMapStoreKey(stableIdentity, bodyCoordinates.lat, bodyCoordinates.lng));
                }

                if (code < 200 || code >= 400) {
                    DiagLog.write(this, "MAP_PARSE_HTTP_FAIL hop=" + hop + " code=" + code);
                }
                break;
            } finally {
                if (connection != null) connection.disconnect();
            }
        }

        String finalIdentity = extractGoogleMapIdentity(current);
        if (finalIdentity != null && !finalIdentity.isEmpty()) stableIdentity = finalIdentity;
        MapCoordinates finalCoordinates = extractMapCoordinates(current);

        if (stableIdentity != null && !stableIdentity.isEmpty()) {
            DiagLog.write(this, "MAP_PARSE_REGISTERED_STORE source=final id=" +
                    safeDiagValue(stableIdentity, 120) + " coordinates=" + (finalCoordinates != null));
            return new MapAnalysisResult(rawInput.trim(), current,
                    finalCoordinates == null ? null : finalCoordinates.lat,
                    finalCoordinates == null ? null : finalCoordinates.lng,
                    buildDeterministicMapStoreKey(stableIdentity,
                            finalCoordinates == null ? null : finalCoordinates.lat,
                            finalCoordinates == null ? null : finalCoordinates.lng));
        }

        if (finalCoordinates == null && !responseBody.isEmpty()) {
            finalCoordinates = extractGoogleInitializationCoordinates(responseBody);
            if (finalCoordinates == null) finalCoordinates = extractMapCoordinates(responseBody);
        }
        if (finalCoordinates == null) {
            DiagLog.write(this, "MAP_PARSE_NO_REGISTERED_STORE resolved=" + mapUrlForLog(current) +
                    " bodyChars=" + responseBody.length());
            return null;
        }
        DiagLog.write(this, "MAP_PARSE_COORDINATES source=final lat=" + finalCoordinates.lat +
                " lng=" + finalCoordinates.lng);
        return new MapAnalysisResult(rawInput.trim(), current, finalCoordinates.lat, finalCoordinates.lng,
                buildDeterministicMapStoreKey(null, finalCoordinates.lat, finalCoordinates.lng));
    }

    private String readMapResponseBody(InputStream stream, int maxChars) throws Exception {
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder body = new StringBuilder(Math.min(maxChars, 65536));
        char[] buf = new char[8192];
        int total = 0;
        int n;
        while ((n = reader.read(buf)) > 0 && total < maxChars) {
            int take = Math.min(n, maxChars - total);
            body.append(buf, 0, take);
            total += take;
        }
        reader.close();
        return body.toString();
    }

    private String normalizeMapInputUrl(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.startsWith("//")) return "https:" + value;
        if (value.startsWith("http://") || value.startsWith("https://")) return value;
        return "https://" + value;
    }

    private String resolveMapCandidateUrl(String baseUrl, String candidate) {
        if (candidate == null) return null;
        String value = decodeMapEscapes(candidate.trim());
        if (value.isEmpty()) return null;
        if (value.startsWith("intent://")) {
            Matcher fallback = Pattern.compile("S\\.browser_fallback_url=([^;]+)", Pattern.CASE_INSENSITIVE).matcher(value);
            if (fallback.find()) {
                try { value = URLDecoder.decode(fallback.group(1), StandardCharsets.UTF_8.name()); }
                catch (Exception ignored) { value = fallback.group(1); }
            } else {
                value = "https://" + value.substring("intent://".length()).replaceFirst("#Intent;.*$", "");
            }
        }
        if (value.startsWith("//")) value = "https:" + value;
        try {
            URL resolved = new URL(new URL(baseUrl), value);
            String protocol = resolved.getProtocol();
            if (!"http".equalsIgnoreCase(protocol) && !"https".equalsIgnoreCase(protocol)) return null;
            return resolved.toString();
        } catch (Exception ignored) {
            return null;
        }
    }

    private String extractMapDestinationUrl(String baseUrl, String body) {
        if (body == null || body.isEmpty()) return null;
        String decoded = decodeMapEscapes(body);

        Pattern[] preferred = new Pattern[]{
                Pattern.compile("<link[^>]+rel\\s*=\\s*['\"]canonical['\"][^>]+href\\s*=\\s*['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE),
                Pattern.compile("<link[^>]+href\\s*=\\s*['\"]([^'\"]+)['\"][^>]+rel\\s*=\\s*['\"]canonical['\"]", Pattern.CASE_INSENSITIVE),
                Pattern.compile("<meta[^>]+(?:property|name)\\s*=\\s*['\"]og:url['\"][^>]+content\\s*=\\s*['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE),
                Pattern.compile("<meta[^>]+content\\s*=\\s*['\"]([^'\"]+)['\"][^>]+(?:property|name)\\s*=\\s*['\"]og:url['\"]", Pattern.CASE_INSENSITIVE),
                Pattern.compile("<meta[^>]+http-equiv\\s*=\\s*['\"]refresh['\"][^>]+content\\s*=\\s*['\"][^'\"]*url\\s*=\\s*([^'\";>]+)", Pattern.CASE_INSENSITIVE),
                Pattern.compile("(?:window\\.)?location(?:\\.href)?\\s*=\\s*['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE),
                Pattern.compile("location\\.(?:replace|assign)\\(\\s*['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE)
        };
        for (Pattern pattern : preferred) {
            Matcher matcher = pattern.matcher(decoded);
            while (matcher.find()) {
                String next = resolveMapCandidateUrl(baseUrl, matcher.group(1));
                if (isUsefulMapDestination(baseUrl, next)) return next;
            }
        }

        Pattern genericMaps = Pattern.compile("https?://(?:www\\.)?(?:google\\.[^/\\s'\"<>]+/maps|maps\\.google\\.[^/\\s'\"<>]+|maps\\.app\\.goo\\.gl)/[^\\s'\"<>]+",
                Pattern.CASE_INSENSITIVE);
        Matcher genericMatcher = genericMaps.matcher(decoded);
        while (genericMatcher.find()) {
            String next = resolveMapCandidateUrl(baseUrl, genericMatcher.group());
            if (isUsefulMapDestination(baseUrl, next)) return next;
        }

        return null;
    }

    private boolean isUsefulMapDestination(String baseUrl, String candidate) {
        if (candidate == null || candidate.isEmpty()) return false;
        if (candidate.equals(baseUrl)) return false;
        try {
            URL url = new URL(candidate);
            String host = url.getHost().toLowerCase(Locale.ROOT);
            return host.contains("google.") || host.endsWith("goo.gl") || host.contains("maps.app.goo.gl");
        } catch (Exception ignored) {
            return false;
        }
    }

    private String decodeMapEscapes(String source) {
        if (source == null || source.isEmpty()) return "";
        String out = source;
        out = out.replace("&amp;", "&").replace("&#38;", "&").replace("&#x26;", "&")
                .replace("&quot;", "\"").replace("&#34;", "\"")
                .replace("\\u0026", "&").replace("\\u003d", "=").replace("\\u003D", "=")
                .replace("\\x26", "&").replace("\\x3d", "=").replace("\\x3D", "=")
                .replace("\\\"", "\"").replace("\\/", "/");
        // Google pages frequently JSON-escape query separators and slashes more than once.
        out = out.replace("\\\\u0026", "&").replace("\\\\u003d", "=").replace("\\\\/", "/");
        return out;
    }

    private String extractGoogleMapIdentity(String source) {
        if (source == null || source.isEmpty()) return null;
        ArrayList<String> candidates = new ArrayList<>();
        candidates.add(source);
        String unescaped = decodeMapEscapes(source);
        if (!unescaped.equals(source)) candidates.add(unescaped);
        try {
            String decoded = URLDecoder.decode(unescaped, StandardCharsets.UTF_8.name());
            if (!decoded.equals(unescaped)) candidates.add(decoded);
        } catch (Exception ignored) { }

        Pattern[] identityPatterns = new Pattern[]{
                // Maps data parameter: the selected feature id. This is much more stable than viewport coordinates.
                Pattern.compile("!1s(0x[0-9a-fA-F]+:0x[0-9a-fA-F]+)"),
                // Some shared Maps URLs expose the same feature id as ftid.
                Pattern.compile("[?&]ftid=([^&#\\\"'\\s]+)", Pattern.CASE_INSENSITIVE),
                // Legacy Maps CID links.
                Pattern.compile("[?&]cid=(\\d{6,})", Pattern.CASE_INSENSITIVE),
                // Place ids frequently appear in a !19s segment.
                Pattern.compile("!19s([A-Za-z0-9_-]{10,})"),
                // Knowledge-graph / machine ids used by Maps.
                Pattern.compile("(/(?:g|m)/[A-Za-z0-9_-]{4,})")
        };
        String[] prefixes = new String[]{"feature:", "ftid:", "cid:", "place:", "kgmid:"};
        for (String candidate : candidates) {
            for (int i = 0; i < identityPatterns.length; i++) {
                Matcher matcher = identityPatterns[i].matcher(candidate);
                if (!matcher.find()) continue;
                String value = matcher.group(1);
                if (value == null || value.trim().isEmpty()) continue;
                value = value.trim();
                try { value = URLDecoder.decode(value, StandardCharsets.UTF_8.name()); }
                catch (Exception ignored) { }
                if (i == 0) return prefixes[i] + value.toLowerCase(Locale.ROOT);
                return prefixes[i] + value;
            }
        }
        return null;
    }

    private MapCoordinates extractGoogleInitializationCoordinates(String source) {
        if (source == null || source.isEmpty()) return null;
        ArrayList<String> candidates = new ArrayList<>();
        candidates.add(source);
        String unescaped = decodeMapEscapes(source);
        if (!unescaped.equals(source)) candidates.add(unescaped);

        // Typical Maps shell (2024-2026):
        // APP_INITIALIZATION_STATE=[[[<scale>,<longitude>,<latitude>],null,...
        Pattern exact = Pattern.compile(
                "(?:window\\.)?APP_INITIALIZATION_STATE\\s*=\\s*\\[\\[\\[\\s*" +
                        "[-+]?\\d+(?:\\.\\d+)?(?:[eE][-+]?\\d+)?\\s*,\\s*" +
                        "(-?\\d{1,3}(?:\\.\\d+)?(?:[eE][-+]?\\d+)?)\\s*,\\s*" +
                        "(-?\\d{1,2}(?:\\.\\d+)?(?:[eE][-+]?\\d+)?)",
                Pattern.CASE_INSENSITIVE);

        for (String candidate : candidates) {
            Matcher matcher = exact.matcher(candidate);
            if (matcher.find()) {
                try {
                    double lng = Double.parseDouble(matcher.group(1));
                    double lat = Double.parseDouble(matcher.group(2));
                    if (isValidMapCoordinate(lat, lng)) return new MapCoordinates(lat, lng);
                } catch (Exception ignored) { }
            }

            // Keep the fallback tightly scoped to the first part of APP_INITIALIZATION_STATE so random
            // coordinates elsewhere in the 800KB Maps HTML cannot be mistaken for the selected place.
            Matcher marker = Pattern.compile("(?:window\\.)?APP_INITIALIZATION_STATE\\s*=", Pattern.CASE_INSENSITIVE)
                    .matcher(candidate);
            if (!marker.find()) continue;
            int start = marker.end();
            int end = Math.min(candidate.length(), start + 4096);
            String head = candidate.substring(start, end);
            Matcher triple = Pattern.compile(
                    "\\[\\s*[-+]?\\d+(?:\\.\\d+)?(?:[eE][-+]?\\d+)?\\s*,\\s*" +
                            "(-?\\d{1,3}(?:\\.\\d+)?(?:[eE][-+]?\\d+)?)\\s*,\\s*" +
                            "(-?\\d{1,2}(?:\\.\\d+)?(?:[eE][-+]?\\d+)?)\\s*\\]")
                    .matcher(head);
            while (triple.find()) {
                try {
                    double lng = Double.parseDouble(triple.group(1));
                    double lat = Double.parseDouble(triple.group(2));
                    if (isValidMapCoordinate(lat, lng)) return new MapCoordinates(lat, lng);
                } catch (Exception ignored) { }
            }
        }
        return null;
    }

    private MapCoordinates extractMapCoordinates(String source) {
        if (source == null || source.isEmpty()) return null;
        ArrayList<String> candidates = new ArrayList<>();
        candidates.add(source);
        String unescaped = decodeMapEscapes(source);
        if (!unescaped.equals(source)) candidates.add(unescaped);
        try {
            String decoded = URLDecoder.decode(unescaped, StandardCharsets.UTF_8.name());
            if (!decoded.equals(unescaped)) candidates.add(decoded);
        } catch (Exception ignored) { }

        Pattern[] patterns = new Pattern[]{
                Pattern.compile("!3d(-?\\d{1,2}(?:\\.\\d+)?)!4d(-?\\d{1,3}(?:\\.\\d+)?)"),
                Pattern.compile("/@(-?\\d{1,2}(?:\\.\\d+)?),(-?\\d{1,3}(?:\\.\\d+)?)"),
                Pattern.compile("(?:[?&](?:query|q|ll|center|destination|origin)=)(-?\\d{1,2}(?:\\.\\d+)?),\\s*(-?\\d{1,3}(?:\\.\\d+)?)", Pattern.CASE_INSENSITIVE),
                Pattern.compile("\\\"latitude\\\"\\s*:\\s*(-?\\d{1,2}(?:\\.\\d+)?).*?\\\"longitude\\\"\\s*:\\s*(-?\\d{1,3}(?:\\.\\d+)?)", Pattern.CASE_INSENSITIVE | Pattern.DOTALL),
                Pattern.compile("\\\"lat\\\"\\s*:\\s*(-?\\d{1,2}(?:\\.\\d+)?).*?\\\"(?:lng|lon|longitude)\\\"\\s*:\\s*(-?\\d{1,3}(?:\\.\\d+)?)", Pattern.CASE_INSENSITIVE | Pattern.DOTALL),
                Pattern.compile("center=(-?\\d{1,2}(?:\\.\\d+)?)%2C(-?\\d{1,3}(?:\\.\\d+)?)", Pattern.CASE_INSENSITIVE)
        };
        for (String candidate : candidates) {
            for (Pattern pattern : patterns) {
                Matcher matcher = pattern.matcher(candidate);
                while (matcher.find()) {
                    try {
                        double lat = Double.parseDouble(matcher.group(1));
                        double lng = Double.parseDouble(matcher.group(2));
                        if (isValidMapCoordinate(lat, lng)) return new MapCoordinates(lat, lng);
                    } catch (Exception ignored) { }
                }
            }
        }
        return null;
    }

    private boolean isValidMapCoordinate(double lat, double lng) {
        return lat >= -90d && lat <= 90d && lng >= -180d && lng <= 180d &&
                !(Math.abs(lat) < 0.000001d && Math.abs(lng) < 0.000001d);
    }

    private String buildDeterministicMapStoreKey(double lat, double lng) {
        return buildDeterministicMapStoreKey(null, lat, lng);
    }

    private String buildDeterministicMapStoreKey(String stableIdentity, Double lat, Double lng) {
        String identity = stableIdentity == null ? "" : stableIdentity.trim();
        String canonical;
        if (!identity.isEmpty()) {
            canonical = "google:" + identity;
        } else if (lat != null && lng != null) {
            canonical = "coord:" + String.format(Locale.ROOT, "%.6f,%.6f", lat, lng);
        } else {
            throw new IllegalArgumentException("Google Maps store identity or coordinates are required");
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(canonical.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder("str.map.");
            for (int i = 0; i < 10; i++) out.append(String.format(Locale.ROOT, "%02x", hash[i] & 0xff));
            return out.toString();
        } catch (Exception ignored) {
            return "str.map." + Integer.toHexString(canonical.hashCode());
        }
    }

    private String mapUrlForLog(String value) {
        if (value == null || value.trim().isEmpty()) return "url=empty";
        try {
            URL url = new URL(normalizeMapInputUrl(value));
            String path = url.getPath() == null ? "" : url.getPath();
            if (path.length() > 100) path = path.substring(0, 100) + "…";
            return "host=" + url.getHost() + " path=" + safeDiagValue(path, 120) + " len=" + value.length();
        } catch (Exception ignored) {
            return "url=" + safeDiagValue(value, 120);
        }
    }

    private String safeDiagValue(String value, int max) {
        String out = value == null ? "" : value.replace('\n', ' ').replace('\r', ' ').trim();
        if (out.length() > max) out = out.substring(0, max) + "…";
        return out;
    }

    private boolean handleIncomingGoogleMapsShare(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return false;
        CharSequence shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (shared == null) return false;
        String text = shared.toString().trim();
        String url = extractGoogleMapsShareUrl(text);
        if (url == null) return false;
        String name = extractGoogleMapsShareName(text, url);
        DiagLog.write(this, "MAP_SHARE_RECEIVED name=" + safeDiagValue(name, 80) + " " + mapUrlForLog(url));
        showAddStoreDialog(name, url);
        return true;
    }

    private String extractGoogleMapsShareUrl(String text) {
        if (text == null) return null;
        Pattern pattern = Pattern.compile("https?://(?:maps\\.app\\.goo\\.gl|(?:www\\.)?google\\.[^/\\s]+/maps|maps\\.google\\.[^/\\s]+)[^\\s<>'\"]*", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (!matcher.find()) return null;
        String url = matcher.group();
        while (url.endsWith(".") || url.endsWith(",") || url.endsWith("、") || url.endsWith("。")) {
            url = url.substring(0, url.length() - 1);
        }
        return url;
    }

    private String extractGoogleMapsShareName(String text, String url) {
        if (text == null) return "";
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty() || line.contains(url) || line.startsWith("http://") || line.startsWith("https://")) continue;
            if (line.equalsIgnoreCase("Google Maps") || line.equals("Google マップ")) continue;
            int bullet = line.indexOf(" · ");
            if (bullet > 0) line = line.substring(0, bullet).trim();
            return line;
        }
        return "";
    }

    private String extractMapPlaceNameFromUrl(String url) {
        if (url == null || url.trim().isEmpty()) return "";
        try {
            String decoded = URLDecoder.decode(url, StandardCharsets.UTF_8.name());
            Matcher m = Pattern.compile("/place/([^/?#]+)", Pattern.CASE_INSENSITIVE).matcher(decoded);
            if (m.find()) return m.group(1).replace('+', ' ').trim();
        } catch (Exception ignored) { }
        return "";
    }

    private void showAddStoreDialog() {
        showAddStoreDialog(null, null);
    }

    private void showAddStoreDialog(String prefillName, String prefillMapUrl) {
        boolean imeWasVisible = isImeVisible();
        EditText nameInput = dialogInput("店舗名");
        EditText mapInput = dialogInput("GoogleマップURL（任意）");
        if (prefillName != null && !prefillName.trim().isEmpty()) {
            nameInput.setText(prefillName.trim());
            nameInput.setSelection(nameInput.length());
        }
        if (prefillMapUrl != null && !prefillMapUrl.trim().isEmpty()) {
            mapInput.setText(prefillMapUrl.trim());
            mapInput.setSelection(mapInput.length());
        }
        mapInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP),
                dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        TextView nameLabel = text("店舗名", 12, SECONDARY, true);
        nameLabel.setPadding(0, 0, 0, dp(UI_TIGHT_SPACING_DP));
        panel.addView(nameLabel);
        panel.addView(nameInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        TextView mapLabel = text("GoogleマップURL（任意）", 12, SECONDARY, true);
        mapLabel.setPadding(0, dp(UI_SPACING_DP), 0, dp(UI_TIGHT_SPACING_DP));
        panel.addView(mapLabel);
        panel.addView(mapInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        TextView mapButton = button("マップ解析", ORANGE, 13);
        TextView cancelButton = button("キャンセル", DGRAY, 13);
        TextView addButton = button("追加", BLUE, 13);
        LinearLayout actionRow = makeStoreInfoActionRow(mapButton, cancelButton, addButton);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        actionLp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        panel.addView(actionRow, actionLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗カード追加")
                .setView(panel)
                .create();
        if (imeWasVisible) {
            nameInput.requestFocus();
            Window preShowWindow = dialog.getWindow();
            if (preShowWindow != null) {
                preShowWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE |
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED);
            }
        }

        final MapAnalysisResult[] parsed = {null};
        final int[] analysisToken = {0};
        final Runnable[] autoPending = {null};
        setMapAnalysisButtonState(mapButton, false, false);

        Runnable scheduleAuto = () -> {
            if (autoPending[0] != null) mapInput.removeCallbacks(autoPending[0]);
            String raw = mapInput.getText().toString().trim();
            parsed[0] = null;
            setMapAnalysisButtonState(mapButton, false, false);
            int token = ++analysisToken[0];
            if (raw.isEmpty()) return;
            autoPending[0] = () -> runMapAnalysis(raw, token, analysisToken, parsed, mapInput, mapButton, false, result -> {
                if (nameInput.getText().toString().trim().isEmpty()) {
                    String inferred = extractMapPlaceNameFromUrl(result == null ? null : result.resolvedUrl);
                    if (inferred != null && !inferred.isEmpty()) nameInput.setText(inferred);
                }
            });
            mapInput.postDelayed(autoPending[0], 550L);
        };
        mapInput.addTextChangedListener(new SimpleTextWatcher(scheduleAuto));
        if (!mapInput.getText().toString().trim().isEmpty()) mapInput.post(scheduleAuto);

        mapButton.setOnClickListener(v -> {
            String raw = mapInput.getText().toString().trim();
            if (raw.isEmpty()) {
                showFieldError(mapInput, "GoogleマップURLを入力");
                return;
            }
            if (autoPending[0] != null) mapInput.removeCallbacks(autoPending[0]);
            int token = ++analysisToken[0];
            runMapAnalysis(raw, token, analysisToken, parsed, mapInput, mapButton, true, result -> {
                if (nameInput.getText().toString().trim().isEmpty()) {
                    String inferred = extractMapPlaceNameFromUrl(result == null ? null : result.resolvedUrl);
                    if (inferred != null && !inferred.isEmpty()) nameInput.setText(inferred);
                }
            });
        });
        cancelButton.setOnClickListener(v -> dialog.cancel());
        addButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String mapUrl = mapInput.getText().toString().trim();
            if (name.isEmpty()) { showFieldError(nameInput, "店舗名を入力"); return; }
            MapAnalysisResult r = parsed[0] != null && parsed[0].inputUrl.equals(mapUrl) ? parsed[0] : null;
            long id = r == null
                    ? db.addStore(name, mapUrl)
                    : db.addStore(name, mapUrl, r.storeKey, r.resolvedUrl, r.lat, r.lng);
            if (id > 0) {
                expandedStoreId = id;
                expandedStoreIds.add(id);
                DiagLog.write(this, "ADD_STORE id=" + id + " name=" + name + " mapUrl=" + (!mapUrl.isEmpty()) + " mapParsed=" + (r != null));
                dialog.dismiss();
                reloadStores();
            }
        });
        dialog.setOnShowListener(d -> focusDialogInput(nameInput, dialog, imeWasVisible));
        showRoundedDialog(dialog);
    }

    private void showStoreMenu(DatabaseHelper.Store store, View card) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), 0, dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setView(panel)
                .create();

        String mapUrl = store.mapUrl == null ? "" : store.mapUrl.trim();
        boolean hasMap = !mapUrl.isEmpty();
        TextView manual = storeMenuRow("手入力商品リスト", true);
        TextView map = storeMenuRow("マップを開く", hasMap);
        TextView info = storeMenuRow("店舗情報変更", true);
        TextView delete = storeMenuRow("店舗削除", true);
        TextView export = storeMenuRow("エクスポート", true);
        panel.addView(manual); panel.addView(map); panel.addView(info); panel.addView(delete); panel.addView(export);

        manual.setOnClickListener(v -> { dialog.dismiss(); showManualProductListDialog(store); });
        if (hasMap) map.setOnClickListener(v -> {
            dialog.dismiss();
            try {
                Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(mapUrl));
                startActivity(open);
            } catch (Exception ex) {
                Toast.makeText(this, "マップを開けませんでした", Toast.LENGTH_SHORT).show();
            }
        });
        info.setOnClickListener(v -> {
            dialog.dismiss();
            if (!store.enabled) Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            else showRenameStoreDialog(store);
        });
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (!store.enabled) Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            else showDeleteStoreDialog(store);
        });
        export.setOnClickListener(v -> { dialog.dismiss(); showStoreExportDialog(Collections.singletonList(store), false); });
        dialog.setOnDismissListener(d -> {
            View current = storeCardViews.get(store.id);
            if (current != null) current.setBackground(roundRect(GRAY, 18));
        });
        showRoundedDialog(dialog);
    }

    private TextView storeMenuRow(String label, boolean enabled) {
        TextView row = text(label, 15, enabled ? WHITE : LGRAY, false);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        row.setEnabled(enabled);
        row.setAlpha(1f);
        row.setBackgroundColor(Color.TRANSPARENT);
        row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        return row;
    }

    private void showRenameStoreDialog(DatabaseHelper.Store store) {
        EditText nameInput = dialogInput("店舗名");
        nameInput.setText(store.name);
        nameInput.setSelection(nameInput.length());

        EditText keyInput = dialogInput("store_key");
        keyInput.setText(store.storeKey == null ? DatabaseHelper.buildStoreKey(store.name) : store.storeKey);
        keyInput.setSelection(keyInput.length());
        KeyListener editableStoreKeyListener = keyInput.getKeyListener();
        final boolean initiallyMapLocked = store.storeKey != null && store.storeKey.startsWith("str.map.");
        if (initiallyMapLocked) lockStoreKeyField(keyInput);

        EditText mapInput = dialogInput("GoogleマップURL（任意）");
        mapInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        mapInput.setText(store.mapUrl == null ? "" : store.mapUrl);
        mapInput.setSelection(mapInput.length());

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP),
                dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        TextView nameLabel = text("店舗名", 12, SECONDARY, true);
        nameLabel.setPadding(0, 0, 0, dp(UI_TIGHT_SPACING_DP));
        panel.addView(nameLabel);
        panel.addView(nameInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        TextView keyLabel = text("store_key", 12, SECONDARY, true);
        keyLabel.setPadding(0, dp(UI_SPACING_DP), 0, dp(UI_TIGHT_SPACING_DP));
        panel.addView(keyLabel);
        panel.addView(keyInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        TextView mapLabel = text("GoogleマップURL（任意）", 12, SECONDARY, true);
        mapLabel.setPadding(0, dp(UI_SPACING_DP), 0, dp(UI_TIGHT_SPACING_DP));
        panel.addView(mapLabel);
        panel.addView(mapInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        TextView mapButton = button("マップ解析", ORANGE, 13);
        TextView cancelButton = button("キャンセル", DGRAY, 13);
        TextView changeButton = button("変更", BLUE, 13);
        LinearLayout actionRow = makeStoreInfoActionRow(mapButton, cancelButton, changeButton);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        actionLp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        panel.addView(actionRow, actionLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗情報変更")
                .setView(panel)
                .create();

        final MapAnalysisResult[] parsed = {store.hasMapAnalysis()
                ? new MapAnalysisResult(store.mapUrl, store.mapResolvedUrl, store.mapLat, store.mapLng, store.storeKey) : null};
        final int[] analysisToken = {0};
        final Runnable[] autoPending = {null};
        final boolean[] duplicatePromptShowing = {false};
        setMapAnalysisButtonState(mapButton, parsed[0] != null, false);

        Runnable scheduleAuto = () -> {
            if (autoPending[0] != null) mapInput.removeCallbacks(autoPending[0]);
            String raw = mapInput.getText().toString().trim();
            // URL edits invalidate the saved analysis immediately. store_key stays locked until this dialog is saved/reopened.
            parsed[0] = null;
            setMapAnalysisButtonState(mapButton, false, false);
            int token = ++analysisToken[0];
            if (raw.isEmpty()) return;
            autoPending[0] = () -> runMapAnalysis(raw, token, analysisToken, parsed, mapInput, mapButton, false, result -> {
                if (!initiallyMapLocked) {
                    if (offerExistingMapStoreMerge(store, result, dialog, mapInput, mapButton, parsed, analysisToken, duplicatePromptShowing)) return;
                    keyInput.setText(result.storeKey);
                    keyInput.setSelection(keyInput.length());
                    lockStoreKeyField(keyInput);
                }
            });
            mapInput.postDelayed(autoPending[0], 550L);
        };
        mapInput.addTextChangedListener(new SimpleTextWatcher(scheduleAuto));
        if (parsed[0] == null && !mapInput.getText().toString().trim().isEmpty()) {
            DiagLog.write(this, "MAP_PARSE_AUTO_EXISTING store=" + store.id);
            mapInput.post(scheduleAuto);
        }

        mapButton.setOnClickListener(v -> {
            String raw = mapInput.getText().toString().trim();
            if (raw.isEmpty()) {
                showFieldError(mapInput, "GoogleマップURLを入力");
                return;
            }
            if (autoPending[0] != null) mapInput.removeCallbacks(autoPending[0]);
            int token = ++analysisToken[0];
            runMapAnalysis(raw, token, analysisToken, parsed, mapInput, mapButton, true, result -> {
                if (!initiallyMapLocked) {
                    if (offerExistingMapStoreMerge(store, result, dialog, mapInput, mapButton, parsed, analysisToken, duplicatePromptShowing)) return;
                    keyInput.setText(result.storeKey);
                    keyInput.setSelection(keyInput.length());
                    lockStoreKeyField(keyInput);
                }
            });
        });
        cancelButton.setOnClickListener(v -> dialog.cancel());
        changeButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String requestedKey = keyInput.getText().toString().trim();
            if (name.isEmpty()) { showFieldError(nameInput, "店舗名を入力"); return; }
            if (requestedKey.isEmpty()) { showFieldError(keyInput, "store_keyを入力"); return; }
            String mapUrl = mapInput.getText().toString().trim();
            MapAnalysisResult r = parsed[0] != null && parsed[0].inputUrl.equals(mapUrl) ? parsed[0] : null;
            if (!initiallyMapLocked && r != null && offerExistingMapStoreMerge(store, r, dialog, mapInput, mapButton, parsed, analysisToken, duplicatePromptShowing)) return;
            String keyToPersist = initiallyMapLocked
                    ? store.storeKey
                    : (r == null ? requestedKey : r.storeKey);
            String finalKey = db.updateStoreIdentity(store.id, name,
                    keyToPersist,
                    mapUrl,
                    r == null ? null : r.resolvedUrl,
                    r == null ? null : r.lat,
                    r == null ? null : r.lng,
                    initiallyMapLocked || r != null);
            DiagLog.write(this, "UPDATE_STORE_IDENTITY id=" + store.id + " name=" + name + " store_key=" + finalKey +
                    " mapUrl=" + (!mapUrl.isEmpty()) + " mapParsed=" + (r != null));
            if (r == null && !finalKey.equals(requestedKey) && !finalKey.equals("str." + requestedKey)) {
                Toast.makeText(this, "store_key衝突のため " + finalKey + " に変更しました", Toast.LENGTH_LONG).show();
            }
            dialog.dismiss();
            reloadStores();
        });
        dialog.setOnDismissListener(d -> {
            if (!initiallyMapLocked && keyInput.getKeyListener() == null) keyInput.setKeyListener(editableStoreKeyListener);
        });
        showRoundedDialog(dialog);
    }

    private boolean offerExistingMapStoreMerge(DatabaseHelper.Store sourceStore, MapAnalysisResult result,
                                               AlertDialog editorDialog, EditText mapInput, TextView mapButton,
                                               MapAnalysisResult[] parsed, int[] analysisToken, boolean[] promptShowing) {
        if (sourceStore == null || result == null || result.storeKey == null) return false;
        DatabaseHelper.Store existing = db.findStoreByKey(result.storeKey, sourceStore.id);
        if (existing == null) return false;
        if (promptShowing != null && promptShowing[0]) return true;
        if (promptShowing != null) promptShowing[0] = true;
        DiagLog.write(this, "MAP_DUPLICATE_STORE_FOUND source=" + sourceStore.id + " target=" + existing.id + " key=" + result.storeKey);
        AlertDialog merge = new AlertDialog.Builder(this)
                .setTitle("同じ店舗がすでに登録されています")
                .setMessage("「" + existing.name + "」と同じGoogleマップ店舗です。\n\n既存店舗にマージすると、このカードの商品・価格・画像を既存店舗へ移します。")
                .setNegativeButton("解析をキャンセル", (d, which) -> {
                    if (analysisToken != null && analysisToken.length > 0) analysisToken[0]++;
                    if (parsed != null && parsed.length > 0) parsed[0] = null;
                    mapInput.setText("");
                    setMapAnalysisButtonState(mapButton, false, false);
                    DiagLog.write(this, "MAP_DUPLICATE_MERGE_CANCEL source=" + sourceStore.id + " target=" + existing.id);
                })
                .setPositiveButton("既存店舗にマージ", (d, which) -> {
                    boolean ok = db.mergeStoreInto(sourceStore.id, existing.id);
                    DiagLog.write(this, "MAP_DUPLICATE_MERGE source=" + sourceStore.id + " target=" + existing.id + " ok=" + ok);
                    if (ok) {
                        editorDialog.dismiss();
                        expandedStoreIds.remove(sourceStore.id);
                        expandedStoreIds.add(existing.id);
                        expandedStoreId = existing.id;
                        reloadStores();
                        Toast.makeText(this, "「" + existing.name + "」にマージしました", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "店舗をマージできませんでした", Toast.LENGTH_LONG).show();
                    }
                })
                .create();
        merge.setOnDismissListener(d -> { if (promptShowing != null) promptShowing[0] = false; });
        showRoundedDialog(merge);
        return true;
    }

    private void showDeleteStoreDialog(DatabaseHelper.Store store) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗削除")
                .setMessage("「" + store.name + "」と、この店舗に紐づく登録データを削除します。\n撮影した画像は端末からも削除します。追加した既存画像の元ファイルは削除しません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    for (DatabaseHelper.Photo p : db.listPhotos(store.id)) {
                        if (p.managed) {
                            try { getContentResolver().delete(Uri.parse(p.uri), null, null); } catch (Exception ignored) { }
                        } else releaseImportedPermission(Uri.parse(p.uri));
                    }
                    db.deleteStore(store.id);
                    expandedStoreIds.remove(store.id);
                    if (expandedStoreId == store.id) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
                    DiagLog.write(this, "DELETE_STORE id=" + store.id + " name=" + store.name);
                    reloadStores();
                }).create();
        showRoundedDialog(dialog);
    }

    private void showTagManager() {
        showTagManager(null);
    }

    private void bindTagCreateButton(EditText input, ImageView add) {
        if (input == null || add == null) return;
        Runnable refresh = () -> {
            boolean enabled = !input.getText().toString().trim().isEmpty();
            add.setEnabled(enabled);
            add.setAlpha(1f);
            add.setColorFilter(enabled ? WHITE : LGRAY);
            add.setBackground(circle(enabled ? ORANGE : DGRAY));
        };
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refresh.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        refresh.run();
    }


    private void showTagManager(Runnable afterClose) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP),
                dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView tagListScroll = newAutoFadeScrollView();
        tagListScroll.setFillViewport(false);
        tagListScroll.addView(rows, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(tagListScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout addRow = new LinearLayout(this);
        addRow.setGravity(Gravity.BOTTOM);
        addRow.setPadding(0, dp(UI_SPACING_DP), 0, 0);

        EditText input = dialogInput("新しいタグ");
        ImageView add = roundPlusIcon(DGRAY, LGRAY, "タグ追加");
        bindTagCreateButton(input, add);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        inputLp.rightMargin = dp(UI_SPACING_DP);
        addRow.addView(input, inputLp);

        // Reserve a real slot for the circular + button instead of letting the
        // drawable sit against the dialog edge.  The extra slot width keeps
        // the full circle inside the common dialog right margin on every
        // screen width and prevents clipping by the rounded window.
        FrameLayout addSlot = new FrameLayout(this);
        LinearLayout.LayoutParams addSlotLp = new LinearLayout.LayoutParams(dp(56), dp(48));
        addRow.addView(addSlot, addSlotLp);
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END | Gravity.BOTTOM);
        addLp.rightMargin = dp(4);
        addSlot.addView(add, addLp);
        content.addView(addRow);

        panel.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView deleteAction = button("削除", DGRAY, 13);
        TextView rightAction = button("OK", BLUE, 13);
        footer.addView(deleteAction, new LinearLayout.LayoutParams(dp(118), dp(38)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
        footer.addView(rightAction, new LinearLayout.LayoutParams(dp(118), dp(38)));
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        footerLp.topMargin = dp(UI_SPACING_DP);
        panel.addView(footer, footerLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ管理")
                .setView(panel)
                .create();

        Set<Long> selectedTagIds = new HashSet<>();
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            populateTagManagerRows(rows, selectedTagIds, render[0]);
            boolean selecting = !selectedTagIds.isEmpty();
            setButtonEnabledStyle(deleteAction, selecting, RED);
            rightAction.setText(selecting ? "キャンセル" : "OK");
            rightAction.setBackground(roundRect(selecting ? DGRAY : BLUE, 999));
            resizeExpandedTagDialog(dialog, tagListScroll, rows);
        };

        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) {
                showFieldError(input, "タグ名を入力");
                return;
            }
            long id = db.addTag(name);
            if (id < 0) {
                showDuplicateTagNameWarning(input);
                return;
            }
            DiagLog.write(this, "ADD_TAG id=" + id + " name=" + name);
            input.setText("");
            render[0].run();
            reloadStores();
        });

        deleteAction.setOnClickListener(v -> {
            if (selectedTagIds.isEmpty()) return;
            int count = selectedTagIds.size();
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("タグ削除")
                    .setMessage("選択した" + count + "件のタグを削除します。画像や商品自体は削除されません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (d, which) -> {
                        ArrayList<Long> ids = new ArrayList<>(selectedTagIds);
                        for (Long id : ids) {
                            if (id == null) continue;
                            db.deleteTag(id);
                            DiagLog.write(this, "DELETE_TAG id=" + id);
                        }
                        selectedTagIds.clear();
                        render[0].run();
                        reloadStores();
                    })
                    .create();
            showRoundedDialog(confirm);
        });

        rightAction.setOnClickListener(v -> {
            if (selectedTagIds.isEmpty()) {
                dialog.dismiss();
            } else {
                selectedTagIds.clear();
                render[0].run();
            }
        });

        dialog.setOnCancelListener(d -> selectedTagIds.clear());
        dialog.setOnDismissListener(d -> {
            selectedTagIds.clear();
            reloadStores();
            if (afterClose != null) afterClose.run();
        });

        render[0].run();
        showExpandedTagDialog(dialog, tagListScroll, rows);
    }

    private void populateTagManagerRows(LinearLayout container, Set<Long> selectedTagIds, Runnable refresh) {
        container.removeAllViews();
        for (DatabaseHelper.Tag tag : db.listTags()) {
            boolean selected = selectedTagIds.contains(tag.id);

            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(1), 0, dp(1));
            row.setBackground(roundRect(selected ? BLUE : DGRAY, 7));
            row.setElevation(dp(2));
            row.setTag(tag.id);

            TextView handle = text("☰", 22, SECONDARY, false);
            handle.setGravity(Gravity.CENTER);
            handle.setContentDescription(tag.name + "を並べ替え");

            TextView name = text(tag.name, 13, WHITE, selected);
            name.setGravity(Gravity.CENTER_VERTICAL);
            name.setIncludeFontPadding(false);

            row.addView(handle, new LinearLayout.LayoutParams(dp(40), dp(38)));
            row.addView(name, new LinearLayout.LayoutParams(0, dp(38), 1f));

            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dp(UI_TIGHT_SPACING_DP);
            container.addView(row, rowLp);

            row.setOnClickListener(v -> {
                if (!selectedTagIds.add(tag.id)) selectedTagIds.remove(tag.id);
                if (refresh != null) refresh.run();
            });

            row.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                showRenameTagDialog(tag, () -> {
                    if (refresh != null) refresh.run();
                });
                return true;
            });

            attachTagManagerReorderGesture(handle, row, container, tag, () -> {
                // Reordering is a layout operation, not a tag-selection operation.
                if (refresh != null) refresh.run();
            });
        }
    }

    private void attachTagManagerReorderGesture(TextView handle, View row, LinearLayout container,
                                                DatabaseHelper.Tag tag, Runnable refresh) {
        final boolean[] armed = {false};
        final boolean[] dragging = {false};
        final float[] downRawY = {0f};
        final int[] sourceIndex = {-1};
        final int[] targetIndex = {-1};

        handle.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawY[0] = event.getRawY();
                    sourceIndex[0] = container.indexOfChild(row);
                    targetIndex[0] = sourceIndex[0];
                    armed[0] = false;
                    dragging[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (!armed[0]) return false;
                    float dy = event.getRawY() - downRawY[0];
                    if (!dragging[0] && Math.abs(dy) < dp(6)) return true;
                    dragging[0] = true;
                    row.setTranslationX(0f);
                    row.setTranslationY(dy);
                    int target = nearestChildIndexByRawY(container, event.getRawY());
                    if (target >= 0 && target != targetIndex[0]) {
                        targetIndex[0] = target;
                        animateVerticalReorderPreview(container, row, sourceIndex[0], targetIndex[0]);
                        DiagLog.write(this, "TAG_DRAG_TARGET id=" + tag.id + " index=" + target);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!armed[0]) return false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    int from = sourceIndex[0];
                    int to = targetIndex[0];
                    boolean wasDragging = dragging[0];
                    resetVerticalReorderPreview(container, row);
                    row.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(145).setInterpolator(new DecelerateInterpolator()).start();
                    row.setElevation(dp(2));
                    if (commit && wasDragging && from >= 0 && to >= 0 && from != to) {
                        ArrayList<Long> ordered = new ArrayList<>();
                        for (DatabaseHelper.Tag t : db.listTags()) ordered.add(t.id);
                        int logicalFrom = ordered.indexOf(tag.id);
                        if (logicalFrom >= 0) {
                            moveListItem(ordered, logicalFrom, Math.max(0, Math.min(to, ordered.size() - 1)));
                            db.setTagOrder(ordered);
                            DiagLog.write(this, "TAG_REORDER_SAVE id=" + tag.id + " from=" + logicalFrom + " to=" + to);
                            container.postDelayed(() -> {
                                if (refresh != null) refresh.run();
                                reloadStores();
                            }, 130);
                        }
                    }
                    armed[0] = false;
                    dragging[0] = false;
                    sourceIndex[0] = -1;
                    targetIndex[0] = -1;
                    return true;
                default:
                    return armed[0];
            }
        });

        handle.setOnLongClickListener(v -> {
            armed[0] = true;
            dragging[0] = false;
            sourceIndex[0] = container.indexOfChild(row);
            targetIndex[0] = sourceIndex[0];
            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            row.setTranslationX(0f);
            row.setElevation(dp(12));
            row.animate().scaleX(1.025f).scaleY(1.025f).alpha(0.84f).setDuration(85).start();
            DiagLog.write(this, "TAG_DRAG_START id=" + tag.id + " name=" + tag.name + " axis=y");
            return true;
        });
    }

    private void showTagAddDialog(Set<Long> initialSelectedTags, TagSelectionListener onApply, Runnable afterClose) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP),
                dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView tagListScroll = newAutoFadeScrollView();
        tagListScroll.setFillViewport(false);
        tagListScroll.addView(rows, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(tagListScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout addRow = new LinearLayout(this);
        addRow.setGravity(Gravity.BOTTOM);
        addRow.setPadding(0, dp(UI_SPACING_DP), 0, 0);

        EditText input = dialogInput("新しいタグ");
        ImageView add = roundPlusIcon(DGRAY, LGRAY, "タグ作成");
        bindTagCreateButton(input, add);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        inputLp.rightMargin = dp(UI_SPACING_DP);
        addRow.addView(input, inputLp);

        // Reserve a real slot for the circular + button instead of letting the
        // drawable sit against the dialog edge.  The extra slot width keeps
        // the full circle inside the common dialog right margin on every
        // screen width and prevents clipping by the rounded window.
        FrameLayout addSlot = new FrameLayout(this);
        LinearLayout.LayoutParams addSlotLp = new LinearLayout.LayoutParams(dp(56), dp(48));
        addRow.addView(addSlot, addSlotLp);
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END | Gravity.BOTTOM);
        addLp.rightMargin = dp(4);
        addSlot.addView(add, addLp);
        content.addView(addRow);

        panel.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView deleteAction = button("削除", DGRAY, 13);
        TextView cancelAction = button("キャンセル", DGRAY, 13);
        TextView okAction = button("OK", BLUE, 13);
        footer.addView(deleteAction, new LinearLayout.LayoutParams(dp(118), dp(38)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(dp(118), dp(38));
        cancelLp.rightMargin = dp(UI_ACTION_GAP_DP);
        footer.addView(cancelAction, cancelLp);
        footer.addView(okAction, new LinearLayout.LayoutParams(dp(118), dp(38)));
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        footerLp.topMargin = dp(UI_SPACING_DP);
        panel.addView(footer, footerLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ選択")
                .setView(panel)
                .create();

        // Start from the tags already assigned to the current photo/product so the
        // add dialog reflects the real assignment immediately. OK writes back the
        // complete pending selection; cancel/outside dismissal leaves it unchanged.
        Set<Long> selectedTagIds = new HashSet<>();
        if (initialSelectedTags != null) selectedTagIds.addAll(initialSelectedTags);
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            populateTagManagerRows(rows, selectedTagIds, render[0]);
            boolean selecting = !selectedTagIds.isEmpty();
            setButtonEnabledStyle(deleteAction, selecting, RED);
            resizeExpandedTagDialog(dialog, tagListScroll, rows);
        };

        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) {
                showFieldError(input, "タグ名を入力");
                return;
            }
            long id = db.addTag(name);
            if (id < 0) {
                showDuplicateTagNameWarning(input);
                return;
            }
            DiagLog.write(this, "ADD_TAG_FROM_ADD_DIALOG id=" + id + " name=" + name);
            input.setText("");
            render[0].run();
            reloadStores();
        });

        deleteAction.setOnClickListener(v -> {
            if (selectedTagIds.isEmpty()) return;
            int count = selectedTagIds.size();
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("タグ削除")
                    .setMessage("選択した" + count + "件のタグを削除します。画像や商品自体は削除されません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (d, which) -> {
                        ArrayList<Long> ids = new ArrayList<>(selectedTagIds);
                        for (Long id : ids) {
                            if (id == null) continue;
                            db.deleteTag(id);
                            DiagLog.write(this, "DELETE_TAG_FROM_ADD_DIALOG id=" + id);
                        }
                        selectedTagIds.clear();
                        render[0].run();
                        reloadStores();
                    })
                    .create();
            showRoundedDialog(confirm);
        });

        cancelAction.setOnClickListener(v -> dialog.cancel());
        okAction.setOnClickListener(v -> {
            if (onApply != null) onApply.onChanged(new HashSet<>(selectedTagIds));
            dialog.dismiss();
        });

        dialog.setOnCancelListener(d -> selectedTagIds.clear());
        dialog.setOnDismissListener(d -> {
            selectedTagIds.clear();
            reloadStores();
            if (afterClose != null) afterClose.run();
        });

        render[0].run();
        showExpandedTagDialog(dialog, tagListScroll, rows);
    }


    private void showExpandedTagDialog(AlertDialog dialog, ScrollView listScroll, LinearLayout rows) {
        showRoundedDialog(dialog, true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        resizeExpandedTagDialog(dialog, listScroll, rows);
    }

    private void resizeExpandedTagDialog(AlertDialog dialog, ScrollView listScroll, LinearLayout rows) {
        if (dialog == null || listScroll == null || rows == null || !dialog.isShowing()) return;
        Window window = dialog.getWindow();
        if (window == null) return;
        View decor = window.getDecorView();
        listScroll.post(() -> {
            if (!dialog.isShowing()) return;
            int safeDialogHeight = getSafeDialogHeightPx();
            int currentListHeight = Math.max(0, listScroll.getHeight());
            int fullRowsHeight = Math.max(rows.getHeight(), rows.getMeasuredHeight());
            int fixedHeight = Math.max(0, decor.getHeight() - currentListHeight);

            // The title, create row and footer stay fixed. The tag list consumes as much
            // vertical room as the screen allows and scrolls only when the rows exceed it.
            int availableListHeight = Math.max(0, safeDialogHeight - fixedHeight);
            int targetListHeight = Math.min(fullRowsHeight, availableListHeight);
            ViewGroup.LayoutParams lp = listScroll.getLayoutParams();
            if (lp != null && lp.height != targetListHeight) {
                lp.height = targetListHeight;
                listScroll.setLayoutParams(lp);
            }
            boolean overflow = fullRowsHeight > availableListHeight;
            listScroll.setVerticalScrollBarEnabled(overflow);
            listScroll.setOverScrollMode(overflow
                    ? View.OVER_SCROLL_IF_CONTENT_SCROLLS : View.OVER_SCROLL_NEVER);

            int targetDialogHeight = Math.min(safeDialogHeight, fixedHeight + targetListHeight);
            if (targetDialogHeight > 0) {
                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, targetDialogHeight);
            }
        });
    }

    private int getSafeDialogHeightPx() {
        int height = getResources().getDisplayMetrics().heightPixels;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowManager wm = getSystemService(WindowManager.class);
            if (wm != null) {
                android.view.WindowMetrics metrics = wm.getCurrentWindowMetrics();
                Insets insets = metrics.getWindowInsets().getInsetsIgnoringVisibility(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                height = Math.max(1, metrics.getBounds().height() - insets.top - insets.bottom);
            }
        }
        // Leave a small safety gap above and below the rounded dialog.
        return Math.max(1, height - dp(24));
    }

    private void showTagSelectionDialog(Set<Long> initialSelectedTags,
                                        TagSelectionListener onApply,
                                        Runnable afterClose) {
        // Single canonical tag UI: selection + create + rename + delete + reorder grip.
        showTagAddDialog(initialSelectedTags, onApply, afterClose);
    }

    private void showRenameTagDialog(DatabaseHelper.Tag tag, Runnable afterRename) {
        if (tag == null) return;
        EditText input = dialogInput("タグ名");
        input.setText(tag.name == null ? "" : tag.name);
        input.setSelection(input.getText().length());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ名編集")
                .setView(storeNameInputHolder(input, UI_SPACING_DP))
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", null)
                .create();

        dialog.setOnShowListener(d -> {
            focusAndShowKeyboard(input, dialog);
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) {
                    showFieldError(input, "タグ名を入力");
                    return;
                }
                if (!db.renameTag(tag.id, name)) {
                    showDuplicateTagNameWarning(input);
                    return;
                }
                DiagLog.write(this, "RENAME_TAG id=" + tag.id + " name=" + name);
                dialog.dismiss();
                reloadStores();
            });
        });
        dialog.setOnDismissListener(d -> {
            if (afterRename != null) afterRename.run();
        });
        showRoundedDialog(dialog);
    }

    private void showDuplicateTagNameWarning(EditText input) {
        if (input != null) showFieldError(input, "重複したタグ名は作成できません");
        Toast.makeText(this, "重複したタグ名は作成できません", Toast.LENGTH_SHORT).show();
    }

    private int nearestChildIndexByRawY(LinearLayout column, float rawY) {
        int[] loc = new int[2];
        column.getLocationOnScreen(loc);
        float localY = rawY - loc[1];
        int best = -1;
        float bestDistance = Float.MAX_VALUE;
        for (int i = 0; i < column.getChildCount(); i++) {
            View child = column.getChildAt(i);
            float center = child.getTop() + child.getHeight() / 2f;
            float distance = Math.abs(localY - center);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = i;
            }
        }
        return best;
    }

    private int verticalOuterSize(View view) {
        int size = view.getHeight();
        ViewGroup.LayoutParams lp = view.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
            size += mlp.topMargin + mlp.bottomMargin;
        }
        return Math.max(dp(1), size);
    }

    private void animateVerticalReorderPreview(LinearLayout column, View dragged, int sourceIndex, int targetIndex) {
        if (sourceIndex < 0 || targetIndex < 0) return;
        int shift = verticalOuterSize(dragged);
        for (int i = 0; i < column.getChildCount(); i++) {
            View child = column.getChildAt(i);
            if (child == dragged) continue;
            float ty = 0f;
            if (targetIndex > sourceIndex && i > sourceIndex && i <= targetIndex) {
                ty = -shift;
            } else if (targetIndex < sourceIndex && i >= targetIndex && i < sourceIndex) {
                ty = shift;
            }
            child.animate().translationX(0f).translationY(ty).setDuration(145)
                    .setInterpolator(new DecelerateInterpolator(1.55f)).start();
        }
    }

    private void resetVerticalReorderPreview(LinearLayout column, View dragged) {
        for (int i = 0; i < column.getChildCount(); i++) {
            View child = column.getChildAt(i);
            if (child == dragged) continue;
            child.animate().translationX(0f).translationY(0f).setDuration(125)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private void showPhotoDetail(DatabaseHelper.Photo photo, DatabaseHelper.Store store) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_ACTION_BOTTOM_DP));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        image.setBackgroundColor(DGRAY);
        Bitmap bmp = loadBitmap(Uri.parse(photo.uri), 1200, 900);
        if (bmp != null) image.setImageBitmap(bmp);
        image.setContentDescription("原寸表示");
        image.setOnClickListener(v -> showOriginalPhoto(photo));
        content.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280)));

        TextView meta = text(dateFormat.format(new Date(photo.createdAt)), 13, SECONDARY, false);
        meta.setPadding(0, dp(UI_SPACING_DP), 0, dp(UI_TIGHT_SPACING_DP));
        content.addView(meta);

        // Tag changes stay local to this dialog until the explicit 保存 action.
        Set<Long> pendingPhotoTags = new HashSet<>(photo.tagIds);
        View tagArea = makeCommonTagSelectionArea(pendingPhotoTags, true, store.enabled, chosen -> {
            DiagLog.write(this, "PHOTO_TAGS_PENDING photo=" + photo.id + " tags=" + chosen);
        });
        tagArea.setMinimumHeight(dp(48));
        LinearLayout.LayoutParams tagAreaLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        content.addView(tagArea, tagAreaLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView delete = button("削除", store.enabled ? RED : DGRAY, 13);
        setButtonEnabledStyle(delete, store.enabled, RED);
        actions.addView(delete, new LinearLayout.LayoutParams(0, dp(38), 1f));

        TextView share = button("共有", ORANGE, 13);
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        shareLp.leftMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(share, shareLp);

        TextView productList = button("商品リスト", LBLUE, 13);
        LinearLayout.LayoutParams productListLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        productListLp.leftMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(productList, productListLp);

        TextView save = button("保存", BLUE, 13);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        saveLp.leftMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(save, saveLp);

        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        actionsLp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        content.addView(actions, actionsLp);

        ScrollView detailScroll = newAutoFadeScrollView();
        detailScroll.setFillViewport(false);
        detailScroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setView(detailScroll)
                .create();

        delete.setOnClickListener(v -> {
            if (!store.enabled) return;
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("画像削除")
                    .setMessage(photo.managed ? "この撮影画像を端末から削除します。" : "この画像をPrice Rec.から外します。元の画像ファイルは削除しません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (d, w) -> {
                        Uri uri = Uri.parse(photo.uri);
                        if (photo.managed) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                        } else releaseImportedPermission(uri);
                        db.deletePhoto(photo.id);
                        DiagLog.write(this, "DELETE_PHOTO id=" + photo.id + " managed=" + photo.managed);
                        dialog.dismiss();
                        reloadStores();
                    }).create();
            showRoundedDialog(confirm);
        });

        share.setOnClickListener(v -> {
            ArrayList<DatabaseHelper.Photo> one = new ArrayList<>();
            one.add(photo);
            dialog.dismiss();
            DiagLog.write(this, "PHOTO_SHARE_SINGLE photo=" + photo.id + " store=" + store.id);
            sharePhotosWithChatGpt(store, one, commonTagLabel(one));
        });

        productList.setOnClickListener(v -> {
            dialog.dismiss();
            DiagLog.write(this, "PHOTO_PRODUCT_LIST_OPEN photo=" + photo.id + " store=" + store.id);
            showProductTableDialog(store.name + " / 商品リスト", store.id, photo.id, "");
        });

        save.setOnClickListener(v -> {
            if (store.enabled) {
                db.updatePhotoTags(photo.id, orderedTagIds(pendingPhotoTags));
                DiagLog.write(this, "PHOTO_TAGS_SAVE photo=" + photo.id + " tags=" + pendingPhotoTags);
                reloadStores();
            }
            dialog.dismiss();
        });

        showRoundedDialog(dialog);
    }

    private boolean showOriginalPhoto(DatabaseHelper.Photo photo) {
        Uri uri = Uri.parse(photo.uri);
        Bitmap original = loadOriginalBitmap(uri);
        if (original == null) {
            Toast.makeText(this, "原寸画像を開けませんでした", Toast.LENGTH_LONG).show();
            return false;
        }

        ZoomImageView zoom = new ZoomImageView(this);
        zoom.setBackgroundColor(BG);
        zoom.setImageBitmap(original);
        zoom.setContentDescription("原寸画像。ピンチでズーム、ドラッグで移動");

        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        // Original/reference-image viewer follows the same dialog content guideline as every other custom dialog:
        // the image viewport and visible footer glyph share the same left/right content anchors.
        holder.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP),
                dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        holder.addView(zoom, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(620)));

        TextView closeAction = makeDialogAction("閉じる");
        LinearLayout footer = makeRightDialogFooter(closeAction);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        footerLp.topMargin = dp(UI_SPACING_DP);
        holder.addView(footer, footerLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(holder)
                .create();
        closeAction.setOnClickListener(v -> dialog.dismiss());
        dialog.setOnDismissListener(d -> zoom.setImageDrawable(null));
        showRoundedDialog(dialog, true);
        DiagLog.write(this, "PHOTO_ORIGINAL_OPEN photo=" + photo.id +
                " size=" + original.getWidth() + "x" + original.getHeight());
        return true;
    }

    private Bitmap loadOriginalBitmap(Uri uri) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source, (decoder, info, src) ->
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        } catch (Exception e) {
            DiagLog.write(this, "IMAGE_ORIGINAL_LOAD_ERROR uri=" + uri + " err=" + e);
            return null;
        }
    }

    private String tagNameById(long id) {
        for (DatabaseHelper.Tag tag : db.listTags()) if (tag.id == id) return tag.name;
        return "タグなし";
    }

    private void sharePhotosWithChatGpt(DatabaseHelper.Store store, List<DatabaseHelper.Photo> photos, String tagName) {
        if (photos == null || photos.isEmpty()) return;
        final long started = SystemClock.elapsedRealtime();
        ArrayList<Uri> uris = new ArrayList<>();
        for (DatabaseHelper.Photo photo : photos) {
            try {
                Uri uri = Uri.parse(photo.uri);
                if (uri != null) uris.add(uri);
            } catch (Exception e) {
                DiagLog.write(this, "SHARE_SOURCE_URI_ERROR photo=" + photo.id + " err=" + e);
            }
        }
        if (uris.isEmpty()) {
            Toast.makeText(this, "共有できる画像がありません", Toast.LENGTH_SHORT).show();
            return;
        }

        saveLastShareMap(photos);
        String prompt = buildChatGptPrompt(store, photos, tagName);
        DiagLog.write(this, "SHARE_PREP_LIGHT sources=" + photos.size() + " attachments=" + uris.size() +
                " promptChars=" + prompt.length() + " prepMs=" + (SystemClock.elapsedRealtime() - started));
        launchChatGptShare(store, tagName, uris, prompt, started);
    }

    private void launchChatGptShare(DatabaseHelper.Store store, String tagName, ArrayList<Uri> uris,
                                    String prompt, long started) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Price Rec. 解析指示", prompt));
                DiagLog.write(this, "SHARE_CLIPBOARD_OK chars=" + prompt.length());
            }
        } catch (Exception e) {
            DiagLog.write(this, "SHARE_CLIPBOARD_ERROR " + e);
        }

        Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
        share.setType("image/*");
        share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        share.putExtra(Intent.EXTRA_TEXT, prompt);
        share.putExtra(Intent.EXTRA_TITLE, "Price Rec. 商品価格解析");
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        ClipData clip = ClipData.newUri(getContentResolver(), "Price Rec. source images", uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        share.setClipData(clip);

        boolean direct = false;
        try {
            Intent chatGpt = new Intent(share);
            chatGpt.setPackage("com.openai.chatgpt");
            boolean directAvailable = getPackageManager().resolveActivity(chatGpt, 0) != null;
            DiagLog.write(this, "SHARE_DIRECT_CHECK available=" + directAvailable);
            if (directAvailable) {
                direct = true;
                for (Uri uri : uris) {
                    try {
                        grantUriPermission("com.openai.chatgpt", uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception e) {
                        DiagLog.write(this, "SHARE_URI_GRANT_ERROR uri=" + uri + " err=" + e);
                    }
                }
                startActivity(chatGpt);
            } else {
                Intent chooser = Intent.createChooser(share, "画像を共有");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(chooser);
            }
            DiagLog.write(this, "CHATGPT_SHARE_START store=" + store.id + " attachments=" + uris.size() +
                    " tag=" + tagName + " textChars=" + prompt.length() + " direct=" + direct +
                    " totalMs=" + (SystemClock.elapsedRealtime() - started));
        } catch (Exception e) {
            DiagLog.write(this, "SHARE_INTENT_ERROR elapsedMs=" + (SystemClock.elapsedRealtime() - started) + " err=" + e);
            Toast.makeText(this, "共有を開始できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void saveLastShareMap(List<DatabaseHelper.Photo> photos) {
        android.content.SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        int oldCount = prefs.getInt("last_share_count", 0);
        android.content.SharedPreferences.Editor editor = prefs.edit();
        for (int i = 1; i <= oldCount; i++) editor.remove("last_share_image_" + i);
        editor.putInt("last_share_count", photos.size());
        editor.putLong("last_share_at", System.currentTimeMillis());
        for (int i = 0; i < photos.size(); i++) editor.putLong("last_share_image_" + (i + 1), photos.get(i).id);
        editor.apply();
    }

    private String buildChatGptPrompt(DatabaseHelper.Store store, List<DatabaseHelper.Photo> photos, String tagName) {
        String csvFileName = "PriceRec_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.JAPAN).format(new Date()) + ".csv";
        SimpleDateFormat shareDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);
        StringBuilder b = new StringBuilder();
        b.append("Price Rec.用の商品価格解析です。\n");
        b.append("店舗: ").append(store.name).append('\n');
        b.append("選択画像数: ").append(photos.size()).append("枚\n\n");

        b.append("Recognition protocol (important):\n");
        b.append("- Use BOTH OCR/transcription and visual product recognition on the original images. Do not identify a product from OCR text alone.\n");
        b.append("- Use label/logo design, colors, typography, bottle/can/package shape, label layout, emblems, age statements, cap/neck design and other visual cues as independent evidence.\n");
        b.append("- For blurred, crushed, compressed, partially hidden or low-resolution characters, compare character shapes with the surrounding label structure and the product's other visible visual cues. You may conservatively reconstruct unclear characters only when multiple independent cues converge on the same reading.\n");
        b.append("- Be relatively proactive about product identity when brand, label design and packaging cues strongly converge, even if OCR is imperfect. However, distinguish close variants such as age, edition, flavor, proof and volume; do not invent a variant that is not visually supported.\n");
        b.append("- Product names may be normalized to the commonly used Japanese product name when the identity is visually well supported.\n");
        b.append("- Price is different: never infer a price from product identity, memory, typical market price or nearby products. Read the actual visible shelf label/POP. If the digits remain ambiguous, leave price blank.\n");
        b.append("- Do not mistake descriptive copy, awards, tasting notes, JAN codes, discount conditions or shelf POP prose for the product name.\n\n");

        b.append("添付画像に写っている商品の商品名と販売価格を、OCRと画像全体の視覚的特徴を組み合わせて抽出してください。\n");
        b.append("同じ商品が複数画像に重複している場合は、同一店舗・同一価格なら重複行をまとめてください。\n");
        b.append("商品名は複数の根拠が一致する場合は積極的に特定して構いません。一方、価格・容量・年数・版違いなど根拠が弱い項目は推測で埋めないでください。\n\n");

        b.append("Price Rec.取込用CSVファイルをUTF-8で作成してください。\n");
        b.append("列順は必ず次の通りです。\n");
        b.append("store,tag,product_name,product_key,price,volume,price_type,captured_at,source_image\n");
        b.append("storeは『").append(store.name).append("』を入れてください。\n");
        b.append("product_keyは同一商品判定用の内部キーです。必ず『prd.』で開始し、以降は日本語・全角文字を使用して構いません。意味の区切りはピリオドを使ってください。例: prd.アサヒスーパードライ.350\n");
        b.append("同じ商品は店舗が違っても同じproduct_keyを使ってください。単なる重複では連番を付けないでください。\n");
        b.append("実際には別商品なのに同じキーになる場合だけ、末尾へ .001 / .002 の3桁連番を付けて分離してください。商品名自体にピリオドが含まれていても問題ありません。\n");
        b.append("priceは円の整数のみ、volumeは判読できる場合のみ。volumeはml換算した整数のみを入れ、ml等の単位文字は付けないでください（例: 700ml→700、1L→1000）。\n");
        b.append("price_typeは画像内に税込／税抜の明記がある場合はその表記を最優先してください。明記がない場合は、各画像に指定した『表示なし』ルールに従って『税込』または『税抜』を入れてください。\n");
        b.append("tag / captured_at / source_image / 表示なしルール は、各画像について下記の値をそのまま使ってください。\n");
        for (int i = 0; i < photos.size(); i++) {
            DatabaseHelper.Photo p = photos.get(i);
            String tag = p.tagName == null ? "タグなし" : p.tagName;
            b.append("image_").append(i + 1)
                    .append(" => source_image=photo_").append(p.id)
                    .append(", tag=").append(tag)
                    .append(", captured_at=").append(shareDateFormat.format(new Date(p.createdAt)))
                    .append(", 表示なし=").append(p.defaultTaxExcluded ? "税抜" : "税込").append('\n');
        }
        b.append("source_imageには image_N ではなく、必ず対応する photo_<番号> を入れてください。\n");
        b.append("\n最終結果はMarkdown表だけでなく、ダウンロード可能なCSVファイルとして作成してください。\n");
        b.append("CSVファイル名は必ず「").append(csvFileName).append("」にしてください。");
        return b.toString();
    }

    private void showAddImagesConfirmation(DatabaseHelper.Store store, List<PendingImage> items) {
        if (store == null || items == null || items.isEmpty()) return;
        final Set<String> selectedUris = new HashSet<>();
        for (PendingImage item : items) if (item != null && item.uri != null) selectedUris.add(item.uri.toString());
        final Set<Long> selectedTags = new HashSet<>();
        final boolean[] defaultTaxExcluded = {true};
        final boolean[] committed = {false};

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP));

        ScrollView imageScroll = newAutoFadeScrollView();
        imageScroll.setFillViewport(false);
        imageScroll.setVerticalScrollBarEnabled(true);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        imageScroll.addView(grid, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Multi-image confirmation gets a little more vertical room so the second-row
        // selection band is fully visible. Extra images scroll only inside this area.
        int previewHeight;
        if (items.size() == 1) previewHeight = 300;
        else if (items.size() <= 3) previewHeight = 205;
        else previewHeight = 380;
        content.addView(imageScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(previewHeight)));

        TextView count = text(selectedUris.size() + "枚選択", 13, SECONDARY, true);
        count.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);

        if (items.size() == 1) {
            PendingImage item = items.get(0);
            FrameLayout singleFrame = new FrameLayout(this);
            singleFrame.setBackground(roundRect(DGRAY, THUMB_RADIUS_DP));
            singleFrame.setClipToOutline(true);
            ImageView singleImage = new ImageView(this);
            singleImage.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            singleImage.setBackgroundColor(DGRAY);
            Bitmap bmp = loadBitmap(item.uri, 1200, 900);
            if (bmp != null) singleImage.setImageBitmap(bmp);
            singleFrame.addView(singleImage, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            LinearLayout.LayoutParams singleLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(280));
            singleLp.setMargins(dp(3), dp(3), dp(3), dp(6));
            grid.addView(singleFrame, singleLp);
        } else {
            LinearLayout row = null;
            for (int i = 0; i < items.size(); i++) {
                if (i % 3 == 0) {
                    row = new LinearLayout(this);
                    row.setGravity(Gravity.TOP | Gravity.START);
                    grid.addView(row, new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                }
                PendingImage item = items.get(i);
                if (item == null || item.uri == null) continue;
                final String key = item.uri.toString();

                LinearLayout tile = new LinearLayout(this);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setPadding(dp(3), dp(3), dp(3), dp(5));

                SquareFrameLayout frame = new SquareFrameLayout(this);
                frame.setBackground(roundRect(DGRAY, THUMB_RADIUS_DP));
                frame.setClipToOutline(true);
                ImageView image = new ImageView(this);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                image.setBackgroundColor(DGRAY);
                Bitmap bmp = loadCachedBitmap(item.uri, 360, 360);
                if (bmp != null) image.setImageBitmap(bmp);
                frame.addView(image, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                tile.addView(frame, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                LinearLayout selectedPanel = new LinearLayout(this);
                selectedPanel.setGravity(Gravity.CENTER);
                View check = new StraightSelectionCheckView(this);
                LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(dp(14), dp(14));
                checkLp.rightMargin = dp(5);
                selectedPanel.addView(check, checkLp);
                TextView state = text("", 11, WHITE, true);
                state.setGravity(Gravity.CENTER);
                selectedPanel.addView(state, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, dp(26)));
                LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
                panelLp.topMargin = dp(UI_TIGHT_SPACING_DP);
                tile.addView(selectedPanel, panelLp);

                Runnable updateSelectionVisual = () -> {
                    boolean selected = selectedUris.contains(key);
                    selectedPanel.setBackground(roundRect(selected ? LBLUE : Color.TRANSPARENT, THUMB_RADIUS_DP));
                    check.setVisibility(selected ? View.VISIBLE : View.GONE);
                    state.setText(selected ? "選択済み" : "除外");
                    state.setTextColor(selected ? WHITE : SECONDARY);
                    state.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
                };
                updateSelectionVisual.run();

                tile.setOnClickListener(v -> {
                    long started = SystemClock.elapsedRealtime();
                    if (!selectedUris.add(key)) selectedUris.remove(key);
                    count.setText(selectedUris.size() + "枚選択");
                    // Local visual update only: no full grid rebuild and no image re-decode.
                    updateSelectionVisual.run();
                    DiagLog.write(this, "PHOTO_CONFIRM_TOGGLE_FAST selected=" + selectedUris.contains(key) +
                            " total=" + selectedUris.size() + " elapsedMs=" +
                            (SystemClock.elapsedRealtime() - started));
                });
                row.addView(tile, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            }
            int remainder = items.size() % 3;
            if (row != null && remainder != 0) {
                for (int i = remainder; i < 3; i++) {
                    row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(1), 1f));
                }
            }
        }

        View confirmTagArea = makeCommonTagSelectionArea(selectedTags, true, store.enabled, chosen -> { });
        confirmTagArea.setMinimumHeight(dp(48));
        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tagLp.topMargin = dp(UI_SPACING_DP);
        content.addView(confirmTagArea, tagLp);

        // Selection count stays at the lower-left, immediately above the bottom controls.
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        countLp.topMargin = dp(UI_TIGHT_SPACING_DP);
        content.addView(count, countLp);

        // Tax fallback N toggle: right aligned, label to its left, vertically centered.
        // ON (default) = unspecified prices are tax-excluded.
        LinearLayout taxRow = new LinearLayout(this);
        taxRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        taxRow.addView(new View(this), new LinearLayout.LayoutParams(0, dp(36), 1f));
        TextView taxLabel = text("表示なしは税抜", 12, WHITE, true);
        taxLabel.setIncludeFontPadding(false);
        taxLabel.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams taxTextLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
        taxTextLp.rightMargin = dp(8);
        taxRow.addView(taxLabel, taxTextLp);
        NToggleSwitch taxToggle = new NToggleSwitch(this);
        taxToggle.setChecked(true);
        taxToggle.setNColors(ORANGE, NWHITE);
        taxToggle.setOnCheckedChangeListener((buttonView, checked) -> {
            defaultTaxExcluded[0] = checked;
            taxLabel.setText(checked ? "表示なしは税抜" : "表示なしは税込");
            buttonView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            DiagLog.write(this, "PHOTO_CONFIRM_TAX_DEFAULT excluded=" + checked);
        });
        taxRow.addView(taxToggle, new LinearLayout.LayoutParams(dp(44), dp(26)));
        LinearLayout.LayoutParams taxRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        taxRowLp.topMargin = dp(UI_TIGHT_SPACING_DP);
        content.addView(taxRow, taxRowLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView cancel = button("キャンセル", DGRAY, 14);
        TextView add = button("画像追加", BLUE, 14);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        cancelLp.rightMargin = dp(5);
        actions.addView(cancel, cancelLp);
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        addLp.leftMargin = dp(5);
        actions.addView(add, addLp);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        actionsLp.topMargin = dp(UI_SPACING_DP);
        content.addView(actions, actionsLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("画像追加")
                .setView(content)
                .create();

        add.setOnClickListener(v -> {
            if (selectedUris.isEmpty()) {
                Toast.makeText(this, "追加する画像を選択してください", Toast.LENGTH_SHORT).show();
                return;
            }
            int added = 0;
            ArrayList<Long> tags = orderedTagIds(selectedTags);
            for (PendingImage item : items) {
                if (item == null || item.uri == null) continue;
                boolean selected = selectedUris.contains(item.uri.toString());
                if (!selected) {
                    cleanupPendingImage(item);
                    continue;
                }
                try {
                    Uri finalUri = item.uri;
                    boolean finalManaged = item.managed;
                    if (item.cameraTempPath != null) {
                        finalUri = commitCameraTempToMediaStore(item, store);
                        finalManaged = true;
                        if (finalUri == null) {
                            DiagLog.write(this, "PHOTO_CONFIRM_ADD_ERROR temp=" + item.cameraTempPath + " err=commit_failed");
                            continue;
                        }
                    } else if (!item.managed) {
                        try {
                            getContentResolver().takePersistableUriPermission(
                                    item.uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (Exception e) {
                            DiagLog.write(this, "PHOTO_PICKER_PERMISSION_WARN uri=" + item.uri + " err=" + e);
                        }
                    }
                    long photoId = db.addPhoto(store.id, null, finalUri.toString(), finalManaged);
                    if (photoId > 0) {
                        db.updatePhotoTags(photoId, tags);
                        db.setPhotoDefaultTaxExcluded(photoId, defaultTaxExcluded[0]);
                        added++;
                        DiagLog.write(this, "PHOTO_CONFIRM_ADD photo=" + photoId + " store=" + store.id +
                                " tags=" + tags + " managed=" + finalManaged +
                                " defaultTaxExcluded=" + defaultTaxExcluded[0]);
                    }
                } catch (Exception e) {
                    DiagLog.write(this, "PHOTO_CONFIRM_ADD_ERROR uri=" + item.uri + " err=" + e);
                }
            }
            committed[0] = true;
            expandedStoreId = store.id;
            expandedStoreIds.add(store.id);
            activeTab.put(store.id, "images");
            Toast.makeText(this, added + "枚追加しました", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
            reloadStores();
        });
        cancel.setOnClickListener(v -> dialog.cancel());
        dialog.setOnDismissListener(d -> {
            if (committed[0]) return;
            for (PendingImage item : items) cleanupPendingImage(item);
            DiagLog.write(this, "PHOTO_CONFIRM_CANCEL store=" + store.id + " count=" + items.size());
        });
        showRoundedDialog(dialog, true);
        DiagLog.write(this, "PHOTO_CONFIRM_OPEN store=" + store.id + " count=" + items.size() +
                " previewHeightDp=" + previewHeight);
    }

    private void importImages(DatabaseHelper.Store store) {
        pendingImportStoreId = store.id;
        pendingImportTagId = null;
        try {
            PickVisualMediaRequest request = new PickVisualMediaRequest.Builder()
                    .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                    .build();
            DiagLog.write(this, "PHOTO_PICKER_START store=" + store.id);
            photoPicker.launch(request);
        } catch (Exception e) {
            clearPendingImportState();
            DiagLog.write(this, "PHOTO_PICKER_ERROR " + e);
            Toast.makeText(this, "画像を選択できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void handlePhotoPickerUris(List<Uri> uris) {
        if (pendingImportStoreId < 0) return;
        if (uris == null || uris.isEmpty()) {
            DiagLog.write(this, "PHOTO_PICKER_CANCEL");
            clearPendingImportState();
            return;
        }
        long storeId = pendingImportStoreId;
        DatabaseHelper.Store store = findStore(storeId);
        ArrayList<PendingImage> pending = new ArrayList<>();
        for (Uri uri : uris) if (uri != null) pending.add(new PendingImage(uri, false, null));
        clearPendingImportState();
        if (store == null) return;
        showAddImagesConfirmation(store, pending);
    }

    private DatabaseHelper.Store findStore(long id) {
        for (DatabaseHelper.Store s : db.listStores()) if (s.id == id) return s;
        return null;
    }

    private void clearPendingImportState() {
        pendingImportStoreId = -1L;
        pendingImportTagId = null;
    }

    private void releaseImportedPermission(Uri uri) {
        try { getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
    }

    private void takePhoto(DatabaseHelper.Store store) {
        try {
            pendingTagId = null;
            pendingStoreId = store.id;
            File base = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (base == null) base = getFilesDir();
            File tempDir = new File(base, "camera_tmp");
            if (!tempDir.exists() && !tempDir.mkdirs()) throw new IllegalStateException("camera temp mkdir failed");
            File temp = new File(tempDir, "PriceRec_capture_" + System.currentTimeMillis() + ".jpg");
            pendingCameraTempPath = temp.getAbsolutePath();
            pendingPhotoUri = FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", temp);

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingPhotoUri);
            intent.setClipData(ClipData.newRawUri("PriceRec camera output", pendingPhotoUri));
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            DiagLog.write(this, "CAMERA_START store=" + pendingStoreId +
                    " uri=" + pendingPhotoUri + " temp=" + pendingCameraTempPath);
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception e) {
            DiagLog.write(this, "CAMERA_START_ERROR " + e);
            cleanupPendingPhoto();
            Toast.makeText(this, "カメラを起動できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAMERA) return;
        if (pendingPhotoUri == null) return;
        Uri capturedUri = pendingPhotoUri;
        String tempPath = pendingCameraTempPath;
        long storeId = pendingStoreId;
        if (resultCode == RESULT_OK) {
            File temp = tempPath == null ? null : new File(tempPath);
            long bytes = temp != null && temp.exists() ? temp.length() : 0L;
            DiagLog.write(this, "CAMERA_RESULT_OK store=" + storeId + " bytes=" + bytes + " temp=" + tempPath);
            if (bytes <= 0L) {
                DiagLog.write(this, "CAMERA_TEMP_FILE_ERROR temp=" + tempPath + " bytes=" + bytes);
                cleanupPendingPhoto();
                Toast.makeText(this, "撮影画像を保存できませんでした", Toast.LENGTH_LONG).show();
                reloadStores();
                return;
            }
            DatabaseHelper.Store store = findStore(storeId);
            clearPendingPhotoState();
            if (store != null) {
                ArrayList<PendingImage> pending = new ArrayList<>();
                pending.add(new PendingImage(capturedUri, true, tempPath));
                showAddImagesConfirmation(store, pending);
                return;
            }
            deleteFileQuietly(tempPath);
        } else {
            DiagLog.write(this, "CAMERA_CANCEL result=" + resultCode + " temp=" + tempPath);
            deleteFileQuietly(tempPath);
        }
        clearPendingPhotoState();
        reloadStores();
    }

    private Uri commitCameraTempToMediaStore(PendingImage item, DatabaseHelper.Store store) {
        if (item == null || item.cameraTempPath == null) return item == null ? null : item.uri;
        File source = new File(item.cameraTempPath);
        if (!source.exists() || source.length() <= 0L) {
            DiagLog.write(this, "CAMERA_COMMIT_FAIL temp=" + item.cameraTempPath + " reason=missing_or_empty");
            return null;
        }
        Uri dest = null;
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "PriceRec_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/PriceRec/" + safeFolder(store.name));
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            dest = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (dest == null) throw new IllegalStateException("MediaStore insert returned null");
            try (FileInputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(dest, "w")) {
                if (out == null) throw new IllegalStateException("MediaStore output stream null");
                byte[] buffer = new byte[128 * 1024];
                int n;
                while ((n = in.read(buffer)) >= 0) {
                    if (n > 0) out.write(buffer, 0, n);
                }
                out.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(dest, done, null, null);
            long bytes = source.length();
            deleteFileQuietly(item.cameraTempPath);
            DiagLog.write(this, "CAMERA_MEDIASTORE_COMMIT uri=" + dest + " bytes=" + bytes);
            return dest;
        } catch (Exception e) {
            if (dest != null) {
                try { getContentResolver().delete(dest, null, null); } catch (Exception ignored) { }
            }
            DiagLog.write(this, "CAMERA_COMMIT_FAIL temp=" + item.cameraTempPath + " err=" + e);
            return null;
        }
    }

    private void cleanupPendingImage(PendingImage item) {
        if (item == null) return;
        if (item.cameraTempPath != null) {
            deleteFileQuietly(item.cameraTempPath);
            return;
        }
        if (item.managed && item.uri != null) {
            try { getContentResolver().delete(item.uri, null, null); } catch (Exception ignored) { }
        }
    }

    private void deleteFileQuietly(String path) {
        if (path == null || path.isEmpty()) return;
        try {
            File file = new File(path);
            if (file.exists() && !file.delete()) file.deleteOnExit();
        } catch (Exception ignored) { }
    }

    private void cleanupPendingPhoto() {
        if (pendingCameraTempPath != null) {
            deleteFileQuietly(pendingCameraTempPath);
        } else if (pendingPhotoUri != null) {
            try { getContentResolver().delete(pendingPhotoUri, null, null); } catch (Exception ignored) { }
        }
        clearPendingPhotoState();
    }

    private void clearPendingPhotoState() {
        pendingPhotoUri = null;
        pendingCameraTempPath = null;
        pendingStoreId = -1L;
        pendingTagId = null;
    }

    private void showOcrSheet(long photoId, String title) {
        DatabaseHelper.Photo photo = db.getPhoto(photoId);
        List<DatabaseHelper.ProductRecord> existing = db.listProductsForPhoto(photoId);
        LinearLayout editors = new LinearLayout(this);
        editors.setOrientation(LinearLayout.VERTICAL);
        ArrayList<OcrEditorRow> rowEditors = new ArrayList<>();
        editors.addView(sheetHeader(new String[]{"商品名", "価格", ""}, new int[]{260, 110, 50}));
        for (DatabaseHelper.ProductRecord p : existing) addOcrEditorRow(editors, rowEditors, p.rawName, p.priceYen);
        if (existing.isEmpty()) addOcrEditorRow(editors, rowEditors, "", null);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP));
        HorizontalScrollView hsv = newAutoFadeHorizontalScrollView();
        hsv.addView(editors);
        ScrollView vsv = newAutoFadeScrollView();
        vsv.addView(hsv);
        content.addView(vsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));
        TextView add = makeDialogAction("＋ 商品");
        add.setTextSize(15);
        add.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        add.setOnClickListener(v -> addOcrEditorRow(editors, rowEditors, "", null));
        content.addView(add, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            ArrayList<DatabaseHelper.ProductInput> rows = new ArrayList<>();
            for (OcrEditorRow r : rowEditors) {
                if (r.row.getParent() == null) continue;
                String name = r.name.getText().toString().trim();
                if (name.isEmpty()) continue;
                Integer price = parsePriceInput(r.price.getText().toString());
                rows.add(new DatabaseHelper.ProductInput(name, price, null));
            }
            db.replaceProductsForPhoto(photoId, rows, photo == null ? null : photo.ocrRaw);
            DiagLog.write(this, "PRODUCT_EDIT_SAVE photo=" + photoId + " rows=" + rows.size());
            dialog.dismiss();
            reloadStores();
        }));
        showRoundedDialog(dialog, true);
    }

    private void addOcrEditorRow(LinearLayout container, ArrayList<OcrEditorRow> list, String nameValue, Integer priceValue) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(2));
        EditText name = sheetEdit(nameValue, false);
        EditText price = sheetEdit(priceValue == null ? "" : String.valueOf(priceValue), true);
        TextView del = text("×", 22, LRED, true);
        del.setGravity(Gravity.CENTER);
        row.addView(name, new LinearLayout.LayoutParams(dp(260), dp(46)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(110), dp(46)); pp.leftMargin = dp(4);
        row.addView(price, pp);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(dp(50), dp(46)); dpv.leftMargin = dp(4);
        row.addView(del, dpv);
        OcrEditorRow editor = new OcrEditorRow(row, name, price);
        list.add(editor);
        del.setOnClickListener(v -> container.removeView(row));
        container.addView(row);
    }

    private Integer parsePriceInput(String s) {
        String digits = s == null ? "" : s.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return null;
        try { return Integer.parseInt(digits); } catch (NumberFormatException e) { return null; }
    }

    private void runSearch(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) return;
        hideKeyboard(searchInput);
        List<DatabaseHelper.ProductRecord> hits = db.searchProducts(q);
        if (!hits.isEmpty()) rememberSearchCandidate(q);
        DiagLog.write(this, "SEARCH q=" + q + " hits=" + hits.size());
        showProductTableDialog("検索", null, q);
    }

    private static final class StoreImportChoice {
        final StorePackageManager.ParsedStore source;
        String mode = "MERGE";
        boolean includeImages;
        boolean selected = false;

        StoreImportChoice(StorePackageManager.ParsedStore source) {
            this.source = source;
            this.includeImages = source != null && source.imageCount() > 0;
        }
    }

    private static final class StoreImportRunResult {
        int stores;
        int products;
        int images;
        int failures;
        final ArrayList<String> messages = new ArrayList<>();
    }

    private void showStoreExportDialog(List<DatabaseHelper.Store> stores, boolean allStores) {
        if (stores == null || stores.isEmpty()) {
            Toast.makeText(this, "エクスポートする店舗がありません", Toast.LENGTH_SHORT).show();
            return;
        }

        int csvCount = 0;
        int productCount = 0;
        for (DatabaseHelper.Store store : stores) {
            csvCount += db.listExportCsvForStore(store.id).size();
            productCount += db.listProductsForStore(store.id).size();
        }

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));

        TextView scope = text(allStores ? (stores.size() + "店舗") : stores.get(0).name, 15, WHITE, true);
        panel.addView(scope);

        TextView counts = text("CSV " + csvCount + "ファイル / " + productCount + "商品", 14, SECONDARY, false);
        LinearLayout.LayoutParams countsLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        countsLp.topMargin = dp(UI_TIGHT_SPACING_DP);
        panel.addView(counts, countsLp);

        TextView noImageSize = text("画像なし　計算中…", 15, WHITE, false);
        LinearLayout.LayoutParams sizeLp1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        sizeLp1.topMargin = dp(UI_SPACING_DP);
        panel.addView(noImageSize, sizeLp1);

        TextView withImageSize = text("画像あり　計算中…", 15, WHITE, false);
        panel.addView(withImageSize, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        TextView imageCount = text("参照画像　計算中…", 13, SECONDARY, false);
        panel.addView(imageCount);

        LinearLayout toggleRow = new LinearLayout(this);
        toggleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView toggleLabel = text("参照画像を含める", 15, WHITE, true);
        toggleRow.addView(toggleLabel, new LinearLayout.LayoutParams(0, dp(44), 1f));
        NToggleSwitch includeToggle = new NToggleSwitch(this);
        includeToggle.setNColors(ORANGE, NWHITE);
        includeToggle.setChecked(false);
        toggleRow.addView(includeToggle, new LinearLayout.LayoutParams(dp(44), dp(28)));
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        toggleLp.topMargin = dp(UI_SPACING_DP);
        panel.addView(toggleRow, toggleLp);

        TextView cancel = button("キャンセル", DGRAY, 13);
        TextView export = button("エクスポート", DGRAY, 13);
        setButtonEnabledStyle(export, false, BLUE);
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(dp(100), dp(38));
        cancelLp.rightMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(cancel, cancelLp);
        actions.addView(export, new LinearLayout.LayoutParams(dp(110), dp(38)));
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        actionsLp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        panel.addView(actions, actionsLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(allStores ? "全店舗をエクスポート" : "店舗をエクスポート")
                .setView(panel)
                .create();

        final StorePackageManager.BuildResult[] noImageResult = {null};
        final StorePackageManager.BuildResult[] withImageResult = {null};
        final String exportName = buildStorePackageFileName(stores, allStores);
        File dir = new File(getCacheDir(), "store_packages");
        if (!dir.exists()) dir.mkdirs();
        File noImageFile = new File(dir, "build_" + UUID.randomUUID() + "_noimg.prstore");
        File withImageFile = new File(dir, "build_" + UUID.randomUUID() + "_img.prstore");

        Runnable refreshExportButton = () -> {
            StorePackageManager.BuildResult selected = includeToggle.isChecked() ? withImageResult[0] : noImageResult[0];
            boolean ready = selected != null && selected.file != null && selected.file.exists();
            setButtonEnabledStyle(export, ready, BLUE);
        };
        includeToggle.setOnCheckedChangeListener((buttonView, isChecked) -> refreshExportButton.run());
        cancel.setOnClickListener(v -> dialog.cancel());
        export.setOnClickListener(v -> {
            StorePackageManager.BuildResult selected = includeToggle.isChecked() ? withImageResult[0] : noImageResult[0];
            if (selected == null || selected.file == null || !selected.file.exists()) return;
            try {
                File finalFile = new File(dir, exportName);
                copyFile(selected.file, finalFile);
                shareStorePackage(finalFile);
                DiagLog.write(this, "STORE_EXPORT_SHARE stores=" + selected.storeCount + " csv=" + selected.csvCount +
                        " products=" + selected.productCount + " images=" + selected.imageCount + " bytes=" + selected.bytes);
                dialog.dismiss();
            } catch (Exception e) {
                DiagLog.write(this, "STORE_EXPORT_SHARE_ERROR " + e);
                Toast.makeText(this, "店舗データを共有できませんでした", Toast.LENGTH_LONG).show();
            }
        });

        showRoundedDialog(dialog);
        DiagLog.write(this, "STORE_EXPORT_PREP_START stores=" + stores.size() + " all=" + allStores);
        packageExecutor.execute(() -> {
            try {
                StorePackageManager.BuildResult r = StorePackageManager.build(this, db, stores, false, noImageFile);
                noImageResult[0] = r;
                runOnUiThread(() -> {
                    noImageSize.setText("画像なし　" + humanFileSize(r.bytes));
                    refreshExportButton.run();
                });
            } catch (Exception e) {
                DiagLog.write(this, "STORE_EXPORT_BUILD_ERROR images=false err=" + e);
                runOnUiThread(() -> noImageSize.setText("画像なし　作成できません"));
            }
            try {
                StorePackageManager.BuildResult r = StorePackageManager.build(this, db, stores, true, withImageFile);
                withImageResult[0] = r;
                runOnUiThread(() -> {
                    withImageSize.setText("画像あり　" + humanFileSize(r.bytes));
                    imageCount.setText("参照画像 " + r.imageCount + "枚");
                    if (r.imageCount == 0) {
                        includeToggle.setChecked(false);
                        includeToggle.setEnabled(false);
                        includeToggle.setAlpha(0.45f);
                        toggleLabel.setTextColor(SECONDARY);
                    }
                    refreshExportButton.run();
                });
                DiagLog.write(this, "STORE_EXPORT_PREP_OK stores=" + r.storeCount + " csv=" + r.csvCount +
                        " products=" + r.productCount + " images=" + r.imageCount + " bytes=" + r.bytes);
            } catch (Exception e) {
                DiagLog.write(this, "STORE_EXPORT_BUILD_ERROR images=true err=" + e);
                runOnUiThread(() -> {
                    withImageSize.setText("画像あり　作成できません");
                    imageCount.setText("参照画像 0枚");
                    includeToggle.setChecked(false);
                    includeToggle.setEnabled(false);
                    includeToggle.setAlpha(0.45f);
                    toggleLabel.setTextColor(SECONDARY);
                    refreshExportButton.run();
                });
            }
        });
    }

    private String buildStorePackageFileName(List<DatabaseHelper.Store> stores, boolean allStores) {
        String base = allStores ? "AllStores" : (stores == null || stores.isEmpty() ? "Store" : stores.get(0).name);
        base = safeFileComponent(base);
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.JAPAN).format(new Date());
        return "PriceRec_" + base + "_" + stamp + ".prstore";
    }

    private String safeFileComponent(String value) {
        String s = value == null ? "Store" : value.trim();
        s = s.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_").replaceAll("\\s+", " ").trim();
        if (s.isEmpty()) s = "Store";
        return s.length() > 48 ? s.substring(0, 48) : s;
    }

    private String humanFileSize(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024.0) return String.format(Locale.JAPAN, "%.1f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024.0) return String.format(Locale.JAPAN, "%.1f MB", mb);
        return String.format(Locale.JAPAN, "%.2f GB", mb / 1024.0);
    }

    private void copyFile(File source, File dest) throws Exception {
        if (source == null || dest == null) throw new IllegalArgumentException("file");
        File parent = dest.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileInputStream in = new FileInputStream(source); OutputStream out = new java.io.FileOutputStream(dest)) {
            byte[] buf = new byte[128 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) if (n > 0) out.write(buf, 0, n);
            out.flush();
        }
    }

    private void shareStorePackage(File file) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(StorePackageManager.MIME);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_TITLE, file.getName());
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        send.setClipData(ClipData.newUri(getContentResolver(), file.getName(), uri));

        Intent chooser = Intent.createChooser(send, "店舗データを共有");
        if (Build.VERSION.SDK_INT >= 34) {
            Intent saveIntent = new Intent(this, MainActivity.class);
            saveIntent.setAction(ACTION_SAVE_STORE_PACKAGE);
            saveIntent.putExtra(EXTRA_STORE_PACKAGE_PATH, file.getAbsolutePath());
            saveIntent.putExtra(EXTRA_STORE_PACKAGE_NAME, file.getName());
            saveIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int requestCode = (file.getAbsolutePath() + file.lastModified()).hashCode();
            PendingIntent savePendingIntent = PendingIntent.getActivity(
                    this, requestCode, saveIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            ChooserAction saveAction = new ChooserAction.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_save),
                    "保存",
                    savePendingIntent).build();
            chooser.putExtra(Intent.EXTRA_CHOOSER_CUSTOM_ACTIONS, new ChooserAction[]{saveAction});
        }
        startActivity(chooser);
    }

    private boolean handleStorePackageSaveIntent(Intent intent) {
        if (intent == null || !ACTION_SAVE_STORE_PACKAGE.equals(intent.getAction())) return false;
        intent.setAction(null);
        String path = intent.getStringExtra(EXTRA_STORE_PACKAGE_PATH);
        String name = intent.getStringExtra(EXTRA_STORE_PACKAGE_NAME);
        File source = path == null ? null : new File(path);
        if (source == null || !source.exists() || !source.isFile()) {
            DiagLog.write(this, "STORE_EXPORT_SAVE_SOURCE_MISSING path=" + path);
            Toast.makeText(this, "保存する店舗データが見つかりません", Toast.LENGTH_LONG).show();
            return true;
        }
        pendingStorePackageSaveFile = source;
        final String suggestedName = (name == null || name.trim().isEmpty()) ? source.getName() : name;
        View anchor = storeContainer;
        if (anchor != null) anchor.post(() -> storePackageSaveLauncher.launch(suggestedName));
        else storePackageSaveLauncher.launch(suggestedName);
        DiagLog.write(this, "STORE_EXPORT_SAVE_PICKER_START file=" + suggestedName + " bytes=" + source.length());
        return true;
    }

    private void handleStorePackageSaveUri(Uri uri) {
        File source = pendingStorePackageSaveFile;
        pendingStorePackageSaveFile = null;
        if (uri == null) {
            DiagLog.write(this, "STORE_EXPORT_SAVE_CANCEL");
            return;
        }
        if (source == null || !source.exists()) {
            DiagLog.write(this, "STORE_EXPORT_SAVE_ERROR reason=source_missing uri=" + uri);
            Toast.makeText(this, "保存元データが見つかりません", Toast.LENGTH_LONG).show();
            return;
        }
        try (FileInputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
            if (out == null) throw new IllegalStateException("openOutputStream returned null");
            byte[] buf = new byte[128 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) if (n > 0) out.write(buf, 0, n);
            out.flush();
            DiagLog.write(this, "STORE_EXPORT_SAVE_OK uri=" + uri + " bytes=" + source.length());
            Toast.makeText(this, "店舗データを保存しました", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            DiagLog.write(this, "STORE_EXPORT_SAVE_ERROR uri=" + uri + " err=" + e);
            Toast.makeText(this, "店舗データを保存できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void startStoreImportPicker() {
        try {
            DiagLog.write(this, "STORE_IMPORT_PICKER_START");
            storePackagePicker.launch(new String[]{StorePackageManager.MIME, "application/zip", "application/octet-stream", "*/*"});
        } catch (Exception e) {
            DiagLog.write(this, "STORE_IMPORT_PICKER_ERROR " + e);
            Toast.makeText(this, "店舗データを選択できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void handleStorePackageUris(List<Uri> uris) {
        if (uris == null || uris.isEmpty()) {
            DiagLog.write(this, "STORE_IMPORT_PICKER_CANCEL");
            return;
        }
        final ArrayList<Uri> input = new ArrayList<>();
        for (Uri uri : uris) if (uri != null) input.add(uri);
        if (input.isEmpty()) return;
        for (Uri uri : input) {
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) { }
        }
        Toast.makeText(this, "店舗データを確認しています…", Toast.LENGTH_SHORT).show();
        DiagLog.write(this, "STORE_IMPORT_PARSE_START files=" + input.size());
        packageExecutor.execute(() -> {
            ArrayList<StorePackageManager.ParsedPackage> packages = new ArrayList<>();
            ArrayList<StorePackageManager.ParsedStore> stores = new ArrayList<>();
            ArrayList<String> errors = new ArrayList<>();
            for (Uri uri : input) {
                try {
                    StorePackageManager.ParsedPackage parsed = StorePackageManager.copyAndParse(this, uri);
                    packages.add(parsed);
                    stores.addAll(parsed.stores);
                    DiagLog.write(this, "STORE_IMPORT_PARSE_FILE_OK file=" + parsed.sourceName + " stores=" + parsed.stores.size());
                } catch (Exception e) {
                    String name = displayNameForUri(uri);
                    errors.add(name + ": " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
                    DiagLog.write(this, "STORE_IMPORT_PARSE_FILE_ERROR uri=" + uri + " err=" + e);
                }
            }
            runOnUiThread(() -> {
                if (stores.isEmpty()) {
                    for (StorePackageManager.ParsedPackage parsed : packages) StorePackageManager.cleanup(parsed);
                    AlertDialog error = new AlertDialog.Builder(this)
                            .setTitle("店舗をインポート")
                            .setMessage(errors.isEmpty() ? "店舗データを読み込めませんでした" : android.text.TextUtils.join("\n", errors))
                            .setPositiveButton("閉じる", null).create();
                    showRoundedDialog(error);
                    return;
                }
                showStoreImportDialog(stores, packages, errors);
            });
        });
    }

    private void showStoreImportDialog(List<StorePackageManager.ParsedStore> stores,
                                       List<StorePackageManager.ParsedPackage> packages,
                                       List<String> parseErrors) {
        ArrayList<StoreImportChoice> choices = new ArrayList<>();
        for (StorePackageManager.ParsedStore store : stores) choices.add(new StoreImportChoice(store));
        final boolean batchMode = choices.size() > 1;
        final boolean[] selectionMode = {false};
        final ArrayList<LinearLayout> cards = new ArrayList<>();
        final Runnable[] refreshSelectionState = new Runnable[1];

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        if (parseErrors != null && !parseErrors.isEmpty()) {
            TextView warning = text(parseErrors.size() + "ファイルは読み込めませんでした", 13, LRED, true);
            panel.addView(warning);
        }

        ScrollView scroll = newAutoFadeScrollView();
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        int maxHeight = Math.min(dp(470), Math.max(dp(190), getResources().getDisplayMetrics().heightPixels * 58 / 100));
        panel.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxHeight));

        for (int i = 0; i < choices.size(); i++) {
            final int index = i;
            StoreImportChoice choice = choices.get(i);
            StorePackageManager.ParsedStore source = choice.source;

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackground(roundRect(GRAY, 14));
            card.setClickable(batchMode);
            card.setLongClickable(batchMode);
            cards.add(card);

            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i > 0) cardLp.topMargin = dp(UI_SPACING_DP);
            rows.addView(card, cardLp);

            TextView name = text(source.name, 16, WHITE, true);
            card.addView(name);
            TextView file = text(source.sourceName, 12, SECONDARY, false);
            file.setMaxLines(1);
            file.setEllipsize(android.text.TextUtils.TruncateAt.END);
            card.addView(file);
            TextView info = text("CSV " + source.csvCount + "ファイル / " + source.products.size() + "商品　参照画像 " + source.imageCount() + "枚", 13, SECONDARY, false);
            LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            infoLp.topMargin = dp(UI_TIGHT_SPACING_DP);
            card.addView(info, infoLp);

            LinearLayout modeRow = new LinearLayout(this);
            modeRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            modeRow.addView(new View(this), new LinearLayout.LayoutParams(0, dp(40), 1f));
            TextView modeLabel = text("同一店舗をマージ", 13, WHITE, false);
            modeLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            LinearLayout.LayoutParams modeLabelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
            modeLabelLp.rightMargin = dp(UI_TIGHT_SPACING_DP);
            modeRow.addView(modeLabel, modeLabelLp);
            NToggleSwitch modeToggle = new NToggleSwitch(this);
            modeToggle.setNColors(ORANGE, NWHITE);
            modeToggle.setChecked("MERGE".equals(choice.mode));
            modeToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
                choice.mode = isChecked ? "MERGE" : "NEW";
                DiagLog.write(this, "STORE_IMPORT_MODE_TOGGLE index=" + index + " mode=" + choice.mode +
                        " store=" + (choice.source == null ? "" : choice.source.name));
            });
            modeRow.addView(modeToggle, new LinearLayout.LayoutParams(dp(44), dp(28)));
            card.addView(modeRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

            LinearLayout imageRow = new LinearLayout(this);
            imageRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            imageRow.addView(new View(this), new LinearLayout.LayoutParams(0, dp(40), 1f));
            TextView imageLabel = text("画像もインポート", 13, source.imageCount() > 0 ? WHITE : LGRAY, false);
            imageLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            LinearLayout.LayoutParams imageLabelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
            imageLabelLp.rightMargin = dp(UI_TIGHT_SPACING_DP);
            imageRow.addView(imageLabel, imageLabelLp);
            NToggleSwitch imageToggle = new NToggleSwitch(this);
            imageToggle.setNColors(BLUE, NWHITE);
            imageToggle.setChecked(choice.includeImages);
            if (source.imageCount() == 0) {
                imageToggle.setChecked(false);
                imageToggle.setEnabled(false);
                imageToggle.setAlpha(0.45f);
                choice.includeImages = false;
            }
            imageToggle.setOnCheckedChangeListener((buttonView, isChecked) -> choice.includeImages = isChecked);
            imageRow.addView(imageToggle, new LinearLayout.LayoutParams(dp(44), dp(28)));
            card.addView(imageRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
            if (source.imageCount() == 0) {
                TextView none = text("このデータには参照画像が含まれていません", 12, LGRAY, false);
                none.setGravity(Gravity.END);
                card.addView(none);
            }

            if (batchMode) {
                card.setOnClickListener(v -> {
                    if (!selectionMode[0]) return;
                    StoreImportChoice tapped = choices.get(index);
                    tapped.selected = !tapped.selected;
                    int selectedCount = 0;
                    for (StoreImportChoice c : choices) if (c.selected) selectedCount++;
                    DiagLog.write(this, "STORE_IMPORT_SELECT_TOGGLE index=" + index + " selected=" + tapped.selected +
                            " selectedCount=" + selectedCount + " store=" + (tapped.source == null ? "" : tapped.source.name));
                    if (selectedCount == 0) selectionMode[0] = false;
                    if (refreshSelectionState[0] != null) refreshSelectionState[0].run();
                });
                card.setOnLongClickListener(v -> {
                    if (!selectionMode[0]) {
                        selectionMode[0] = true;
                        for (StoreImportChoice c : choices) c.selected = false;
                    }
                    choices.get(index).selected = true;
                    DiagLog.write(this, "STORE_IMPORT_SELECT_LONG index=" + index +
                            " store=" + (choice.source == null ? "" : choice.source.name));
                    if (refreshSelectionState[0] != null) refreshSelectionState[0].run();
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    return true;
                });
            }
        }

        TextView select = batchMode ? button("選択", ORANGE, 13) : null;
        TextView cancel = button("キャンセル", DGRAY, 13);
        TextView run = button(batchMode ? "まとめてインポート" : "インポート", BLUE, 13);
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        if (batchMode) {
            // Fixed slot: 選択 / 選択解除 share the same 110dp button rectangle.
            actions.addView(select, new LinearLayout.LayoutParams(dp(110), dp(38)));
            actions.addView(new View(this), new LinearLayout.LayoutParams(0, dp(1), 1f));
        } else {
            actions.addView(new View(this), new LinearLayout.LayoutParams(0, dp(1), 1f));
        }
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(dp(100), dp(38));
        cLp.rightMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(cancel, cLp);
        // Fixed slot: インポート / まとめてインポート always remain 152dp.
        actions.addView(run, new LinearLayout.LayoutParams(dp(152), dp(38)));
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        actionsLp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        panel.addView(actions, actionsLp);

        refreshSelectionState[0] = () -> {
            if (!batchMode) return;
            int selectedCount = 0;
            for (int i = 0; i < choices.size(); i++) {
                StoreImportChoice choice = choices.get(i);
                LinearLayout card = cards.get(i);
                if (selectionMode[0] && choice.selected) {
                    selectedCount++;
                    card.setBackground(roundRect(LBLUE, 14));
                } else {
                    card.setBackground(roundRect(GRAY, 14));
                }
            }

            if (!selectionMode[0]) {
                for (StoreImportChoice choice : choices) choice.selected = false;
                select.setText("選択");
                setButtonEnabledStyle(select, true, ORANGE);
                run.setText("まとめてインポート");
                setButtonEnabledStyle(run, true, BLUE);
            } else {
                select.setText("選択解除");
                boolean any = selectedCount > 0;
                setButtonEnabledStyle(select, any, RED);
                run.setText(selectedCount >= 2 ? "まとめてインポート" : "インポート");
                setButtonEnabledStyle(run, any, BLUE);
            }
        };

        if (batchMode) {
            select.setOnClickListener(v -> {
                if (!selectionMode[0]) {
                    selectionMode[0] = true;
                    for (StoreImportChoice choice : choices) choice.selected = false;
                    DiagLog.write(this, "STORE_IMPORT_SELECT_MODE_START count=" + choices.size());
                } else {
                    int cleared = 0;
                    for (StoreImportChoice choice : choices) {
                        if (choice.selected) cleared++;
                        choice.selected = false;
                    }
                    selectionMode[0] = false;
                    DiagLog.write(this, "STORE_IMPORT_SELECT_CLEAR count=" + cleared);
                }
                refreshSelectionState[0].run();
            });
            refreshSelectionState[0].run();
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗をインポート")
                .setView(panel)
                .create();
        final boolean[] importStarted = {false};
        cancel.setOnClickListener(v -> {
            if (batchMode && selectionMode[0]) {
                for (StoreImportChoice choice : choices) choice.selected = false;
                selectionMode[0] = false;
                DiagLog.write(this, "STORE_IMPORT_SELECT_CANCEL_TO_NORMAL");
                refreshSelectionState[0].run();
            } else {
                dialog.cancel();
            }
        });
        run.setOnClickListener(v -> {
            ArrayList<StoreImportChoice> runChoices = new ArrayList<>();
            if (batchMode && selectionMode[0]) {
                for (StoreImportChoice choice : choices) if (choice.selected) runChoices.add(choice);
            } else {
                runChoices.addAll(choices);
            }
            if (runChoices.isEmpty()) return;
            importStarted[0] = true;
            setButtonEnabledStyle(run, false, BLUE);
            dialog.dismiss();
            Toast.makeText(this, "店舗データをインポートしています…", Toast.LENGTH_SHORT).show();
            packageExecutor.execute(() -> {
                StoreImportRunResult result = importStoreChoices(runChoices);
                for (StorePackageManager.ParsedPackage parsed : packages) StorePackageManager.cleanup(parsed);
                runOnUiThread(() -> {
                    reloadStores();
                    StringBuilder msg = new StringBuilder();
                    msg.append(result.stores).append("店舗 / ").append(result.products).append("商品");
                    if (result.images > 0) msg.append(" / 画像").append(result.images).append("枚");
                    if (result.failures > 0) msg.append("\n失敗: ").append(result.failures);
                    if (!result.messages.isEmpty()) msg.append("\n\n").append(android.text.TextUtils.join("\n", result.messages));
                    AlertDialog done = new AlertDialog.Builder(this)
                            .setTitle("インポート完了")
                            .setMessage(msg.toString())
                            .setPositiveButton("閉じる", null).create();
                    showRoundedDialog(done);
                });
            });
        });
        dialog.setOnDismissListener(d -> {
            if (!importStarted[0]) for (StorePackageManager.ParsedPackage parsed : packages) StorePackageManager.cleanup(parsed);
        });
        showRoundedDialog(dialog, true);
    }

    private StoreImportRunResult importStoreChoices(List<StoreImportChoice> choices) {
        StoreImportRunResult total = new StoreImportRunResult();
        for (StoreImportChoice choice : choices) {
            try {
                int[] imported = importOneStore(choice);
                total.stores++;
                total.products += imported[0];
                total.images += imported[1];
            } catch (Exception e) {
                total.failures++;
                String label = choice == null || choice.source == null ? "店舗" : choice.source.name;
                total.messages.add(label + ": " + (e.getMessage() == null ? "インポート失敗" : e.getMessage()));
                DiagLog.write(this, "STORE_IMPORT_ERROR store=" + label + " err=" + e);
            }
        }
        return total;
    }

    private int[] importOneStore(StoreImportChoice choice) throws Exception {
        if (choice == null || choice.source == null) throw new IllegalArgumentException("店舗データがありません");
        StorePackageManager.ParsedStore source = choice.source;
        boolean newStoreMode = "NEW".equals(choice.mode);
        DatabaseHelper.Store target = null;
        boolean createdStore = false;
        if (!newStoreMode) {
            target = db.findStoreByKey(source.storeKey);
            if (target != null && !target.enabled) throw new IllegalStateException("NトグルOFFの店舗にはマージできません");
        }
        if (target == null) {
            long newId;
            if (newStoreMode) {
                // Intentional fork: no imported map identity and no imported store_key.
                newId = db.addStore(source.name, "");
            } else {
                newId = db.addStore(source.name, source.mapUrl, source.storeKey,
                        source.mapResolvedUrl, source.mapLat, source.mapLng);
            }
            if (newId < 0) throw new IllegalStateException("店舗を作成できません");
            target = db.getStore(newId);
            createdStore = true;
        }
        if (target == null) throw new IllegalStateException("取込先店舗がありません");

        String packageId = "imp." + UUID.randomUUID();
        long historyId = db.createStoreImportHistory(packageId, source.sourceName, source.sourceUri, source.storeKey,
                target.id, target.storeKey, target.name, newStoreMode ? "NEW" : "MERGE",
                choice.includeImages, source.csvCount, source.products.size(), choice.includeImages ? source.imageCount() : 0, createdStore);
        if (historyId < 0) throw new IllegalStateException("インポート履歴を作成できません");

        LinkedHashMap<String, Long> photoIds = new LinkedHashMap<>();
        int importedImages = 0;
        int importedProducts = 0;
        try {
            for (StorePackageManager.CsvData csv : source.csvs) {
                String rawCsv = StorePackageManager.readTextEntry(source.packageFile, csv.entryName);
                db.recordStoreImportCsv(historyId, csv.fileName, rawCsv);
            }
            for (StorePackageManager.PhotoData photo : source.photos) {
                List<Long> tagIds = ensureTagsByName(photo.tags);
                Long primaryTag = tagIds.isEmpty() ? null : tagIds.get(0);
                Uri importedUri = null;
                boolean managed = false;
                if (choice.includeImages && photo.imageEntry != null && !photo.imageEntry.isEmpty()) {
                    importedUri = importPackageImage(source.packageFile, photo.imageEntry, photo.sourceName, target);
                    managed = importedUri != null;
                    if (managed) importedImages++;
                }
                long photoId;
                if (managed) {
                    photoId = db.addPhotoAt(target.id, primaryTag, importedUri.toString(), true, photo.createdAt, "imported");
                } else {
                    photoId = db.createVirtualImportPhoto(target.id, primaryTag, photo.createdAt,
                            photo.sourceName == null ? photo.token : photo.sourceName);
                }
                if (photoId < 0) throw new IllegalStateException("画像情報を登録できません");
                db.updatePhotoTags(photoId, tagIds);
                db.setPhotoDefaultTaxExcluded(photoId, photo.defaultTaxExcluded);
                db.recordStoreImportPhoto(historyId, photoId, managed, managed ? importedUri.toString() : null);
                photoIds.put(photo.token, photoId);
            }

            for (StorePackageManager.ProductData product : source.products) {
                Long photoId = photoIds.get(product.photoToken);
                if (photoId == null) {
                    photoId = db.createVirtualImportPhoto(target.id, null, product.createdAt, product.sourceImage);
                    db.recordStoreImportPhoto(historyId, photoId, false, null);
                    photoIds.put(product.photoToken == null ? ("missing_" + photoId) : product.photoToken, photoId);
                }
                List<Long> tagIds = ensureTagsByName(product.tags);
                Long primaryTag = tagIds.isEmpty() ? null : tagIds.get(0);
                long productId = db.insertImportedProductAt(photoId, target.id, primaryTag, product.name, product.productKey,
                        product.priceYen, product.volume, product.priceType, product.sourceImage, product.createdAt, product.manualEntry);
                if (productId < 0) throw new IllegalStateException("商品を登録できません");
                db.updateProductsTags(Collections.singletonList(productId), tagIds);
                db.recordStoreImportProduct(historyId, productId);
                importedProducts++;
            }
            db.updateStoreImportCounts(historyId, importedProducts, importedImages);
            DiagLog.write(this, "STORE_IMPORT_OK history=" + historyId + " mode=" + choice.mode + " target=" + target.id +
                    " key=" + target.storeKey + " products=" + importedProducts + " images=" + importedImages);
            return new int[]{importedProducts, importedImages};
        } catch (Exception e) {
            DatabaseHelper.StoreImportPurgeResult purge = db.purgeStoreImport(historyId);
            for (String uri : purge.managedUris) {
                try { getContentResolver().delete(Uri.parse(uri), null, null); } catch (Exception ignored) { }
            }
            throw e;
        }
    }

    private List<Long> ensureTagsByName(List<String> names) {
        ArrayList<Long> ids = new ArrayList<>();
        if (names == null) return ids;
        for (String name : names) {
            if (name == null || name.trim().isEmpty()) continue;
            Long id = db.ensureTag(name);
            if (id != null && !ids.contains(id)) ids.add(id);
        }
        return ids;
    }

    private Uri importPackageImage(File packageFile, String entryName, String sourceName, DatabaseHelper.Store store) {
        Uri dest = null;
        try {
            String ext = ".jpg";
            String nameForExt = sourceName == null || sourceName.trim().isEmpty() ? entryName : sourceName;
            int dot = nameForExt == null ? -1 : nameForExt.lastIndexOf('.');
            if (dot >= 0 && dot < nameForExt.length() - 1) {
                String candidate = nameForExt.substring(dot).toLowerCase(Locale.ROOT);
                if (candidate.matches("\\.[a-z0-9]{1,6}")) ext = candidate;
            }
            String display = "PriceRec_Import_" + System.currentTimeMillis() + "_" + Math.abs(UUID.randomUUID().hashCode()) + ext;
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, display);
            values.put(MediaStore.Images.Media.MIME_TYPE, mimeForImageExtension(ext));
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PriceRec/" + safeFolder(store.name));
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            dest = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (dest == null) throw new IllegalStateException("MediaStore insert returned null");
            try (OutputStream out = getContentResolver().openOutputStream(dest, "w")) {
                if (out == null) throw new IllegalStateException("MediaStore output stream null");
                StorePackageManager.copyEntry(packageFile, entryName, out);
                out.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(dest, done, null, null);
            return dest;
        } catch (Exception e) {
            if (dest != null) {
                try { getContentResolver().delete(dest, null, null); } catch (Exception ignored) { }
            }
            DiagLog.write(this, "STORE_IMPORT_IMAGE_ERROR entry=" + entryName + " err=" + e);
            return null;
        }
    }

    private String mimeForImageExtension(String ext) {
        String e = ext == null ? "" : ext.toLowerCase(Locale.ROOT);
        if (".png".equals(e)) return "image/png";
        if (".webp".equals(e)) return "image/webp";
        if (".gif".equals(e)) return "image/gif";
        if (".heic".equals(e) || ".heif".equals(e)) return "image/heic";
        if (".avif".equals(e)) return "image/avif";
        return "image/jpeg";
    }

    private void showStoreImportHistoryDialog() {
        List<DatabaseHelper.StoreImportHistory> history = db.listStoreImportHistory();

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));

        ScrollView scroll = newAutoFadeScrollView();
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows);
        int historyHeight = history.isEmpty() ? dp(150)
                : Math.min(dp(520), getResources().getDisplayMetrics().heightPixels * 65 / 100);
        content.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, historyHeight));

        final AlertDialog[] holder = {null};
        if (history.isEmpty()) {
            TextView empty = text("店舗のインポート履歴はありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(28), dp(8), dp(28));
            rows.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            for (int i = 0; i < history.size(); i++) {
                DatabaseHelper.StoreImportHistory item = history.get(i);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(12), dp(9), dp(12), dp(9));
                row.setBackground(roundRect(DGRAY, 14));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                if (i > 0) lp.topMargin = dp(UI_SPACING_DP);
                rows.addView(row, lp);

                TextView title = text(item.targetStoreName + (item.purged ? "　[パージ済]" : ""),
                        15, item.purged ? SECONDARY : WHITE, true);
                row.addView(title);
                TextView date = text(dateFormat.format(new Date(item.importedAt)) + "　" + item.modeLabel(),
                        12, SECONDARY, false);
                row.addView(date);
                TextView count = text("CSV " + item.csvCount + "ファイル / " + item.productCount +
                        "商品　画像 " + item.imageCount + "枚", 12, SECONDARY, false);
                row.addView(count);

                TextView memo = text("MEMO:" + (item.memo.trim().isEmpty() ? "" : " " + item.memo),
                        13, WHITE, false);
                memo.setMaxLines(1);
                memo.setEllipsize(android.text.TextUtils.TruncateAt.END);
                row.addView(memo);

                row.setOnClickListener(v -> {
                    if (holder[0] != null) holder[0].dismiss();
                    showStoreImportHistoryDetail(item.id);
                });
            }
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        boolean hasPurged = false;
        for (DatabaseHelper.StoreImportHistory item : history) {
            if (item.purged) { hasPurged = true; break; }
        }
        TextView deletePurged = button("パージ済を削除", hasPurged ? RED : DGRAY, 13);
        setButtonEnabledStyle(deletePurged, hasPurged, RED);
        actions.addView(deletePurged, new LinearLayout.LayoutParams(dp(132), dp(38)));
        actions.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));

        TextView cancel = button("キャンセル", DGRAY, 13);
        actions.addView(cancel, new LinearLayout.LayoutParams(dp(92), dp(38)));

        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        actionsLp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        content.addView(actions, actionsLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("インポート履歴")
                .setView(content)
                .create();
        holder[0] = dialog;

        cancel.setOnClickListener(v -> dialog.cancel());
        deletePurged.setOnClickListener(v -> {
            int deleted = db.deletePurgedStoreImportHistory();
            DiagLog.write(this, "STORE_IMPORT_PURGED_HISTORY_DELETE count=" + deleted);
            if (deleted <= 0) {
                Toast.makeText(this, "パージ済の履歴はありません", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, deleted + "件のパージ済履歴を削除しました", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
            showStoreImportHistoryDialog();
        });

        showRoundedDialog(dialog, true);
    }

    private void showStoreImportHistoryDetail(long historyId) {
        DatabaseHelper.StoreImportHistory item = db.getStoreImportHistory(historyId);
        if (item == null) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        panel.addView(text(item.targetStoreName, 17, WHITE, true));
        panel.addView(text(dateFormat.format(new Date(item.importedAt)) + "　" + item.modeLabel(), 13, SECONDARY, false));
        panel.addView(text("CSV " + item.csvCount + "ファイル / " + item.productCount + "商品　画像 " + item.imageCount + "枚", 13, SECONDARY, false));
        TextView file = text(item.fileName, 12, SECONDARY, false);
        file.setMaxLines(1);
        file.setEllipsize(android.text.TextUtils.TruncateAt.END);
        panel.addView(file);

        TextView memoLabel = text("一行メモ", 12, SECONDARY, true);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = dp(UI_SPACING_DP);
        panel.addView(memoLabel, mlp);
        EditText memoInput = dialogInput("○○が作成 / 9月共有分 など");
        memoInput.setText(item.memo);
        memoInput.setSelection(memoInput.length());
        panel.addView(memoInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        if (item.purged) {
            TextView purged = text("このインポートはパージ済みです", 13, SECONDARY, true);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            plp.topMargin = dp(UI_SPACING_DP);
            panel.addView(purged, plp);
        }

        TextView purge = button(item.purged ? "パージ済" : "パージ", item.purged ? DGRAY : RED, 13);
        setButtonEnabledStyle(purge, !item.purged, RED);
        TextView cancel = button("キャンセル", DGRAY, 13);
        TextView save = button("保存", BLUE, 13);
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.addView(purge, new LinearLayout.LayoutParams(dp(92), dp(38)));
        actions.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(dp(92), dp(38));
        cancelLp.rightMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(cancel, cancelLp);
        actions.addView(save, new LinearLayout.LayoutParams(dp(92), dp(38)));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        alp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        panel.addView(actions, alp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("インポート履歴")
                .setView(panel)
                .create();
        cancel.setOnClickListener(v -> dialog.cancel());
        save.setOnClickListener(v -> {
            db.updateStoreImportMemo(item.id, memoInput.getText().toString());
            DiagLog.write(this, "STORE_IMPORT_MEMO_SAVE history=" + item.id);
            dialog.dismiss();
            showStoreImportHistoryDialog();
        });
        purge.setOnClickListener(v -> {
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("このインポートをパージ")
                    .setMessage("このインポートで追加された商品と画像だけを取り消します。\n元からあった店舗データには触れません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("パージ", (d, which) -> {
                        DatabaseHelper.StoreImportPurgeResult result = db.purgeStoreImport(item.id);
                        for (String uri : result.managedUris) {
                            try { getContentResolver().delete(Uri.parse(uri), null, null); } catch (Exception ignored) { }
                        }
                        DiagLog.write(this, "STORE_IMPORT_PURGE history=" + item.id + " products=" + result.deletedProducts +
                                " photos=" + result.deletedPhotos + " store=" + result.deletedStore);
                        dialog.dismiss();
                        reloadStores();
                        showStoreImportHistoryDialog();
                    }).create();
            showRoundedDialog(confirm);
        });
        showRoundedDialog(dialog);
    }


    private void showAppMenu() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setItems(new String[]{"全CSV一覧", "CSVインポート", "店舗をインポート", "インポート履歴", "全店舗をエクスポート", "診断ログ"}, (d, which) -> {
                    if (which == 0) showImportHistoryDialog(null);
                    else if (which == 1) startCsvImportPicker();
                    else if (which == 2) startStoreImportPicker();
                    else if (which == 3) showStoreImportHistoryDialog();
                    else if (which == 4) {
                        List<DatabaseHelper.Store> stores = db.listStores();
                        if (stores.isEmpty()) Toast.makeText(this, "エクスポートする店舗がありません", Toast.LENGTH_SHORT).show();
                        else showStoreExportDialog(stores, true);
                    } else showDiagnosticLog();
                }).create();
        showRoundedDialog(dialog);
    }

    private void startCsvImportPicker() {
        try {
            DiagLog.write(this, "CSV_PICKER_START");
            csvPicker.launch(new String[]{"text/csv", "text/comma-separated-values", "application/csv", "application/vnd.ms-excel", "text/plain"});
        } catch (Exception e) {
            DiagLog.write(this, "CSV_PICKER_ERROR " + e);
            Toast.makeText(this, "CSVファイルを選択できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void handleCsvPicked(Uri uri) {
        if (uri == null) {
            DiagLog.write(this, "CSV_PICKER_CANCEL");
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        loadCsvAndPreview(uri, "picker");
    }

    private void handleIncomingCsvIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            Uri uri = intent.getData();
            if (uri == null) return;
            intent.setAction(null);
            String type = intent.getType();
            if (looksLikeStorePackage(uri, type)) {
                DiagLog.write(this, "STORE_VIEW_INTENT uri=" + uri + " type=" + type);
                storeContainer.post(() -> handleStorePackageUris(Collections.singletonList(uri)));
            } else {
                DiagLog.write(this, "CSV_VIEW_INTENT uri=" + uri + " type=" + type);
                storeContainer.post(() -> loadCsvAndPreview(uri, "view_intent"));
            }
            return;
        }
        if (Intent.ACTION_SEND.equals(action)) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri == null && intent.getClipData() != null && intent.getClipData().getItemCount() > 0) {
                uri = intent.getClipData().getItemAt(0).getUri();
            }
            if (uri == null) {
                DiagLog.write(this, "SHARE_INTENT_REJECT reason=no_uri type=" + intent.getType());
                return;
            }
            intent.setAction(null);
            Uri finalUri = uri;
            String type = intent.getType();
            if (looksLikeStorePackage(uri, type)) {
                DiagLog.write(this, "STORE_SHARE_INTENT uri=" + uri + " type=" + type);
                storeContainer.post(() -> handleStorePackageUris(Collections.singletonList(finalUri)));
            } else {
                DiagLog.write(this, "CSV_SHARE_INTENT uri=" + uri + " type=" + type);
                storeContainer.post(() -> loadCsvAndPreview(finalUri, "share_intent"));
            }
            return;
        }
        if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if ((uris == null || uris.isEmpty()) && intent.getClipData() != null) {
                uris = new ArrayList<>();
                for (int i = 0; i < intent.getClipData().getItemCount(); i++) {
                    Uri u = intent.getClipData().getItemAt(i).getUri();
                    if (u != null) uris.add(u);
                }
            }
            if (uris == null || uris.isEmpty()) return;
            intent.setAction(null);
            String type = intent.getType();
            boolean packages = true;
            for (Uri uri : uris) {
                if (!looksLikeStorePackage(uri, type)) { packages = false; break; }
            }
            if (packages) {
                ArrayList<Uri> finalUris = new ArrayList<>(uris);
                DiagLog.write(this, "STORE_SHARE_MULTIPLE files=" + finalUris.size() + " type=" + type);
                storeContainer.post(() -> handleStorePackageUris(finalUris));
            } else if (uris.size() == 1) {
                Uri uri = uris.get(0);
                DiagLog.write(this, "CSV_SHARE_INTENT uri=" + uri + " type=" + type + " multiple=true");
                storeContainer.post(() -> loadCsvAndPreview(uri, "share_intent"));
            } else {
                DiagLog.write(this, "CSV_SHARE_MULTIPLE_REJECT count=" + uris.size());
                storeContainer.post(() -> Toast.makeText(this, "CSVは1ファイルずつ共有してください", Toast.LENGTH_LONG).show());
            }
        }
    }

    private boolean looksLikeStorePackage(Uri uri, String mimeType) {
        String name = displayNameForUri(uri).toLowerCase(Locale.ROOT);
        if (name.endsWith(".prstore")) return true;
        String type = mimeType == null ? "" : mimeType.toLowerCase(Locale.ROOT);
        return StorePackageManager.MIME.equals(type) || "application/zip".equals(type) || "application/octet-stream".equals(type);
    }

    private void loadCsvAndPreview(Uri uri, String source) {
        long started = SystemClock.elapsedRealtime();
        DiagLog.write(this, "CSV_READ_START source=" + source + " uri=" + uri);
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("openInputStream returned null");
            CsvImporter.Result parsed = CsvImporter.parse(in);
            ArrayList<ImportPreviewRow> preview = buildImportPreview(parsed.rows);
            String sourceName = displayNameForUri(uri);
            DiagLog.write(this, "CSV_READ_OK rows=" + preview.size() + " warnings=" + parsed.warnings.size() +
                    " bytes=" + parsed.byteCount + " file=" + sourceName + " ms=" + (SystemClock.elapsedRealtime() - started));
            showCsvImportPreview(uri, sourceName, preview, parsed.warnings, parsed.rawText);
        } catch (Exception e) {
            DiagLog.write(this, "CSV_READ_ERROR uri=" + uri + " ms=" + (SystemClock.elapsedRealtime() - started) + " err=" + e);
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("CSVインポート")
                    .setMessage("CSVを読み込めませんでした。\n\n" + e.getMessage())
                    .setPositiveButton("閉じる", null).create();
            showRoundedDialog(dialog);
        }
    }

    private ArrayList<ImportPreviewRow> buildImportPreview(List<CsvImporter.Row> rows) {
        ArrayList<ImportPreviewRow> out = new ArrayList<>();
        for (CsvImporter.Row row : rows) {
            ImportPreviewRow p = new ImportPreviewRow(row);
            if (row.store.isEmpty() || row.productName.isEmpty()) {
                p.status = "必須項目不足";
                p.action = ImportPreviewRow.SKIP;
            } else {
                DatabaseHelper.Store store = db.findStoreByName(row.store);
                p.resolvedProductKey = store == null
                        ? DatabaseHelper.ensureProductKeyPrefix(row.productKey, row.productName)
                        : db.resolveProductKeyForStore(store.id, row.productKey, row.productName, row.volume);
                DatabaseHelper.ProductRecord existing = store == null ? null : db.findLatestProductInStore(store.id, p.resolvedProductKey);
                p.existingProductId = existing == null ? -1L : existing.id;
                if (existing == null) {
                    p.status = "新規";
                    p.action = ImportPreviewRow.ADD;
                } else if (sameInteger(existing.priceYen, row.priceYen)) {
                    p.action = ImportPreviewRow.SKIP;
                    if (existing.referenceMissing) {
                        p.status = "参照画像更新";
                        p.refreshReference = true;
                    } else {
                        p.status = "重複";
                    }
                } else {
                    p.status = "価格変更";
                    p.action = ImportPreviewRow.UPDATE;
                }
            }
            out.add(p);
        }
        return out;
    }

    private boolean sameInteger(Integer a, Integer b) {
        return a == null ? b == null : a.equals(b);
    }

    private void showCsvImportPreview(Uri uri, String sourceName, ArrayList<ImportPreviewRow> preview, List<String> warnings, String rawCsv) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP));

        int addCount = 0, updateCount = 0, skipCount = 0;
        for (ImportPreviewRow p : preview) {
            if (ImportPreviewRow.ADD.equals(p.action)) addCount++;
            else if (ImportPreviewRow.UPDATE.equals(p.action)) updateCount++;
            else skipCount++;
        }
        TextView summary = text("全" + preview.size() + "行  /  追加" + addCount + "  更新" + updateCount + "  スキップ" + skipCount +
                (warnings.isEmpty() ? "" : "  /  注意" + warnings.size()), 13, SECONDARY, false);
        summary.setPadding(0, dp(UI_TIGHT_SPACING_DP), 0, dp(UI_SPACING_DP));
        content.addView(summary);

        if (!warnings.isEmpty()) {
            TextView warning = text(warnings.get(0) + (warnings.size() > 1 ? " ほか" + (warnings.size() - 1) + "件" : ""), 12, LRED, false);
            warning.setPadding(0, 0, 0, dp(UI_SPACING_DP));
            content.addView(warning);
        }

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        int[] widths = {240, 170, 100, 105, 100};
        sheet.addView(sheetHeader(new String[]{"商品名", "店舗", "価格", "判定", "動作"}, widths));
        for (ImportPreviewRow p : preview) sheet.addView(makeCsvPreviewRow(p, widths));

        HorizontalScrollView hsv = newAutoFadeHorizontalScrollView();
        hsv.addView(sheet);
        ScrollView vsv = newAutoFadeScrollView();
        vsv.addView(hsv);
        content.addView(vsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        TextView hint = text("動作セルをタップすると 追加 → 更新 → スキップ を切り替えられます。", 12, SECONDARY, false);
        hint.setPadding(0, dp(UI_SPACING_DP), 0, dp(UI_TIGHT_SPACING_DP));
        content.addView(hint);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("CSVインポート確認")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("インポート", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            importCsvRows(uri, sourceName, preview, rawCsv, true);
            dialog.dismiss();
        }));
        showRoundedDialog(dialog, true);
    }

    private View makeCsvPreviewRow(ImportPreviewRow p, int[] widths) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(1), 0, dp(1));
        String price = p.row.priceYen == null ? (p.row.priceRaw.isEmpty() ? "—" : p.row.priceRaw) : yen(p.row.priceYen);
        TextView product = csvCell(p.row.productName, widths[0], WHITE, false);
        TextView store = csvCell(p.row.store, widths[1], WHITE, false);
        TextView priceCell = csvCell(price, widths[2], WHITE, false);
        TextView status = csvCell(p.status, widths[3], "必須項目不足".equals(p.status) ? LRED : SECONDARY, false);
        TextView action = csvCell(p.action, widths[4], actionColor(p.action), true);
        action.setGravity(Gravity.CENTER);
        action.setBackground(roundRect(DGRAY, 8));
        action.setOnClickListener(v -> {
            p.action = nextImportAction(p.action);
            action.setText(p.action);
            action.setTextColor(actionColor(p.action));
        });
        row.addView(product); row.addView(store); row.addView(priceCell); row.addView(status); row.addView(action);
        return row;
    }

    private TextView csvCell(String value, int widthDp, int color, boolean bold) {
        TextView cell = text(value == null ? "" : value, 13, color, bold);
        cell.setGravity(Gravity.CENTER_VERTICAL);
        cell.setSingleLine(true);
        cell.setPadding(dp(8), 0, dp(8), 0);
        cell.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), dp(44)));
        return cell;
    }

    private int actionColor(String action) {
        if (ImportPreviewRow.ADD.equals(action)) return LBLUE;
        if (ImportPreviewRow.UPDATE.equals(action)) return ORANGE;
        return SECONDARY;
    }

    private String nextImportAction(String current) {
        if (ImportPreviewRow.ADD.equals(current)) return ImportPreviewRow.UPDATE;
        if (ImportPreviewRow.UPDATE.equals(current)) return ImportPreviewRow.SKIP;
        return ImportPreviewRow.ADD;
    }

    private int scoreCsvQuality(List<ImportPreviewRow> preview) {
        if (preview == null || preview.isEmpty()) return 0;
        int total = 0;
        Set<String> sourceImages = new HashSet<>();
        for (ImportPreviewRow p : preview) {
            CsvImporter.Row row = p.row;
            int score = 20; // store + product_name are validated before import
            if (row.priceYen != null) score += 25;
            if (row.productKey != null && !row.productKey.trim().isEmpty()) score += 5;
            if (row.sourceImage != null && !row.sourceImage.trim().isEmpty()) {
                score += 20;
                sourceImages.add(row.sourceImage.trim());
            }
            if (row.capturedAtRaw != null && !row.capturedAtRaw.trim().isEmpty()) score += 10;
            String priceType = row.priceType == null ? "" : row.priceType.trim();
            if (priceTaxMarker(priceType).length() > 0) score += 8;
            if (row.volume != null && !row.volume.trim().isEmpty()) score += 7;
            if (row.tag != null && !row.tag.trim().isEmpty()) score += 5;
            total += Math.min(100, score);
        }
        int average = total / Math.max(1, preview.size());
        if (!sourceImages.isEmpty()) {
            float rowsPerImage = (float) preview.size() / (float) sourceImages.size();
            if (rowsPerImage >= 10f) average += 10;
            else if (rowsPerImage >= 6f) average += 4;
            else if (rowsPerImage >= 3f) average -= 6;
            else average -= 16;
        } else {
            average -= 12;
        }
        return Math.max(0, Math.min(100, average));
    }

    private void importCsvRows(Uri uri, String sourceName, List<ImportPreviewRow> preview, String rawCsv, boolean showResultDialog) {
        long started = SystemClock.elapsedRealtime();
        int added = 0, updated = 0, refreshed = 0, skipped = 0, failed = 0;
        HashMap<String, Long> virtualPhotos = new HashMap<>();
        int qualityScore = scoreCsvQuality(preview);
        long batchId = db.createImportBatch(sourceName, uri == null ? null : uri.toString(), rawCsv, qualityScore, preview.size());
        DiagLog.write(this, "CSV_IMPORT_START uri=" + uri + " file=" + sourceName + " batch=" + batchId +
                " rows=" + preview.size() + " quality=" + qualityScore);
        for (ImportPreviewRow p : preview) {
            CsvImporter.Row row = p.row;
            if (row.store.isEmpty() || row.productName.isEmpty()) {
                skipped++;
                continue;
            }
            if (ImportPreviewRow.SKIP.equals(p.action)) {
                if (p.refreshReference && p.existingProductId > 0) {
                    try {
                        DatabaseHelper.Store store = db.findStoreByName(row.store);
                        long storeId = store == null ? -1L : store.id;
                        long newPhotoId = storeId < 0 ? -1L : resolveSourcePhotoId(row.sourceImage, storeId);
                        DatabaseHelper.Photo newPhoto = newPhotoId > 0 ? db.getPhoto(newPhotoId) : null;
                        if (newPhoto != null && !db.isVirtualImportPhoto(newPhoto)) {
                            db.restoreProductReference(p.existingProductId, newPhotoId, row.sourceImage);
                            refreshed++;
                            DiagLog.write(this, "PRODUCT_REFERENCE_RESTORED product=" + p.existingProductId +
                                    " photo=" + newPhotoId + " line=" + row.lineNumber);
                            continue;
                        }
                    } catch (Exception e) {
                        DiagLog.write(this, "PRODUCT_REFERENCE_RESTORE_ERROR product=" + p.existingProductId +
                                " line=" + row.lineNumber + " err=" + e);
                    }
                }
                skipped++;
                continue;
            }
            try {
                long storeId = db.ensureStore(row.store);
                if (storeId < 0) throw new IllegalStateException("店舗を作成できません: " + row.store);
                if (!db.isStoreEnabled(storeId)) {
                    throw new IllegalStateException("NトグルOFFのカードにはCSVを取り込めません: " + row.store);
                }
                Long tagId = db.ensureTag(row.tag);
                long photoId = resolveImportPhoto(row, storeId, tagId, virtualPhotos);
                String resolvedProductKey = db.resolveProductKeyForStore(storeId, row.productKey, row.productName, row.volume);
                if (!resolvedProductKey.equals(DatabaseHelper.ensureProductKeyPrefix(row.productKey, row.productName))) {
                    DiagLog.write(this, "PRODUCT_KEY_COLLISION line=" + row.lineNumber + " base=" + row.productKey + " resolved=" + resolvedProductKey);
                }
                if (ImportPreviewRow.UPDATE.equals(p.action)) {
                    DatabaseHelper.ProductRecord existing = db.findLatestProductInStore(storeId, resolvedProductKey);
                    if (existing != null) {
                        db.recordImportUpdated(batchId, existing);
                        db.updateImportedProduct(existing.id, photoId, storeId, tagId, row.productName, resolvedProductKey, row.priceYen,
                                row.volume, row.priceType, row.sourceImage);
                        db.updateImportSnapshot(batchId, existing.id);
                        updated++;
                    } else {
                        long productId = db.insertImportedProduct(photoId, storeId, tagId, row.productName, resolvedProductKey, row.priceYen,
                                row.volume, row.priceType, row.sourceImage);
                        if (productId < 0) throw new IllegalStateException("商品を追加できません");
                        db.recordImportAdded(batchId, productId, storeId, row.store);
                        added++;
                    }
                } else {
                    long productId = db.insertImportedProduct(photoId, storeId, tagId, row.productName, resolvedProductKey, row.priceYen,
                            row.volume, row.priceType, row.sourceImage);
                    if (productId < 0) throw new IllegalStateException("商品を追加できません");
                    db.recordImportAdded(batchId, productId, storeId, row.store);
                    added++;
                }
            } catch (Exception e) {
                failed++;
                DiagLog.write(this, "CSV_IMPORT_ROW_ERROR line=" + row.lineNumber + " action=" + p.action + " batch=" + batchId + " err=" + e);
            }
        }
        db.deleteImportBatchIfEmpty(batchId);
        DiagLog.write(this, "CSV_IMPORT_OK batch=" + batchId + " added=" + added + " updated=" + updated + " reference_refreshed=" + refreshed + " skipped=" + skipped +
                " failed=" + failed + " ms=" + (SystemClock.elapsedRealtime() - started));
        reloadStores();
        if (showResultDialog) {
            AlertDialog result = new AlertDialog.Builder(this)
                    .setTitle("CSVインポート完了")
                    .setMessage("追加: " + added + "\n更新: " + updated +
                            (refreshed == 0 ? "" : "\n参照画像更新: " + refreshed) + "\nスキップ: " + skipped +
                            (failed == 0 ? "" : "\n失敗: " + failed) +
                            ((added + updated) > 0 ? "\n\nこの取込は「全CSV一覧」または店舗の「CSV一覧」から後で取り消せます。" : ""))
                    .setPositiveButton("閉じる", null).create();
            showRoundedDialog(result);
        }
    }

    private String displayNameForUri(Uri uri) {
        if (uri == null) return "CSV";
        try (android.database.Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) {
                String name = c.getString(0);
                if (name != null && !name.trim().isEmpty()) return name.trim();
            }
        } catch (Exception ignored) { }
        String last = uri.getLastPathSegment();
        return last == null || last.trim().isEmpty() ? "CSV" : last;
    }

    private long resolveImportPhoto(CsvImporter.Row row, long storeId, Long tagId, Map<String, Long> virtualPhotos) {
        long mapped = resolveSourcePhotoId(row.sourceImage, storeId);
        if (mapped > 0) return mapped;
        String key = storeId + "|" + (tagId == null ? "null" : tagId) + "|" + row.sourceImage + "|" + row.capturedAt;
        Long existing = virtualPhotos.get(key);
        if (existing != null) return existing;
        long id = db.createVirtualImportPhoto(storeId, tagId, row.capturedAt, row.sourceImage);
        if (id < 0) throw new IllegalStateException("CSV用データ行を作成できません");
        virtualPhotos.put(key, id);
        return id;
    }

    private long resolveSourcePhotoId(String sourceImage, long storeId) {
        if (sourceImage == null) return -1L;
        String source = sourceImage.trim().toLowerCase(Locale.ROOT);
        long photoId = -1L;
        try {
            if (source.matches("photo_[0-9]+")) {
                photoId = Long.parseLong(source.substring("photo_".length()));
            } else if (source.matches("image_[0-9]+")) {
                int index = Integer.parseInt(source.substring("image_".length()));
                photoId = getPreferences(MODE_PRIVATE).getLong("last_share_image_" + index, -1L);
            }
        } catch (Exception ignored) { }
        if (photoId <= 0) return -1L;
        DatabaseHelper.Photo photo = db.getPhoto(photoId);
        if (photo == null || photo.storeId != storeId) return -1L;
        return photoId;
    }

    private void showAllList() {
        showProductTableDialog("全商品リスト", null, "");
    }

    private void showProductTableDialog(String title, Long fixedStoreId, String initialQuery) {
        showProductTableDialog(title, fixedStoreId, null, initialQuery, false);
    }

    private void showProductTableDialog(String title, Long fixedStoreId, Long fixedPhotoId, String initialQuery) {
        showProductTableDialog(title, fixedStoreId, fixedPhotoId, initialQuery, false);
    }

    private void showManualProductListDialog(DatabaseHelper.Store store) {
        if (store == null) return;
        showProductTableDialog(store.name + " / 手入力商品リスト", store.id, null, "", true);
    }

    private void showProductTableDialog(String title, Long fixedStoreId, Long fixedPhotoId, String initialQuery, boolean manualOnly) {
        final Set<Long> selected = new HashSet<>();
        final boolean[] selecting = {false};
        // Empty store filter means the default "全カード" state.
        final Set<Long> storeFilters = new HashSet<>();
        // Empty tag filter means all tags. -1 represents "タグなし" and can coexist with tag ids.
        final Set<Long> tagFilters = new HashSet<>();
        final String[] query = {initialQuery == null ? "" : initialQuery.trim()};
        final String selectionScope = fixedPhotoId == null ? "list" : ("photo:" + fixedPhotoId);
        final boolean readOnly = fixedStoreId != null && !db.isStoreEnabled(fixedStoreId);
        final boolean allowManualAdd = fixedPhotoId == null && !"検索".equals(title);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP));

        if (fixedPhotoId == null && !manualOnly) {
            LinearLayout topActions = new LinearLayout(this);
            topActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            TextView history = makeDialogAction(fixedStoreId == null ? "全CSV一覧" : "CSV一覧");
            history.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            history.setOnClickListener(v -> {
                DiagLog.write(this, "CSV_HISTORY_OPEN_FROM_LIST scope=" + (fixedStoreId == null ? "all" : ("store:" + fixedStoreId)));
                showImportHistoryDialog(fixedStoreId);
            });
            topActions.addView(history, new LinearLayout.LayoutParams(dp(fixedStoreId == null ? 112 : 96), dp(42)));
            panel.addView(topActions);
        }

        Runnable filterChanged = () -> {
            selected.clear();
            selecting[0] = false;
            Object tag = panel.getTag();
            if (tag instanceof Runnable) ((Runnable) tag).run();
        };

        // 全商品リストだけ店舗選択を表示。店舗別商品リストは店舗が固定なので店舗選択欄を持たない。
        if (fixedStoreId == null) {
            View storeFilterArea = makeStoreFilterArea(storeFilters, filterChanged);
            LinearLayout.LayoutParams storeFilterLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
            storeFilterLp.bottomMargin = dp(UI_TIGHT_SPACING_DP);
            panel.addView(storeFilterArea, storeFilterLp);
        }

        // 店舗カードと同じチップ式タグUI。リスト側には＋アイコンを付けない。
        View tagFilterArea = makeProductTagFilterArea(tagFilters, filterChanged);
        LinearLayout.LayoutParams tagFilterLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        tagFilterLp.bottomMargin = dp(UI_SPACING_DP);
        panel.addView(tagFilterArea, tagFilterLp);

        EditText q = dialogInput("商品名検索");
        q.setText(query[0]);
        q.setTextSize(15);
        panel.addView(productSearchInputHolder(q), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        // Keep this slot at a fixed height so entering/exiting selection never shifts the list.
        LinearLayout selectionHost = new LinearLayout(this);
        selectionHost.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams selectionHostLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        selectionHostLp.topMargin = dp(UI_SPACING_DP);
        panel.addView(selectionHost, selectionHostLp);

        LinearLayout listHost = new LinearLayout(this);
        listHost.setOrientation(LinearLayout.VERTICAL);
        int listHeight = fixedStoreId == null ? 420 : 452;
        LinearLayout.LayoutParams hostLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(listHeight));
        panel.addView(listHost, hostLp);

        // Bottom-most dialog line: selection count stays on the same line as "閉じる".
        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(0, dp(UI_TIGHT_SPACING_DP), 0, 0);
        TextView footerSelectionCount = text("", 14, SECONDARY, true);
        footerSelectionCount.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        // Mirror the 92dp "閉じる" text-link slot from the left edge.
        footer.addView(footerSelectionCount, new LinearLayout.LayoutParams(dp(92), dp(48)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(48), 1f));
        final int footerActionWidthDp = manualOnly ? 118 : 92;
        TextView manualCsvExportAction = manualOnly ? makeDialogAction("CSVで書き出す", ORANGE, footerActionWidthDp) : null;
        if (manualCsvExportAction != null) {
            manualCsvExportAction.setGravity(Gravity.CENTER);
            setDialogActionEnabled(manualCsvExportAction, false);
            LinearLayout.LayoutParams exportLp = new LinearLayout.LayoutParams(dp(footerActionWidthDp), dp(48));
            exportLp.rightMargin = dp(UI_ACTION_GAP_DP);
            footer.addView(manualCsvExportAction, exportLp);
        }
        TextView closeAction = manualOnly
                ? makeDialogAction("閉じる", LBLUE, footerActionWidthDp)
                : makeDialogAction("閉じる");
        closeAction.setGravity(manualOnly ? Gravity.CENTER : (Gravity.END | Gravity.CENTER_VERTICAL));
        footer.addView(closeAction, new LinearLayout.LayoutParams(dp(footerActionWidthDp), dp(48)));
        panel.addView(footer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        final ScrollView[] verticalScroll = {null};
        final HorizontalScrollView[] horizontalScroll = {null};
        final Map<Long, LinearLayout> visibleProductRows = new HashMap<>();
        final Runnable[] refreshVisibleSelection = new Runnable[1];
        final Runnable[] renderSelectionControls = new Runnable[1];
        final Runnable[] render = new Runnable[1];

        refreshVisibleSelection[0] = () -> {
            for (Map.Entry<Long, LinearLayout> entry : visibleProductRows.entrySet()) {
                entry.getValue().setBackgroundColor(selecting[0] && selected.contains(entry.getKey())
                        ? BLUE : Color.TRANSPARENT);
            }
        };

        renderSelectionControls[0] = () -> {
            selectionHost.removeAllViews();
            selectionHost.setPadding(0, 0, 0, dp(UI_TIGHT_SPACING_DP));
            footerSelectionCount.setText(selecting[0] ? (selected.size() + "件選択") : "");
            footerSelectionCount.setVisibility(selecting[0] ? View.VISIBLE : View.INVISIBLE);
            if (manualCsvExportAction != null) {
                setDialogActionEnabled(manualCsvExportAction, selecting[0] && !selected.isEmpty());
            }
            if (readOnly) {
                selectionHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                TextView mode = text("閲覧モード", 13, SECONDARY, true);
                mode.setGravity(Gravity.CENTER);
                mode.setBackground(roundRect(DGRAY, 999));
                selectionHost.addView(mode, new LinearLayout.LayoutParams(dp(96), dp(38)));
            } else if (!selecting[0]) {
                selectionHost.setGravity(Gravity.CENTER_VERTICAL);

                if (allowManualAdd) {
                    ImageView addManual = makeManualProductAddIcon(fixedStoreId, () -> {
                        render[0].run();
                        reloadStores();
                    });
                    selectionHost.addView(addManual, new LinearLayout.LayoutParams(dp(38), dp(38)));
                    selectionHost.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
                } else {
                    selectionHost.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
                }

                TextView selectAll = button("全て選択", DGRAY, 13);
                selectAll.setOnClickListener(v -> {
                    if (visibleProductRows.isEmpty()) {
                        Toast.makeText(this, "選択する商品がありません", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    selecting[0] = true;
                    selected.clear();
                    selected.addAll(visibleProductRows.keySet());
                    DiagLog.write(this, "PRODUCT_SELECT_ALL scope=" + selectionScope + " count=" + selected.size() + " source=button_bar");
                    renderSelectionControls[0].run();
                });
                LinearLayout.LayoutParams allLp = new LinearLayout.LayoutParams(dp(96), dp(38));
                allLp.rightMargin = dp(UI_ACTION_GAP_DP);
                selectionHost.addView(selectAll, allLp);

                TextView select = button("選択", BLUE, 13);
                select.setOnClickListener(v -> {
                    selecting[0] = true;
                    selected.clear();
                    DiagLog.write(this, "PRODUCT_SELECT_START scope=" + selectionScope + " source=button_bar");
                    renderSelectionControls[0].run();
                });
                selectionHost.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
            } else {
                selectionHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);

                TextView delete = button("削除", selected.isEmpty() ? DGRAY : RED, 13);
                setButtonEnabledStyle(delete, !selected.isEmpty(), RED);
                delete.setOnClickListener(v -> {
                    if (!selected.isEmpty()) {
                        confirmDeleteProducts(new ArrayList<>(selected), () -> {
                            selected.clear();
                            selecting[0] = false;
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(72), dp(38));
                delLp.rightMargin = dp(6);
                selectionHost.addView(delete, delLp);

                TextView same = button("同一商品", selected.size() < 2 ? DGRAY : ORANGE, 13);
                setButtonEnabledStyle(same, selected.size() >= 2, ORANGE);
                same.setOnClickListener(v -> {
                    if (selected.size() >= 2) {
                        showUnifyProductsDialog(new ArrayList<>(selected), () -> {
                            selected.clear();
                            selecting[0] = false;
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                LinearLayout.LayoutParams sameLp = new LinearLayout.LayoutParams(dp(92), dp(38));
                sameLp.leftMargin = dp(6);
                selectionHost.addView(same, sameLp);

                TextView cancel = button("キャンセル", DGRAY, 13);
                cancel.setOnClickListener(v -> {
                    selected.clear();
                    selecting[0] = false;
                    renderSelectionControls[0].run();
                });
                LinearLayout.LayoutParams canLp = new LinearLayout.LayoutParams(dp(88), dp(38));
                canLp.leftMargin = dp(6);
                selectionHost.addView(cancel, canLp);

                TextView move = button("タグ編集", selected.isEmpty() ? DGRAY : BLUE, 13);
                setButtonEnabledStyle(move, !selected.isEmpty(), BLUE);
                move.setOnClickListener(v -> {
                    if (!selected.isEmpty()) {
                        showMoveProductsTagDialog(new ArrayList<>(selected), () -> {
                            selected.clear();
                            selecting[0] = false;
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                LinearLayout.LayoutParams moveLp = new LinearLayout.LayoutParams(dp(96), dp(38));
                moveLp.leftMargin = dp(6);
                selectionHost.addView(move, moveLp);
            }
            refreshVisibleSelection[0].run();
        };

        render[0] = () -> {
            final int keepY = verticalScroll[0] == null ? 0 : verticalScroll[0].getScrollY();
            final int keepX = horizontalScroll[0] == null ? 0 : horizontalScroll[0].getScrollX();

            renderSelectionControls[0].run();

            listHost.removeAllViews();
            visibleProductRows.clear();
            ArrayList<DatabaseHelper.ProductRecord> products = new ArrayList<>();
            String normalizedQuery = query[0] == null ? "" : query[0].trim().toLowerCase(Locale.ROOT);
            List<DatabaseHelper.ProductRecord> baseProducts = fixedStoreId == null
                    ? db.listAllProducts() : db.listProductsForStore(fixedStoreId);
            for (DatabaseHelper.ProductRecord p : baseProducts) {
                if (manualOnly && !p.manualEntry) continue;
                if (fixedPhotoId != null && p.photoId != fixedPhotoId) continue;
                if (fixedStoreId == null && !storeFilters.isEmpty() && !storeFilters.contains(p.storeId)) continue;

                if (!tagFilters.isEmpty()) {
                    boolean tagMatch = false;
                    if (tagFilters.contains(-1L) && p.tagIds.isEmpty() && p.tagId == null) tagMatch = true;
                    if (!tagMatch) {
                        for (Long tagId : tagFilters) {
                            if (tagId != null && tagId >= 0 && p.hasTag(tagId)) {
                                tagMatch = true;
                                break;
                            }
                        }
                    }
                    if (!tagMatch) continue;
                }

                if (!normalizedQuery.isEmpty()) {
                    String hay = ((p.rawName == null ? "" : p.rawName) + " " +
                            (p.productKey == null ? "" : p.productKey) + " " +
                            (p.storeName == null ? "" : p.storeName) + " " +
                            p.tagDisplay()).toLowerCase(Locale.ROOT);
                    if (!hay.contains(normalizedQuery)) continue;
                }
                products.add(p);
            }

            if (products.isEmpty()) {
                String emptyMessage = manualOnly ? "手入力商品はまだありません。"
                        : (fixedPhotoId == null ? "条件に一致する商品がありません。" : "この画像から登録された商品はありません。");
                TextView empty = text(emptyMessage, 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(dp(16), dp(28), dp(16), dp(28));
                listHost.addView(empty, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                verticalScroll[0] = null;
                horizontalScroll[0] = null;
                return;
            }

            LinearLayout sheet = new LinearLayout(this);
            sheet.setOrientation(LinearLayout.VERTICAL);
            boolean storeWholeList = fixedStoreId != null;
            ArrayList<String> columnOrder = loadProductColumnOrder(storeWholeList);
            sheet.addView(makeReorderableProductHeader(columnOrder, storeWholeList, render[0]));
            String last = null;
            for (DatabaseHelper.ProductRecord p : products) {
                String key = p.normalizedName == null ? p.rawName : p.normalizedName;
                String productCell = key != null && key.equals(last) ? "" : p.rawName;
                last = key;
                LinearLayout row = makeProductDataRow(columnOrder, p, productCell, render[0]);
                visibleProductRows.put(p.id, row);
                View compareIcon = row.findViewWithTag("product_compare_icon");
                if (compareIcon != null) {
                    compareIcon.setOnClickListener(v -> {
                        if (selecting[0]) {
                            boolean wasSelected = selected.remove(p.id);
                            if (!wasSelected) selected.add(p.id);
                            DiagLog.write(this, "PRODUCT_SELECT_TOGGLE scope=" + selectionScope + " product=" + p.id +
                                    " selected=" + selected.contains(p.id) + " count=" + selected.size());
                            if (wasSelected && selected.isEmpty()) {
                                selecting[0] = false;
                                DiagLog.write(this, "PRODUCT_SELECT_END_EMPTY scope=" + selectionScope + " source=compare");
                            }
                            renderSelectionControls[0].run();
                        } else {
                            showSameProductPrices(p.productKey == null ? p.rawName : p.productKey);
                        }
                    });
                }
                if (selecting[0] && selected.contains(p.id)) row.setBackgroundColor(BLUE);
                row.setOnClickListener(v -> {
                    if (selecting[0]) {
                        boolean wasSelected = selected.remove(p.id);
                        if (!wasSelected) selected.add(p.id);
                        DiagLog.write(this, "PRODUCT_SELECT_TOGGLE scope=" + selectionScope + " product=" + p.id +
                                " selected=" + selected.contains(p.id) + " count=" + selected.size());
                        if (wasSelected && selected.isEmpty()) {
                            selecting[0] = false;
                            DiagLog.write(this, "PRODUCT_SELECT_END_EMPTY scope=" + selectionScope + " source=row");
                        }
                        renderSelectionControls[0].run();
                    } else if (!readOnly) {
                        DatabaseHelper.ProductRecord fresh = db.getProduct(p.id);
                        showProductEditor(fresh == null ? p : fresh, () -> {
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                row.setOnLongClickListener(v -> {
                    if (readOnly) return true;
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    if (!selecting[0]) {
                        selecting[0] = true;
                        selected.clear();
                        selected.add(p.id);
                        DiagLog.write(this, "PRODUCT_SELECT_START scope=" + selectionScope + " product=" + p.id + " source=long_press");
                    } else {
                        boolean wasSelected = selected.remove(p.id);
                        if (!wasSelected) selected.add(p.id);
                        if (wasSelected && selected.isEmpty()) {
                            selecting[0] = false;
                            DiagLog.write(this, "PRODUCT_SELECT_END_EMPTY scope=" + selectionScope + " source=long_press");
                        }
                    }
                    renderSelectionControls[0].run();
                    return true;
                });
                sheet.addView(row);
            }

            HorizontalScrollView hsv = newAutoFadeHorizontalScrollView();
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.addView(sheet);
            ScrollView vsv = newAutoFadeScrollView();
            vsv.addView(hsv);
            horizontalScroll[0] = hsv;
            verticalScroll[0] = vsv;
            listHost.addView(withFastScroll(vsv), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            refreshVisibleSelection[0].run();
            vsv.post(() -> {
                vsv.scrollTo(0, keepY);
                hsv.scrollTo(keepX, 0);
            });
        };

        panel.setTag(render[0]);

        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                query[0] = s == null ? "" : s.toString();
                selected.clear();
                selecting[0] = false;
                render[0].run();
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        render[0].run();
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(panel)
                .create();
        if (manualCsvExportAction != null) {
            manualCsvExportAction.setOnClickListener(v -> {
                if (!manualCsvExportAction.isEnabled() || selected.isEmpty() || fixedStoreId == null) return;
                exportSelectedManualProductsCsv(fixedStoreId, new HashSet<>(selected));
            });
        }
        closeAction.setOnClickListener(v -> dialog.dismiss());
        showRoundedDialog(dialog, true);
    }

    private void exportSelectedManualProductsCsv(long storeId, Set<Long> selectedIds) {
        if (selectedIds == null || selectedIds.isEmpty()) return;
        ArrayList<DatabaseHelper.ProductRecord> rows = new ArrayList<>();
        for (DatabaseHelper.ProductRecord p : db.listManualProductsForStore(storeId)) {
            if (p != null && selectedIds.contains(p.id)) rows.add(p);
        }
        if (rows.isEmpty()) {
            Toast.makeText(this, "書き出す商品がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        File dir = new File(getCacheDir(), "manual_csv");
        if (!dir.exists() && !dir.mkdirs()) {
            Toast.makeText(this, "CSVの準備に失敗しました", Toast.LENGTH_LONG).show();
            return;
        }
        File out = new File(dir, "PriceRec_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.JAPAN).format(new Date()) + ".csv");
        try (OutputStream stream = new java.io.FileOutputStream(out);
             java.io.OutputStreamWriter writer = new java.io.OutputStreamWriter(stream, StandardCharsets.UTF_8)) {
            writer.write("store,tag,product_name,product_key,price,volume,price_type,captured_at,source_image\n");
            SimpleDateFormat csvDate = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);
            for (DatabaseHelper.ProductRecord p : rows) {
                long at = p.photoCreatedAt > 0 ? p.photoCreatedAt : p.createdAt;
                writer.write(csvCell(p.storeName));
                writer.write(',');
                writer.write(csvCell(p.tagDisplay()));
                writer.write(',');
                writer.write(csvCell(p.rawName));
                writer.write(',');
                writer.write(csvCell(p.productKey));
                writer.write(',');
                writer.write(csvCell(p.priceYen == null ? "" : String.valueOf(p.priceYen)));
                writer.write(',');
                writer.write(csvCell(normalizeVolumeForStorage(p.volume)));
                writer.write(',');
                writer.write(csvCell(p.priceType));
                writer.write(',');
                writer.write(csvCell(at > 0 ? csvDate.format(new Date(at)) : ""));
                writer.write(',');
                writer.write("");
                writer.write('\n');
            }
            writer.flush();
            if (pendingManualCsvFile != null && pendingManualCsvFile.exists()) pendingManualCsvFile.delete();
            pendingManualCsvFile = out;
            DiagLog.write(this, "MANUAL_CSV_EXPORT_READY store=" + storeId + " count=" + rows.size() +
                    " file=" + out.getName() + " bytes=" + out.length());
            manualCsvSaveLauncher.launch(out.getName());
        } catch (Exception e) {
            DiagLog.write(this, "MANUAL_CSV_EXPORT_ERROR store=" + storeId + " count=" + rows.size() + " err=" + e);
            Toast.makeText(this, "CSVの書き出し準備に失敗しました", Toast.LENGTH_LONG).show();
        }
    }

    private String csvCell(String value) {
        String valueOrEmpty = value == null ? "" : value;
        if (valueOrEmpty.indexOf(',') >= 0 || valueOrEmpty.indexOf('"') >= 0 ||
                valueOrEmpty.indexOf('\n') >= 0 || valueOrEmpty.indexOf('\r') >= 0) {
            return "\"" + valueOrEmpty.replace("\"", "\"\"") + "\"";
        }
        return valueOrEmpty;
    }

    private void handleManualCsvSaveUri(Uri uri) {
        File source = pendingManualCsvFile;
        pendingManualCsvFile = null;
        if (uri == null) {
            if (source != null) source.delete();
            DiagLog.write(this, "MANUAL_CSV_EXPORT_CANCEL");
            return;
        }
        if (source == null || !source.exists()) {
            DiagLog.write(this, "MANUAL_CSV_EXPORT_SAVE_ERROR reason=source_missing uri=" + uri);
            Toast.makeText(this, "保存元CSVが見つかりません", Toast.LENGTH_LONG).show();
            return;
        }
        try (FileInputStream in = new FileInputStream(source);
             OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
            if (out == null) throw new IllegalStateException("openOutputStream returned null");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) if (n > 0) out.write(buf, 0, n);
            out.flush();
            DiagLog.write(this, "MANUAL_CSV_EXPORT_SAVE_OK uri=" + uri + " bytes=" + source.length());
            Toast.makeText(this, "CSVを書き出しました", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            DiagLog.write(this, "MANUAL_CSV_EXPORT_SAVE_ERROR uri=" + uri + " err=" + e);
            Toast.makeText(this, "CSVを書き出せませんでした", Toast.LENGTH_LONG).show();
        } finally {
            source.delete();
        }
    }

    private String storeNameForId(long storeId) {
        DatabaseHelper.Store s = db.getStore(storeId);
        return s == null ? "不明" : s.name;
    }

    private void showImportHistoryDialog(Long storeId) {
        DiagLog.write(this, "CSV_HISTORY_OPEN scope=" + (storeId == null ? "all" : ("store:" + storeId)));
        final boolean storeReadOnly = storeId != null && !db.isStoreEnabled(storeId);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP),
                dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));

        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = newAutoFadeScrollView();
        scroll.addView(rows);
        content.addView(withFastScroll(scroll), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(470)));

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            rows.removeAllViews();
            List<DatabaseHelper.ImportBatch> batches = db.listImportBatches(storeId);
            if (batches.isEmpty()) {
                TextView empty = text("CSV取込はまだありません。", 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(dp(12), dp(30), dp(12), dp(30));
                rows.addView(empty);
                return;
            }
            for (DatabaseHelper.ImportBatch batch : batches) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(UI_CARD_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_CARD_MARGIN_DP), dp(UI_SPACING_DP));
                card.setBackground(roundRect(DGRAY, 14));

                TextView date = text(dateFormat.format(new Date(batch.importedAt)), 14, WHITE, true);
                card.addView(date, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26)));

                TextView file = text(batch.fileName, 13, SECONDARY, false);
                file.setSingleLine(true);
                card.addView(file, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

                String stores = batch.storeNames == null || batch.storeNames.trim().isEmpty() ? "" : "  /  " + batch.storeNames;
                TextView meta = text(batch.qualityLabel() + "  " + batch.displayCount() + "件（追加" + batch.addCount + " / 更新" + batch.updateCount + "）" + stores,
                        12, SECONDARY, false);
                card.addView(meta, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

                card.setOnClickListener(v -> showImportBatchContents(batch));

                boolean batchReadOnly = storeReadOnly || db.importBatchHasDisabledStore(batch.id);
                LinearLayout batchActions = new LinearLayout(this);
                batchActions.setGravity(Gravity.CENTER_VERTICAL);
                if (batchReadOnly) {
                    TextView mode = text("閲覧モード", 13, SECONDARY, true);
                    mode.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                    batchActions.addView(mode, new LinearLayout.LayoutParams(0, dp(42), 1f));
                } else {
                    TextView reload = makeDialogAction("再読み込み");
                    reload.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                    reload.setOnClickListener(v -> confirmReloadImportBatch(batch, () -> {
                        reloadStores();
                        render[0].run();
                    }));
                    batchActions.addView(reload, new LinearLayout.LayoutParams(0, dp(42), 1f));

                    TextView undo = makeDialogAction("CSVを削除", RED);
                    undo.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                    undo.setOnClickListener(v -> {
                        AlertDialog confirm = new AlertDialog.Builder(this)
                                .setTitle("CSV消去")
                                .setMessage(dateFormat.format(new Date(batch.importedAt)) + "\n" + batch.fileName +
                                        "\n\nこのCSVで追加した商品は削除し、更新した商品は取込前の状態へ戻します。" +
                                        "\n店舗・タグ・元画像は削除しません。")
                                .setNegativeButton("キャンセル", null)
                                .setPositiveButton("消去", (d, which) -> {
                                    DatabaseHelper.RollbackResult result = db.rollbackImportBatch(batch.id);
                                    DiagLog.write(this, "CSV_BATCH_ROLLBACK batch=" + batch.id +
                                            " deleted=" + result.deleted + " restored=" + result.restored + " missing=" + result.missing);
                                    Toast.makeText(this, "削除 " + result.deleted + " / 復元 " + result.restored +
                                            (result.missing == 0 ? "" : " / 対象なし " + result.missing), Toast.LENGTH_LONG).show();
                                    reloadStores();
                                    render[0].run();
                                })
                                .create();
                        showRoundedDialog(confirm);
                    });
                    batchActions.addView(undo, new LinearLayout.LayoutParams(dp(132), dp(42)));
                }
                card.addView(batchActions, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.bottomMargin = dp(8);
                rows.addView(card, lp);
            }
        };

        TextView closeAction = makeDialogAction("閉じる");
        LinearLayout footer = makeRightDialogFooter(closeAction);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        footerLp.topMargin = dp(UI_SPACING_DP);
        content.addView(footer, footerLp);

        render[0].run();
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(storeId == null ? "全CSV一覧" : storeNameForId(storeId) + " CSV一覧")
                .setView(content)
                .create();
        closeAction.setOnClickListener(v -> dialog.dismiss());
        showRoundedDialog(dialog, true);
    }

    private void confirmReloadImportBatch(DatabaseHelper.ImportBatch batch, Runnable afterReload) {
        if (batch == null) return;
        AlertDialog confirm = new AlertDialog.Builder(this)
                .setTitle("CSV再読み込み")
                .setMessage("編集したデータは削除されます。\n\n" + batch.fileName + " を元のCSV内容で再読み込みしますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("再読み込み", (d, which) -> reloadImportBatch(batch, afterReload))
                .create();
        showRoundedDialog(confirm);
    }

    private void reloadImportBatch(DatabaseHelper.ImportBatch batch, Runnable afterReload) {
        long started = SystemClock.elapsedRealtime();
        DiagLog.write(this, "CSV_BATCH_RELOAD_START batch=" + batch.id + " file=" + batch.fileName);
        try {
            CsvImporter.Result parsed;
            Uri sourceUri = null;
            if (batch.rawCsv != null && !batch.rawCsv.isEmpty()) {
                parsed = CsvImporter.parseText(batch.rawCsv);
                if (batch.sourceUri != null && !batch.sourceUri.isEmpty()) sourceUri = Uri.parse(batch.sourceUri);
            } else if (batch.sourceUri != null && !batch.sourceUri.isEmpty()) {
                sourceUri = Uri.parse(batch.sourceUri);
                try (InputStream in = getContentResolver().openInputStream(sourceUri)) {
                    if (in == null) throw new IllegalStateException("元CSVを開けません");
                    parsed = CsvImporter.parse(in);
                }
            } else {
                throw new IllegalStateException("元CSVを保持していないため再読み込みできません");
            }

            DatabaseHelper.RollbackResult rollback = db.rollbackImportBatch(batch.id);
            DiagLog.write(this, "CSV_BATCH_RELOAD_ROLLBACK batch=" + batch.id +
                    " deleted=" + rollback.deleted + " restored=" + rollback.restored + " missing=" + rollback.missing);
            ArrayList<ImportPreviewRow> preview = buildImportPreview(parsed.rows);
            importCsvRows(sourceUri, batch.fileName, preview, parsed.rawText, false);
            DiagLog.write(this, "CSV_BATCH_RELOAD_OK oldBatch=" + batch.id +
                    " rows=" + preview.size() + " ms=" + (SystemClock.elapsedRealtime() - started));
            Toast.makeText(this, "CSVを再読み込みしました", Toast.LENGTH_LONG).show();
            if (afterReload != null) afterReload.run();
        } catch (Exception e) {
            DiagLog.write(this, "CSV_BATCH_RELOAD_ERROR batch=" + batch.id + " err=" + e);
            AlertDialog error = new AlertDialog.Builder(this)
                    .setTitle("CSV再読み込み")
                    .setMessage("再読み込みできませんでした。\n\n" + e.getMessage())
                    .setPositiveButton("閉じる", null)
                    .create();
            showRoundedDialog(error);
        }
    }

    private void showImportBatchContents(DatabaseHelper.ImportBatch batch) {
        if (batch == null) return;
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP));

        TextView meta = text(dateFormat.format(new Date(batch.importedAt)) + "  /  " + batch.qualityLabel() + "  " + batch.displayCount() + "件\n" + batch.fileName,
                12, SECONDARY, false);
        meta.setPadding(0, dp(UI_TIGHT_SPACING_DP), 0, dp(UI_SPACING_DP));
        content.addView(meta);

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        int[] widths = {90, 240, 170, 100, 90, 110, 150};
        sheet.addView(sheetHeader(new String[]{"動作", "商品名", "店舗", "価格", "容量", "タグ", "source_image"}, widths));
        List<DatabaseHelper.ImportBatchRow> rows = db.listImportBatchRows(batch.id);
        for (DatabaseHelper.ImportBatchRow row : rows) {
            sheet.addView(sheetRow(new String[]{row.actionLabel(), row.productName, row.storeName,
                    row.priceYen == null ? "—" : yen(row.priceYen), formatVolumeDisplay(row.volume),
                    row.tagName == null ? "—" : row.tagName, row.sourceImage == null ? "—" : row.sourceImage}, widths));
        }
        HorizontalScrollView hsv = newAutoFadeHorizontalScrollView();
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(sheet);
        ScrollView scroll = newAutoFadeScrollView();
        scroll.addView(hsv);
        content.addView(withFastScroll(scroll), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(500)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("CSV内容")
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        showRoundedDialog(dialog, true);
    }

    private ImageView makeManualProductAddIcon(Long initialStoreId, Runnable afterSave) {
        boolean enabled = initialStoreId == null || db.isStoreEnabled(initialStoreId);
        ImageView add = roundPlusIcon(enabled ? LBLUE : DGRAY,
                enabled ? NWHITE : LGRAY, "新規商品追加");
        add.setEnabled(enabled);
        if (enabled) add.setOnClickListener(v -> showNewManualProductDialog(initialStoreId, afterSave));
        return add;
    }

    private void showNewManualProductDialog(Long initialStoreId, Runnable afterSave) {
        final long[] selectedStore = {-1L};
        DatabaseHelper.Store initialStore = initialStoreId == null ? null : db.getStore(initialStoreId);
        if (initialStore != null && initialStore.enabled) selectedStore[0] = initialStore.id;

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP),
                dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_ACTION_BOTTOM_DP));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        panel.addView(form, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView storeButton = button(selectedStore[0] > 0 ? initialStore.name : "店舗を選択", DGRAY, 14);
        LinearLayout.LayoutParams storeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        storeLp.bottomMargin = dp(UI_SPACING_DP);
        form.addView(storeButton, storeLp);

        EditText name = dialogInput("商品名");
        addProductEditField(form, "商品名", name);

        EditText price = dialogInput("価格");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        price.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789"));
        addProductEditField(form, "価格（円）", price);

        EditText volume = dialogInput("容量");
        volume.setInputType(InputType.TYPE_CLASS_NUMBER);
        volume.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789"));
        addProductEditField(form, "容量（ml）", volume);

        EditText productKey = dialogInput("product_key（空欄で自動生成）");
        productKey.setKeyListener(android.text.method.DigitsKeyListener.getInstance(
                "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ._-"));
        addProductEditField(form, "product_key", productKey);

        final String[] selectedPriceType = {"不明"};
        TextView priceType = button(selectedPriceType[0], DGRAY, 14);
        priceType.setOnClickListener(v -> showPriceTypeChoice(selectedPriceType, priceType));
        addProductEditControl(form, "価格種別", priceType);

        final Set<Long> selectedTags = new HashSet<>();
        View tagArea = makeCommonTagSelectionArea(selectedTags, true, true, chosen -> { });
        addProductEditWrapControl(form, "タグ", tagArea);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
        TextView cancelButton = button("キャンセル", DGRAY, 13);
        TextView saveButton = button("保存", DGRAY, 13);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(dp(92), dp(38));
        actions.addView(cancelButton, cancelLp);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(dp(92), dp(38));
        saveLp.leftMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(saveButton, saveLp);
        LinearLayout.LayoutParams actionRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        actionRowLp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        panel.addView(actions, actionRowLp);

        ScrollView manualScroll = newAutoFadeScrollView();
        manualScroll.setFillViewport(false);
        manualScroll.addView(panel, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新規商品追加")
                .setView(manualScroll)
                .create();

        Runnable refreshSave = () -> {
            boolean valid = selectedStore[0] > 0
                    && !name.getText().toString().trim().isEmpty()
                    && !price.getText().toString().trim().isEmpty();
            setButtonEnabledStyle(saveButton, valid, BLUE);
        };
        TextWatcher requiredWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshSave.run(); }
            @Override public void afterTextChanged(Editable s) { }
        };
        name.addTextChangedListener(requiredWatcher);
        price.addTextChangedListener(requiredWatcher);
        storeButton.setOnClickListener(v -> showStoreChoiceForManualEditor(selectedStore, storeButton, refreshSave));
        refreshSave.run();

        cancelButton.setOnClickListener(v -> dialog.dismiss());
        saveButton.setOnClickListener(v -> {
            if (!saveButton.isEnabled()) return;
            String n = name.getText().toString().trim();
            String priceText = price.getText().toString().trim();
            if (selectedStore[0] <= 0 || db.getStore(selectedStore[0]) == null) {
                Toast.makeText(this, "店舗を選択してください", Toast.LENGTH_SHORT).show();
                refreshSave.run();
                return;
            }
            if (n.isEmpty()) { showFieldError(name, "商品名を入力"); refreshSave.run(); return; }
            if (priceText.isEmpty()) { showFieldError(price, "価格を入力"); refreshSave.run(); return; }
            Integer priceValue;
            try { priceValue = Integer.parseInt(priceText); }
            catch (NumberFormatException ex) { showFieldError(price, "整数で入力"); return; }

            long productId = db.createManualProduct(selectedStore[0], n, productKey.getText().toString(), priceValue,
                    normalizeVolumeForStorage(volume.getText().toString()), selectedPriceType[0], new ArrayList<>(selectedTags));
            if (productId < 0) {
                Toast.makeText(this, "商品を保存できませんでした", Toast.LENGTH_LONG).show();
                return;
            }
            DatabaseHelper.ProductRecord saved = db.getProduct(productId);
            DiagLog.write(this, "MANUAL_PRODUCT_ADD id=" + productId + " store=" + selectedStore[0] +
                    " key=" + (saved == null ? "" : saved.productKey));
            dialog.dismiss();
            if (afterSave != null) afterSave.run();
        });

        showRoundedDialog(dialog, true);
    }

    private void showStoreChoiceForManualEditor(long[] selectedStore, TextView button, Runnable afterChange) {
        List<DatabaseHelper.Store> allStores = db.listStores();
        ArrayList<DatabaseHelper.Store> stores = new ArrayList<>();
        for (DatabaseHelper.Store store : allStores) if (store.enabled) stores.add(store);
        if (stores.isEmpty()) {
            Toast.makeText(this, "選択できる店舗がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[stores.size()];
        for (int i = 0; i < stores.size(); i++) names[i] = stores.get(i).name;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗を選択")
                .setItems(names, (d, which) -> {
                    DatabaseHelper.Store store = stores.get(which);
                    selectedStore[0] = store.id;
                    button.setText(store.name);
                    if (afterChange != null) afterChange.run();
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private void showProductEditor(DatabaseHelper.ProductRecord product, Runnable afterSave) {
        if (product == null) return;
        if (!db.isStoreEnabled(product.storeId)) {
            Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_ACTION_BOTTOM_DP));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(0, 0, 0, 0);
        panel.addView(form, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final long[] selectedStore = {product.storeId};
        TextView storeButton = button(product.storeName, DGRAY, 14);
        storeButton.setOnClickListener(v -> showStoreChoiceForEditor(selectedStore, storeButton));
        LinearLayout.LayoutParams storeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        storeLp.bottomMargin = dp(8);
        form.addView(storeButton, storeLp);

        EditText name = dialogInput("商品名");
        name.setText(product.rawName == null ? "" : product.rawName);
        addProductEditField(form, "商品名", name);

        EditText price = dialogInput("価格");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        price.setText(product.priceYen == null ? "" : String.valueOf(product.priceYen));
        addProductEditField(form, "価格（円）", price);

        EditText volume = dialogInput("容量");
        volume.setInputType(InputType.TYPE_CLASS_NUMBER);
        volume.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789"));
        volume.setText(normalizeVolumeForStorage(product.volume));
        addProductEditField(form, "容量（ml）", volume);

        EditText productKey = dialogInput("product_key");
        productKey.setText(product.productKey == null ? (product.manualEntry ? "" : product.rawName) : product.productKey);
        if (product.manualEntry) {
            productKey.setKeyListener(android.text.method.DigitsKeyListener.getInstance(
                    "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ._-"));
        }
        addProductEditField(form, "product_key", productKey);

        final String[] selectedPriceType = {normalizePriceTypeForEditor(product.priceType)};
        TextView priceType = button(selectedPriceType[0], DGRAY, 14);
        priceType.setOnClickListener(v -> showPriceTypeChoice(selectedPriceType, priceType));
        addProductEditControl(form, "価格種別", priceType);

        final Set<Long> selectedTags = new HashSet<>(product.tagIds);
        View tagArea = makeCommonTagSelectionArea(selectedTags, true, true, chosen -> { });
        addProductEditWrapControl(form, "タグ", tagArea);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        // Match the single-photo four-button row: use the dialog width, with even outer/inner gaps.
        actions.setPadding(0, 0, 0, 0);

        TextView deleteButton = button("削除", RED, 13);
        TextView referenceButton = button("参照画像", ORANGE, 13);
        TextView cancelButton = button("キャンセル", DGRAY, 13);
        TextView saveButton = button("保存", BLUE, 13);

        actions.addView(deleteButton, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams actionLp2 = new LinearLayout.LayoutParams(0, dp(38), 1f);
        actionLp2.leftMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(referenceButton, actionLp2);
        LinearLayout.LayoutParams actionLp3 = new LinearLayout.LayoutParams(0, dp(38), 1f);
        actionLp3.leftMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(cancelButton, actionLp3);
        LinearLayout.LayoutParams actionLp4 = new LinearLayout.LayoutParams(0, dp(38), 1f);
        actionLp4.leftMargin = dp(UI_ACTION_GAP_DP);
        actions.addView(saveButton, actionLp4);

        LinearLayout.LayoutParams actionRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        actionRowLp.topMargin = dp(UI_DIALOG_ACTION_SPACING_DP);
        panel.addView(actions, actionRowLp);

        ScrollView productEditScroll = newAutoFadeScrollView();
        productEditScroll.setFillViewport(false);
        productEditScroll.addView(panel, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("商品編集")
                .setView(productEditScroll)
                .create();

        if (product.manualEntry) {
            Runnable refreshManualSave = () -> setButtonEnabledStyle(saveButton,
                    !name.getText().toString().trim().isEmpty()
                            && !price.getText().toString().trim().isEmpty(), BLUE);
            TextWatcher manualRequiredWatcher = new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshManualSave.run(); }
                @Override public void afterTextChanged(Editable s) { }
            };
            name.addTextChangedListener(manualRequiredWatcher);
            price.addTextChangedListener(manualRequiredWatcher);
            refreshManualSave.run();
        }

        deleteButton.setOnClickListener(v -> {
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("商品削除")
                    .setMessage("「" + product.rawName + "」を削除しますか？\n元画像は削除されません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (dd, which) -> {
                        db.deleteProduct(product.id);
                        DiagLog.write(this, "PRODUCT_DELETE id=" + product.id + " source=editor");
                        dialog.dismiss();
                        if (afterSave != null) afterSave.run();
                    })
                    .create();
            showRoundedDialog(confirm);
        });

        referenceButton.setOnClickListener(v -> showProductReferenceImage(product));
        cancelButton.setOnClickListener(v -> dialog.dismiss());

        saveButton.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { showFieldError(name, "商品名を入力"); return; }
            Integer priceValue = null;
            String priceText = price.getText().toString().trim();
            if (product.manualEntry && priceText.isEmpty()) { showFieldError(price, "価格を入力"); return; }
            if (!priceText.isEmpty()) {
                try { priceValue = Integer.parseInt(priceText); }
                catch (NumberFormatException ex) { showFieldError(price, "整数で入力"); return; }
            }
            if (db.getStore(selectedStore[0]) == null) {
                Toast.makeText(this, "店舗を選択してください", Toast.LENGTH_SHORT).show();
                return;
            }
            db.updateProductDetails(product.id, n, productKey.getText().toString(), priceValue,
                    normalizeVolumeForStorage(volume.getText().toString()), selectedPriceType[0], new ArrayList<>(selectedTags), selectedStore[0]);
            DiagLog.write(this, "PRODUCT_EDIT id=" + product.id + " store=" + selectedStore[0] +
                    " tags=" + selectedTags);
            dialog.dismiss();
            if (afterSave != null) afterSave.run();
        });

        showRoundedDialog(dialog, true);
    }

    private void showProductReferenceImage(DatabaseHelper.ProductRecord product) {
        if (product == null) return;
        DatabaseHelper.Photo photo = db.getPhoto(product.photoId);
        if (product.referenceMissing || photo == null || db.isVirtualImportPhoto(photo) || photo.uri == null || photo.uri.trim().isEmpty()) {
            if (!product.referenceMissing) db.markProductReferenceMissing(product.id);
            Toast.makeText(this, "参照画像がありません", Toast.LENGTH_SHORT).show();
            DiagLog.write(this, "PRODUCT_REFERENCE_IMAGE_MISSING product=" + product.id + " photo=" + product.photoId);
            return;
        }
        DiagLog.write(this, "PRODUCT_REFERENCE_IMAGE_OPEN product=" + product.id + " photo=" + photo.id);
        if (!showOriginalPhoto(photo)) {
            db.markProductReferenceMissing(product.id);
            Toast.makeText(this, "参照画像がありません", Toast.LENGTH_SHORT).show();
            DiagLog.write(this, "PRODUCT_REFERENCE_IMAGE_MARK_MISSING product=" + product.id + " photo=" + photo.id);
        }
    }

    private void addProductEditField(LinearLayout panel, String label, EditText input) {
        addProductEditControl(panel, label, input);
    }

    private void addProductEditControl(LinearLayout panel, String label, View control) {
        TextView l = text(label, 12, SECONDARY, false);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24));
        llp.topMargin = dp(UI_TIGHT_SPACING_DP);
        panel.addView(l, llp);
        panel.addView(control, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
    }

    private void addProductEditWrapControl(LinearLayout panel, String label, View control) {
        TextView l = text(label, 12, SECONDARY, false);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24));
        llp.topMargin = dp(UI_TIGHT_SPACING_DP);
        panel.addView(l, llp);
        control.setMinimumHeight(dp(46));
        panel.addView(control, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void showPriceTypeChoice(String[] selectedPriceType, TextView button) {
        String[] values = {"税抜", "税込", "不明"};
        int checked = 2;
        if ("税抜".equals(selectedPriceType[0])) checked = 0;
        else if ("税込".equals(selectedPriceType[0])) checked = 1;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("価格種別")
                .setSingleChoiceItems(values, checked, (d, which) -> {
                    selectedPriceType[0] = values[which];
                    button.setText(values[which]);
                    d.dismiss();
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private String normalizePriceTypeForEditor(String value) {
        if (value == null) return "不明";
        String s = value.trim().toLowerCase(Locale.ROOT);
        if (s.contains("税抜") || s.contains("税別") || s.equals("抜") || s.contains("tax excluded") || s.contains("excl")) return "税抜";
        if (s.contains("税込") || s.equals("込") || s.contains("tax included") || s.contains("incl")) return "税込";
        return "不明";
    }

    private String normalizeVolumeForStorage(String value) {
        if (value == null) return "";
        String raw = value.trim();
        if (raw.isEmpty()) return "";
        String normalized = raw.replace('０', '0').replace('１', '1').replace('２', '2')
                .replace('３', '3').replace('４', '4').replace('５', '5').replace('６', '6')
                .replace('７', '7').replace('８', '8').replace('９', '9')
                .replace('．', '.').replace('，', ',').toLowerCase(Locale.ROOT);
        normalized = normalized.replace(",", "").replace(" ", "");
        try {
            if (normalized.matches("[0-9]+(?:\\.[0-9]+)?l")) {
                double liters = Double.parseDouble(normalized.substring(0, normalized.length() - 1));
                return String.valueOf(Math.round(liters * 1000.0));
            }
            if (normalized.matches("[0-9]+(?:\\.[0-9]+)?(?:ml|ｍｌ)")) {
                String number = normalized.replaceAll("(?:ml|ｍｌ)$", "");
                return String.valueOf(Math.round(Double.parseDouble(number)));
            }
            if (normalized.matches("[0-9]+")) return normalized;
        } catch (Exception ignored) { }
        String digits = normalized.replaceAll("[^0-9]", "");
        return digits;
    }

    private String formatVolumeDisplay(String value) {
        String normalized = normalizeVolumeForStorage(value);
        return normalized.isEmpty() ? "—" : normalized + "ml";
    }

    private void showStoreChoiceForEditor(long[] selectedStore, TextView button) {
        List<DatabaseHelper.Store> stores = db.listStores();
        if (stores.isEmpty()) {
            Toast.makeText(this, "店舗がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[stores.size()];
        for (int i = 0; i < stores.size(); i++) names[i] = stores.get(i).name;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗を選択")
                .setItems(names, (d, which) -> {
                    DatabaseHelper.Store store = stores.get(which);
                    selectedStore[0] = store.id;
                    button.setText(store.name);
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private void showTagChoiceForEditor(Long[] selectedTag, TextView button) {
        List<DatabaseHelper.Tag> tags = db.listTags();
        String[] names = new String[tags.size() + 2];
        names[0] = "タグなし";
        for (int i = 0; i < tags.size(); i++) names[i + 1] = tags.get(i).name;
        names[names.length - 1] = "＋ 新しいタグ";

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグを選択")
                .setItems(names, (d, which) -> {
                    if (which == names.length - 1) {
                        showCreateTagForEditor(selectedTag, button);
                    } else if (which == 0) {
                        selectedTag[0] = null;
                        button.setText("タグ: タグなし");
                    } else {
                        DatabaseHelper.Tag tag = tags.get(which - 1);
                        selectedTag[0] = tag.id;
                        button.setText("タグ: " + tag.name);
                    }
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private void showCreateTagForEditor(Long[] selectedTag, TextView button) {
        EditText input = dialogInput("新しいタグ");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新しいタグ")
                .setView(storeNameInputHolder(input, UI_SPACING_DP))
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("追加", null)
                .create();
        dialog.setOnShowListener(d -> {
            focusAndShowKeyboard(input, dialog);
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { showFieldError(input, "タグ名を入力"); return; }
                long tagId = db.addTag(name);
                if (tagId < 0) {
                    showDuplicateTagNameWarning(input);
                    return;
                }
                selectedTag[0] = tagId;
                button.setText("タグ: " + name);
                DiagLog.write(this, "ADD_TAG_FROM_PRODUCT tag=" + tagId + " name=" + name);
                dialog.dismiss();
                reloadStores();
            });
        });
        showRoundedDialog(dialog);
    }

    private void showSameProductPrices(String productKey) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP),
                dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));

        LinearLayout tableHost = new LinearLayout(this);
        tableHost.setOrientation(LinearLayout.VERTICAL);
        panel.addView(tableHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView closeAction = makeDialogAction("閉じる");
        LinearLayout footer = makeRightDialogFooter(closeAction);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        footerLp.topMargin = dp(UI_SPACING_DP);
        panel.addView(footer, footerLp);

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            tableHost.removeAllViews();
            List<DatabaseHelper.ProductRecord> rows = db.listSameProductAcrossStores(productKey);
            if (rows.isEmpty()) {
                TextView empty = text("他店舗の価格データはありません。", 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(dp(16), dp(26), dp(16), dp(26));
                tableHost.addView(empty);
                return;
            }

            LinearLayout sheet = new LinearLayout(this);
            sheet.setOrientation(LinearLayout.VERTICAL);
            // Comparison is read-only with respect to layout. It consumes the globally saved widths,
            // falling back to the same defaults used by the product lists.
            int[] widths = {
                    productColumnWidth("store"),
                    productColumnWidth("price"),
                    productColumnWidth("volume"),
                    productColumnWidth("date")
            };
            sheet.addView(sheetHeader(new String[]{"店舗", "価格", "容量", "日付"}, widths));
            for (DatabaseHelper.ProductRecord p : rows) {
                LinearLayout row = sheetRow(new String[]{
                        p.storeName,
                        p.priceYen == null ? "—" : yen(p.priceYen) + priceTaxMarker(p.priceType),
                        formatVolumeDisplay(p.volume),
                        dateFormat.format(new Date(p.photoCreatedAt))
                }, widths);
                row.setClickable(true);
                row.setFocusable(true);
                row.setContentDescription((p.rawName == null ? "商品" : p.rawName) + "を編集");
                row.setOnClickListener(v -> {
                    DatabaseHelper.ProductRecord fresh = db.getProduct(p.id);
                    if (fresh == null) {
                        render[0].run();
                        return;
                    }
                    // Keep this comparison dialog open underneath. Closing/saving the editor returns here.
                    showProductEditor(fresh, () -> {
                        reloadStores();
                        render[0].run();
                    });
                });
                sheet.addView(row);
            }
            tableHost.addView(wrapHorizontal(sheet));
        };

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(productKey == null || productKey.trim().isEmpty() ? "他店舗価格" : productKey)
                .setView(panel)
                .create();
        closeAction.setOnClickListener(v -> dialog.dismiss());
        render[0].run();
        showRoundedDialog(dialog, true);
    }

    private void showUnifyProductsDialog(List<Long> productIds, Runnable afterApply) {
        if (productIds == null || productIds.size() < 2) return;

        ArrayList<DatabaseHelper.ProductRecord> records = new ArrayList<>();
        for (Long id : productIds) {
            if (id == null) continue;
            DatabaseHelper.ProductRecord p = db.getProduct(id);
            if (p != null) records.add(p);
        }
        if (records.size() < 2) return;
        records.sort((a, b) -> Long.compare(a.id, b.id));

        ArrayList<DatabaseHelper.ProductRecord> candidates = new ArrayList<>();
        HashSet<String> seenNames = new HashSet<>();
        for (DatabaseHelper.ProductRecord p : records) {
            String name = p.rawName == null ? "" : p.rawName.trim();
            if (name.isEmpty() || !seenNames.add(name)) continue;
            candidates.add(p);
        }
        if (candidates.isEmpty()) return;

        String[] labels = new String[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            DatabaseHelper.ProductRecord p = candidates.get(i);
            StringBuilder label = new StringBuilder(p.rawName == null ? "" : p.rawName);
            if (p.volume != null && !p.volume.trim().isEmpty()) label.append("  ").append(formatVolumeDisplay(p.volume));
            if (p.storeName != null && !p.storeName.trim().isEmpty()) label.append("\n").append(p.storeName);
            labels[i] = label.toString();
        }

        AlertDialog choose = new AlertDialog.Builder(this)
                .setTitle("共通の商品名を選択")
                .setItems(labels, (d, which) -> {
                    DatabaseHelper.ProductRecord chosen = candidates.get(which);
                    String commonName = chosen.rawName == null ? "" : chosen.rawName.trim();
                    String commonKey = chosen.productKey == null ? "" : chosen.productKey.trim();

                    HashSet<String> volumes = new HashSet<>();
                    for (DatabaseHelper.ProductRecord p : records) {
                        if (p.volume != null && !p.volume.trim().isEmpty()) volumes.add(p.volume.trim());
                    }
                    boolean mixedVolume = volumes.size() > 1;
                    StringBuilder message = new StringBuilder();
                    if (mixedVolume) {
                        message.append("容量が異なる商品が含まれています。\n\n");
                    }
                    message.append(productIds.size()).append("件を同一商品として扱います。\n")
                            .append("商品名: ").append(commonName).append("\n")
                            .append("product_key: ").append(commonKey.isEmpty() ? "自動生成" : commonKey)
                            .append("\n\n価格・店舗・容量・タグ・画像情報は変更しません。");

                    AlertDialog confirm = new AlertDialog.Builder(this)
                            .setTitle("同一商品")
                            .setMessage(message.toString())
                            .setNegativeButton("キャンセル", null)
                            .setPositiveButton("適用", (dd, w) -> {
                                db.unifyProductIdentity(productIds, commonName, commonKey);
                                DatabaseHelper.ProductRecord refreshed = db.getProduct(chosen.id);
                                String appliedKey = refreshed == null ? commonKey : refreshed.productKey;
                                DiagLog.write(this, "PRODUCT_UNIFY count=" + productIds.size() +
                                        " name=" + commonName + " key=" + appliedKey + " mixedVolume=" + mixedVolume);
                                Toast.makeText(this, productIds.size() + "件を同一商品にしました", Toast.LENGTH_SHORT).show();
                                if (afterApply != null) afterApply.run();
                            })
                            .create();
                    showRoundedDialog(confirm);
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(choose, true);
    }

    private void confirmDeleteProducts(List<Long> productIds, Runnable afterDelete) {
        if (productIds == null || productIds.isEmpty()) return;
        AlertDialog confirm = new AlertDialog.Builder(this)
                .setTitle("商品削除")
                .setMessage(productIds.size() + "件の商品を削除しますか？\n元画像は削除されません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, which) -> {
                    db.deleteProducts(productIds);
                    DiagLog.write(this, "PRODUCT_BULK_DELETE count=" + productIds.size());
                    Toast.makeText(this, productIds.size() + "件削除しました", Toast.LENGTH_SHORT).show();
                    if (afterDelete != null) afterDelete.run();
                })
                .create();
        showRoundedDialog(confirm);
    }


    private void showMoveProductsTagDialog(List<Long> productIds, Runnable afterMove) {
        if (productIds == null || productIds.isEmpty()) return;
        Set<Long> selectedTags = new HashSet<>();
        boolean first = true;
        for (Long productId : productIds) {
            if (productId == null) continue;
            Set<Long> tags = new HashSet<>(db.productTagIds(productId));
            if (first) {
                selectedTags.addAll(tags);
                first = false;
            } else {
                selectedTags.retainAll(tags);
            }
        }

        showTagSelectionDialog(selectedTags, chosen -> {
            db.updateProductsTags(productIds, orderedTagIds(chosen));
            DiagLog.write(this, "PRODUCT_TAG_MULTI_APPLY count=" + productIds.size() + " tags=" + chosen);
            if (afterMove != null) afterMove.run();
        }, null);
    }
    private void showDiagnosticLog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));

        TextView title = text("診断ログ", 21, WHITE, true);
        panel.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        ScrollView scroll = newAutoFadeScrollView();
        scroll.setFillViewport(false);
        TextView body = text(DiagLog.report(this), 11, WHITE, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(10), dp(8), dp(10), dp(8));
        body.setBackground(roundRect(DGRAY, 10));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(withFastScroll(scroll), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(UI_SPACING_DP), 0, 0);

        TextView clearAction = makeDialogAction("ログ消去");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        copyAction.setGravity(Gravity.CENTER);
        closeAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);

        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));

        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .create();

        clearAction.setOnClickListener(v -> {
            DiagLog.clear(this);
            body.setText(DiagLog.report(this));
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        copyAction.setOnClickListener(v -> {
            String report = DiagLog.report(this);
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("PriceRec diagnostic", report));
            Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
        });
        closeAction.setOnClickListener(v -> dialog.dismiss());

        showRoundedDialog(dialog, true);
    }

    private long selectedTagForStore(long storeId) {
        long id = getPreferences(MODE_PRIVATE).getLong("selected_tag_" + storeId, Long.MIN_VALUE);
        if (id == -1L) return -1L;
        if (id != Long.MIN_VALUE && db.tagExists(id)) return id;
        List<DatabaseHelper.Tag> tags = db.listTags();
        return tags.isEmpty() ? -1L : tags.get(0).id;
    }

    private void saveSelectedTag(long storeId, long tagId) {
        getPreferences(MODE_PRIVATE).edit().putLong("selected_tag_" + storeId, tagId).apply();
    }

    private String safeFolder(String name) {
        String s = name.replace('/', '_').replace('\\', '_').trim();
        return s.isEmpty() ? "Store" : s;
    }

    private String ocrStatusLabel(String s) {
        if (s == null || "pending".equals(s)) return "未解析";
        if ("processing".equals(s)) return "解析中";
        if ("done".equals(s)) return "完了";
        if ("no_results".equals(s)) return "候補なし";
        if ("error".equals(s)) return "エラー";
        return s;
    }

    private void bindThumbnailAsync(ImageView image, Uri uri, int targetW, int targetH) {
        if (image == null || uri == null) return;
        String key = uri.toString() + "@" + targetW + "x" + targetH;
        image.setTag(key);
        Bitmap cached;
        synchronized (thumbnailCache) {
            cached = thumbnailCache.get(key);
        }
        if (cached != null && !cached.isRecycled()) {
            image.setImageBitmap(cached);
            return;
        }
        image.setImageDrawable(null);
        thumbnailExecutor.execute(() -> {
            Bitmap decoded = loadBitmap(uri, targetW, targetH);
            if (decoded == null) return;
            synchronized (thumbnailCache) {
                thumbnailCache.put(key, decoded);
            }
            runOnUiThread(() -> {
                Object currentTag = image.getTag();
                if (key.equals(currentTag) && !decoded.isRecycled()) image.setImageBitmap(decoded);
            });
        });
    }

    private Bitmap loadCachedBitmap(Uri uri, int targetW, int targetH) {
        if (uri == null) return null;
        String key = uri.toString() + "@" + targetW + "x" + targetH;
        Bitmap cached;
        synchronized (thumbnailCache) {
            cached = thumbnailCache.get(key);
        }
        if (cached != null && !cached.isRecycled()) return cached;
        Bitmap decoded = loadBitmap(uri, targetW, targetH);
        if (decoded != null) {
            synchronized (thumbnailCache) {
                thumbnailCache.put(key, decoded);
            }
        }
        return decoded;
    }

    private Bitmap loadBitmap(Uri uri, int targetW, int targetH) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
                int w = info.getSize().getWidth();
                int h = info.getSize().getHeight();
                if (w <= 0 || h <= 0) return;
                double scale = Math.min(1.0, Math.min((double) targetW / w, (double) targetH / h));
                decoder.setTargetSize(Math.max(1, (int) (w * scale)), Math.max(1, (int) (h * scale)));
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            });
        } catch (Exception e) {
            DiagLog.write(this, "IMAGE_LOAD_ERROR uri=" + uri + " err=" + e);
            return null;
        }
    }

    private String yen(int price) {
        return "¥" + NumberFormat.getIntegerInstance(Locale.JAPAN).format(price);
    }

    private View wrapHorizontal(View child) {
        HorizontalScrollView hsv = newAutoFadeHorizontalScrollView();
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(child);
        return hsv;
    }

    private ArrayList<String> loadGlobalProductColumnOrder() {
        final String defaultOrder = "price,volume,store,tag,date";
        final String oldAutoDefault = "price,store,volume,tag,date";
        final String migrationKey = "product_columns_v0148_default_migrated";
        android.content.SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        String saved = prefs.getString(PREF_PRODUCT_COLUMNS_GLOBAL, null);

        if (!prefs.getBoolean(migrationKey, false)) {
            if (saved == null || saved.trim().isEmpty()) {
                String legacy = prefs.getString("product_columns_all_v2", null);
                saved = (legacy == null || legacy.trim().isEmpty() || oldAutoDefault.equals(legacy.trim()))
                        ? defaultOrder : legacy;
            } else if (oldAutoDefault.equals(saved.trim())) {
                // v0.1.47 wrote its default order into preferences even before the user explicitly reordered.
                // Move only that untouched default to the new initial order; any different saved order is preserved.
                saved = defaultOrder;
            }
            prefs.edit().putString(PREF_PRODUCT_COLUMNS_GLOBAL, saved)
                    .putBoolean(migrationKey, true).apply();
        } else if (saved == null || saved.trim().isEmpty()) {
            saved = defaultOrder;
            prefs.edit().putString(PREF_PRODUCT_COLUMNS_GLOBAL, saved).apply();
        }

        String[] allowed = {"store", "price", "volume", "tag", "date"};
        ArrayList<String> out = new ArrayList<>();
        for (String part : saved.split(",")) {
            String key = part.trim();
            for (String a : allowed) {
                if (a.equals(key) && !out.contains(key)) {
                    out.add(key);
                    break;
                }
            }
        }
        for (String a : allowed) if (!out.contains(a)) out.add(a);
        return out;
    }

    private ArrayList<String> loadProductColumnOrder(boolean storeWholeList) {
        ArrayList<String> nonProduct = loadGlobalProductColumnOrder();
        // Store-specific lists keep their structurally fixed store column at the end; all movable columns still
        // inherit the same global order used by the all-products list.
        if (storeWholeList) {
            nonProduct.remove("store");
            nonProduct.add("store");
        }
        ArrayList<String> out = new ArrayList<>();
        out.add("product"); // Product name remains the fixed leading anchor everywhere.
        out.addAll(nonProduct);
        return out;
    }

    private void saveProductColumnOrder(List<String> visibleOrder, boolean storeWholeList) {
        ArrayList<String> global;
        if (storeWholeList) {
            // Preserve the globally saved store-column slot while applying the visible movable order.
            ArrayList<String> previous = loadGlobalProductColumnOrder();
            ArrayList<String> movable = new ArrayList<>();
            for (String key : visibleOrder) {
                if (!"product".equals(key) && !"store".equals(key)) movable.add(key);
            }
            global = new ArrayList<>();
            int movableIndex = 0;
            for (String key : previous) {
                if ("store".equals(key)) global.add("store");
                else if (movableIndex < movable.size()) global.add(movable.get(movableIndex++));
            }
            while (movableIndex < movable.size()) global.add(movable.get(movableIndex++));
            if (!global.contains("store")) global.add("store");
        } else {
            global = new ArrayList<>();
            for (String key : visibleOrder) if (!"product".equals(key)) global.add(key);
        }
        getPreferences(MODE_PRIVATE).edit()
                .putString(PREF_PRODUCT_COLUMNS_GLOBAL, String.join(",", global))
                .apply();
        DiagLog.write(this, "PRODUCT_COLUMNS_SAVE scope=global source=" + (storeWholeList ? "store" : "all") +
                " order=" + String.join(",", global));
    }

    private LinearLayout makeReorderableProductHeader(ArrayList<String> order, boolean storeWholeList, Runnable rerender) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(DGRAY);
        final int longPressMs = android.view.ViewConfiguration.getLongPressTimeout();
        final int touchSlop = android.view.ViewConfiguration.get(this).getScaledTouchSlop();
        for (String key : order) {
            TextView cell = text(productColumnLabel(key), 13, SECONDARY, true);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            cell.setLayoutParams(new LinearLayout.LayoutParams(dp(productColumnWidth(key)), dp(38)));
            boolean fixed = "product".equals(key) || (storeWholeList && "store".equals(key));
            if (fixed) {
                // Fixed position does not mean fixed width: a tap still opens the global width editor.
                cell.setOnClickListener(v -> showProductColumnWidthDialog(key, rerender));
            } else {
                final float[] downX = {0f};
                final float[] downY = {0f};
                final boolean[] longPressed = {false};
                final boolean[] cancelled = {false};
                final Runnable activate = () -> {
                    if (cancelled[0]) return;
                    longPressed[0] = true;
                    cell.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    // Highlight the full grabbed column-header range instead of dimming the text.
                    cell.setBackgroundColor(LGRAY);
                    cell.animate().scaleX(1.02f).scaleY(1.02f).setDuration(90).start();
                    ViewParentDisallow(cell, true);
                    DiagLog.write(this, "PRODUCT_COLUMN_DRAG_START scope=" + (storeWholeList ? "store" : "all") + " column=" + key);
                };
                cell.setOnTouchListener((v, event) -> {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX[0] = event.getRawX();
                            downY[0] = event.getRawY();
                            cancelled[0] = false;
                            longPressed[0] = false;
                            v.postDelayed(activate, longPressMs);
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getRawX() - downX[0];
                            float dy = event.getRawY() - downY[0];
                            if (!longPressed[0]) {
                                if (Math.hypot(dx, dy) > touchSlop) {
                                    cancelled[0] = true;
                                    v.removeCallbacks(activate);
                                    return false;
                                }
                            } else {
                                v.setTranslationX(dx);
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            v.removeCallbacks(activate);
                            float totalDx = event.getRawX() - downX[0];
                            boolean released = event.getActionMasked() == MotionEvent.ACTION_UP;
                            ViewParentDisallow(v, false);
                            if (!longPressed[0]) {
                                if (released && !cancelled[0]) showProductColumnWidthDialog(key, rerender);
                                cancelled[0] = true;
                                return true;
                            }

                            int from = order.indexOf(key);
                            int min = 1;
                            int max = storeWholeList ? order.size() - 2 : order.size() - 1;
                            int to = productColumnDropIndex(row, from, min, max, totalDx);
                            if (released && to != from) {
                                final int target = to;
                                animateProductColumnSwap(row, v, from, target, () -> {
                                    order.remove(from);
                                    order.add(target, key);
                                    saveProductColumnOrder(order, storeWholeList);
                                    v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                                    DiagLog.write(this, "PRODUCT_COLUMN_DRAG_END scope=" + (storeWholeList ? "store" : "all") +
                                            " column=" + key + " from=" + from + " to=" + target);
                                    if (rerender != null) rerender.run();
                                });
                            } else {
                                v.animate().translationX(0f).scaleX(1f).scaleY(1f).setDuration(130)
                                        .withEndAction(() -> v.setBackgroundColor(Color.TRANSPARENT)).start();
                            }
                            longPressed[0] = false;
                            cancelled[0] = true;
                            return true;
                        default:
                            return true;
                    }
                });
            }
            row.addView(cell);
        }
        return row;
    }

    private int productColumnDropIndex(LinearLayout row, int from, int min, int max, float totalDx) {
        if (from < min || from > max) return from;
        float draggedCenter = row.getChildAt(from).getLeft() + row.getChildAt(from).getWidth() / 2f + totalDx;
        int target = min;
        for (int i = min; i <= max; i++) {
            View child = row.getChildAt(i);
            float center = child.getLeft() + child.getWidth() / 2f;
            if (draggedCenter >= center) target = i;
            else break;
        }
        return Math.max(min, Math.min(max, target));
    }

    private void animateProductColumnSwap(LinearLayout row, View dragged, int from, int to, Runnable completion) {
        final long duration = 170L;
        final int draggedWidth = Math.max(1, dragged.getWidth());
        float targetX = 0f;
        if (to > from) {
            for (int i = from + 1; i <= to; i++) {
                View peer = row.getChildAt(i);
                targetX += peer.getWidth();
                peer.animate().translationX(-draggedWidth).setDuration(duration)
                        .setInterpolator(new DecelerateInterpolator()).start();
            }
        } else {
            for (int i = from - 1; i >= to; i--) {
                View peer = row.getChildAt(i);
                targetX -= peer.getWidth();
                peer.animate().translationX(draggedWidth).setDuration(duration)
                        .setInterpolator(new DecelerateInterpolator()).start();
            }
        }
        dragged.animate().translationX(targetX).scaleX(1f).scaleY(1f).setDuration(duration)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    dragged.setBackgroundColor(Color.TRANSPARENT);
                    if (completion != null) completion.run();
                }).start();
    }

    private void ViewParentDisallow(View view, boolean disallow) {
        if (view != null && view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(disallow);
    }

    private String productColumnLabel(String key) {
        switch (key) {
            case "product": return "商品名";
            case "store": return "店舗";
            case "price": return "価格";
            case "volume": return "容量";
            case "tag": return "タグ";
            case "date": return "日付";
            default: return key;
        }
    }

    private int defaultProductColumnWidth(String key) {
        switch (key) {
            case "product": return 220;
            case "price": return 90;
            case "volume": return 80;
            case "store": return 140;
            case "tag": return 120;
            case "date": return 130;
            default: return 100;
        }
    }

    private int minProductColumnWidth(String key) {
        switch (key) {
            case "product": return 120;
            case "store": return 80;
            case "price": return 70;
            case "volume": return 56;
            case "tag": return 70;
            case "date": return 90;
            default: return 56;
        }
    }

    private int maxProductColumnWidth(String key) {
        switch (key) {
            case "product": return 420;
            case "store": return 300;
            case "price": return 220;
            case "volume": return 180;
            case "tag": return 280;
            case "date": return 280;
            default: return 320;
        }
    }

    private int productColumnWidth(String key) {
        int def = defaultProductColumnWidth(key);
        int value = getPreferences(MODE_PRIVATE).getInt(PREF_PRODUCT_COLUMN_WIDTH_PREFIX + key, def);
        return Math.max(minProductColumnWidth(key), Math.min(maxProductColumnWidth(key), value));
    }

    private void saveProductColumnWidth(String key, int widthDp) {
        int value = Math.max(minProductColumnWidth(key), Math.min(maxProductColumnWidth(key), widthDp));
        getPreferences(MODE_PRIVATE).edit().putInt(PREF_PRODUCT_COLUMN_WIDTH_PREFIX + key, value).apply();
        DiagLog.write(this, "PRODUCT_COLUMN_WIDTH_SAVE column=" + key + " widthDp=" + value);
    }

    private void resetProductColumnWidth(String key) {
        getPreferences(MODE_PRIVATE).edit().remove(PREF_PRODUCT_COLUMN_WIDTH_PREFIX + key).apply();
        DiagLog.write(this, "PRODUCT_COLUMN_WIDTH_RESET column=" + key + " widthDp=" + defaultProductColumnWidth(key));
    }

    private void showProductColumnWidthDialog(String key, Runnable rerender) {
        int current = productColumnWidth(key);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP), dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP));

        TextView currentLabel = text("現在の幅：" + current + " dp", 13, SECONDARY, false);
        currentLabel.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        panel.addView(currentLabel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));

        EditText input = dialogInput("幅（dp）");
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789"));
        input.setText(String.valueOf(current));
        input.setSelection(input.length());
        panel.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        TextView range = text(minProductColumnWidth(key) + "〜" + maxProductColumnWidth(key) + " dp", 11, SECONDARY, false);
        range.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        panel.addView(range, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(productColumnLabel(key) + " カラム幅")
                .setView(panel)
                .setNegativeButton("キャンセル", null)
                .setNeutralButton("初期値", (d, which) -> {
                    resetProductColumnWidth(key);
                    if (rerender != null) rerender.run();
                })
                .setPositiveButton("保存", null)
                .create();
        showRoundedDialog(dialog);
        TextView save = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
        if (save != null) save.setOnClickListener(v -> {
            String raw = input.getText().toString().trim();
            if (raw.isEmpty()) {
                showFieldError(input, "幅を入力");
                return;
            }
            int value;
            try {
                value = Integer.parseInt(raw);
            } catch (NumberFormatException ex) {
                showFieldError(input, "整数で入力");
                return;
            }
            int min = minProductColumnWidth(key);
            int max = maxProductColumnWidth(key);
            if (value < min || value > max) {
                showFieldError(input, min + "〜" + max + " dpで入力");
                return;
            }
            saveProductColumnWidth(key, value);
            dialog.dismiss();
            if (rerender != null) rerender.run();
        });
    }

    private String productColumnValue(String key, DatabaseHelper.ProductRecord p, String productCell) {
        switch (key) {
            case "product": return productCell == null ? "" : productCell;
            case "store": return p.storeName == null ? "—" : p.storeName;
            case "price": return p.priceYen == null ? "—" : yen(p.priceYen) + priceTaxMarker(p.priceType);
            case "volume": return formatVolumeDisplay(p.volume);
            case "tag": return p.tagDisplay();
            case "date": return dateFormat.format(new Date(p.photoCreatedAt));
            default: return "";
        }
    }

    private String priceTaxMarker(String priceType) {
        if (priceType == null) return "";
        String value = priceType.trim().toLowerCase(Locale.ROOT);
        if (value.isEmpty()) return "";
        if (value.contains("税込") || value.equals("込") || value.contains("tax included") || value.contains("incl. tax") || value.contains("incl tax")) return " 込";
        if (value.contains("税抜") || value.equals("抜") || value.contains("税別") || value.contains("tax excluded") || value.contains("excl. tax") || value.contains("excl tax")) return " 抜";
        return "";
    }

    private LinearLayout makeProductDataRow(List<String> order, DatabaseHelper.ProductRecord p, String productCell, Runnable afterTagChange) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(1), 0, dp(1));
        for (String key : order) {
            int width = productColumnWidth(key);
            if ("product".equals(key)) {
                FrameLayout cell = new FrameLayout(this);
                cell.setMinimumHeight(dp(44));

                TextView name = text(productColumnValue(key, p, productCell), 13, WHITE, false);
                name.setGravity(Gravity.START | Gravity.TOP);
                name.setIncludeFontPadding(false);
                name.setMaxLines(3);
                name.setEllipsize(android.text.TextUtils.TruncateAt.END);
                name.setPadding(dp(10), dp(5), dp(36), dp(5));
                FrameLayout.LayoutParams nameLp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
                cell.addView(name, nameLp);

                View magnifier = new MagnifierIconView(this);
                magnifier.setTag("product_compare_icon");
                magnifier.setContentDescription("他店舗価格を比較");
                // Keep comparison icon on the same upper line as the first product-name line.
                FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.END | Gravity.TOP);
                iconLp.rightMargin = dp(3);
                cell.addView(magnifier, iconLp);
                row.addView(cell, new LinearLayout.LayoutParams(dp(width), ViewGroup.LayoutParams.WRAP_CONTENT));
            } else if ("tag".equals(key)) {
                row.addView(makeProductTagCell(p, afterTagChange), new LinearLayout.LayoutParams(dp(width), ViewGroup.LayoutParams.WRAP_CONTENT));
            } else {
                TextView cell = text(productColumnValue(key, p, productCell), 14, WHITE, false);
                cell.setGravity(Gravity.START | Gravity.TOP);
                cell.setIncludeFontPadding(false);
                cell.setMaxLines(3);
                cell.setEllipsize(android.text.TextUtils.TruncateAt.END);
                cell.setMinHeight(dp(44));
                cell.setPadding(dp(10), dp(5), dp(10), dp(5));
                row.addView(cell, new LinearLayout.LayoutParams(dp(width), ViewGroup.LayoutParams.WRAP_CONTENT));
            }
        }
        return row;
    }

    private View makeProductTagCell(DatabaseHelper.ProductRecord product, Runnable afterChange) {
        FrameLayout cell = new FrameLayout(this);
        cell.setMinimumHeight(dp(44));
        TagFlowLayout flow = new TagFlowLayout(this);
        flow.setPadding(dp(6), dp(5), dp(34), dp(5));
        List<DatabaseHelper.Tag> tags = db.listTags();
        boolean added = false;
        for (DatabaseHelper.Tag tag : tags) {
            if (!product.hasTag(tag.id)) continue;
            TextView t = tagChip(tag.name, false, false);
            flow.addView(t);
            added = true;
        }
        if (!added) flow.addView(tagChip("タグなし", false, true));
        FrameLayout.LayoutParams flowLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        cell.addView(flow, flowLp);

        ImageView plus = roundPlusIcon(ORANGE, WHITE, "タグ選択");
        plus.setPadding(dp(3), dp(3), dp(3), dp(3));
        plus.setOnClickListener(v -> {
            HashSet<Long> selected = new HashSet<>(product.tagIds);
            showTagSelectionDialog(selected, chosen -> {
                db.updateProductsTags(Collections.singletonList(product.id), orderedTagIds(chosen));
                DiagLog.write(this, "PRODUCT_TAGS_INLINE product=" + product.id + " tags=" + chosen);
                if (afterChange != null) afterChange.run();
            }, () -> {
                if (afterChange != null) afterChange.run();
            });
        });
        FrameLayout.LayoutParams plusLp = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.END | Gravity.BOTTOM);
        plusLp.rightMargin = dp(3);
        plusLp.bottomMargin = dp(3);
        cell.addView(plus, plusLp);
        return cell;
    }

    private LinearLayout sheetHeader(String[] values, int[] widthsDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(DGRAY);
        for (int i = 0; i < values.length; i++) {
            TextView cell = text(values[i], 13, SECONDARY, true);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            row.addView(cell, new LinearLayout.LayoutParams(dp(widthsDp[i]), dp(38)));
        }
        return row;
    }

    private LinearLayout sheetRow(String[] values, int[] widthsDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(1), 0, dp(1));
        for (int i = 0; i < values.length; i++) {
            TextView cell = text(values[i] == null ? "" : values[i], 14, WHITE, false);
            cell.setGravity(Gravity.START | Gravity.TOP);
            cell.setIncludeFontPadding(false);
            cell.setMaxLines(3);
            cell.setEllipsize(android.text.TextUtils.TruncateAt.END);
            cell.setMinHeight(dp(44));
            cell.setPadding(dp(10), dp(5), dp(10), dp(5));
            row.addView(cell, new LinearLayout.LayoutParams(dp(widthsDp[i]), ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return row;
    }

    private void alignWrappedTextTop(TextView view) {
        if (view == null) return;
        view.setIncludeFontPadding(false);
        view.setMaxLines(3);
        view.setEllipsize(android.text.TextUtils.TruncateAt.END);
        view.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            TextView t = (TextView) v;
            int desired = Gravity.START | (t.getLineCount() > 1 ? Gravity.TOP : Gravity.CENTER_VERTICAL);
            if (t.getGravity() != desired) t.setGravity(desired);
        });
    }

    private EditText sheetEdit(String value, boolean numeric) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(14);
        e.setTextColor(DGRAY);
        e.setHintTextColor(GRAY);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER_VERTICAL);
        e.setIncludeFontPadding(false);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setBackground(roundRect(NWHITE, 999));
        applyDarkInputCursor(e);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private ImageView roundPlusIcon(int backgroundColor, int iconColor, String contentDescription) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_plus_geometric);
        icon.setScaleType(ImageView.ScaleType.CENTER);
        icon.setColorFilter(iconColor);
        icon.setBackground(circle(backgroundColor));
        icon.setContentDescription(contentDescription);
        return icon;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView button(String value, int color, float sp) {
        TextView t = text(value, sp, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundRect(color, 999));
        return t;
    }

    private void setButtonEnabledStyle(TextView button, boolean enabled, int enabledColor) {
        if (button == null) return;
        button.setEnabled(enabled);
        button.setAlpha(1f);
        button.setTextColor(enabled ? WHITE : LGRAY);
        button.setBackground(roundRect(enabled ? enabledColor : DGRAY, 999));
    }

    private TextView tagChip(String value, boolean selected, boolean secondary) {
        TextView t = text(value, 13, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setPadding(dp(10), 0, dp(10), 0);
        t.setBackground(roundRect(selected ? (secondary ? ORANGE : LBLUE) : DGRAY, 8));
        ViewGroup.MarginLayoutParams lp = new ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(28));
        lp.rightMargin = dp(5);
        lp.bottomMargin = dp(5);
        t.setLayoutParams(lp);
        return t;
    }

    private final class TagFlowLayout extends ViewGroup {
        TagFlowLayout(Context context) { super(context); }
        @Override protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
            return new MarginLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        }
        @Override protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams p) {
            return new MarginLayoutParams(p);
        }
        @Override protected boolean checkLayoutParams(ViewGroup.LayoutParams p) { return p instanceof MarginLayoutParams; }
        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int widthSize = MeasureSpec.getSize(widthMeasureSpec);
            int widthMode = MeasureSpec.getMode(widthMeasureSpec);
            int maxWidth = widthMode == MeasureSpec.UNSPECIFIED ? Integer.MAX_VALUE : Math.max(0, widthSize - getPaddingLeft() - getPaddingRight());
            int x = 0, y = 0, lineHeight = 0, usedWidth = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                if (child.getVisibility() == GONE) continue;
                measureChildWithMargins(child, widthMeasureSpec, getPaddingLeft() + getPaddingRight(), heightMeasureSpec, getPaddingTop() + getPaddingBottom());
                MarginLayoutParams lp = (MarginLayoutParams) child.getLayoutParams();
                int cw = child.getMeasuredWidth() + lp.leftMargin + lp.rightMargin;
                int ch = child.getMeasuredHeight() + lp.topMargin + lp.bottomMargin;
                if (x > 0 && x + cw > maxWidth) { y += lineHeight; x = 0; lineHeight = 0; }
                x += cw; lineHeight = Math.max(lineHeight, ch); usedWidth = Math.max(usedWidth, x);
            }
            y += lineHeight;
            int measuredW = widthMode == MeasureSpec.EXACTLY ? widthSize : Math.min(widthSize, usedWidth + getPaddingLeft() + getPaddingRight());
            int measuredH = resolveSize(y + getPaddingTop() + getPaddingBottom(), heightMeasureSpec);
            setMeasuredDimension(measuredW, measuredH);
        }
        @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int maxWidth = Math.max(0, r - l - getPaddingLeft() - getPaddingRight());
            int x = 0, y = 0, lineHeight = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                if (child.getVisibility() == GONE) continue;
                MarginLayoutParams lp = (MarginLayoutParams) child.getLayoutParams();
                int cw = child.getMeasuredWidth() + lp.leftMargin + lp.rightMargin;
                int ch = child.getMeasuredHeight() + lp.topMargin + lp.bottomMargin;
                if (x > 0 && x + cw > maxWidth) { y += lineHeight; x = 0; lineHeight = 0; }
                int cl = getPaddingLeft() + x + lp.leftMargin;
                int ct = getPaddingTop() + y + lp.topMargin;
                child.layout(cl, ct, cl + child.getMeasuredWidth(), ct + child.getMeasuredHeight());
                x += cw; lineHeight = Math.max(lineHeight, ch);
            }
        }
    }

    private TextView chip(String value, boolean selected, boolean secondary) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? (secondary ? ORANGE : LBLUE) : DGRAY, 999));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView dialogChip(String value, boolean selected) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? LBLUE : DGRAY, 999));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private LinearLayout makeRightDialogFooter(TextView action) {
        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(48), 1f));
        if (action != null) {
            action.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            footer.addView(action, new LinearLayout.LayoutParams(dp(92), dp(48)));
        }
        return footer;
    }

    private TextView makeDialogAction(String value) {
        return makeDialogAction(value, LBLUE);
    }

    private TextView makeDialogAction(String value, int enabledColor) {
        return makeDialogAction(value, enabledColor, 0);
    }

    private TextView makeDialogAction(String value, int enabledColor, int fixedVisualWidthDp) {
        TextView t = text(value, 14, WHITE, true);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        // Keep the existing font size and touch slot; only the visible surface becomes a very thin capsule.
        t.setPadding(dp(8), 0, dp(8), 0);
        t.setBackground(new LinkCapsuleDrawable(t, enabledColor, fixedVisualWidthDp));
        return t;
    }

    private void setDialogActionEnabled(TextView action, boolean enabled) {
        if (action == null) return;
        action.setEnabled(enabled);
        action.setAlpha(1f);
        action.setTextColor(enabled ? WHITE : LGRAY);
        action.invalidate();
    }

    private final class LinkCapsuleDrawable extends Drawable {
        private final TextView host;
        private final int enabledColor;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final int fixedVisualWidthDp;

        LinkCapsuleDrawable(TextView host) {
            this(host, LBLUE, 0);
        }

        LinkCapsuleDrawable(TextView host, int enabledColor) {
            this(host, enabledColor, 0);
        }

        LinkCapsuleDrawable(TextView host, int enabledColor, int fixedVisualWidthDp) {
            this.host = host;
            this.enabledColor = enabledColor;
            this.fixedVisualWidthDp = fixedVisualWidthDp;
            paint.setStyle(Paint.Style.FILL);
        }

        @Override public void draw(Canvas canvas) {
            if (host == null) return;
            paint.setColor(host.isEnabled() ? enabledColor : DGRAY);
            CharSequence text = host.getText();
            float textWidth = host.getPaint().measureText(text == null ? "" : text.toString());
            float visualWidth = fixedVisualWidthDp > 0
                    ? dp(fixedVisualWidthDp)
                    : Math.max(dp(24), textWidth + dp(14));
            float visualHeight = dp(26);
            android.graphics.Rect bounds = getBounds();
            float textLeft;
            int absoluteGravity = Gravity.getAbsoluteGravity(host.getGravity(), host.getLayoutDirection());
            int horizontal = absoluteGravity & Gravity.HORIZONTAL_GRAVITY_MASK;
            float contentLeft = bounds.left + host.getPaddingLeft();
            float contentRight = bounds.right - host.getPaddingRight();
            if (horizontal == Gravity.RIGHT) {
                float textRight = contentRight;
                textLeft = textRight - textWidth;
            } else if (horizontal == Gravity.CENTER_HORIZONTAL) {
                textLeft = (contentLeft + contentRight - textWidth) / 2f;
            } else {
                textLeft = contentLeft;
            }
            float left = textLeft - dp(7);
            float right = textLeft + textWidth + dp(7);
            if (left < bounds.left) {
                right += bounds.left - left;
                left = bounds.left;
            }
            if (right > bounds.right) {
                left -= right - bounds.right;
                right = bounds.right;
            }
            if (right - left < visualWidth) {
                float cx = (left + right) / 2f;
                left = Math.max(bounds.left, cx - visualWidth / 2f);
                right = Math.min(bounds.right, cx + visualWidth / 2f);
            }
            float cy = bounds.exactCenterY();
            float top = cy - visualHeight / 2f;
            float bottom = cy + visualHeight / 2f;
            canvas.drawRoundRect(left, top, right, bottom, visualHeight / 2f, visualHeight / 2f, paint);
        }

        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private void styleCapsuleDialogButton(TextView button, int color) {
        if (button == null) return;
        button.setTag("capsule_action");
        button.setTextColor(WHITE);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setIncludeFontPadding(false);
        button.setGravity(Gravity.CENTER);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(roundRect(color, 999));
        ViewGroup.LayoutParams rawLp = button.getLayoutParams();
        if (rawLp != null) {
            rawLp.width = dp(92);
            rawLp.height = dp(38);
            if (rawLp instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) rawLp;
                mlp.leftMargin = dp(3);
                mlp.rightMargin = dp(3);
            }
            button.setLayoutParams(rawLp);
        }
        if (button instanceof android.widget.Button) ((android.widget.Button) button).setAllCaps(false);
    }

    private void styleDialogLinkFont(TextView button) {
        if (button == null || "capsule_action".equals(button.getTag())) return;
        // Font size stays exactly as before. The large Android button slot remains the touch target,
        // while LinkCapsuleDrawable paints only a compact 26dp-high capsule behind the text.
        button.setTextColor(button.isEnabled() ? WHITE : LGRAY);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setIncludeFontPadding(false);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(new LinkCapsuleDrawable(button));
        if (button instanceof android.widget.Button) ((android.widget.Button) button).setAllCaps(false);
    }

    private View productSearchInputHolder(EditText input) {
        FrameLayout holder = new FrameLayout(this);
        holder.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        int left = input.getPaddingLeft();
        int top = input.getPaddingTop();
        int bottom = input.getPaddingBottom();
        input.setPadding(left, top, dp(46), bottom);

        TextView clear = text("×", 24, DGRAY, true);
        clear.setGravity(Gravity.CENTER);
        clear.setContentDescription("検索文字を消去");
        clear.setVisibility(input.length() == 0 ? View.GONE : View.VISIBLE);
        clear.setOnClickListener(v -> {
            input.setText("");
            input.requestFocus();
            DiagLog.write(this, "PRODUCT_SEARCH_CLEAR");
        });
        FrameLayout.LayoutParams clearLp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.END | Gravity.CENTER_VERTICAL);
        clearLp.rightMargin = dp(3);
        holder.addView(clear, clearLp);

        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                clear.setVisibility(s == null || s.length() == 0 ? View.GONE : View.VISIBLE);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        return holder;
    }

    private EditText dialogInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setTextSize(17);
        input.setTextColor(DGRAY);
        input.setHintTextColor(GRAY);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setIncludeFontPadding(false);
        input.setMinHeight(dp(48));
        input.setPadding(dp(16), 0, dp(16), 0);
        input.setBackground(roundRect(NWHITE, 999));
        applyDarkInputCursor(input);
        input.setOnFocusChangeListener((v, hasFocus) -> input.setBackground(roundRect(NWHITE, 999)));
        return input;
    }

    private void showFieldError(EditText input, String message) {
        if (input == null) return;
        clearFieldError(input);

        // Do not use Android's EditText.setError popup here: its icon/pointer color is supplied by
        // the framework and stayed bright red on Android 16 even when colorError was overridden.
        // PriceRec owns the whole error surface so N Light Red is deterministic on every device.
        final Drawable[] before = input.getCompoundDrawablesRelative().clone();
        activeFieldErrorOriginalDrawables.put(input, before);
        final Drawable start = before.length > 0 ? before[0] : null;
        final Drawable top = before.length > 1 ? before[1] : null;
        final Drawable bottom = before.length > 3 ? before[3] : null;
        final ErrorBadgeDrawable badge = new ErrorBadgeDrawable();
        input.setCompoundDrawablePadding(dp(8));
        input.setCompoundDrawablesRelativeWithIntrinsicBounds(start, top, badge, bottom);
        input.requestFocus();
        input.announceForAccessibility(message);

        final int popupWidth = dp(220);
        final int pointerHeight = dp(10);
        final int bodyHeight = dp(58);
        final FrameLayout popupRoot = new FrameLayout(this);

        final LinearLayout body = new LinearLayout(this);
        body.setGravity(Gravity.CENTER_VERTICAL);
        body.setPadding(dp(18), dp(6), dp(18), dp(6));
        body.setBackground(roundRect(Color.WHITE, 0));
        FrameLayout.LayoutParams bodyLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, bodyHeight);
        bodyLp.topMargin = pointerHeight;
        popupRoot.addView(body, bodyLp);

        View topRule = new View(this);
        topRule.setBackgroundColor(LRED);
        FrameLayout.LayoutParams ruleLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3));
        ruleLp.topMargin = pointerHeight;
        popupRoot.addView(topRule, ruleLp);

        View pointer = new View(this);
        pointer.setBackground(new ErrorPointerDrawable());
        FrameLayout.LayoutParams pointerLp = new FrameLayout.LayoutParams(dp(22), pointerHeight, Gravity.TOP | Gravity.END);
        pointerLp.rightMargin = dp(28);
        popupRoot.addView(pointer, pointerLp);

        TextView errorText = text(message == null ? "" : message, 17, Color.BLACK, false);
        errorText.setGravity(Gravity.CENTER_VERTICAL);
        errorText.setIncludeFontPadding(false);
        body.addView(errorText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final PopupWindow popup = new PopupWindow(popupRoot, popupWidth, pointerHeight + bodyHeight, false);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(8));
        activeFieldErrorPopups.put(input, popup);

        input.post(() -> {
            if (!input.isAttachedToWindow()) return;
            int xOffset = input.getWidth() - popupWidth;
            popup.showAsDropDown(input, xOffset, -dp(2));
        });

        TextWatcher clearOnEdit = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                input.post(() -> clearFieldError(input));
            }
            @Override public void afterTextChanged(Editable s) { }
        };
        activeFieldErrorWatchers.put(input, clearOnEdit);
        input.addTextChangedListener(clearOnEdit);
    }

    private void clearFieldError(EditText input) {
        if (input == null) return;
        PopupWindow popup = activeFieldErrorPopups.remove(input);
        if (popup != null && popup.isShowing()) popup.dismiss();
        TextWatcher watcher = activeFieldErrorWatchers.remove(input);
        if (watcher != null) input.removeTextChangedListener(watcher);
        Drawable[] original = activeFieldErrorOriginalDrawables.remove(input);
        if (original != null && original.length >= 4) {
            input.setCompoundDrawablesRelativeWithIntrinsicBounds(
                    original[0], original[1], original[2], original[3]);
        }
    }

    private final class ErrorBadgeDrawable extends Drawable {
        private final Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint markPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        ErrorBadgeDrawable() {
            circlePaint.setColor(LRED);
            circlePaint.setStyle(Paint.Style.FILL);
            markPaint.setColor(Color.WHITE);
            markPaint.setStyle(Paint.Style.FILL);
            markPaint.setTextAlign(Paint.Align.CENTER);
            markPaint.setTypeface(Typeface.DEFAULT_BOLD);
            markPaint.setTextSize(dp(19));
        }

        @Override public void draw(Canvas canvas) {
            float cx = getBounds().exactCenterX();
            float cy = getBounds().exactCenterY();
            float radius = Math.min(getBounds().width(), getBounds().height()) * 0.44f;
            canvas.drawCircle(cx, cy, radius, circlePaint);
            Paint.FontMetrics fm = markPaint.getFontMetrics();
            float baseline = cy - (fm.ascent + fm.descent) / 2f;
            canvas.drawText("!", cx, baseline, markPaint);
        }

        @Override public void setAlpha(int alpha) { circlePaint.setAlpha(alpha); markPaint.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) {
            circlePaint.setColorFilter(colorFilter); markPaint.setColorFilter(colorFilter);
        }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
        @Override public int getIntrinsicWidth() { return dp(28); }
        @Override public int getIntrinsicHeight() { return dp(28); }
    }

    private final class ErrorPointerDrawable extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ErrorPointerDrawable() { paint.setColor(LRED); paint.setStyle(Paint.Style.FILL); }
        @Override public void draw(Canvas canvas) {
            android.graphics.Path path = new android.graphics.Path();
            path.moveTo(0f, getBounds().height());
            path.lineTo(getBounds().width() / 2f, 0f);
            path.lineTo(getBounds().width(), getBounds().height());
            path.close();
            canvas.drawPath(path, paint);
        }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private void applyDarkInputCursor(EditText input) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            GradientDrawable cursor = new GradientDrawable();
            cursor.setColor(DGRAY);
            cursor.setSize(dp(2), dp(28));
            input.setTextCursorDrawable(cursor);
        }
    }

    private View storeNameInputHolder(EditText input) {
        return storeNameInputHolder(input, 0);
    }

    private View storeNameInputHolder(EditText input, int topPaddingDp) {
        LinearLayout holder = new LinearLayout(this);
        holder.setGravity(Gravity.CENTER_VERTICAL);
        holder.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(topPaddingDp), dp(UI_DIALOG_MARGIN_DP), 0);
        holder.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        return holder;
    }

    private boolean isImeVisible() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsets insets = getWindow().getDecorView().getRootWindowInsets();
            return insets != null && insets.isVisible(WindowInsets.Type.ime());
        }
        return false;
    }

    private void focusDialogInput(EditText input, AlertDialog dialog, boolean imeWasVisible) {
        Window w = dialog.getWindow();
        if (w != null) {
            int state = imeWasVisible ? WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED
                    : WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE;
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | state);
        }
        if (imeWasVisible) {
            // The IME is already on screen: only move focus, do not hide/show it again.
            input.requestFocus();
            input.setSelection(input.length());
        } else {
            input.postDelayed(() -> {
                input.requestFocus();
                input.setSelection(input.length());
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            }, 90);
        }
    }

    private void focusAndShowKeyboard(EditText input, AlertDialog dialog) {
        focusDialogInput(input, dialog, false);
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private void configureAutoFadeScrollbar(View scrollable) {
        scrollable.setScrollbarFadingEnabled(true);
        scrollable.setScrollBarDefaultDelayBeforeFade(850);
        scrollable.setScrollBarFadeDuration(300);
        scrollable.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    }

    private ScrollView newAutoFadeScrollView() {
        ScrollView scroll = new ScrollView(this);
        configureAutoFadeScrollbar(scroll);
        return scroll;
    }

    private HorizontalScrollView newAutoFadeHorizontalScrollView() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        configureAutoFadeScrollbar(scroll);
        return scroll;
    }

    private FrameLayout withFastScroll(ScrollView scroll) {
        FrameLayout frame = new FrameLayout(this);
        scroll.setVerticalScrollBarEnabled(false);
        frame.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Wider transparent grip area; visible thumb is fixed 12x58dp.
        // It appears while scrolling/dragging, then naturally fades after inactivity.
        FrameLayout grip = new FrameLayout(this);
        grip.setContentDescription("スクロールグリップ");
        grip.setClickable(true);
        grip.setFocusable(true);
        grip.setAlpha(0f);
        FrameLayout.LayoutParams gripLp = new FrameLayout.LayoutParams(dp(32), dp(58), Gravity.END | Gravity.TOP);
        gripLp.topMargin = dp(4);
        frame.addView(grip, gripLp);

        View thumb = new View(this);
        thumb.setBackground(roundRect(LGRAY, 999));
        thumb.setContentDescription("スクロールサム");
        FrameLayout.LayoutParams thumbLp = new FrameLayout.LayoutParams(dp(12), dp(58), Gravity.CENTER);
        grip.addView(thumb, thumbLp);

        final Runnable[] hideGrip = new Runnable[1];
        final Runnable[] showGrip = new Runnable[1];
        hideGrip[0] = () -> grip.animate().alpha(0f).setDuration(280).start();
        showGrip[0] = () -> {
            if (grip.getVisibility() != View.VISIBLE) return;
            grip.removeCallbacks(hideGrip[0]);
            grip.animate().cancel();
            grip.setAlpha(1f);
            grip.postDelayed(hideGrip[0], 900L);
        };

        final Runnable[] update = new Runnable[1];
        update[0] = () -> {
            if (scroll.getChildCount() == 0 || frame.getHeight() <= 0) return;
            int range = Math.max(0, scroll.getChildAt(0).getHeight() - scroll.getHeight());
            if (range <= 0) {
                grip.setVisibility(View.GONE);
                return;
            }
            if (grip.getVisibility() != View.VISIBLE) {
                grip.setVisibility(View.VISIBLE);
                grip.setAlpha(0f);
            }
            int top = dp(4);
            int travel = Math.max(1, frame.getHeight() - grip.getHeight() - dp(8));
            float fraction = Math.max(0f, Math.min(1f, scroll.getScrollY() / (float) range));
            grip.setTranslationY(top + fraction * travel);
        };
        scroll.setOnScrollChangeListener((v, sx, sy, oldSx, oldSy) -> {
            update[0].run();
            if (sy != oldSy) showGrip[0].run();
        });

        final float[] grabOffset = {0f};
        grip.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    grabOffset[0] = event.getY();
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    thumb.setBackground(roundRect(NWHITE, 999));
                    showGrip[0].run();
                    v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (scroll.getChildCount() == 0) return true;
                    int range = Math.max(0, scroll.getChildAt(0).getHeight() - scroll.getHeight());
                    int top = dp(4);
                    int travel = Math.max(1, frame.getHeight() - grip.getHeight() - dp(8));
                    int[] loc = new int[2];
                    frame.getLocationOnScreen(loc);
                    float wanted = event.getRawY() - loc[1] - grabOffset[0] - top;
                    float fraction = Math.max(0f, Math.min(1f, wanted / travel));
                    scroll.scrollTo(scroll.getScrollX(), Math.round(range * fraction));
                    update[0].run();
                    showGrip[0].run();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    thumb.setBackground(roundRect(LGRAY, 999));
                    showGrip[0].run();
                    return true;
                default:
                    return true;
            }
        });
        frame.post(update[0]);
        return frame;
    }

    private void showRoundedDialog(AlertDialog dialog) {
        showRoundedDialog(dialog, false);
    }

    private void showRoundedDialog(AlertDialog dialog, boolean wide) {
        dialog.show();
        // System dialog buttons and custom text links use the same typography as "全て表示".
        TextView negative = dialog.getButton(DialogInterface.BUTTON_NEGATIVE);
        TextView neutral = dialog.getButton(DialogInterface.BUTTON_NEUTRAL);
        TextView positive = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
        styleDialogLinkFont(negative);
        styleDialogLinkFont(neutral);
        styleDialogLinkFont(positive);
        // Large button slots remain clickable, but the visible text is anchored independently to the slot edge.
        if (negative != null && !"capsule_action".equals(negative.getTag()))
            negative.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        if (neutral != null && !"capsule_action".equals(neutral.getTag()))
            neutral.setGravity(Gravity.CENTER);
        if (positive != null && !"capsule_action".equals(positive.getTag()))
            positive.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        Window window = dialog.getWindow();
        if (window == null) return;
        normalizeDialogChrome(window);
        window.setBackgroundDrawable(roundRect(GRAY, 20));
        if (wide) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private void normalizeDialogChrome(Window window) {
        if (window == null) return;
        int alertTitleId = getResources().getIdentifier("alertTitle", "id", "android");
        View alertTitle = alertTitleId == 0 ? null : window.findViewById(alertTitleId);
        if (alertTitle instanceof TextView) {
            TextView title = (TextView) alertTitle;
            title.setPadding(0, 0, 0, 0);
            title.setIncludeFontPadding(false);
        }
        int titleTemplateId = getResources().getIdentifier("title_template", "id", "android");
        View titleTemplate = titleTemplateId == 0 ? null : window.findViewById(titleTemplateId);
        if (titleTemplate != null) {
            titleTemplate.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP),
                    dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP));
        }
        int buttonPanelId = getResources().getIdentifier("buttonPanel", "id", "android");
        View buttonPanel = buttonPanelId == 0 ? null : window.findViewById(buttonPanelId);
        if (buttonPanel != null) {
            buttonPanel.setPadding(dp(UI_DIALOG_MARGIN_DP), dp(UI_SPACING_DP),
                    dp(UI_DIALOG_MARGIN_DP), dp(UI_DIALOG_EDGE_MARGIN_DP));
        }
    }

    private GradientDrawable roundRect(int fill, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable circle(int fill) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }


    private final class TagDeleteIconView extends View {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint xPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        TagDeleteIconView(Context context) {
            super(context);
            fillPaint.setColor(RED);
            fillPaint.setStyle(Paint.Style.FILL);
            xPaint.setColor(NWHITE);
            xPaint.setStyle(Paint.Style.STROKE);
            xPaint.setStrokeWidth(dp(1));
            xPaint.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float radius = Math.min(getWidth(), getHeight()) / 2f;
            canvas.drawCircle(cx, cy, radius, fillPaint);
            float half = Math.min(getWidth(), getHeight()) * 0.189f;
            canvas.drawLine(cx - half, cy - half, cx + half, cy + half, xPaint);
            canvas.drawLine(cx + half, cy - half, cx - half, cy + half, xPaint);
        }
    }

    private final class DocumentListIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        DocumentListIconView(Context context) {
            super(context);
            paint.setColor(NWHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            canvas.save();
            canvas.scale(0.88f, 0.88f, w / 2f, h / 2f);

            // Two stacked documents, based on the user's hand-drawn reference.
            // Rear sheet sits slightly up/right; front sheet has a folded upper-right corner.
            float rearLeft = w * 0.38f;
            float rearTop = h * 0.23f;
            float rearRight = w * 0.72f;
            float rearBottom = h * 0.70f;
            android.graphics.Path rear = new android.graphics.Path();
            rear.moveTo(rearLeft, rearTop);
            rear.lineTo(rearRight, rearTop);
            rear.lineTo(rearRight, rearBottom);
            rear.lineTo(w * 0.63f, rearBottom);
            canvas.drawPath(rear, paint);

            float left = w * 0.28f;
            float top = h * 0.32f;
            float right = w * 0.63f;
            float bottom = h * 0.79f;
            float foldX = w * 0.51f;
            float foldY = h * 0.32f;
            float foldBottom = h * 0.45f;

            android.graphics.Path front = new android.graphics.Path();
            front.moveTo(left, top);
            front.lineTo(foldX, top);
            front.lineTo(right, foldBottom);
            front.lineTo(right, bottom);
            front.lineTo(left, bottom);
            front.close();
            canvas.drawPath(front, paint);

            android.graphics.Path fold = new android.graphics.Path();
            fold.moveTo(foldX, foldY);
            fold.lineTo(foldX, foldBottom);
            fold.lineTo(right, foldBottom);
            canvas.drawPath(fold, paint);

            float lineLeft = w * 0.34f;
            float lineRight = w * 0.55f;
            canvas.drawLine(lineLeft, h * 0.50f, lineRight, h * 0.50f, paint);
            canvas.drawLine(lineLeft, h * 0.59f, lineRight, h * 0.59f, paint);
            canvas.drawLine(lineLeft, h * 0.68f, lineRight, h * 0.68f, paint);
            canvas.restore();
        }
    }

    private final class TagManageIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint holePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        TagManageIconView(Context context) {
            super(context);
            paint.setColor(NWHITE);
            paint.setStyle(Paint.Style.FILL);
            holePaint.setColor(GRAY);
            holePaint.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * 0.50f;
            float cy = h * 0.50f;

            // Keep the 48dp circular button unchanged; shrink only the glyph inside it.
            canvas.save();
            canvas.scale(0.88f, 0.88f, cx, cy);

            // Flat 2D tag silhouette. Build it face-on with parallel sides, then rotate as one rigid shape.
            // This keeps the requested mirrored direction without perspective/skew distortion.
            canvas.save();
            canvas.rotate(45f, cx, cy);

            android.graphics.Path path = new android.graphics.Path();
            float left = w * 0.34f;
            float right = w * 0.66f;
            float top = h * 0.20f;
            float bottom = h * 0.80f;
            float r = Math.min(w, h) * 0.12f;

            path.moveTo(left + r, top);
            path.lineTo(right - r, top);
            path.quadTo(right, top, right, top + r);
            path.lineTo(right, bottom - r * 0.55f);
            path.quadTo(right, bottom, right - r * 0.55f, bottom);
            path.lineTo(left + r * 0.55f, bottom);
            path.quadTo(left, bottom, left, bottom - r * 0.55f);
            path.lineTo(left, top + r);
            path.quadTo(left, top, left + r, top);
            path.close();

            canvas.drawPath(path, paint);
            canvas.drawCircle(cx, h * 0.31f, Math.min(w, h) * 0.072f, holePaint);
            canvas.restore();
            canvas.restore();
        }
    }

    private final class CardPhotoScrollView extends ScrollView {
        CardPhotoScrollView(Context context) {
            super(context);
            setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = View.MeasureSpec.getSize(widthMeasureSpec);
            int cellWidth = Math.max(1, width / 3);
            // Tile = square image (cell minus horizontal tile padding) + 6dp gap + 44dp text panel + tile vertical padding.
            int rowHeight = Math.max(dp(1), cellWidth - dp(6) + dp(58));
            int rowCount = 1;
            if (getChildCount() > 0 && getChildAt(0) instanceof ViewGroup) {
                rowCount = Math.max(1, ((ViewGroup) getChildAt(0)).getChildCount());
            }
            // 1-3 photos: one row. 4+ photos: at most two visible rows; overflow scrolls inside.
            int visibleRows = Math.min(2, rowCount);
            int targetHeight = rowHeight * visibleRows;
            int fixedHeight = View.MeasureSpec.makeMeasureSpec(targetHeight, View.MeasureSpec.EXACTLY);
            super.onMeasure(widthMeasureSpec, fixedHeight);
            setMeasuredDimension(getMeasuredWidth(), targetHeight);
        }
    }

    private final class SquareFrameLayout extends FrameLayout {
        SquareFrameLayout(Context context) {
            super(context);
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = View.MeasureSpec.getSize(widthMeasureSpec);
            int square = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
            super.onMeasure(widthMeasureSpec, square);
            setMeasuredDimension(getMeasuredWidth(), getMeasuredWidth());
        }
    }

    private final class MagnifierIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        MagnifierIconView(Context context) {
            super(context);
            paint.setColor(LBLUE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setStrokeCap(Paint.Cap.SQUARE);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * 0.43f;
            float cy = h * 0.45f;
            float r = Math.min(w, h) * 0.16f;
            canvas.drawCircle(cx, cy, r, paint);
            float startX = cx + r * 0.72f;
            float startY = cy + r * 0.72f;
            canvas.drawLine(startX, startY, w * 0.72f, h * 0.68f, paint);
        }
    }

    private final class StraightSelectionCheckView extends View {
        private final Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        StraightSelectionCheckView(Context context) {
            super(context);
            checkPaint.setColor(NWHITE);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(dp(2));
            checkPaint.setStrokeCap(Paint.Cap.SQUARE);
            checkPaint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            canvas.drawLine(w * 0.14f, h * 0.52f, w * 0.40f, h * 0.76f, checkPaint);
            canvas.drawLine(w * 0.40f, h * 0.76f, w * 0.86f, h * 0.25f, checkPaint);
        }
    }

    private final class StraightCheckBadgeView extends View {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        StraightCheckBadgeView(Context context) {
            super(context);
            fillPaint.setColor(CHECK_GREEN);
            fillPaint.setStyle(Paint.Style.FILL);
            checkPaint.setColor(WHITE);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(dp(2));
            checkPaint.setStrokeCap(Paint.Cap.SQUARE);
            checkPaint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(w, h) / 2f;
            canvas.drawCircle(w / 2f, h / 2f, r, fillPaint);
            canvas.drawLine(w * 0.27f, h * 0.53f, w * 0.44f, h * 0.69f, checkPaint);
            canvas.drawLine(w * 0.44f, h * 0.69f, w * 0.76f, h * 0.34f, checkPaint);
        }
    }

    private final class ZoomImageView extends ImageView {
        private final Matrix zoomMatrix = new Matrix();
        private final ScaleGestureDetector scaleDetector;
        private final GestureDetector gestureDetector;
        private float scale = 1f;
        private float minScale = 0.1f;
        private final float maxScale = 8f;
        private float lastX;
        private float lastY;
        private boolean dragging;

        ZoomImageView(Context context) {
            super(context);
            setScaleType(ScaleType.MATRIX);
            scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float wanted = scale * detector.getScaleFactor();
                    float clamped = Math.max(minScale, Math.min(maxScale, wanted));
                    float factor = clamped / scale;
                    zoomMatrix.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                    scale = clamped;
                    setImageMatrix(zoomMatrix);
                    return true;
                }
            });
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    resetToOriginalPixels();
                    return true;
                }
            });
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            post(this::resetToOriginalPixels);
        }

        private void resetToOriginalPixels() {
            if (getDrawable() == null || getWidth() <= 0 || getHeight() <= 0) return;
            int dw = Math.max(1, getDrawable().getIntrinsicWidth());
            int dh = Math.max(1, getDrawable().getIntrinsicHeight());
            minScale = Math.min(1f, Math.min((float) getWidth() / dw, (float) getHeight() / dh));
            scale = 1f;
            zoomMatrix.reset();
            float dx = (getWidth() - dw) / 2f;
            float dy = (getHeight() - dh) / 2f;
            zoomMatrix.postTranslate(dx, dy);
            setImageMatrix(zoomMatrix);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);
            gestureDetector.onTouchEvent(event);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    dragging = true;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging && !scaleDetector.isInProgress() && event.getPointerCount() == 1) {
                        float dx = event.getX() - lastX;
                        float dy = event.getY() - lastY;
                        zoomMatrix.postTranslate(dx, dy);
                        setImageMatrix(zoomMatrix);
                        lastX = event.getX();
                        lastY = event.getY();
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerCount() - 1 == 1) {
                        int remain = event.getActionIndex() == 0 ? 1 : 0;
                        if (remain < event.getPointerCount()) {
                            lastX = event.getX(remain);
                            lastY = event.getY(remain);
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
                default:
                    return true;
            }
        }
    }

    private static final class DragPayload {
        final String type; final long id;
        DragPayload(String type, long id) { this.type = type; this.id = id; }
    }

    private static final class PendingImage {
        final Uri uri;
        final boolean managed;
        final String cameraTempPath;
        PendingImage(Uri uri, boolean managed, String cameraTempPath) {
            this.uri = uri;
            this.managed = managed;
            this.cameraTempPath = cameraTempPath;
        }
    }

    private static final class ImportPreviewRow {
        static final String ADD = "追加";
        static final String UPDATE = "更新";
        static final String SKIP = "スキップ";
        final CsvImporter.Row row;
        String status = "";
        String action = ADD;
        long existingProductId = -1L;
        boolean refreshReference = false;
        String resolvedProductKey = "";
        ImportPreviewRow(CsvImporter.Row row) { this.row = row; }
    }

    private static final class OcrEditorRow {
        final LinearLayout row; final EditText name; final EditText price;
        OcrEditorRow(LinearLayout row, EditText name, EditText price) { this.row = row; this.name = name; this.price = price; }
    }
}
