package com.pricerec.app;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Insets;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.GestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;

import org.json.JSONArray;

import java.io.InputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

public final class MainActivity extends ComponentActivity {
    private static final int REQ_CAMERA = 4101;

    private static final int BG = Color.parseColor("#303030");
    private static final int DGRAY = Color.parseColor("#2A2222");
    private static final int GRAY = Color.parseColor("#3A3333");
    private static final int LGRAY = Color.parseColor("#5A5555");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int LBLUE = Color.parseColor("#445577");
    private static final int RED = Color.parseColor("#441100");
    private static final int LRED = Color.parseColor("#882211");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int CSV_GREEN = Color.parseColor("#2E7D32");
    private static final int WHITE = Color.WHITE;
    private static final int SECONDARY = Color.parseColor("#C9C4C4");

    private DatabaseHelper db;
    private LinearLayout storeContainer;
    private EditText searchInput;
    private LinearLayout searchCandidateRow;
    private LinearLayout searchCandidateChips;
    private TextView searchCandidateDelete;
    private boolean searchCandidateSelectionMode = false;
    private final Set<String> selectedSearchCandidates = new HashSet<>();
    private static final String PREF_SEARCH_CANDIDATES = "search_candidates_v1";
    private long expandedStoreId = -1L; // last-opened store, kept for backward state compatibility
    private final Set<Long> expandedStoreIds = new HashSet<>();
    private final Map<Long, String> activeTab = new HashMap<>();
    private final Map<Long, LinearLayout> storeCardViews = new HashMap<>();
    private final Map<Long, LinearLayout> storeDetailViews = new HashMap<>();
    private View draggingStoreCard;
    private long draggingStoreId = -1L;
    private int draggingStoreSourceIndex = -1;
    private int draggingStoreTargetIndex = -1;
    private float draggingStoreGrabOffsetY = 0f;
    private int draggingStoreSlotHeight = 0;
    private boolean draggingStoreDropCommitted = false;

    private Uri pendingPhotoUri;
    private long pendingStoreId = -1L;
    private Long pendingTagId = null;

    private long pendingImportStoreId = -1L;
    private Long pendingImportTagId = null;

    private long shareSelectionStoreId = -1L;
    private final Set<Long> shareSelectedPhotoIds = new HashSet<>();

    private long productSelectionStoreId = -1L;
    private final Set<Long> selectedProductIds = new HashSet<>();

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);

    private final ActivityResultLauncher<PickVisualMediaRequest> photoPicker =
            registerForActivityResult(new ActivityResultContracts.PickMultipleVisualMedia(100), this::handlePhotoPickerUris);

    private final ActivityResultLauncher<String[]> csvPicker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::handleCsvPicked);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DatabaseHelper(this);
        DiagLog.write(this, "APP_START version=" + DiagLog.versionName(this));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        if (state != null) {
            String uri = state.getString("pending_uri");
            if (uri != null) pendingPhotoUri = Uri.parse(uri);
            pendingStoreId = state.getLong("pending_store", -1L);
            long tag = state.getLong("pending_tag", Long.MIN_VALUE);
            pendingTagId = tag == Long.MIN_VALUE ? null : tag;
            pendingImportStoreId = state.getLong("pending_import_store", -1L);
            long importTag = state.getLong("pending_import_tag", Long.MIN_VALUE);
            pendingImportTagId = importTag == Long.MIN_VALUE ? null : importTag;
            expandedStoreId = state.getLong("expanded_store", -1L);
            long[] expandedIds = state.getLongArray("expanded_store_ids");
            if (expandedIds != null) {
                for (long id : expandedIds) expandedStoreIds.add(id);
            } else if (expandedStoreId >= 0) {
                expandedStoreIds.add(expandedStoreId);
            }
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                top = bars.top;
                bottom = Math.max(bars.bottom, ime.bottom);
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(14), top + dp(8), dp(14), bottom + dp(8));
            return insets;
        });

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(dp(4), dp(2), 0, dp(10));

        TextView title = text("PRICE REC.", 25, WHITE, true);
        title.setLetterSpacing(0.08f);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));

        TextView appMenu = text("⋮", 26, SECONDARY, true);
        appMenu.setGravity(Gravity.CENTER);
        appMenu.setContentDescription("アプリメニュー");
        appMenu.setOnClickListener(v -> showAppMenu());
        titleRow.addView(appMenu, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(titleRow);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        storeContainer = new LinearLayout(this);
        storeContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(storeContainer, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(makeBottomBar());
        setContentView(root);
        root.requestApplyInsets();
        reloadStores();
        handleIncomingCsvIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingCsvIntent(intent);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (searchCandidateSelectionMode && event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            if (!isTouchInside(event, searchCandidateRow)) {
                exitSearchCandidateSelection();
            }
        }
        return super.dispatchTouchEvent(event);
    }

    private boolean isTouchInside(MotionEvent event, View view) {
        if (view == null || view.getVisibility() != View.VISIBLE) return false;
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        float x = event.getRawX();
        float y = event.getRawY();
        return x >= location[0] && x <= location[0] + view.getWidth()
                && y >= location[1] && y <= location[1] + view.getHeight();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (pendingPhotoUri != null) out.putString("pending_uri", pendingPhotoUri.toString());
        out.putLong("pending_store", pendingStoreId);
        out.putLong("pending_tag", pendingTagId == null ? Long.MIN_VALUE : pendingTagId);
        out.putLong("pending_import_store", pendingImportStoreId);
        out.putLong("pending_import_tag", pendingImportTagId == null ? Long.MIN_VALUE : pendingImportTagId);
        out.putLong("expanded_store", expandedStoreId);
        long[] expandedIds = new long[expandedStoreIds.size()];
        int expandedIndex = 0;
        for (Long id : expandedStoreIds) expandedIds[expandedIndex++] = id;
        out.putLongArray("expanded_store_ids", expandedIds);
    }

    private View makeBottomBar() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(6), 0, 0);

        searchCandidateRow = new LinearLayout(this);
        searchCandidateRow.setGravity(Gravity.CENTER_VERTICAL);
        searchCandidateRow.setPadding(0, 0, 0, dp(6));

        HorizontalScrollView candidateScroll = new HorizontalScrollView(this);
        candidateScroll.setHorizontalScrollBarEnabled(false);
        candidateScroll.setFillViewport(false);
        searchCandidateChips = new LinearLayout(this);
        searchCandidateChips.setOrientation(LinearLayout.HORIZONTAL);
        searchCandidateChips.setGravity(Gravity.CENTER_VERTICAL);
        candidateScroll.addView(searchCandidateChips, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));
        searchCandidateRow.addView(candidateScroll, new LinearLayout.LayoutParams(0, dp(36), 1f));

        searchCandidateDelete = button("削除", LRED, 13);
        searchCandidateDelete.setVisibility(View.GONE);
        searchCandidateDelete.setOnClickListener(v -> deleteSelectedSearchCandidates());
        LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(dp(72), dp(36));
        deleteLp.leftMargin = dp(8);
        searchCandidateRow.addView(searchCandidateDelete, deleteLp);
        box.addView(searchCandidateRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(WHITE);
        searchInput.setTextSize(16);
        searchInput.setHint("");
        searchInput.setGravity(Gravity.CENTER_VERTICAL);
        searchInput.setIncludeFontPadding(false);
        searchInput.setPadding(dp(16), 0, dp(16), 0);
        searchInput.setBackground(roundRect(LGRAY, 24));
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setOnFocusChangeListener((v, focused) -> searchInput.setBackground(roundRect(LGRAY, 24)));
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        searchLp.rightMargin = dp(12);
        row.addView(searchInput, searchLp);

        TextView add = text("＋", 24, WHITE, true);
        add.setGravity(Gravity.CENTER);
        add.setBackground(circle(LBLUE));
        add.setContentDescription("新規店舗");
        add.setOnClickListener(v -> showAddStoreDialog());
        row.addView(add, new LinearLayout.LayoutParams(dp(48), dp(48)));
        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        refreshSearchCandidates();
        return box;
    }

    private List<String> loadSearchCandidates() {
        ArrayList<String> out = new ArrayList<>();
        String raw = getPreferences(MODE_PRIVATE).getString(PREF_SEARCH_CANDIDATES, "");
        if (raw == null || raw.isEmpty()) return out;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i, "").trim();
                if (!value.isEmpty() && !out.contains(value)) out.add(value);
            }
        } catch (Exception e) {
            DiagLog.write(this, "SEARCH_CANDIDATE_LOAD_ERROR " + e);
        }
        return out;
    }

    private void saveSearchCandidates(List<String> values) {
        JSONArray array = new JSONArray();
        for (String value : values) array.put(value);
        getPreferences(MODE_PRIVATE).edit()
                .putString(PREF_SEARCH_CANDIDATES, array.toString())
                .apply();
    }

    private void rememberSearchCandidate(String query) {
        String q = query == null ? "" : query.trim();
        if (q.isEmpty()) return;
        List<String> values = loadSearchCandidates();
        for (int i = values.size() - 1; i >= 0; i--) {
            if (values.get(i).equalsIgnoreCase(q)) values.remove(i);
        }
        values.add(0, q);
        saveSearchCandidates(values);
        refreshSearchCandidates();
        DiagLog.write(this, "SEARCH_CANDIDATE_SAVE q=" + q + " total=" + values.size());
    }

    private void refreshSearchCandidates() {
        if (searchCandidateRow == null || searchCandidateChips == null) return;
        List<String> values = loadSearchCandidates();
        searchCandidateChips.removeAllViews();
        for (String value : values) {
            boolean selected = selectedSearchCandidates.contains(value);
            TextView candidate = chip(value, selected, false);
            candidate.setOnLongClickListener(v -> {
                if (!searchCandidateSelectionMode) {
                    searchCandidateSelectionMode = true;
                    selectedSearchCandidates.clear();
                }
                selectedSearchCandidates.add(value);
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_START q=" + value);
                refreshSearchCandidates();
                return true;
            });
            candidate.setOnClickListener(v -> {
                if (searchCandidateSelectionMode) {
                    if (!selectedSearchCandidates.add(value)) selectedSearchCandidates.remove(value);
                    DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_TOGGLE q=" + value + " selected="
                            + selectedSearchCandidates.contains(value) + " count=" + selectedSearchCandidates.size());
                    refreshSearchCandidates();
                } else {
                    searchInput.setText(value);
                    searchInput.setSelection(searchInput.length());
                    runSearch(value);
                }
            });
            searchCandidateChips.addView(candidate);
        }
        searchCandidateDelete.setVisibility(searchCandidateSelectionMode ? View.VISIBLE : View.GONE);
        searchCandidateDelete.setAlpha(selectedSearchCandidates.isEmpty() ? 0.45f : 1f);
        searchCandidateRow.setVisibility(values.isEmpty() && !searchCandidateSelectionMode ? View.GONE : View.VISIBLE);
    }

    private void deleteSelectedSearchCandidates() {
        if (selectedSearchCandidates.isEmpty()) return;
        List<String> values = loadSearchCandidates();
        int before = values.size();
        values.removeIf(selectedSearchCandidates::contains);
        int removed = before - values.size();
        saveSearchCandidates(values);
        DiagLog.write(this, "SEARCH_CANDIDATE_DELETE count=" + removed);
        exitSearchCandidateSelection();
    }

    private void exitSearchCandidateSelection() {
        if (!searchCandidateSelectionMode && selectedSearchCandidates.isEmpty()) return;
        searchCandidateSelectionMode = false;
        selectedSearchCandidates.clear();
        refreshSearchCandidates();
        DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_CANCEL");
    }

    private void reloadStores() {
        if (storeContainer == null) return;
        storeCardViews.clear();
        storeDetailViews.clear();
        storeContainer.removeAllViews();
        List<DatabaseHelper.Store> stores = db.listStores();
        if (stores.isEmpty()) {
            TextView empty = text("右下の＋から店舗を追加", 16, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(80), 0, 0);
            storeContainer.addView(empty);
            return;
        }
        for (DatabaseHelper.Store store : stores) storeContainer.addView(makeStoreCard(store));
    }

    private View makeStoreCard(DatabaseHelper.Store store) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundRect(GRAY, 18));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(12);
        card.setLayoutParams(cardLp);
        storeCardViews.put(store.id, card);
        card.setTag(Long.valueOf(store.id));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(6), dp(8), dp(6), dp(8));

        TextView handle = text("☰", 22, SECONDARY, false);
        handle.setGravity(Gravity.CENTER);
        handle.setContentDescription("店舗を並べ替え");
        final float[] handleTouchY = {dp(24)};
        handle.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                handleTouchY[0] = event.getY();
            }
            return false;
        });
        handle.setOnLongClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            draggingStoreCard = card;
            draggingStoreId = store.id;
            draggingStoreSourceIndex = storeContainer.indexOfChild(card);
            draggingStoreTargetIndex = draggingStoreSourceIndex;
            draggingStoreGrabOffsetY = header.getTop() + handle.getTop() + handleTouchY[0];
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) card.getLayoutParams();
            draggingStoreSlotHeight = card.getHeight() + mlp.topMargin + mlp.bottomMargin;
            draggingStoreDropCommitted = false;
            card.setElevation(dp(12));
            card.animate().scaleX(1.015f).scaleY(1.015f).alpha(0.94f).setDuration(90).start();
            DragPayload payload = new DragPayload("store", store.id);
            ClipData data = ClipData.newPlainText("store_id", String.valueOf(store.id));
            DiagLog.write(this, "STORE_DRAG_START id=" + store.id + " name=" + store.name + " axis=y");
            v.startDragAndDrop(data, new InvisibleDragShadowBuilder(v), payload, 0);
            return true;
        });

        TextView name = text(store.name, 18, WHITE, true);
        name.setGravity(Gravity.CENTER_VERTICAL);

        header.addView(handle, new LinearLayout.LayoutParams(dp(48), dp(48)));
        header.addView(name, new LinearLayout.LayoutParams(0, dp(48), 1f));

        View.OnLongClickListener storeMenuLongPress = v -> {
            if (draggingStoreId >= 0) return true;
            card.setBackground(roundRect(LGRAY, 18));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                card.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            } else {
                card.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            }
            DiagLog.write(this, "STORE_MENU_LONG_PRESS id=" + store.id + " name=" + store.name);
            showStoreMenu(store, card);
            return true;
        };
        header.setOnLongClickListener(storeMenuLongPress);
        card.setOnLongClickListener(storeMenuLongPress);
        card.setOnDragListener((v, event) -> handleStoreDrag(card, store, event));
        card.addView(header);

        if (expandedStoreIds.contains(store.id)) {
            LinearLayout details = buildStoreDetails(store);
            card.addView(details);
            storeDetailViews.put(store.id, details);
        }

        header.setOnClickListener(v -> {
            if (draggingStoreId >= 0) return;
            if (expandedStoreIds.contains(store.id)) {
                animateCollapseStore(store.id, null);
            } else {
                animateExpandStore(store, card);
            }
        });
        return card;
    }

    private LinearLayout buildStoreDetails(DatabaseHelper.Store store) {
        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(12), 0, dp(12), dp(12));
        details.addView(makeTagSelector(store));
        details.addView(makeActionRow(store));
        details.addView(makePhotoGrid(store));
        return details;
    }

    private void animateExpandStore(DatabaseHelper.Store store, LinearLayout card) {
        if (expandedStoreIds.contains(store.id) && storeDetailViews.containsKey(store.id)) return;
        expandedStoreIds.add(store.id);
        expandedStoreId = store.id;
        DiagLog.write(this, "STORE_EXPAND id=" + store.id);
        LinearLayout details = buildStoreDetails(store);
        storeDetailViews.put(store.id, details);
        details.setAlpha(0f);
        details.setTranslationY(-dp(6));
        card.addView(details, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0));
        details.measure(
                View.MeasureSpec.makeMeasureSpec(Math.max(1, card.getWidth()), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int targetHeight = Math.max(1, details.getMeasuredHeight());
        ValueAnimator height = ValueAnimator.ofInt(0, targetHeight);
        height.setDuration(230);
        height.setInterpolator(new DecelerateInterpolator(1.5f));
        height.addUpdateListener(a -> {
            ViewGroup.LayoutParams lp = details.getLayoutParams();
            lp.height = (Integer) a.getAnimatedValue();
            details.setLayoutParams(lp);
        });
        height.start();
        details.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(24)
                .setDuration(190)
                .setInterpolator(new DecelerateInterpolator(1.4f))
                .withEndAction(() -> {
                    ViewGroup.LayoutParams lp = details.getLayoutParams();
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    details.setLayoutParams(lp);
                })
                .start();
    }

    private void animateCollapseStore(long storeId, Runnable after) {
        LinearLayout card = storeCardViews.get(storeId);
        LinearLayout details = storeDetailViews.get(storeId);
        if (card == null || details == null) {
            expandedStoreIds.remove(storeId);
            if (expandedStoreId == storeId) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
            if (after != null) after.run();
            return;
        }
        int startHeight = Math.max(1, details.getHeight());
        details.animate()
                .alpha(0f)
                .translationY(-dp(6))
                .setDuration(145)
                .setInterpolator(new DecelerateInterpolator(1.2f))
                .start();
        ValueAnimator height = ValueAnimator.ofInt(startHeight, 0);
        height.setDuration(190);
        height.setInterpolator(new DecelerateInterpolator(1.35f));
        height.addUpdateListener(a -> {
            ViewGroup.LayoutParams lp = details.getLayoutParams();
            lp.height = (Integer) a.getAnimatedValue();
            details.setLayoutParams(lp);
        });
        height.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                card.removeView(details);
                storeDetailViews.remove(storeId);
                expandedStoreIds.remove(storeId);
                if (expandedStoreId == storeId) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
                DiagLog.write(MainActivity.this, "STORE_COLLAPSE id=" + storeId);
                if (after != null) after.run();
            }
        });
        height.start();
    }

    private boolean handleStoreDrag(View targetView, DatabaseHelper.Store target, DragEvent event) {
        Object local = event.getLocalState();
        if (!(local instanceof DragPayload) || !"store".equals(((DragPayload) local).type)) {
            return event.getAction() != DragEvent.ACTION_DRAG_STARTED;
        }
        switch (event.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_LOCATION:
                if (draggingStoreCard == null || draggingStoreId < 0) return true;
                float globalY = targetView.getTop() + event.getY();
                float translationY = globalY - draggingStoreCard.getTop() - draggingStoreGrabOffsetY;
                draggingStoreCard.setTranslationX(0f);
                draggingStoreCard.setTranslationY(translationY);
                float draggedCenterY = draggingStoreCard.getTop() + translationY + draggingStoreCard.getHeight() / 2f;
                int nextTarget = computeStoreDragTargetIndex(draggedCenterY);
                if (nextTarget != draggingStoreTargetIndex) {
                    draggingStoreTargetIndex = nextTarget;
                    animateStoreDragSlots(nextTarget);
                    DiagLog.write(this, "STORE_DRAG_TARGET id=" + draggingStoreId + " index=" + nextTarget);
                }
                return true;
            case DragEvent.ACTION_DROP:
                finishStoreDrag(true);
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                if (!draggingStoreDropCommitted) finishStoreDrag(false);
                return true;
            default:
                return true;
        }
    }

    private int computeStoreDragTargetIndex(float draggedCenterY) {
        int count = storeContainer.getChildCount();
        int candidate = 0;
        for (int i = 0; i < count; i++) {
            if (i == draggingStoreSourceIndex) continue;
            View child = storeContainer.getChildAt(i);
            float mid = child.getTop() + child.getHeight() / 2f;
            if (draggedCenterY > mid) candidate++;
        }
        return Math.max(0, Math.min(count - 1, candidate));
    }

    private void animateStoreDragSlots(int targetIndex) {
        if (draggingStoreCard == null || draggingStoreSourceIndex < 0) return;
        for (int i = 0; i < storeContainer.getChildCount(); i++) {
            View child = storeContainer.getChildAt(i);
            if (child == draggingStoreCard) continue;
            float targetY = 0f;
            if (targetIndex > draggingStoreSourceIndex && i > draggingStoreSourceIndex && i <= targetIndex) {
                targetY = -draggingStoreSlotHeight;
            } else if (targetIndex < draggingStoreSourceIndex && i >= targetIndex && i < draggingStoreSourceIndex) {
                targetY = draggingStoreSlotHeight;
            }
            child.animate()
                    .translationY(targetY)
                    .setDuration(150)
                    .setInterpolator(new DecelerateInterpolator(1.55f))
                    .start();
        }
    }

    private void finishStoreDrag(boolean commit) {
        if (draggingStoreCard == null || draggingStoreId < 0) return;
        final View source = draggingStoreCard;
        final long sourceId = draggingStoreId;
        final int sourceIndex = draggingStoreSourceIndex;
        final int targetIndex = draggingStoreTargetIndex;
        if (commit && targetIndex >= 0 && targetIndex < storeContainer.getChildCount() && targetIndex != sourceIndex) {
            View targetView = storeContainer.getChildAt(targetIndex);
            Object tag = targetView.getTag();
            if (tag instanceof Long) {
                long targetId = (Long) tag;
                boolean after = targetIndex > sourceIndex;
                db.moveStore(sourceId, targetId, after);
                DiagLog.write(this, "STORE_REORDER dragged=" + sourceId + " target=" + targetId + " after=" + after);
                draggingStoreDropCommitted = true;
                float settleY = targetView.getTop() - source.getTop();
                source.animate()
                        .translationX(0f)
                        .translationY(settleY)
                        .scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(145)
                        .setInterpolator(new DecelerateInterpolator(1.6f))
                        .withEndAction(() -> {
                            clearStoreDragState();
                            reloadStores();
                        })
                        .start();
                return;
            }
        }
        for (int i = 0; i < storeContainer.getChildCount(); i++) {
            View child = storeContainer.getChildAt(i);
            if (child == source) continue;
            child.animate().translationY(0f).setDuration(130).setInterpolator(new DecelerateInterpolator()).start();
        }
        source.animate()
                .translationX(0f).translationY(0f)
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(145)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(this::clearStoreDragState)
                .start();
    }

    private void clearStoreDragState() {
        if (draggingStoreCard != null) draggingStoreCard.setElevation(0f);
        draggingStoreCard = null;
        draggingStoreId = -1L;
        draggingStoreSourceIndex = -1;
        draggingStoreTargetIndex = -1;
        draggingStoreGrabOffsetY = 0f;
        draggingStoreSlotHeight = 0;
        draggingStoreDropCommitted = false;
    }

    private static final class InvisibleDragShadowBuilder extends View.DragShadowBuilder {
        InvisibleDragShadowBuilder(View view) { super(view); }
        @Override public void onProvideShadowMetrics(android.graphics.Point size, android.graphics.Point touch) {
            size.set(1, 1);
            touch.set(0, 0);
        }
        @Override public void onDrawShadow(Canvas canvas) { }
    }

    private View makeTagSelector(DatabaseHelper.Store store) {
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(0, 0, 0, dp(4));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setFillViewport(false);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        long selected = selectedTagForStore(store.id);
        for (DatabaseHelper.Tag tag : db.listTags()) {
            TextView chip = chip(tag.name, selected == tag.id, false);
            chip.setOnClickListener(v -> {
                saveSelectedTag(store.id, tag.id);
                reloadStores();
            });
            row.addView(chip);
        }
        TextView none = chip("タグなし", selected < 0, true);
        none.setOnClickListener(v -> {
            saveSelectedTag(store.id, -1L);
            reloadStores();
        });
        row.addView(none);
        hsv.addView(row);
        line.addView(hsv, new LinearLayout.LayoutParams(0, dp(42), 1f));

        TextView manage = text("＋", 22, WHITE, true);
        manage.setGravity(Gravity.CENTER);
        manage.setBackground(circle(LBLUE));
        manage.setContentDescription("タグ管理");
        manage.setOnClickListener(v -> showTagManager());
        LinearLayout.LayoutParams plusLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        plusLp.leftMargin = dp(8);
        line.addView(manage, plusLp);
        return line;
    }

    private View makeActionRow(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(0, dp(8), 0, dp(8));

        LinearLayout row1 = new LinearLayout(this);
        TextView camera = button("撮影", BLUE, 16);
        camera.setOnClickListener(v -> takePhoto(store));
        TextView addImage = button("画像追加", BLUE, 15);
        addImage.setOnClickListener(v -> importImages(store));
        LinearLayout.LayoutParams r1a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r1a.rightMargin = dp(4);
        LinearLayout.LayoutParams r1b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r1b.leftMargin = dp(4);
        row1.addView(camera, r1a);
        row1.addView(addImage, r1b);
        outer.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setPadding(0, dp(8), 0, 0);
        TextView list = button("リスト", DGRAY, 15);
        list.setOnClickListener(v -> showProductTableDialog(store.name + " 店舗全体リスト", store.id, ""));
        TextView csv = button("CSV一覧", DGRAY, 15);
        csv.setOnClickListener(v -> showImportHistoryDialog(store.id));
        LinearLayout.LayoutParams r2a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r2a.rightMargin = dp(4);
        LinearLayout.LayoutParams r2b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r2b.leftMargin = dp(4);
        row2.addView(list, r2a);
        row2.addView(csv, r2b);
        outer.addView(row2);
        return outer;
    }

    private View makeTabs(DatabaseHelper.Store store) {
        String tab = activeTab.getOrDefault(store.id, "list");
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, 0, 0, dp(8));
        TextView list = button("リスト", "list".equals(tab) ? LBLUE : DGRAY, 15);
        list.setOnClickListener(v -> { activeTab.put(store.id, "list"); reloadStores(); });
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp1.rightMargin = dp(4);
        row.addView(list, lp1);
        TextView images = button("画像", "images".equals(tab) ? LBLUE : DGRAY, 15);
        images.setOnClickListener(v -> { activeTab.put(store.id, "images"); reloadStores(); });
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp2.leftMargin = dp(4);
        row.addView(images, lp2);
        return row;
    }

    private View makeStoreBody(DatabaseHelper.Store store) {
        return "images".equals(activeTab.getOrDefault(store.id, "list")) ? makePhotoGrid(store) : makeProductSheet(store);
    }

    private View makeProductSheet(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.ProductRecord> products = db.listProductsForStore(store.id);
        boolean selecting = productSelectionStoreId == store.id;

        if (!selecting) {
            LinearLayout bar = new LinearLayout(this);
            bar.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            bar.setPadding(dp(4), 0, dp(4), dp(8));
            TextView select = button("選択", DGRAY, 13);
            select.setOnClickListener(v -> {
                productSelectionStoreId = store.id;
                selectedProductIds.clear();
                DiagLog.write(this, "PRODUCT_SELECT_START store=" + store.id + " source=button");
                reloadStores();
            });
            bar.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
            outer.addView(bar);
        }

        if (selecting) {
            LinearLayout bar = new LinearLayout(this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setPadding(dp(4), 0, dp(4), dp(8));

            TextView count = text(selectedProductIds.size() + "件選択", 14, SECONDARY, true);
            bar.addView(count, new LinearLayout.LayoutParams(0, dp(40), 1f));

            TextView delete = button("削除", selectedProductIds.isEmpty() ? DGRAY : RED, 13);
            delete.setAlpha(selectedProductIds.isEmpty() ? 0.45f : 1f);
            delete.setOnClickListener(v -> {
                if (!selectedProductIds.isEmpty()) {
                    confirmDeleteProducts(new ArrayList<>(selectedProductIds), () -> {
                        cancelProductSelection();
                        reloadStores();
                    });
                }
            });
            LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(72), dp(38));
            delLp.rightMargin = dp(6);
            bar.addView(delete, delLp);

            TextView move = button("タグ移動", selectedProductIds.isEmpty() ? DGRAY : LBLUE, 13);
            move.setAlpha(selectedProductIds.isEmpty() ? 0.45f : 1f);
            move.setOnClickListener(v -> {
                if (!selectedProductIds.isEmpty()) {
                    showMoveProductsTagDialog(new ArrayList<>(selectedProductIds), () -> {
                        cancelProductSelection();
                        reloadStores();
                    });
                }
            });
            bar.addView(move, new LinearLayout.LayoutParams(dp(92), dp(38)));

            TextView cancel = button("キャンセル", DGRAY, 13);
            cancel.setOnClickListener(v -> {
                cancelProductSelection();
                reloadStores();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(96), dp(38));
            cp.leftMargin = dp(6);
            bar.addView(cancel, cp);
            outer.addView(bar);
        }

        if (products.isEmpty()) {
            TextView empty = text("商品データはまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.addView(sheetHeader(new String[]{"商品名", "価格", "容量", "タグ", "比較"}, new int[]{240, 100, 90, 100, 70}));
        for (DatabaseHelper.ProductRecord p : products) {
            LinearLayout row = sheetRow(new String[]{p.rawName, p.priceYen == null ? "—" : yen(p.priceYen),
                            p.volume == null ? "—" : p.volume, p.tagName == null ? "—" : p.tagName, "比較"},
                    new int[]{240, 100, 90, 100, 70});
            TextView compareCell = (TextView) row.getChildAt(4);
            compareCell.setTextColor(LBLUE);
            compareCell.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            compareCell.setGravity(Gravity.CENTER);
            compareCell.setOnClickListener(v -> {
                if (productSelectionStoreId == store.id) {
                    toggleProductSelection(p.id);
                    reloadStores();
                } else {
                    showSameProductPrices(p.productKey == null ? p.rawName : p.productKey);
                }
            });
            if (selecting && selectedProductIds.contains(p.id)) row.setBackgroundColor(BLUE);
            row.setOnClickListener(v -> {
                if (productSelectionStoreId == store.id) {
                    toggleProductSelection(p.id);
                    reloadStores();
                } else {
                    DatabaseHelper.ProductRecord fresh = db.getProduct(p.id);
                    showProductEditor(fresh == null ? p : fresh, this::reloadStores);
                }
            });
            row.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                if (productSelectionStoreId != store.id) {
                    productSelectionStoreId = store.id;
                    selectedProductIds.clear();
                    selectedProductIds.add(p.id);
                    DiagLog.write(this, "PRODUCT_SELECT_START store=" + store.id + " product=" + p.id + " source=long_press");
                } else {
                    toggleProductSelection(p.id);
                }
                reloadStores();
                return true;
            });
            sheet.addView(row);
        }
        outer.addView(wrapHorizontal(sheet));
        return outer;
    }

    private void toggleProductSelection(long productId) {
        boolean selected;
        if (selectedProductIds.contains(productId)) {
            selectedProductIds.remove(productId);
            selected = false;
        } else {
            selectedProductIds.add(productId);
            selected = true;
        }
        DiagLog.write(this, "PRODUCT_SELECT_TOGGLE product=" + productId + " selected=" + selected + " count=" + selectedProductIds.size());
    }

    private void cancelProductSelection() {
        if (productSelectionStoreId >= 0) {
            DiagLog.write(this, "PRODUCT_SELECT_CANCEL store=" + productSelectionStoreId + " count=" + selectedProductIds.size());
        }
        productSelectionStoreId = -1L;
        selectedProductIds.clear();
    }

    private View makePhotoGrid(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);

        boolean selecting = shareSelectionStoreId == store.id;
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), 0, dp(4), dp(8));
        if (selecting) {
            TextView count = text(shareSelectedPhotoIds.size() + "枚選択", 14, SECONDARY, true);
            bar.addView(count, new LinearLayout.LayoutParams(0, dp(40), 1f));
            TextView cancel = button("キャンセル", DGRAY, 13);
            cancel.setOnClickListener(v -> cancelShareSelection());
            bar.addView(cancel, new LinearLayout.LayoutParams(dp(96), dp(38)));
            TextView go = button("共有", shareSelectedPhotoIds.isEmpty() ? DGRAY : LBLUE, 13);
            go.setAlpha(shareSelectedPhotoIds.isEmpty() ? 0.45f : 1f);
            go.setOnClickListener(v -> { if (!shareSelectedPhotoIds.isEmpty()) shareSelectedPhotos(store); });
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(84), dp(38));
            gp.leftMargin = dp(6);
            bar.addView(go, gp);
        } else {
            bar.addView(new View(this), new LinearLayout.LayoutParams(0, dp(40), 1f));
            TextView select = button("選択", DGRAY, 13);
            select.setOnClickListener(v -> beginShareSelection(store));
            bar.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
        }
        outer.addView(bar);

        if (photos.isEmpty()) {
            TextView empty = text("画像はまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }

        int visibleCount = selecting ? photos.size() : Math.min(6, photos.size());
        LinearLayout currentRow = null;
        for (int i = 0; i < visibleCount; i++) {
            if (i % 3 == 0) {
                currentRow = new LinearLayout(this);
                currentRow.setGravity(Gravity.TOP);
                outer.addView(currentRow);
            }
            DatabaseHelper.Photo photo = photos.get(i);
            boolean selected = shareSelectedPhotoIds.contains(photo.id);
            LinearLayout tile = makePhotoTile(photo, store, selecting, selected, true);
            currentRow.addView(tile, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }

        if (!selecting && photos.size() > 6) {
            TextView all = makeDialogAction("全て表示");
            all.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            all.setOnClickListener(v -> showAllPhotosDialog(store));
            LinearLayout.LayoutParams allLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
            allLp.topMargin = dp(2);
            outer.addView(all, allLp);
        }
        return outer;
    }

    private LinearLayout makePhotoTile(DatabaseHelper.Photo photo, DatabaseHelper.Store store,
                                       boolean selecting, boolean selected, boolean allowLongSelect) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(3), dp(3), dp(3), dp(5));
        if (selecting) tile.setBackground(roundRect(selected ? LBLUE : Color.TRANSPARENT, 10));

        FrameLayout imageFrame = new FrameLayout(this);
        imageFrame.setBackground(roundRect(DGRAY, 12));
        imageFrame.setClipToOutline(true);
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundColor(DGRAY);
        Bitmap bmp = loadBitmap(Uri.parse(photo.uri), 360, 360);
        if (bmp != null) image.setImageBitmap(bmp);
        imageFrame.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        if (photo.csvImported) {
            View imported = new StraightCheckBadgeView(this);
            imported.setContentDescription("CSV取り込み済み");
            FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP | Gravity.END);
            badgeLp.topMargin = dp(5);
            badgeLp.rightMargin = dp(5);
            imageFrame.addView(imported, badgeLp);
        }
        tile.addView(imageFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));

        String label = photo.tagName == null ? "タグなし" : photo.tagName;
        LinearLayout tagRow = new LinearLayout(this);
        tagRow.setGravity(Gravity.CENTER);
        if (selecting && selected) {
            View check = new StraightSelectionCheckView(this);
            LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(dp(14), dp(14));
            checkLp.rightMargin = dp(4);
            tagRow.addView(check, checkLp);
        }
        TextView tag = text(label, 12, selected ? WHITE : SECONDARY, selected);
        tag.setGravity(Gravity.CENTER);
        tag.setSingleLine(true);
        tagRow.addView(tag, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(24)));
        tile.addView(tagRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        TextView added = text(dateFormat.format(new Date(photo.createdAt)), 10, SECONDARY, false);
        added.setGravity(Gravity.CENTER);
        added.setSingleLine(true);
        tile.addView(added, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(20)));

        tile.setOnClickListener(v -> {
            if (shareSelectionStoreId == store.id) {
                boolean selectedNow;
                if (shareSelectedPhotoIds.contains(photo.id)) {
                    shareSelectedPhotoIds.remove(photo.id);
                    selectedNow = false;
                } else {
                    shareSelectedPhotoIds.add(photo.id);
                    selectedNow = true;
                }
                DiagLog.write(this, "SHARE_SELECT_TOGGLE store=" + store.id + " photo=" + photo.id +
                        " selected=" + selectedNow + " total=" + shareSelectedPhotoIds.size());
                reloadStores();
            } else {
                showPhotoDetail(photo, store);
            }
        });
        if (allowLongSelect) {
            tile.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                if (shareSelectionStoreId != store.id) {
                    shareSelectionStoreId = store.id;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" +
                            db.listPhotos(store.id).size() + " source=long_press");
                }
                shareSelectedPhotoIds.add(photo.id);
                DiagLog.write(this, "SHARE_SELECT_TOGGLE store=" + store.id + " photo=" + photo.id +
                        " selected=true total=" + shareSelectedPhotoIds.size());
                reloadStores();
                return true;
            });
        }
        return tile;
    }

    private void showAllPhotosDialog(DatabaseHelper.Store store) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(4), dp(10), dp(8));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        TextView select = makeDialogAction("選択");
        select.setOnClickListener(v -> {
            beginShareSelection(store);
            Toast.makeText(this, "画像を選択してください", Toast.LENGTH_SHORT).show();
        });
        top.addView(select, new LinearLayout.LayoutParams(dp(80), dp(40)));
        content.addView(top);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
        LinearLayout row = null;
        for (int i = 0; i < photos.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                row.setGravity(Gravity.TOP);
                grid.addView(row);
            }
            row.addView(makePhotoTile(photos.get(i), store, false, false, false),
                    new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(grid);
        content.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(520)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name + " 画像")
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        select.setOnClickListener(v -> {
            dialog.dismiss();
            beginShareSelection(store);
        });
        showRoundedDialog(dialog, true);
    }

    private void beginShareSelection(DatabaseHelper.Store store) {
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
        if (photos.isEmpty()) {
            Toast.makeText(this, "共有する画像がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        shareSelectionStoreId = store.id;
        shareSelectedPhotoIds.clear();
        DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" + photos.size() + " source=button");
        reloadStores();
    }

    private void cancelShareSelection() {
        if (shareSelectionStoreId >= 0) DiagLog.write(this, "SHARE_SELECT_CANCEL store=" + shareSelectionStoreId + " selected=" + shareSelectedPhotoIds.size());
        shareSelectionStoreId = -1L;
        shareSelectedPhotoIds.clear();
        reloadStores();
    }

    private void shareSelectedPhotos(DatabaseHelper.Store store) {
        ArrayList<DatabaseHelper.Photo> selected = new ArrayList<>();
        for (DatabaseHelper.Photo photo : db.listPhotos(store.id)) {
            if (shareSelectedPhotoIds.contains(photo.id)) selected.add(photo);
        }
        if (selected.isEmpty()) {
            Toast.makeText(this, "画像を選択してください", Toast.LENGTH_SHORT).show();
            return;
        }
        shareSelectionStoreId = -1L;
        shareSelectedPhotoIds.clear();
        sharePhotosWithChatGpt(store, selected, commonTagLabel(selected));
        reloadStores();
    }

    private String commonTagLabel(List<DatabaseHelper.Photo> photos) {
        String common = null;
        for (DatabaseHelper.Photo p : photos) {
            String tag = p.tagName == null ? "タグなし" : p.tagName;
            if (common == null) common = tag;
            else if (!common.equals(tag)) return "複数タグ";
        }
        return common == null ? "タグなし" : common;
    }

    private void showAddStoreDialog() {
        EditText input = dialogInput("店舗名");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗追加")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("追加", null)
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { input.setError("店舗名を入力"); return; }
                long id = db.addStore(name);
                if (id > 0) {
                    expandedStoreId = id;
                    expandedStoreIds.add(id);
                    DiagLog.write(this, "ADD_STORE id=" + id + " name=" + name);
                    dialog.dismiss();
                    reloadStores();
                }
            });
            focusAndShowKeyboard(input, dialog);
        });
        showRoundedDialog(dialog);
    }

    private void showStoreMenu(DatabaseHelper.Store store, View card) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setItems(new String[]{"店舗全体リスト", "店舗名変更", "店舗削除"}, (d, which) -> {
                    if (which == 0) showProductTableDialog(store.name + " 店舗全体リスト", store.id, "");
                    else if (which == 1) showRenameStoreDialog(store);
                    else showDeleteStoreDialog(store);
                })
                .create();
        dialog.setOnDismissListener(d -> {
            View current = storeCardViews.get(store.id);
            if (current != null) current.setBackground(roundRect(GRAY, 18));
        });
        showRoundedDialog(dialog);
    }

    private void showRenameStoreDialog(DatabaseHelper.Store store) {
        EditText input = dialogInput("店舗名");
        input.setText(store.name);
        input.setSelection(input.length());
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗名変更")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("変更", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("店舗名を入力"); return; }
            db.renameStore(store.id, name);
            DiagLog.write(this, "RENAME_STORE id=" + store.id + " name=" + name);
            dialog.dismiss();
            reloadStores();
        }));
        showRoundedDialog(dialog);
    }

    private void showDeleteStoreDialog(DatabaseHelper.Store store) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗削除")
                .setMessage("「" + store.name + "」と、この店舗に紐づく登録データを削除します。\n撮影した画像は端末からも削除します。追加した既存画像の元ファイルは削除しません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    for (DatabaseHelper.Photo p : db.listPhotos(store.id)) {
                        if (p.managed) {
                            try { getContentResolver().delete(Uri.parse(p.uri), null, null); } catch (Exception ignored) { }
                        } else releaseImportedPermission(Uri.parse(p.uri));
                    }
                    db.deleteStore(store.id);
                    expandedStoreIds.remove(store.id);
                    if (expandedStoreId == store.id) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
                    DiagLog.write(this, "DELETE_STORE id=" + store.id + " name=" + store.name);
                    reloadStores();
                }).create();
        showRoundedDialog(dialog);
    }

    private void showTagManager() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(10));

        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        content.addView(rows);
        populateTagManagerRows(rows);

        LinearLayout addRow = new LinearLayout(this);
        addRow.setGravity(Gravity.CENTER_VERTICAL);
        addRow.setPadding(0, dp(10), 0, 0);

        EditText input = dialogInput("新しいタグ");
        TextView add = makeDialogAction("追加");
        add.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        inputLp.rightMargin = dp(8);
        addRow.addView(input, inputLp);
        addRow.addView(add, new LinearLayout.LayoutParams(dp(64), dp(48)));
        content.addView(addRow);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ管理")
                .setView(scroll)
                .setNegativeButton("閉じる", null)
                .create();

        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            long id = db.addTag(name);
            if (id < 0) { input.setError("同じタグがあります"); return; }
            DiagLog.write(this, "ADD_TAG id=" + id + " name=" + name);
            input.setText("");
            populateTagManagerRows(rows);
            reloadStores();
        });
        dialog.setOnDismissListener(d -> reloadStores());
        showRoundedDialog(dialog);
    }

    private void populateTagManagerRows(LinearLayout container) {
        container.removeAllViews();
        for (DatabaseHelper.Tag tag : db.listTags()) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6), dp(4), dp(8), dp(4));
            row.setBackground(roundRect(DGRAY, 14));
            row.setElevation(dp(2));

            TextView handle = text("☰", 22, SECONDARY, false);
            handle.setGravity(Gravity.CENTER);
            handle.setContentDescription(tag.name + "を並べ替え");

            TextView name = text(tag.name, 16, WHITE, false);
            name.setGravity(Gravity.CENTER_VERTICAL);
            name.setIncludeFontPadding(false);

            TextView del = makeDialogAction("削除");
            del.setGravity(Gravity.CENTER);
            del.setOnClickListener(v -> {
                AlertDialog confirm = new AlertDialog.Builder(this)
                        .setTitle("タグ削除")
                        .setMessage("「" + tag.name + "」を削除します。画像自体は削除されません。")
                        .setNegativeButton("キャンセル", null)
                        .setPositiveButton("削除", (d, w) -> {
                            db.deleteTag(tag.id);
                            DiagLog.write(this, "DELETE_TAG id=" + tag.id + " name=" + tag.name);
                            populateTagManagerRows(container);
                            reloadStores();
                        }).create();
                showRoundedDialog(confirm);
            });

            row.addView(handle, new LinearLayout.LayoutParams(dp(48), dp(52)));
            row.addView(name, new LinearLayout.LayoutParams(0, dp(52), 1f));
            row.addView(del, new LinearLayout.LayoutParams(dp(64), dp(52)));

            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dp(7);
            container.addView(row, rowLp);

            handle.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                row.animate().scaleX(1.025f).scaleY(1.025f).alpha(0.82f).setDuration(90).start();
                row.setElevation(dp(12));
                DragPayload payload = new DragPayload("tag", tag.id);
                DiagLog.write(this, "TAG_DRAG_START id=" + tag.id + " name=" + tag.name);
                v.startDragAndDrop(ClipData.newPlainText("tag_id", String.valueOf(tag.id)),
                        new View.DragShadowBuilder(row), payload, 0);
                return true;
            });

            row.setOnDragListener((v, event) -> handleTagDrag(row, tag, container, event));
        }
    }

    private boolean handleTagDrag(View targetView, DatabaseHelper.Tag target, LinearLayout container, DragEvent event) {
        Object local = event.getLocalState();
        if (!(local instanceof DragPayload) || !"tag".equals(((DragPayload) local).type)) {
            return event.getAction() != DragEvent.ACTION_DRAG_STARTED;
        }
        DragPayload payload = (DragPayload) local;
        switch (event.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_ENTERED:
                if (payload.id != target.id) {
                    targetView.animate().scaleX(0.985f).scaleY(0.985f).alpha(0.70f).setDuration(90).start();
                }
                return true;
            case DragEvent.ACTION_DRAG_LOCATION:
                return true;
            case DragEvent.ACTION_DRAG_EXITED:
                targetView.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(90).start();
                return true;
            case DragEvent.ACTION_DROP:
                targetView.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(90).start();
                if (payload.id != target.id) {
                    boolean after = event.getY() > targetView.getHeight() / 2f;
                    db.moveTag(payload.id, target.id, after);
                    DiagLog.write(this, "TAG_REORDER dragged=" + payload.id + " target=" + target.id + " after=" + after);
                    container.postDelayed(() -> populateTagManagerRows(container), 100);
                    reloadStores();
                }
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                targetView.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start();
                targetView.setElevation(dp(2));
                return true;
            default:
                return true;
        }
    }

    private void showPhotoDetail(DatabaseHelper.Photo photo, DatabaseHelper.Store store) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        image.setBackgroundColor(DGRAY);
        Bitmap bmp = loadBitmap(Uri.parse(photo.uri), 1200, 900);
        if (bmp != null) image.setImageBitmap(bmp);
        image.setContentDescription("原寸表示");
        image.setOnClickListener(v -> showOriginalPhoto(photo));
        content.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280)));

        TextView meta = text(dateFormat.format(new Date(photo.createdAt)), 13, SECONDARY, false);
        meta.setPadding(dp(4), dp(8), 0, dp(4));
        content.addView(meta);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout tags = new LinearLayout(this);
        tags.setPadding(0, dp(4), 0, dp(8));
        for (DatabaseHelper.Tag tag : db.listTags()) {
            TextView c = dialogChip(tag.name, photo.tagId != null && photo.tagId == tag.id);
            c.setOnClickListener(v -> {
                db.updatePhotoTag(photo.id, tag.id);
                DiagLog.write(this, "PHOTO_TAG photo=" + photo.id + " tag=" + tag.id);
                reloadStores();
            });
            tags.addView(c);
        }
        TextView none = dialogChip("タグなし", photo.tagId == null);
        none.setOnClickListener(v -> { db.updatePhotoTag(photo.id, null); reloadStores(); });
        tags.addView(none);
        hsv.addView(tags);
        content.addView(hsv);

        LinearLayout actions = new LinearLayout(this);
        TextView edit = button("商品入力", DGRAY, 14);
        TextView delete = button("削除", RED, 14);
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, dp(42), 1f); p1.rightMargin = dp(4);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(42), 1f); p2.leftMargin = dp(4);
        actions.addView(edit, p1); actions.addView(delete, p2);
        content.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        edit.setOnClickListener(v -> {
            dialog.dismiss();
            showOcrSheet(photo.id, store.name + " / 商品データ");
        });
        delete.setOnClickListener(v -> {
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("画像削除")
                    .setMessage(photo.managed ? "この撮影画像を端末から削除します。" : "この画像をPrice Rec.から外します。元の画像ファイルは削除しません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (d, w) -> {
                        Uri uri = Uri.parse(photo.uri);
                        if (photo.managed) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                        } else releaseImportedPermission(uri);
                        db.deletePhoto(photo.id);
                        DiagLog.write(this, "DELETE_PHOTO id=" + photo.id + " managed=" + photo.managed);
                        dialog.dismiss();
                        reloadStores();
                    }).create();
            showRoundedDialog(confirm);
        });
        showRoundedDialog(dialog);
    }

    private void showOriginalPhoto(DatabaseHelper.Photo photo) {
        Uri uri = Uri.parse(photo.uri);
        Bitmap original = loadOriginalBitmap(uri);
        if (original == null) {
            Toast.makeText(this, "原寸画像を開けませんでした", Toast.LENGTH_LONG).show();
            return;
        }

        ZoomImageView zoom = new ZoomImageView(this);
        zoom.setBackgroundColor(Color.BLACK);
        zoom.setImageBitmap(original);
        zoom.setContentDescription("原寸画像。ピンチでズーム、ドラッグで移動");

        LinearLayout holder = new LinearLayout(this);
        holder.setPadding(dp(4), dp(4), dp(4), dp(4));
        holder.addView(zoom, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(620)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(holder)
                .setNegativeButton("閉じる", null)
                .create();
        dialog.setOnDismissListener(d -> zoom.setImageDrawable(null));
        showRoundedDialog(dialog, true);
        DiagLog.write(this, "PHOTO_ORIGINAL_OPEN photo=" + photo.id +
                " size=" + original.getWidth() + "x" + original.getHeight());
    }

    private Bitmap loadOriginalBitmap(Uri uri) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source, (decoder, info, src) ->
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        } catch (Exception e) {
            DiagLog.write(this, "IMAGE_ORIGINAL_LOAD_ERROR uri=" + uri + " err=" + e);
            return null;
        }
    }

    private String tagNameById(long id) {
        for (DatabaseHelper.Tag tag : db.listTags()) if (tag.id == id) return tag.name;
        return "タグなし";
    }

    private void sharePhotosWithChatGpt(DatabaseHelper.Store store, List<DatabaseHelper.Photo> photos, String tagName) {
        if (photos == null || photos.isEmpty()) return;
        long totalStart = SystemClock.elapsedRealtime();
        DiagLog.write(this, "SHARE_PREP_START store=" + store.id + " requested=" + photos.size() + " tag=" + tagName);

        ArrayList<Uri> uris = new ArrayList<>();
        long totalBytes = 0L;
        for (int i = 0; i < photos.size(); i++) {
            DatabaseHelper.Photo photo = photos.get(i);
            long itemStart = SystemClock.elapsedRealtime();
            try {
                Uri uri = Uri.parse(photo.uri);
                ShareImageInfo info = inspectShareImage(uri);
                uris.add(uri);
                if (info.bytes > 0) totalBytes += info.bytes;
                DiagLog.write(this, "SHARE_IMAGE index=" + (i + 1) + " photo=" + photo.id +
                        " uri=" + uri + " size=" + info.width + "x" + info.height +
                        " bytes=" + info.bytes + " prepMs=" + (SystemClock.elapsedRealtime() - itemStart));
            } catch (Exception e) {
                DiagLog.write(this, "SHARE_IMAGE_ERROR index=" + (i + 1) + " photo=" + photo.id + " err=" + e);
            }
        }
        if (uris.isEmpty()) {
            Toast.makeText(this, "共有できる画像がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        DiagLog.write(this, "SHARE_PREP_OK photos=" + uris.size() + " totalBytes=" + totalBytes +
                " prepMs=" + (SystemClock.elapsedRealtime() - totalStart));

        saveLastShareMap(photos);
        String prompt = buildChatGptPrompt(store, photos, tagName);
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Price Rec. 解析指示", prompt));
                DiagLog.write(this, "SHARE_CLIPBOARD_OK chars=" + prompt.length());
            } else {
                DiagLog.write(this, "SHARE_CLIPBOARD_UNAVAILABLE");
            }
        } catch (Exception e) {
            DiagLog.write(this, "SHARE_CLIPBOARD_ERROR " + e);
        }

        Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
        share.setType("image/*");
        share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        share.putExtra(Intent.EXTRA_TEXT, prompt);
        share.putExtra(Intent.EXTRA_TITLE, "Price Rec. 商品価格解析");
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        ClipData clip = ClipData.newUri(getContentResolver(), "Price Rec. images", uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        share.setClipData(clip);

        boolean direct = false;
        try {
            Intent chatGpt = new Intent(share);
            chatGpt.setPackage("com.openai.chatgpt");
            boolean directAvailable = getPackageManager().resolveActivity(chatGpt, 0) != null;
            DiagLog.write(this, "SHARE_DIRECT_CHECK available=" + directAvailable);
            DiagLog.write(this, "SHARE_INTENT_START photos=" + uris.size() + " totalBytes=" + totalBytes +
                    " elapsedMs=" + (SystemClock.elapsedRealtime() - totalStart));
            if (directAvailable) {
                direct = true;
                startActivity(chatGpt);
                DiagLog.write(this, "SHARE_DIRECT_STARTED elapsedMs=" + (SystemClock.elapsedRealtime() - totalStart));
            } else {
                DiagLog.write(this, "SHARE_CHOOSER_FALLBACK");
                startActivity(Intent.createChooser(share, "画像を共有"));
                DiagLog.write(this, "SHARE_CHOOSER_STARTED elapsedMs=" + (SystemClock.elapsedRealtime() - totalStart));
            }
            DiagLog.write(this, "CHATGPT_SHARE_START store=" + store.id + " photos=" + uris.size() +
                    " tag=" + tagName + " textChars=" + prompt.length() + " direct=" + direct +
                    " totalMs=" + (SystemClock.elapsedRealtime() - totalStart));
            Toast.makeText(this, "解析指示文もクリップボードへコピーしました", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            DiagLog.write(this, "SHARE_INTENT_ERROR elapsedMs=" + (SystemClock.elapsedRealtime() - totalStart) + " err=" + e);
            Toast.makeText(this, "共有を開始できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private ShareImageInfo inspectShareImage(Uri uri) {
        long bytes = -1L;
        int width = -1;
        int height = -1;
        try (ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r")) {
            if (pfd != null) bytes = pfd.getStatSize();
        } catch (Exception ignored) { }
        if (bytes < 0) {
            try (android.database.Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) bytes = c.getLong(0);
            } catch (Exception ignored) { }
        }
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in != null) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeStream(in, null, options);
                width = options.outWidth;
                height = options.outHeight;
            }
        } catch (Exception ignored) { }
        return new ShareImageInfo(width, height, bytes);
    }

    private void saveLastShareMap(List<DatabaseHelper.Photo> photos) {
        android.content.SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        int oldCount = prefs.getInt("last_share_count", 0);
        android.content.SharedPreferences.Editor editor = prefs.edit();
        for (int i = 1; i <= oldCount; i++) editor.remove("last_share_image_" + i);
        editor.putInt("last_share_count", photos.size());
        editor.putLong("last_share_at", System.currentTimeMillis());
        for (int i = 0; i < photos.size(); i++) editor.putLong("last_share_image_" + (i + 1), photos.get(i).id);
        editor.apply();
    }

    private String buildChatGptPrompt(DatabaseHelper.Store store, List<DatabaseHelper.Photo> photos, String tagName) {
        String csvFileName = "PriceRec_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.JAPAN).format(new Date()) + ".csv";
        StringBuilder b = new StringBuilder();
        b.append("Price Rec.用の商品価格解析です。\n");
        b.append("店舗: ").append(store.name).append('\n');
        b.append("選択画像数: ").append(photos.size()).append("枚\n\n");
        b.append("添付画像に写っている商品の商品名と販売価格を画像全体の意味から判断して抽出してください。\n");
        b.append("瓶・パッケージ上の説明文、POP文章、JANコード、割引条件などを商品名として誤採用しないでください。\n");
        b.append("同じ商品が複数画像に重複している場合は、同一店舗・同一価格なら重複行をまとめてください。\n");
        b.append("判読できない項目は推測で埋めず空欄にしてください。\n\n");
        b.append("Price Rec.取込用CSVファイルをUTF-8で作成してください。\n");
        b.append("列順は必ず次の通りです。\n");
        b.append("store,tag,product_name,product_key,price,volume,price_type,captured_at,source_image\n");
        b.append("storeは『").append(store.name).append("』を入れてください。\n");
        b.append("product_keyは店舗横断比較用の正規化商品名、priceは円の整数のみ、volumeは判読できる場合のみ。\n");
        b.append("price_typeは税込価格なら『税込』、税抜価格なら『税抜』。画像から判別できない場合は空欄にしてください。\n");
        b.append("tag / captured_at / source_image は、各画像について下記の値をそのまま使ってください。\n");
        for (int i = 0; i < photos.size(); i++) {
            DatabaseHelper.Photo p = photos.get(i);
            String tag = p.tagName == null ? "タグなし" : p.tagName;
            b.append("image_").append(i + 1)
                    .append(" => source_image=photo_").append(p.id)
                    .append(", tag=").append(tag)
                    .append(", captured_at=").append(dateFormat.format(new Date(p.createdAt))).append('\n');
        }
        b.append("source_imageには image_1 等ではなく、必ず対応する photo_<番号> を入れてください。\n");
        b.append("\n最終結果はMarkdown表だけでなく、ダウンロード可能なCSVファイルとして作成してください。\n");
        b.append("CSVファイル名は必ず「").append(csvFileName).append("」にしてください。");
        return b.toString();
    }

    private void importImages(DatabaseHelper.Store store) {
        long selected = selectedTagForStore(store.id);
        pendingImportStoreId = store.id;
        pendingImportTagId = selected < 0 ? null : selected;
        try {
            PickVisualMediaRequest request = new PickVisualMediaRequest.Builder()
                    .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                    .build();
            DiagLog.write(this, "PHOTO_PICKER_START store=" + store.id + " tag=" + pendingImportTagId);
            photoPicker.launch(request);
        } catch (Exception e) {
            clearPendingImportState();
            DiagLog.write(this, "PHOTO_PICKER_ERROR " + e);
            Toast.makeText(this, "画像を選択できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void handlePhotoPickerUris(List<Uri> uris) {
        if (pendingImportStoreId < 0) return;
        if (uris == null || uris.isEmpty()) {
            DiagLog.write(this, "PHOTO_PICKER_CANCEL");
            clearPendingImportState();
            return;
        }
        long storeId = pendingImportStoreId;
        Long tagId = pendingImportTagId;
        int added = 0;
        for (Uri uri : uris) {
            if (uri == null) continue;
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) {
                DiagLog.write(this, "PHOTO_PICKER_PERMISSION_WARN uri=" + uri + " err=" + e);
            }
            long id = db.addPhoto(storeId, tagId, uri.toString(), false);
            if (id > 0) {
                added++;
                DiagLog.write(this, "PHOTO_IMPORT_OK photo=" + id + " store=" + storeId + " tag=" + tagId);
            }
        }
        clearPendingImportState();
        expandedStoreId = storeId;
        expandedStoreIds.add(storeId);
        activeTab.put(storeId, "images");
        Toast.makeText(this, added + "枚追加しました", Toast.LENGTH_SHORT).show();
        reloadStores();
    }

    private DatabaseHelper.Store findStore(long id) {
        for (DatabaseHelper.Store s : db.listStores()) if (s.id == id) return s;
        return null;
    }

    private void clearPendingImportState() {
        pendingImportStoreId = -1L;
        pendingImportTagId = null;
    }

    private void releaseImportedPermission(Uri uri) {
        try { getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
    }

    private void takePhoto(DatabaseHelper.Store store) {
        try {
            long selected = selectedTagForStore(store.id);
            pendingTagId = selected < 0 ? null : selected;
            pendingStoreId = store.id;
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "PriceRec_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PriceRec/" + safeFolder(store.name));
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            pendingPhotoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingPhotoUri == null) throw new IllegalStateException("MediaStore insert returned null");
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingPhotoUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            DiagLog.write(this, "CAMERA_START store=" + pendingStoreId + " tag=" + pendingTagId + " uri=" + pendingPhotoUri);
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception e) {
            DiagLog.write(this, "CAMERA_START_ERROR " + e);
            cleanupPendingPhoto();
            Toast.makeText(this, "カメラを起動できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAMERA) return;
        if (pendingPhotoUri == null) return;
        if (resultCode == RESULT_OK) {
            try {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(pendingPhotoUri, done, null, null);
                long photoId = db.addPhoto(pendingStoreId, pendingTagId, pendingPhotoUri.toString(), true);
                DiagLog.write(this, "CAMERA_OK photo=" + photoId + " store=" + pendingStoreId);
                expandedStoreId = pendingStoreId;
                expandedStoreIds.add(pendingStoreId);
                activeTab.put(pendingStoreId, "images");
                clearPendingPhotoState();
                reloadStores();
                return;
            } catch (Exception e) {
                DiagLog.write(this, "CAMERA_SAVE_ERROR " + e);
                Toast.makeText(this, "画像の登録に失敗しました", Toast.LENGTH_LONG).show();
            }
        } else {
            try { getContentResolver().delete(pendingPhotoUri, null, null); } catch (Exception ignored) { }
        }
        clearPendingPhotoState();
        reloadStores();
    }

    private void cleanupPendingPhoto() {
        if (pendingPhotoUri != null) {
            try { getContentResolver().delete(pendingPhotoUri, null, null); } catch (Exception ignored) { }
        }
        clearPendingPhotoState();
    }

    private void clearPendingPhotoState() {
        pendingPhotoUri = null;
        pendingStoreId = -1L;
        pendingTagId = null;
    }

    private void showOcrSheet(long photoId, String title) {
        DatabaseHelper.Photo photo = db.getPhoto(photoId);
        List<DatabaseHelper.ProductRecord> existing = db.listProductsForPhoto(photoId);
        LinearLayout editors = new LinearLayout(this);
        editors.setOrientation(LinearLayout.VERTICAL);
        ArrayList<OcrEditorRow> rowEditors = new ArrayList<>();
        editors.addView(sheetHeader(new String[]{"商品名", "価格", ""}, new int[]{260, 110, 50}));
        for (DatabaseHelper.ProductRecord p : existing) addOcrEditorRow(editors, rowEditors, p.rawName, p.priceYen);
        if (existing.isEmpty()) addOcrEditorRow(editors, rowEditors, "", null);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.addView(editors);
        ScrollView vsv = new ScrollView(this);
        vsv.addView(hsv);
        content.addView(vsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));
        TextView add = text("＋ 商品", 15, LBLUE, true);
        add.setGravity(Gravity.CENTER_VERTICAL);
        add.setPadding(dp(8), dp(10), dp(8), dp(8));
        add.setOnClickListener(v -> addOcrEditorRow(editors, rowEditors, "", null));
        content.addView(add);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            ArrayList<DatabaseHelper.ProductInput> rows = new ArrayList<>();
            for (OcrEditorRow r : rowEditors) {
                if (r.row.getParent() == null) continue;
                String name = r.name.getText().toString().trim();
                if (name.isEmpty()) continue;
                Integer price = parsePriceInput(r.price.getText().toString());
                rows.add(new DatabaseHelper.ProductInput(name, price, null));
            }
            db.replaceProductsForPhoto(photoId, rows, photo == null ? null : photo.ocrRaw);
            DiagLog.write(this, "PRODUCT_EDIT_SAVE photo=" + photoId + " rows=" + rows.size());
            dialog.dismiss();
            reloadStores();
        }));
        showRoundedDialog(dialog, true);
    }

    private void addOcrEditorRow(LinearLayout container, ArrayList<OcrEditorRow> list, String nameValue, Integer priceValue) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(2));
        EditText name = sheetEdit(nameValue, false);
        EditText price = sheetEdit(priceValue == null ? "" : String.valueOf(priceValue), true);
        TextView del = text("×", 22, LRED, true);
        del.setGravity(Gravity.CENTER);
        row.addView(name, new LinearLayout.LayoutParams(dp(260), dp(46)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(110), dp(46)); pp.leftMargin = dp(4);
        row.addView(price, pp);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(dp(50), dp(46)); dpv.leftMargin = dp(4);
        row.addView(del, dpv);
        OcrEditorRow editor = new OcrEditorRow(row, name, price);
        list.add(editor);
        del.setOnClickListener(v -> container.removeView(row));
        container.addView(row);
    }

    private Integer parsePriceInput(String s) {
        String digits = s == null ? "" : s.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return null;
        try { return Integer.parseInt(digits); } catch (NumberFormatException e) { return null; }
    }

    private void runSearch(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) return;
        hideKeyboard(searchInput);
        List<DatabaseHelper.ProductRecord> hits = db.searchProducts(q);
        if (!hits.isEmpty()) rememberSearchCandidate(q);
        DiagLog.write(this, "SEARCH q=" + q + " hits=" + hits.size());
        showProductTableDialog("検索", null, q);
    }

    private void showAppMenu() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setItems(new String[]{"全リスト表示", "CSVインポート", "診断ログ"}, (d, which) -> {
                    if (which == 0) showAllList();
                    else if (which == 1) startCsvImportPicker();
                    else showDiagnosticLog();
                }).create();
        showRoundedDialog(dialog);
    }

    private void startCsvImportPicker() {
        try {
            DiagLog.write(this, "CSV_PICKER_START");
            csvPicker.launch(new String[]{"text/csv", "text/comma-separated-values", "application/csv", "application/vnd.ms-excel", "text/plain"});
        } catch (Exception e) {
            DiagLog.write(this, "CSV_PICKER_ERROR " + e);
            Toast.makeText(this, "CSVファイルを選択できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void handleCsvPicked(Uri uri) {
        if (uri == null) {
            DiagLog.write(this, "CSV_PICKER_CANCEL");
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        loadCsvAndPreview(uri, "picker");
    }

    private void handleIncomingCsvIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            Uri uri = intent.getData();
            if (uri == null) return;
            intent.setAction(null);
            DiagLog.write(this, "CSV_VIEW_INTENT uri=" + uri + " type=" + intent.getType());
            storeContainer.post(() -> loadCsvAndPreview(uri, "view_intent"));
            return;
        }
        if (Intent.ACTION_SEND.equals(action)) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri == null && intent.getClipData() != null && intent.getClipData().getItemCount() > 0) {
                uri = intent.getClipData().getItemAt(0).getUri();
            }
            if (uri == null) {
                DiagLog.write(this, "CSV_SHARE_INTENT_REJECT reason=no_uri type=" + intent.getType());
                return;
            }
            intent.setAction(null);
            Uri finalUri = uri;
            DiagLog.write(this, "CSV_SHARE_INTENT uri=" + uri + " type=" + intent.getType());
            storeContainer.post(() -> loadCsvAndPreview(finalUri, "share_intent"));
            return;
        }
        if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (uris == null || uris.size() != 1) {
                DiagLog.write(this, "CSV_SHARE_MULTIPLE_REJECT count=" + (uris == null ? 0 : uris.size()));
                storeContainer.post(() -> Toast.makeText(this, "CSVは1ファイルずつ共有してください", Toast.LENGTH_LONG).show());
                return;
            }
            intent.setAction(null);
            Uri uri = uris.get(0);
            DiagLog.write(this, "CSV_SHARE_INTENT uri=" + uri + " type=" + intent.getType() + " multiple=true");
            storeContainer.post(() -> loadCsvAndPreview(uri, "share_intent"));
        }
    }

    private void loadCsvAndPreview(Uri uri, String source) {
        long started = SystemClock.elapsedRealtime();
        DiagLog.write(this, "CSV_READ_START source=" + source + " uri=" + uri);
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("openInputStream returned null");
            CsvImporter.Result parsed = CsvImporter.parse(in);
            ArrayList<ImportPreviewRow> preview = buildImportPreview(parsed.rows);
            String sourceName = displayNameForUri(uri);
            DiagLog.write(this, "CSV_READ_OK rows=" + preview.size() + " warnings=" + parsed.warnings.size() +
                    " bytes=" + parsed.byteCount + " file=" + sourceName + " ms=" + (SystemClock.elapsedRealtime() - started));
            showCsvImportPreview(uri, sourceName, preview, parsed.warnings, parsed.rawText);
        } catch (Exception e) {
            DiagLog.write(this, "CSV_READ_ERROR uri=" + uri + " ms=" + (SystemClock.elapsedRealtime() - started) + " err=" + e);
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("CSVインポート")
                    .setMessage("CSVを読み込めませんでした。\n\n" + e.getMessage())
                    .setPositiveButton("閉じる", null).create();
            showRoundedDialog(dialog);
        }
    }

    private ArrayList<ImportPreviewRow> buildImportPreview(List<CsvImporter.Row> rows) {
        ArrayList<ImportPreviewRow> out = new ArrayList<>();
        for (CsvImporter.Row row : rows) {
            ImportPreviewRow p = new ImportPreviewRow(row);
            if (row.store.isEmpty() || row.productName.isEmpty()) {
                p.status = "必須項目不足";
                p.action = ImportPreviewRow.SKIP;
            } else {
                DatabaseHelper.Store store = db.findStoreByName(row.store);
                DatabaseHelper.ProductRecord existing = store == null ? null : db.findLatestProductInStore(store.id, row.productKey);
                p.existingProductId = existing == null ? -1L : existing.id;
                if (existing == null) {
                    p.status = "新規";
                    p.action = ImportPreviewRow.ADD;
                } else if (sameInteger(existing.priceYen, row.priceYen)) {
                    p.status = "重複";
                    p.action = ImportPreviewRow.SKIP;
                } else {
                    p.status = "価格変更";
                    p.action = ImportPreviewRow.UPDATE;
                }
            }
            out.add(p);
        }
        return out;
    }

    private boolean sameInteger(Integer a, Integer b) {
        return a == null ? b == null : a.equals(b);
    }

    private void showCsvImportPreview(Uri uri, String sourceName, ArrayList<ImportPreviewRow> preview, List<String> warnings, String rawCsv) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));

        int addCount = 0, updateCount = 0, skipCount = 0;
        for (ImportPreviewRow p : preview) {
            if (ImportPreviewRow.ADD.equals(p.action)) addCount++;
            else if (ImportPreviewRow.UPDATE.equals(p.action)) updateCount++;
            else skipCount++;
        }
        TextView summary = text("全" + preview.size() + "行  /  追加" + addCount + "  更新" + updateCount + "  スキップ" + skipCount +
                (warnings.isEmpty() ? "" : "  /  注意" + warnings.size()), 13, SECONDARY, false);
        summary.setPadding(dp(6), dp(4), dp(6), dp(8));
        content.addView(summary);

        if (!warnings.isEmpty()) {
            TextView warning = text(warnings.get(0) + (warnings.size() > 1 ? " ほか" + (warnings.size() - 1) + "件" : ""), 12, LRED, false);
            warning.setPadding(dp(6), 0, dp(6), dp(8));
            content.addView(warning);
        }

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        int[] widths = {240, 170, 100, 105, 100};
        sheet.addView(sheetHeader(new String[]{"商品名", "店舗", "価格", "判定", "動作"}, widths));
        for (ImportPreviewRow p : preview) sheet.addView(makeCsvPreviewRow(p, widths));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.addView(sheet);
        ScrollView vsv = new ScrollView(this);
        vsv.addView(hsv);
        content.addView(vsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        TextView hint = text("動作セルをタップすると 追加 → 更新 → スキップ を切り替えられます。", 12, SECONDARY, false);
        hint.setPadding(dp(6), dp(8), dp(6), dp(2));
        content.addView(hint);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("CSVインポート確認")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("インポート", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            importCsvRows(uri, sourceName, preview, rawCsv, true);
            dialog.dismiss();
        }));
        showRoundedDialog(dialog, true);
    }

    private View makeCsvPreviewRow(ImportPreviewRow p, int[] widths) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(1), 0, dp(1));
        String price = p.row.priceYen == null ? (p.row.priceRaw.isEmpty() ? "—" : p.row.priceRaw) : yen(p.row.priceYen);
        TextView product = csvCell(p.row.productName, widths[0], WHITE, false);
        TextView store = csvCell(p.row.store, widths[1], WHITE, false);
        TextView priceCell = csvCell(price, widths[2], WHITE, false);
        TextView status = csvCell(p.status, widths[3], "必須項目不足".equals(p.status) ? LRED : SECONDARY, false);
        TextView action = csvCell(p.action, widths[4], actionColor(p.action), true);
        action.setGravity(Gravity.CENTER);
        action.setBackground(roundRect(DGRAY, 8));
        action.setOnClickListener(v -> {
            p.action = nextImportAction(p.action);
            action.setText(p.action);
            action.setTextColor(actionColor(p.action));
        });
        row.addView(product); row.addView(store); row.addView(priceCell); row.addView(status); row.addView(action);
        return row;
    }

    private TextView csvCell(String value, int widthDp, int color, boolean bold) {
        TextView cell = text(value == null ? "" : value, 13, color, bold);
        cell.setGravity(Gravity.CENTER_VERTICAL);
        cell.setSingleLine(true);
        cell.setPadding(dp(8), 0, dp(8), 0);
        cell.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), dp(44)));
        return cell;
    }

    private int actionColor(String action) {
        if (ImportPreviewRow.ADD.equals(action)) return LBLUE;
        if (ImportPreviewRow.UPDATE.equals(action)) return ORANGE;
        return SECONDARY;
    }

    private String nextImportAction(String current) {
        if (ImportPreviewRow.ADD.equals(current)) return ImportPreviewRow.UPDATE;
        if (ImportPreviewRow.UPDATE.equals(current)) return ImportPreviewRow.SKIP;
        return ImportPreviewRow.ADD;
    }

    private void importCsvRows(Uri uri, String sourceName, List<ImportPreviewRow> preview, String rawCsv, boolean showResultDialog) {
        long started = SystemClock.elapsedRealtime();
        int added = 0, updated = 0, skipped = 0, failed = 0;
        HashMap<String, Long> virtualPhotos = new HashMap<>();
        long batchId = db.createImportBatch(sourceName, uri == null ? null : uri.toString(), rawCsv);
        DiagLog.write(this, "CSV_IMPORT_START uri=" + uri + " file=" + sourceName + " batch=" + batchId + " rows=" + preview.size());
        for (ImportPreviewRow p : preview) {
            CsvImporter.Row row = p.row;
            if (ImportPreviewRow.SKIP.equals(p.action) || row.store.isEmpty() || row.productName.isEmpty()) {
                skipped++;
                continue;
            }
            try {
                long storeId = db.ensureStore(row.store);
                if (storeId < 0) throw new IllegalStateException("店舗を作成できません: " + row.store);
                Long tagId = db.ensureTag(row.tag);
                long photoId = resolveImportPhoto(row, storeId, tagId, virtualPhotos);
                if (ImportPreviewRow.UPDATE.equals(p.action)) {
                    DatabaseHelper.ProductRecord existing = db.findLatestProductInStore(storeId, row.productKey);
                    if (existing != null) {
                        db.recordImportUpdated(batchId, existing);
                        db.updateImportedProduct(existing.id, photoId, storeId, tagId, row.productName, row.productKey, row.priceYen,
                                row.volume, row.priceType, row.sourceImage);
                        db.updateImportSnapshot(batchId, existing.id);
                        updated++;
                    } else {
                        long productId = db.insertImportedProduct(photoId, storeId, tagId, row.productName, row.productKey, row.priceYen,
                                row.volume, row.priceType, row.sourceImage);
                        if (productId < 0) throw new IllegalStateException("商品を追加できません");
                        db.recordImportAdded(batchId, productId, storeId, row.store);
                        added++;
                    }
                } else {
                    long productId = db.insertImportedProduct(photoId, storeId, tagId, row.productName, row.productKey, row.priceYen,
                            row.volume, row.priceType, row.sourceImage);
                    if (productId < 0) throw new IllegalStateException("商品を追加できません");
                    db.recordImportAdded(batchId, productId, storeId, row.store);
                    added++;
                }
            } catch (Exception e) {
                failed++;
                DiagLog.write(this, "CSV_IMPORT_ROW_ERROR line=" + row.lineNumber + " action=" + p.action + " batch=" + batchId + " err=" + e);
            }
        }
        db.deleteImportBatchIfEmpty(batchId);
        DiagLog.write(this, "CSV_IMPORT_OK batch=" + batchId + " added=" + added + " updated=" + updated + " skipped=" + skipped +
                " failed=" + failed + " ms=" + (SystemClock.elapsedRealtime() - started));
        reloadStores();
        if (showResultDialog) {
            AlertDialog result = new AlertDialog.Builder(this)
                    .setTitle("CSVインポート完了")
                    .setMessage("追加: " + added + "\n更新: " + updated + "\nスキップ: " + skipped +
                            (failed == 0 ? "" : "\n失敗: " + failed) +
                            ((added + updated) > 0 ? "\n\nこの取込は「全CSV一覧」または店舗の「CSV一覧」から後で取り消せます。" : ""))
                    .setPositiveButton("閉じる", null).create();
            showRoundedDialog(result);
        }
    }

    private String displayNameForUri(Uri uri) {
        if (uri == null) return "CSV";
        try (android.database.Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) {
                String name = c.getString(0);
                if (name != null && !name.trim().isEmpty()) return name.trim();
            }
        } catch (Exception ignored) { }
        String last = uri.getLastPathSegment();
        return last == null || last.trim().isEmpty() ? "CSV" : last;
    }

    private long resolveImportPhoto(CsvImporter.Row row, long storeId, Long tagId, Map<String, Long> virtualPhotos) {
        long mapped = resolveSourcePhotoId(row.sourceImage, storeId);
        if (mapped > 0) return mapped;
        String key = storeId + "|" + (tagId == null ? "null" : tagId) + "|" + row.sourceImage + "|" + row.capturedAt;
        Long existing = virtualPhotos.get(key);
        if (existing != null) return existing;
        long id = db.createVirtualImportPhoto(storeId, tagId, row.capturedAt, row.sourceImage);
        if (id < 0) throw new IllegalStateException("CSV用データ行を作成できません");
        virtualPhotos.put(key, id);
        return id;
    }

    private long resolveSourcePhotoId(String sourceImage, long storeId) {
        if (sourceImage == null) return -1L;
        String source = sourceImage.trim().toLowerCase(Locale.ROOT);
        long photoId = -1L;
        try {
            if (source.matches("photo_[0-9]+")) {
                photoId = Long.parseLong(source.substring("photo_".length()));
            } else if (source.matches("image_[0-9]+")) {
                int index = Integer.parseInt(source.substring("image_".length()));
                photoId = getPreferences(MODE_PRIVATE).getLong("last_share_image_" + index, -1L);
            }
        } catch (Exception ignored) { }
        if (photoId <= 0) return -1L;
        DatabaseHelper.Photo photo = db.getPhoto(photoId);
        if (photo == null || photo.storeId != storeId) return -1L;
        return photoId;
    }

    private void showAllList() {
        showProductTableDialog("全リスト", null, "");
    }

    private void showProductTableDialog(String title, Long fixedStoreId, String initialQuery) {
        final Set<Long> selected = new HashSet<>();
        final boolean[] selecting = {false};
        final Long[] storeFilter = {fixedStoreId};
        final long[] tagFilter = {Long.MIN_VALUE}; // MIN=all, -1=none, >=0 tag id
        final String[] query = {initialQuery == null ? "" : initialQuery.trim()};

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(6), dp(10), dp(6));

        final AlertDialog[] productDialogRef = {null};
        LinearLayout topActions = new LinearLayout(this);
        topActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        TextView history = makeDialogAction(fixedStoreId == null ? "全CSV一覧" : "CSV一覧");
        history.setOnClickListener(v -> {
            DiagLog.write(this, "CSV_HISTORY_OPEN_FROM_LIST scope=" + (fixedStoreId == null ? "all" : ("store:" + fixedStoreId)));
            showImportHistoryDialog(fixedStoreId);
        });
        topActions.addView(history, new LinearLayout.LayoutParams(dp(fixedStoreId == null ? 112 : 96), dp(42)));
        panel.addView(topActions);

        LinearLayout filters = new LinearLayout(this);
        filters.setGravity(Gravity.CENTER_VERTICAL);
        filters.setPadding(0, 0, 0, dp(8));

        final TextView storeButton = button(fixedStoreId == null ? "店舗: すべて" :
                "店舗: " + storeNameForId(fixedStoreId), DGRAY, 13);
        if (fixedStoreId == null) {
            storeButton.setOnClickListener(v -> {
                List<DatabaseHelper.Store> stores = db.listStores();
                String[] names = new String[stores.size() + 1];
                names[0] = "すべて";
                for (int i = 0; i < stores.size(); i++) names[i + 1] = stores.get(i).name;
                AlertDialog d = new AlertDialog.Builder(this)
                        .setTitle("店舗で絞り込み")
                        .setItems(names, (dd, which) -> {
                            storeFilter[0] = which == 0 ? null : stores.get(which - 1).id;
                            storeButton.setText("店舗: " + (which == 0 ? "すべて" : stores.get(which - 1).name));
                            selected.clear();
                            selecting[0] = false;
                            Object tag = panel.getTag();
                            if (tag instanceof Runnable) ((Runnable) tag).run();
                        })
                        .setNegativeButton("キャンセル", null)
                        .create();
                showRoundedDialog(d);
            });
        } else {
            storeButton.setAlpha(0.7f);
        }

        final TextView tagButton = button("タグ: すべて", DGRAY, 13);
        tagButton.setOnClickListener(v -> {
            List<DatabaseHelper.Tag> tags = db.listTags();
            String[] names = new String[tags.size() + 2];
            names[0] = "すべて";
            names[1] = "タグなし";
            for (int i = 0; i < tags.size(); i++) names[i + 2] = tags.get(i).name;
            AlertDialog d = new AlertDialog.Builder(this)
                    .setTitle("タグで絞り込み")
                    .setItems(names, (dd, which) -> {
                        if (which == 0) {
                            tagFilter[0] = Long.MIN_VALUE;
                            tagButton.setText("タグ: すべて");
                        } else if (which == 1) {
                            tagFilter[0] = -1L;
                            tagButton.setText("タグ: タグなし");
                        } else {
                            DatabaseHelper.Tag tag = tags.get(which - 2);
                            tagFilter[0] = tag.id;
                            tagButton.setText("タグ: " + tag.name);
                        }
                        selected.clear();
                        selecting[0] = false;
                        Object tag = panel.getTag();
                        if (tag instanceof Runnable) ((Runnable) tag).run();
                    })
                    .setNegativeButton("キャンセル", null)
                    .create();
            showRoundedDialog(d);
        });

        LinearLayout.LayoutParams storeLp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        storeLp.rightMargin = dp(4);
        filters.addView(storeButton, storeLp);
        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        tagLp.leftMargin = dp(4);
        filters.addView(tagButton, tagLp);
        panel.addView(filters);

        EditText q = dialogInput("商品名検索");
        q.setText(query[0]);
        q.setTextSize(15);
        panel.addView(q, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        LinearLayout listHost = new LinearLayout(this);
        listHost.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams hostLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(510));
        hostLp.topMargin = dp(8);
        panel.addView(listHost, hostLp);

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            listHost.removeAllViews();
            ArrayList<DatabaseHelper.ProductRecord> products = new ArrayList<>();
            String normalizedQuery = query[0] == null ? "" : query[0].trim().toLowerCase(Locale.ROOT);
            for (DatabaseHelper.ProductRecord p : db.listAllProducts()) {
                if (storeFilter[0] != null && p.storeId != storeFilter[0]) continue;
                if (tagFilter[0] == -1L && p.tagId != null) continue;
                if (tagFilter[0] >= 0 && (p.tagId == null || p.tagId != tagFilter[0])) continue;
                if (!normalizedQuery.isEmpty()) {
                    String hay = ((p.rawName == null ? "" : p.rawName) + " " +
                            (p.productKey == null ? "" : p.productKey) + " " +
                            (p.storeName == null ? "" : p.storeName) + " " +
                            (p.tagName == null ? "" : p.tagName)).toLowerCase(Locale.ROOT);
                    if (!hay.contains(normalizedQuery)) continue;
                }
                products.add(p);
            }

            if (!selecting[0]) {
                LinearLayout bar = new LinearLayout(this);
                bar.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                bar.setPadding(dp(4), 0, dp(4), dp(8));
                TextView select = button("選択", DGRAY, 13);
                select.setOnClickListener(v -> {
                    selecting[0] = true;
                    selected.clear();
                    DiagLog.write(this, "PRODUCT_SELECT_START scope=list source=button_bar");
                    render[0].run();
                });
                bar.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
                listHost.addView(bar);
            }

            if (selecting[0]) {
                LinearLayout bar = new LinearLayout(this);
                bar.setGravity(Gravity.CENTER_VERTICAL);
                bar.setPadding(dp(4), 0, dp(4), dp(8));

                TextView count = text(selected.size() + "件選択", 14, SECONDARY, true);
                bar.addView(count, new LinearLayout.LayoutParams(0, dp(40), 1f));

                TextView delete = button("削除", selected.isEmpty() ? DGRAY : RED, 13);
                delete.setAlpha(selected.isEmpty() ? 0.45f : 1f);
                delete.setOnClickListener(v -> {
                    if (!selected.isEmpty()) {
                        confirmDeleteProducts(new ArrayList<>(selected), () -> {
                            selected.clear();
                            selecting[0] = false;
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(72), dp(38));
                delLp.rightMargin = dp(6);
                bar.addView(delete, delLp);

                TextView move = button("タグ移動", selected.isEmpty() ? DGRAY : LBLUE, 13);
                move.setAlpha(selected.isEmpty() ? 0.45f : 1f);
                move.setOnClickListener(v -> {
                    if (!selected.isEmpty()) {
                        showMoveProductsTagDialog(new ArrayList<>(selected), () -> {
                            selected.clear();
                            selecting[0] = false;
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                bar.addView(move, new LinearLayout.LayoutParams(dp(92), dp(38)));

                TextView cancel = button("キャンセル", DGRAY, 13);
                cancel.setOnClickListener(v -> {
                    selected.clear();
                    selecting[0] = false;
                    render[0].run();
                });
                LinearLayout.LayoutParams canLp = new LinearLayout.LayoutParams(dp(96), dp(38));
                canLp.leftMargin = dp(6);
                bar.addView(cancel, canLp);
                listHost.addView(bar);
            }

            if (products.isEmpty()) {
                TextView empty = text("条件に一致する商品がありません。", 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(dp(16), dp(28), dp(16), dp(28));
                listHost.addView(empty);
                return;
            }

            LinearLayout sheet = new LinearLayout(this);
            sheet.setOrientation(LinearLayout.VERTICAL);
            boolean storeWholeList = fixedStoreId != null;
            ArrayList<String> columnOrder = loadProductColumnOrder(storeWholeList);
            sheet.addView(makeReorderableProductHeader(columnOrder, storeWholeList, render[0]));
            String last = null;
            for (DatabaseHelper.ProductRecord p : products) {
                String key = p.normalizedName == null ? p.rawName : p.normalizedName;
                String productCell = key != null && key.equals(last) ? "" : p.rawName;
                last = key;
                LinearLayout row = makeProductDataRow(columnOrder, p, productCell);
                View compareIcon = row.findViewWithTag("product_compare_icon");
                if (compareIcon != null) {
                    compareIcon.setOnClickListener(v -> {
                        if (selecting[0]) {
                            if (selected.contains(p.id)) selected.remove(p.id); else selected.add(p.id);
                            render[0].run();
                        } else {
                            showSameProductPrices(p.productKey == null ? p.rawName : p.productKey);
                        }
                    });
                }
                if (selecting[0] && selected.contains(p.id)) row.setBackgroundColor(BLUE);
                row.setOnClickListener(v -> {
                    if (selecting[0]) {
                        if (selected.contains(p.id)) selected.remove(p.id); else selected.add(p.id);
                        DiagLog.write(this, "PRODUCT_SELECT_TOGGLE scope=list product=" + p.id +
                                " selected=" + selected.contains(p.id) + " count=" + selected.size());
                        render[0].run();
                    } else {
                        DatabaseHelper.ProductRecord fresh = db.getProduct(p.id);
                        showProductEditor(fresh == null ? p : fresh, () -> {
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                row.setOnLongClickListener(v -> {
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    if (!selecting[0]) {
                        selecting[0] = true;
                        selected.clear();
                        selected.add(p.id);
                        DiagLog.write(this, "PRODUCT_SELECT_START scope=list product=" + p.id + " source=long_press");
                    } else {
                        if (selected.contains(p.id)) selected.remove(p.id); else selected.add(p.id);
                    }
                    render[0].run();
                    return true;
                });
                sheet.addView(row);
            }

            HorizontalScrollView hsv = new HorizontalScrollView(this);
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.addView(sheet);
            ScrollView vsv = new ScrollView(this);
            vsv.addView(hsv);
            listHost.addView(vsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        };

        panel.setTag(render[0]);

        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                query[0] = s == null ? "" : s.toString();
                selected.clear();
                selecting[0] = false;
                render[0].run();
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        render[0].run();
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(panel)
                .setNegativeButton("閉じる", null)
                .create();
        productDialogRef[0] = dialog;
        showRoundedDialog(dialog, true);
    }

    private String storeNameForId(long storeId) {
        DatabaseHelper.Store s = db.getStore(storeId);
        return s == null ? "不明" : s.name;
    }

    private void showImportHistoryDialog(Long storeId) {
        DiagLog.write(this, "CSV_HISTORY_OPEN scope=" + (storeId == null ? "all" : ("store:" + storeId)));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(8));

        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(rows);
        content.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(470)));

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            rows.removeAllViews();
            List<DatabaseHelper.ImportBatch> batches = db.listImportBatches(storeId);
            if (batches.isEmpty()) {
                TextView empty = text("CSV取込はまだありません。", 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(dp(12), dp(30), dp(12), dp(30));
                rows.addView(empty);
                return;
            }
            for (DatabaseHelper.ImportBatch batch : batches) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(14), dp(10), dp(10), dp(8));
                card.setBackground(roundRect(DGRAY, 14));

                TextView date = text(dateFormat.format(new Date(batch.importedAt)), 14, WHITE, true);
                card.addView(date, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26)));

                TextView file = text(batch.fileName, 13, SECONDARY, false);
                file.setSingleLine(true);
                card.addView(file, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

                String stores = batch.storeNames == null || batch.storeNames.trim().isEmpty() ? "" : "  /  " + batch.storeNames;
                TextView meta = text(batch.itemCount + "件（追加" + batch.addCount + " / 更新" + batch.updateCount + "）" + stores,
                        12, SECONDARY, false);
                card.addView(meta, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

                card.setOnClickListener(v -> showImportBatchContents(batch));

                LinearLayout batchActions = new LinearLayout(this);
                batchActions.setGravity(Gravity.CENTER_VERTICAL);

                TextView reload = makeDialogAction("再読み込み");
                reload.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                reload.setOnClickListener(v -> confirmReloadImportBatch(batch, () -> {
                    reloadStores();
                    render[0].run();
                }));
                batchActions.addView(reload, new LinearLayout.LayoutParams(0, dp(42), 1f));

                TextView undo = makeDialogAction("このCSVを消去");
                undo.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                undo.setOnClickListener(v -> {
                    AlertDialog confirm = new AlertDialog.Builder(this)
                            .setTitle("CSV消去")
                            .setMessage(dateFormat.format(new Date(batch.importedAt)) + "\n" + batch.fileName +
                                    "\n\nこのCSVで追加した商品は削除し、更新した商品は取込前の状態へ戻します。" +
                                    "\n店舗・タグ・元画像は削除しません。")
                            .setNegativeButton("キャンセル", null)
                            .setPositiveButton("消去", (d, which) -> {
                                DatabaseHelper.RollbackResult result = db.rollbackImportBatch(batch.id);
                                DiagLog.write(this, "CSV_BATCH_ROLLBACK batch=" + batch.id +
                                        " deleted=" + result.deleted + " restored=" + result.restored + " missing=" + result.missing);
                                Toast.makeText(this, "削除 " + result.deleted + " / 復元 " + result.restored +
                                        (result.missing == 0 ? "" : " / 対象なし " + result.missing), Toast.LENGTH_LONG).show();
                                reloadStores();
                                render[0].run();
                            })
                            .create();
                    showRoundedDialog(confirm);
                });
                batchActions.addView(undo, new LinearLayout.LayoutParams(dp(132), dp(42)));
                card.addView(batchActions, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.bottomMargin = dp(8);
                rows.addView(card, lp);
            }
        };

        render[0].run();
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(storeId == null ? "全CSV一覧" : storeNameForId(storeId) + " CSV一覧")
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        showRoundedDialog(dialog, true);
    }

    private void confirmReloadImportBatch(DatabaseHelper.ImportBatch batch, Runnable afterReload) {
        if (batch == null) return;
        AlertDialog confirm = new AlertDialog.Builder(this)
                .setTitle("CSV再読み込み")
                .setMessage("編集したデータは削除されます。\n\n" + batch.fileName + " を元のCSV内容で再読み込みしますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("再読み込み", (d, which) -> reloadImportBatch(batch, afterReload))
                .create();
        showRoundedDialog(confirm);
    }

    private void reloadImportBatch(DatabaseHelper.ImportBatch batch, Runnable afterReload) {
        long started = SystemClock.elapsedRealtime();
        DiagLog.write(this, "CSV_BATCH_RELOAD_START batch=" + batch.id + " file=" + batch.fileName);
        try {
            CsvImporter.Result parsed;
            Uri sourceUri = null;
            if (batch.rawCsv != null && !batch.rawCsv.isEmpty()) {
                parsed = CsvImporter.parseText(batch.rawCsv);
                if (batch.sourceUri != null && !batch.sourceUri.isEmpty()) sourceUri = Uri.parse(batch.sourceUri);
            } else if (batch.sourceUri != null && !batch.sourceUri.isEmpty()) {
                sourceUri = Uri.parse(batch.sourceUri);
                try (InputStream in = getContentResolver().openInputStream(sourceUri)) {
                    if (in == null) throw new IllegalStateException("元CSVを開けません");
                    parsed = CsvImporter.parse(in);
                }
            } else {
                throw new IllegalStateException("元CSVを保持していないため再読み込みできません");
            }

            DatabaseHelper.RollbackResult rollback = db.rollbackImportBatch(batch.id);
            DiagLog.write(this, "CSV_BATCH_RELOAD_ROLLBACK batch=" + batch.id +
                    " deleted=" + rollback.deleted + " restored=" + rollback.restored + " missing=" + rollback.missing);
            ArrayList<ImportPreviewRow> preview = buildImportPreview(parsed.rows);
            importCsvRows(sourceUri, batch.fileName, preview, parsed.rawText, false);
            DiagLog.write(this, "CSV_BATCH_RELOAD_OK oldBatch=" + batch.id +
                    " rows=" + preview.size() + " ms=" + (SystemClock.elapsedRealtime() - started));
            Toast.makeText(this, "CSVを再読み込みしました", Toast.LENGTH_LONG).show();
            if (afterReload != null) afterReload.run();
        } catch (Exception e) {
            DiagLog.write(this, "CSV_BATCH_RELOAD_ERROR batch=" + batch.id + " err=" + e);
            AlertDialog error = new AlertDialog.Builder(this)
                    .setTitle("CSV再読み込み")
                    .setMessage("再読み込みできませんでした。\n\n" + e.getMessage())
                    .setPositiveButton("閉じる", null)
                    .create();
            showRoundedDialog(error);
        }
    }

    private void showImportBatchContents(DatabaseHelper.ImportBatch batch) {
        if (batch == null) return;
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(4), dp(10), dp(8));

        TextView meta = text(dateFormat.format(new Date(batch.importedAt)) + "  /  " + batch.itemCount + "件\n" + batch.fileName,
                12, SECONDARY, false);
        meta.setPadding(dp(4), dp(2), dp(4), dp(8));
        content.addView(meta);

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        int[] widths = {90, 240, 170, 100, 90, 110, 150};
        sheet.addView(sheetHeader(new String[]{"動作", "商品名", "店舗", "価格", "容量", "タグ", "source_image"}, widths));
        List<DatabaseHelper.ImportBatchRow> rows = db.listImportBatchRows(batch.id);
        for (DatabaseHelper.ImportBatchRow row : rows) {
            sheet.addView(sheetRow(new String[]{row.actionLabel(), row.productName, row.storeName,
                    row.priceYen == null ? "—" : yen(row.priceYen), row.volume == null ? "—" : row.volume,
                    row.tagName == null ? "—" : row.tagName, row.sourceImage == null ? "—" : row.sourceImage}, widths));
        }
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(sheet);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(hsv);
        content.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(500)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("CSV内容")
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        showRoundedDialog(dialog, true);
    }

    private void showProductEditor(DatabaseHelper.ProductRecord product, Runnable afterSave) {
        if (product == null) return;

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(8), dp(20), dp(6));

        final long[] selectedStore = {product.storeId};
        TextView storeButton = button("店舗: " + product.storeName, DGRAY, 14);
        storeButton.setOnClickListener(v -> showStoreChoiceForEditor(selectedStore, storeButton));
        LinearLayout.LayoutParams storeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        storeLp.bottomMargin = dp(8);
        panel.addView(storeButton, storeLp);

        EditText name = dialogInput("商品名");
        name.setText(product.rawName == null ? "" : product.rawName);
        addProductEditField(panel, "商品名", name);

        EditText price = dialogInput("価格");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        price.setText(product.priceYen == null ? "" : String.valueOf(product.priceYen));
        addProductEditField(panel, "価格（円）", price);

        EditText volume = dialogInput("容量");
        volume.setText(product.volume == null ? "" : product.volume);
        addProductEditField(panel, "容量", volume);

        EditText productKey = dialogInput("product_key");
        productKey.setText(product.productKey == null ? product.rawName : product.productKey);
        addProductEditField(panel, "product_key", productKey);

        EditText priceType = dialogInput("価格種別");
        priceType.setText(product.priceType == null ? "" : product.priceType);
        addProductEditField(panel, "価格種別", priceType);

        final Long[] selectedTag = {product.tagId};
        TextView tagButton = button("タグ: " + (product.tagName == null ? "タグなし" : product.tagName), DGRAY, 14);
        tagButton.setOnClickListener(v -> showTagChoiceForEditor(selectedTag, tagButton));
        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        tagLp.topMargin = dp(10);
        panel.addView(tagButton, tagLp);

        TextView compare = makeDialogAction("同じ商品の他店舗価格");
        compare.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        compare.setOnClickListener(v -> showSameProductPrices(productKey.getText().toString().trim().isEmpty()
                ? name.getText().toString().trim() : productKey.getText().toString().trim()));
        LinearLayout.LayoutParams compareLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        compareLp.topMargin = dp(4);
        panel.addView(compare, compareLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("商品編集")
                .setView(panel)
                .setNeutralButton("削除", null)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener(v -> {
                AlertDialog confirm = new AlertDialog.Builder(this)
                        .setTitle("商品削除")
                        .setMessage("「" + product.rawName + "」を削除しますか？\n元画像は削除されません。")
                        .setNegativeButton("キャンセル", null)
                        .setPositiveButton("削除", (dd, which) -> {
                            db.deleteProduct(product.id);
                            DiagLog.write(this, "PRODUCT_DELETE id=" + product.id + " source=editor");
                            dialog.dismiss();
                            if (afterSave != null) afterSave.run();
                        })
                        .create();
                showRoundedDialog(confirm);
            });

            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String n = name.getText().toString().trim();
                if (n.isEmpty()) { name.setError("商品名を入力"); return; }
                Integer priceValue = null;
                String priceText = price.getText().toString().trim();
                if (!priceText.isEmpty()) {
                    try { priceValue = Integer.parseInt(priceText); }
                    catch (NumberFormatException ex) { price.setError("整数で入力"); return; }
                }
                if (db.getStore(selectedStore[0]) == null) {
                    Toast.makeText(this, "店舗を選択してください", Toast.LENGTH_SHORT).show();
                    return;
                }
                db.updateProductDetails(product.id, n, productKey.getText().toString(), priceValue,
                        volume.getText().toString(), priceType.getText().toString(), selectedTag[0], selectedStore[0]);
                DiagLog.write(this, "PRODUCT_EDIT id=" + product.id + " store=" + selectedStore[0] +
                        " tag=" + (selectedTag[0] == null ? "none" : selectedTag[0]));
                dialog.dismiss();
                if (afterSave != null) afterSave.run();
            });
        });
        showRoundedDialog(dialog, true);
    }

    private void addProductEditField(LinearLayout panel, String label, EditText input) {
        TextView l = text(label, 12, SECONDARY, false);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24));
        llp.topMargin = dp(4);
        panel.addView(l, llp);
        panel.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
    }

    private void showStoreChoiceForEditor(long[] selectedStore, TextView button) {
        List<DatabaseHelper.Store> stores = db.listStores();
        if (stores.isEmpty()) {
            Toast.makeText(this, "店舗がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[stores.size()];
        for (int i = 0; i < stores.size(); i++) names[i] = stores.get(i).name;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗を選択")
                .setItems(names, (d, which) -> {
                    DatabaseHelper.Store store = stores.get(which);
                    selectedStore[0] = store.id;
                    button.setText("店舗: " + store.name);
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private void showTagChoiceForEditor(Long[] selectedTag, TextView button) {
        List<DatabaseHelper.Tag> tags = db.listTags();
        String[] names = new String[tags.size() + 2];
        names[0] = "タグなし";
        for (int i = 0; i < tags.size(); i++) names[i + 1] = tags.get(i).name;
        names[names.length - 1] = "＋ 新しいタグ";

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグを選択")
                .setItems(names, (d, which) -> {
                    if (which == names.length - 1) {
                        showCreateTagForEditor(selectedTag, button);
                    } else if (which == 0) {
                        selectedTag[0] = null;
                        button.setText("タグ: タグなし");
                    } else {
                        DatabaseHelper.Tag tag = tags.get(which - 1);
                        selectedTag[0] = tag.id;
                        button.setText("タグ: " + tag.name);
                    }
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private void showCreateTagForEditor(Long[] selectedTag, TextView button) {
        EditText input = dialogInput("新しいタグ");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新しいタグ")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("追加", null)
                .create();
        dialog.setOnShowListener(d -> {
            focusAndShowKeyboard(input, dialog);
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
                Long tagId = db.ensureTag(name);
                if (tagId == null) { input.setError("タグを作成できませんでした"); return; }
                selectedTag[0] = tagId;
                button.setText("タグ: " + name);
                DiagLog.write(this, "ADD_TAG_FROM_PRODUCT tag=" + tagId + " name=" + name);
                dialog.dismiss();
                reloadStores();
            });
        });
        showRoundedDialog(dialog);
    }

    private void showSameProductPrices(String productKey) {
        List<DatabaseHelper.ProductRecord> rows = db.listSameProductAcrossStores(productKey);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(6), dp(10), dp(6));

        if (rows.isEmpty()) {
            TextView empty = text("他店舗の価格データはありません。", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(16), dp(26), dp(16), dp(26));
            content.addView(empty);
        } else {
            LinearLayout sheet = new LinearLayout(this);
            sheet.setOrientation(LinearLayout.VERTICAL);
            int[] widths = {190, 120, 100, 120};
            sheet.addView(sheetHeader(new String[]{"店舗", "価格", "容量", "日付"}, widths));
            for (DatabaseHelper.ProductRecord p : rows) {
                sheet.addView(sheetRow(new String[]{p.storeName, p.priceYen == null ? "—" : yen(p.priceYen),
                        p.volume == null ? "—" : p.volume, dateFormat.format(new Date(p.photoCreatedAt))}, widths));
            }
            content.addView(wrapHorizontal(sheet));
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(productKey == null || productKey.trim().isEmpty() ? "他店舗価格" : productKey)
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        showRoundedDialog(dialog, true);
    }

    private void confirmDeleteProducts(List<Long> productIds, Runnable afterDelete) {
        if (productIds == null || productIds.isEmpty()) return;
        AlertDialog confirm = new AlertDialog.Builder(this)
                .setTitle("商品削除")
                .setMessage(productIds.size() + "件の商品を削除しますか？\n元画像は削除されません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, which) -> {
                    db.deleteProducts(productIds);
                    DiagLog.write(this, "PRODUCT_BULK_DELETE count=" + productIds.size());
                    Toast.makeText(this, productIds.size() + "件削除しました", Toast.LENGTH_SHORT).show();
                    if (afterDelete != null) afterDelete.run();
                })
                .create();
        showRoundedDialog(confirm);
    }

    private void showMoveProductsTagDialog(List<Long> productIds, Runnable afterMove) {
        if (productIds == null || productIds.isEmpty()) return;
        List<DatabaseHelper.Tag> tags = db.listTags();
        String[] names = new String[tags.size() + 2];
        names[0] = "タグなし";
        for (int i = 0; i < tags.size(); i++) names[i + 1] = tags.get(i).name;
        names[names.length - 1] = "＋ 新しいタグ";
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(productIds.size() + "件をタグ移動")
                .setItems(names, (d, which) -> {
                    if (which == names.length - 1) {
                        showCreateTagAndMove(productIds, afterMove);
                        return;
                    }
                    Long tagId = which == 0 ? null : tags.get(which - 1).id;
                    db.updateProductsTag(productIds, tagId);
                    DiagLog.write(this, "PRODUCT_TAG_MOVE count=" + productIds.size() + " tag=" + (tagId == null ? "none" : tagId));
                    if (afterMove != null) afterMove.run();
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private void showCreateTagAndMove(List<Long> productIds, Runnable afterMove) {
        EditText input = dialogInput("新しいタグ");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新しいタグ")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("作成して移動", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            Long tagId = db.ensureTag(name);
            if (tagId == null) { input.setError("タグを作成できませんでした"); return; }
            db.updateProductsTag(productIds, tagId);
            DiagLog.write(this, "PRODUCT_TAG_MOVE count=" + productIds.size() + " tag=" + tagId + " created=true");
            dialog.dismiss();
            if (afterMove != null) afterMove.run();
        }));
        showRoundedDialog(dialog);
    }

    private void showDiagnosticLog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(16), dp(20), dp(10));

        TextView title = text("診断ログ", 21, WHITE, true);
        panel.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        TextView body = text(DiagLog.report(this), 11, WHITE, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(10), dp(8), dp(10), dp(8));
        body.setBackground(roundRect(DGRAY, 10));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(8), 0, 0);

        TextView clearAction = makeDialogAction("ログ消去");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);

        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));

        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .create();

        clearAction.setOnClickListener(v -> {
            DiagLog.clear(this);
            body.setText(DiagLog.report(this));
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        copyAction.setOnClickListener(v -> {
            String report = DiagLog.report(this);
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("PriceRec diagnostic", report));
            Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
        });
        closeAction.setOnClickListener(v -> dialog.dismiss());

        showRoundedDialog(dialog, true);
    }

    private long selectedTagForStore(long storeId) {
        long id = getPreferences(MODE_PRIVATE).getLong("selected_tag_" + storeId, Long.MIN_VALUE);
        if (id == -1L) return -1L;
        if (id != Long.MIN_VALUE && db.tagExists(id)) return id;
        List<DatabaseHelper.Tag> tags = db.listTags();
        return tags.isEmpty() ? -1L : tags.get(0).id;
    }

    private void saveSelectedTag(long storeId, long tagId) {
        getPreferences(MODE_PRIVATE).edit().putLong("selected_tag_" + storeId, tagId).apply();
    }

    private String safeFolder(String name) {
        String s = name.replace('/', '_').replace('\\', '_').trim();
        return s.isEmpty() ? "Store" : s;
    }

    private String ocrStatusLabel(String s) {
        if (s == null || "pending".equals(s)) return "未解析";
        if ("processing".equals(s)) return "解析中";
        if ("done".equals(s)) return "完了";
        if ("no_results".equals(s)) return "候補なし";
        if ("error".equals(s)) return "エラー";
        return s;
    }

    private Bitmap loadBitmap(Uri uri, int targetW, int targetH) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
                int w = info.getSize().getWidth();
                int h = info.getSize().getHeight();
                if (w <= 0 || h <= 0) return;
                double scale = Math.min(1.0, Math.min((double) targetW / w, (double) targetH / h));
                decoder.setTargetSize(Math.max(1, (int) (w * scale)), Math.max(1, (int) (h * scale)));
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            });
        } catch (Exception e) {
            DiagLog.write(this, "IMAGE_LOAD_ERROR uri=" + uri + " err=" + e);
            return null;
        }
    }

    private String yen(int price) {
        return "¥" + NumberFormat.getIntegerInstance(Locale.JAPAN).format(price);
    }

    private View wrapHorizontal(View child) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(child);
        return hsv;
    }

    private ArrayList<String> loadProductColumnOrder(boolean storeWholeList) {
        // v2 intentionally starts from the new compact list layout while preserving future user changes.
        String prefKey = storeWholeList ? "product_columns_store_v2" : "product_columns_all_v2";
        String defaultOrder = storeWholeList
                ? "price,volume,tag,date,store"
                : "price,store,volume,tag,date";
        String saved = getPreferences(MODE_PRIVATE).getString(prefKey, defaultOrder);
        String[] allowed = {"store", "price", "volume", "tag", "date"};
        ArrayList<String> nonProduct = new ArrayList<>();
        if (saved != null) {
            for (String part : saved.split(",")) {
                String key = part.trim();
                for (String a : allowed) {
                    if (a.equals(key) && !nonProduct.contains(key)) {
                        nonProduct.add(key);
                        break;
                    }
                }
            }
        }
        for (String a : allowed) if (!nonProduct.contains(a)) nonProduct.add(a);
        if (storeWholeList) {
            nonProduct.remove("store");
            nonProduct.add("store");
        }
        ArrayList<String> out = new ArrayList<>();
        out.add("product");
        out.addAll(nonProduct);
        return out;
    }

    private void saveProductColumnOrder(List<String> order, boolean storeWholeList) {
        ArrayList<String> nonProduct = new ArrayList<>();
        for (String key : order) if (!"product".equals(key)) nonProduct.add(key);
        if (storeWholeList) {
            nonProduct.remove("store");
            nonProduct.add("store");
        }
        getPreferences(MODE_PRIVATE).edit()
                .putString(storeWholeList ? "product_columns_store_v2" : "product_columns_all_v2", String.join(",", nonProduct))
                .apply();
        DiagLog.write(this, "PRODUCT_COLUMNS_SAVE scope=" + (storeWholeList ? "store" : "all") +
                " order=" + String.join(",", nonProduct));
    }

    private LinearLayout makeReorderableProductHeader(ArrayList<String> order, boolean storeWholeList, Runnable rerender) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(DGRAY);
        final int longPressMs = android.view.ViewConfiguration.getLongPressTimeout();
        final int touchSlop = android.view.ViewConfiguration.get(this).getScaledTouchSlop();
        for (String key : order) {
            TextView cell = text(productColumnLabel(key), 13, SECONDARY, true);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            cell.setLayoutParams(new LinearLayout.LayoutParams(dp(productColumnWidth(key)), dp(38)));
            boolean fixed = "product".equals(key) || (storeWholeList && "store".equals(key));
            if (!fixed) {
                final float[] downX = {0f};
                final float[] downY = {0f};
                final boolean[] longPressed = {false};
                final boolean[] cancelled = {false};
                final Runnable activate = () -> {
                    if (cancelled[0]) return;
                    longPressed[0] = true;
                    cell.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    cell.animate().alpha(0.72f).scaleX(1.03f).scaleY(1.03f).setDuration(90).start();
                    ViewParentDisallow(cell, true);
                    DiagLog.write(this, "PRODUCT_COLUMN_DRAG_START scope=" + (storeWholeList ? "store" : "all") + " column=" + key);
                };
                cell.setOnTouchListener((v, event) -> {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX[0] = event.getRawX();
                            downY[0] = event.getRawY();
                            cancelled[0] = false;
                            longPressed[0] = false;
                            v.postDelayed(activate, longPressMs);
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getRawX() - downX[0];
                            float dy = event.getRawY() - downY[0];
                            if (!longPressed[0]) {
                                if (Math.hypot(dx, dy) > touchSlop) {
                                    cancelled[0] = true;
                                    v.removeCallbacks(activate);
                                    return false;
                                }
                            } else {
                                v.setTranslationX(dx);
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            v.removeCallbacks(activate);
                            float totalDx = event.getRawX() - downX[0];
                            boolean doMove = longPressed[0] && event.getActionMasked() == MotionEvent.ACTION_UP;
                            v.animate().translationX(0f).alpha(1f).scaleX(1f).scaleY(1f).setDuration(120).start();
                            ViewParentDisallow(v, false);
                            if (doMove) {
                                int from = order.indexOf(key);
                                int min = 1;
                                int max = storeWholeList ? order.size() - 2 : order.size() - 1;
                                int stepWidth = dp(84);
                                int steps = Math.round(totalDx / Math.max(1f, stepWidth));
                                int to = Math.max(min, Math.min(max, from + steps));
                                if (to != from) {
                                    order.remove(from);
                                    order.add(to, key);
                                    saveProductColumnOrder(order, storeWholeList);
                                    v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                                    DiagLog.write(this, "PRODUCT_COLUMN_DRAG_END scope=" + (storeWholeList ? "store" : "all") +
                                            " column=" + key + " from=" + from + " to=" + to);
                                    if (rerender != null) rerender.run();
                                }
                            }
                            longPressed[0] = false;
                            cancelled[0] = true;
                            return true;
                        default:
                            return true;
                    }
                });
            }
            row.addView(cell);
        }
        return row;
    }

    private void ViewParentDisallow(View view, boolean disallow) {
        if (view != null && view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(disallow);
    }

    private String productColumnLabel(String key) {
        switch (key) {
            case "product": return "商品名";
            case "store": return "店舗";
            case "price": return "価格";
            case "volume": return "容量";
            case "tag": return "タグ";
            case "date": return "日付";
            default: return key;
        }
    }

    private int productColumnWidth(String key) {
        switch (key) {
            case "product": return 220;
            case "store": return 135;
            case "price": return 105;
            case "volume": return 95;
            case "tag": return 105;
            case "date": return 145;
            default: return 100;
        }
    }

    private String productColumnValue(String key, DatabaseHelper.ProductRecord p, String productCell) {
        switch (key) {
            case "product": return productCell == null ? "" : productCell;
            case "store": return p.storeName == null ? "—" : p.storeName;
            case "price": return p.priceYen == null ? "—" : yen(p.priceYen) + priceTaxMarker(p.priceType);
            case "volume": return p.volume == null ? "—" : p.volume;
            case "tag": return p.tagName == null ? "—" : p.tagName;
            case "date": return dateFormat.format(new Date(p.photoCreatedAt));
            default: return "";
        }
    }

    private String priceTaxMarker(String priceType) {
        if (priceType == null) return "";
        String value = priceType.trim().toLowerCase(Locale.ROOT);
        if (value.isEmpty()) return "";
        if (value.contains("税込") || value.equals("込") || value.contains("tax included") || value.contains("incl. tax") || value.contains("incl tax")) return " 込";
        if (value.contains("税抜") || value.equals("抜") || value.contains("税別") || value.contains("tax excluded") || value.contains("excl. tax") || value.contains("excl tax")) return " 抜";
        return "";
    }

    private LinearLayout makeProductDataRow(List<String> order, DatabaseHelper.ProductRecord p, String productCell) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(1), 0, dp(1));
        for (String key : order) {
            int width = productColumnWidth(key);
            if ("product".equals(key)) {
                FrameLayout cell = new FrameLayout(this);
                TextView name = text(productColumnValue(key, p, productCell), 13, WHITE, false);
                name.setGravity(Gravity.CENTER_VERTICAL);
                name.setPadding(dp(10), 0, dp(36), 0);
                cell.addView(name, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

                View magnifier = new MagnifierIconView(this);
                magnifier.setTag("product_compare_icon");
                magnifier.setContentDescription("他店舗価格を比較");
                FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(30), dp(44), Gravity.END | Gravity.CENTER_VERTICAL);
                iconLp.rightMargin = dp(3);
                cell.addView(magnifier, iconLp);
                row.addView(cell, new LinearLayout.LayoutParams(dp(width), dp(44)));
            } else {
                TextView cell = text(productColumnValue(key, p, productCell), 14, WHITE, false);
                cell.setGravity(Gravity.CENTER_VERTICAL);
                cell.setPadding(dp(10), 0, dp(10), 0);
                row.addView(cell, new LinearLayout.LayoutParams(dp(width), dp(44)));
            }
        }
        return row;
    }

    private LinearLayout sheetHeader(String[] values, int[] widthsDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(DGRAY);
        for (int i = 0; i < values.length; i++) {
            TextView cell = text(values[i], 13, SECONDARY, true);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            row.addView(cell, new LinearLayout.LayoutParams(dp(widthsDp[i]), dp(38)));
        }
        return row;
    }

    private LinearLayout sheetRow(String[] values, int[] widthsDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(1), 0, dp(1));
        for (int i = 0; i < values.length; i++) {
            TextView cell = text(values[i] == null ? "" : values[i], 14, WHITE, false);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            row.addView(cell, new LinearLayout.LayoutParams(dp(widthsDp[i]), dp(44)));
        }
        return row;
    }

    private EditText sheetEdit(String value, boolean numeric) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(14);
        e.setTextColor(WHITE);
        e.setHintTextColor(Color.parseColor("#888383"));
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER_VERTICAL);
        e.setIncludeFontPadding(false);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setBackground(roundRect(LGRAY, 8));
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView button(String value, int color, float sp) {
        TextView t = text(value, sp, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundRect(color, 999));
        return t;
    }

    private TextView chip(String value, boolean selected, boolean secondary) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? (secondary ? ORANGE : LBLUE) : DGRAY, 999));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView dialogChip(String value, boolean selected) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? LBLUE : DGRAY, 999));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView makeDialogAction(String value) {
        TextView t = text(value, 14, LBLUE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), 0, dp(8), 0);
        t.setBackgroundColor(Color.TRANSPARENT);
        return t;
    }

    private EditText dialogInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setTextSize(17);
        input.setTextColor(WHITE);
        input.setHintTextColor(Color.parseColor("#9E9999"));
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setIncludeFontPadding(false);
        input.setMinHeight(dp(48));
        input.setPadding(dp(16), 0, dp(16), 0);
        input.setBackground(roundRect(LGRAY, 10));
        input.setOnFocusChangeListener((v, hasFocus) -> input.setBackground(roundRect(LGRAY, 10)));
        return input;
    }

    private void focusAndShowKeyboard(EditText input, AlertDialog dialog) {
        Window w = dialog.getWindow();
        if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        input.postDelayed(() -> {
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }, 120);
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private void showRoundedDialog(AlertDialog dialog) {
        showRoundedDialog(dialog, false);
    }

    private void showRoundedDialog(AlertDialog dialog, boolean wide) {
        dialog.show();
        Window window = dialog.getWindow();
        if (window == null) return;
        window.setBackgroundDrawable(roundRect(GRAY, 20));
        if (wide) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private GradientDrawable roundRect(int fill, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable circle(int fill) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }


    private final class MagnifierIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        MagnifierIconView(Context context) {
            super(context);
            paint.setColor(LBLUE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setStrokeCap(Paint.Cap.SQUARE);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * 0.43f;
            float cy = h * 0.45f;
            float r = Math.min(w, h) * 0.16f;
            canvas.drawCircle(cx, cy, r, paint);
            float startX = cx + r * 0.72f;
            float startY = cy + r * 0.72f;
            canvas.drawLine(startX, startY, w * 0.72f, h * 0.68f, paint);
        }
    }

    private final class StraightSelectionCheckView extends View {
        private final Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        StraightSelectionCheckView(Context context) {
            super(context);
            checkPaint.setColor(WHITE);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(dp(2));
            checkPaint.setStrokeCap(Paint.Cap.SQUARE);
            checkPaint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            canvas.drawLine(w * 0.14f, h * 0.52f, w * 0.40f, h * 0.76f, checkPaint);
            canvas.drawLine(w * 0.40f, h * 0.76f, w * 0.86f, h * 0.25f, checkPaint);
        }
    }

    private final class StraightCheckBadgeView extends View {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        StraightCheckBadgeView(Context context) {
            super(context);
            fillPaint.setColor(CSV_GREEN);
            fillPaint.setStyle(Paint.Style.FILL);
            checkPaint.setColor(WHITE);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(dp(2));
            checkPaint.setStrokeCap(Paint.Cap.SQUARE);
            checkPaint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(w, h) / 2f;
            canvas.drawCircle(w / 2f, h / 2f, r, fillPaint);
            canvas.drawLine(w * 0.27f, h * 0.53f, w * 0.44f, h * 0.69f, checkPaint);
            canvas.drawLine(w * 0.44f, h * 0.69f, w * 0.76f, h * 0.34f, checkPaint);
        }
    }

    private final class ZoomImageView extends ImageView {
        private final Matrix zoomMatrix = new Matrix();
        private final ScaleGestureDetector scaleDetector;
        private final GestureDetector gestureDetector;
        private float scale = 1f;
        private float minScale = 0.1f;
        private final float maxScale = 8f;
        private float lastX;
        private float lastY;
        private boolean dragging;

        ZoomImageView(Context context) {
            super(context);
            setScaleType(ScaleType.MATRIX);
            scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float wanted = scale * detector.getScaleFactor();
                    float clamped = Math.max(minScale, Math.min(maxScale, wanted));
                    float factor = clamped / scale;
                    zoomMatrix.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                    scale = clamped;
                    setImageMatrix(zoomMatrix);
                    return true;
                }
            });
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    resetToOriginalPixels();
                    return true;
                }
            });
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            post(this::resetToOriginalPixels);
        }

        private void resetToOriginalPixels() {
            if (getDrawable() == null || getWidth() <= 0 || getHeight() <= 0) return;
            int dw = Math.max(1, getDrawable().getIntrinsicWidth());
            int dh = Math.max(1, getDrawable().getIntrinsicHeight());
            minScale = Math.min(1f, Math.min((float) getWidth() / dw, (float) getHeight() / dh));
            scale = 1f;
            zoomMatrix.reset();
            float dx = (getWidth() - dw) / 2f;
            float dy = (getHeight() - dh) / 2f;
            zoomMatrix.postTranslate(dx, dy);
            setImageMatrix(zoomMatrix);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);
            gestureDetector.onTouchEvent(event);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    dragging = true;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging && !scaleDetector.isInProgress() && event.getPointerCount() == 1) {
                        float dx = event.getX() - lastX;
                        float dy = event.getY() - lastY;
                        zoomMatrix.postTranslate(dx, dy);
                        setImageMatrix(zoomMatrix);
                        lastX = event.getX();
                        lastY = event.getY();
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerCount() - 1 == 1) {
                        int remain = event.getActionIndex() == 0 ? 1 : 0;
                        if (remain < event.getPointerCount()) {
                            lastX = event.getX(remain);
                            lastY = event.getY(remain);
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
                default:
                    return true;
            }
        }
    }

    private static final class DragPayload {
        final String type; final long id;
        DragPayload(String type, long id) { this.type = type; this.id = id; }
    }

    private static final class ShareImageInfo {
        final int width; final int height; final long bytes;
        ShareImageInfo(int width, int height, long bytes) { this.width = width; this.height = height; this.bytes = bytes; }
    }

    private static final class ImportPreviewRow {
        static final String ADD = "追加";
        static final String UPDATE = "更新";
        static final String SKIP = "スキップ";
        final CsvImporter.Row row;
        String status = "";
        String action = ADD;
        long existingProductId = -1L;
        ImportPreviewRow(CsvImporter.Row row) { this.row = row; }
    }

    private static final class OcrEditorRow {
        final LinearLayout row; final EditText name; final EditText price;
        OcrEditorRow(LinearLayout row, EditText name, EditText price) { this.row = row; this.name = name; this.price = price; }
    }
}
