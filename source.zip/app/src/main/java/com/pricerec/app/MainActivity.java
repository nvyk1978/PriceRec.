package com.pricerec.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final int REQ_CAMERA = 4101;

    private static final int BG = Color.parseColor("#303030");
    private static final int DGRAY = Color.parseColor("#2A2222");
    private static final int GRAY = Color.parseColor("#3A3333");
    private static final int LGRAY = Color.parseColor("#5A5555");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int LBLUE = Color.parseColor("#445577");
    private static final int RED = Color.parseColor("#441100");
    private static final int LRED = Color.parseColor("#882211");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int WHITE = Color.WHITE;
    private static final int SECONDARY = Color.parseColor("#C9C4C4");

    private DatabaseHelper db;
    private LinearLayout storeContainer;
    private EditText searchInput;
    private long expandedStoreId = -1L;
    private final Map<Long, String> activeTab = new HashMap<>();

    private Uri pendingPhotoUri;
    private long pendingStoreId = -1L;
    private Long pendingTagId = null;
    private String pendingStoreName = null;

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DatabaseHelper(this);
        DiagLog.write(this, "APP_START version=0.1.0");

        if (state != null) {
            String uri = state.getString("pending_uri");
            if (uri != null) pendingPhotoUri = Uri.parse(uri);
            pendingStoreId = state.getLong("pending_store", -1L);
            if (state.containsKey("pending_tag")) {
                long tag = state.getLong("pending_tag", -1L);
                pendingTagId = tag < 0 ? null : tag;
            }
            pendingStoreName = state.getString("pending_store_name");
            expandedStoreId = state.getLong("expanded_store", -1L);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(14), top + dp(8), dp(14), bottom + dp(8));
            return insets;
        });

        TextView title = text("PRICE REC.", 25, WHITE, true);
        title.setLetterSpacing(0.08f);
        title.setPadding(dp(4), dp(4), dp(4), dp(12));
        title.setOnLongClickListener(v -> {
            showDiagnosticLog();
            return true;
        });
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        storeContainer = new LinearLayout(this);
        storeContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(storeContainer, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(scroll, scrollLp);

        root.addView(makeBottomBar(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        reloadStores();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (pendingPhotoUri != null) out.putString("pending_uri", pendingPhotoUri.toString());
        out.putLong("pending_store", pendingStoreId);
        out.putLong("pending_tag", pendingTagId == null ? -1L : pendingTagId);
        out.putString("pending_store_name", pendingStoreName);
        out.putLong("expanded_store", expandedStoreId);
    }

    private View makeBottomBar() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, 0);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(WHITE);
        searchInput.setHintTextColor(Color.parseColor("#9E9999"));
        searchInput.setTextSize(16);
        searchInput.setHint("検索モード");
        searchInput.setPadding(dp(16), 0, dp(16), 0);
        searchInput.setBackground(roundRect(DGRAY, 22, LGRAY, 1));
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        searchLp.rightMargin = dp(12);
        row.addView(searchInput, searchLp);

        TextView add = button("＋", LBLUE, 22);
        add.setGravity(Gravity.CENTER);
        add.setOnClickListener(v -> showAddStoreDialog());
        row.addView(add, new LinearLayout.LayoutParams(dp(48), dp(48)));
        return row;
    }

    private void reloadStores() {
        storeContainer.removeAllViews();
        List<DatabaseHelper.Store> stores = db.listStores();
        if (stores.isEmpty()) {
            TextView empty = text("右下の＋から店舗を追加", 16, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(80), 0, 0);
            storeContainer.addView(empty, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return;
        }

        for (DatabaseHelper.Store store : stores) {
            storeContainer.addView(makeStoreCard(store));
        }
    }

    private View makeStoreCard(DatabaseHelper.Store store) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundRect(GRAY, 18, LGRAY, 1));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(12);
        card.setLayoutParams(cardLp);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(14), dp(12), dp(14));
        TextView name = text(store.name, 18, WHITE, true);
        TextView arrow = text(expandedStoreId == store.id ? "▲" : "▼", 14, SECONDARY, false);
        header.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(arrow);
        header.setOnClickListener(v -> {
            expandedStoreId = expandedStoreId == store.id ? -1L : store.id;
            reloadStores();
        });
        header.setOnLongClickListener(v -> {
            showStoreMenu(store);
            return true;
        });
        card.addView(header);

        if (expandedStoreId == store.id) {
            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setPadding(dp(12), 0, dp(12), dp(12));
            details.addView(makeTagSelector(store));
            details.addView(makeActionRow(store));
            details.addView(makeTabs(store));
            details.addView(makeStoreBody(store));
            card.addView(details);
        }
        return card;
    }

    private View makeTagSelector(DatabaseHelper.Store store) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView label = text("撮影タグ", 13, SECONDARY, false);
        label.setPadding(dp(4), 0, 0, dp(6));
        box.addView(label);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout tagsRow = new LinearLayout(this);
        tagsRow.setGravity(Gravity.CENTER_VERTICAL);
        long selected = selectedTagForStore(store.id);
        for (DatabaseHelper.Tag tag : db.listTags()) {
            TextView chip = chip(tag.name, selected == tag.id);
            chip.setOnClickListener(v -> {
                saveSelectedTag(store.id, tag.id);
                DiagLog.write(this, "SELECT_TAG store=" + store.id + " tag=" + tag.id + " name=" + tag.name);
                reloadStores();
            });
            tagsRow.addView(chip);
        }
        TextView none = chip("タグなし", selected < 0, true);
        none.setOnClickListener(v -> {
            saveSelectedTag(store.id, -1L);
            reloadStores();
        });
        tagsRow.addView(none);
        hsv.addView(tagsRow);
        box.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        return box;
    }

    private View makeActionRow(DatabaseHelper.Store store) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(8), 0, dp(8));
        TextView camera = button("撮影", BLUE, 16);
        camera.setOnClickListener(v -> takePhoto(store));
        LinearLayout.LayoutParams camLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        camLp.rightMargin = dp(8);
        row.addView(camera, camLp);

        TextView tags = button("タグ管理", DGRAY, 15);
        tags.setOnClickListener(v -> showTagManager());
        row.addView(tags, new LinearLayout.LayoutParams(0, dp(44), 1f));
        return row;
    }

    private View makeTabs(DatabaseHelper.Store store) {
        String tab = activeTab.getOrDefault(store.id, "list");
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, 0, 0, dp(8));

        TextView list = button("リスト", "list".equals(tab) ? LBLUE : DGRAY, 15);
        list.setOnClickListener(v -> { activeTab.put(store.id, "list"); reloadStores(); });
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp1.rightMargin = dp(4);
        row.addView(list, lp1);

        TextView images = button("画像", "images".equals(tab) ? LBLUE : DGRAY, 15);
        images.setOnClickListener(v -> { activeTab.put(store.id, "images"); reloadStores(); });
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp2.leftMargin = dp(4);
        row.addView(images, lp2);
        return row;
    }

    private View makeStoreBody(DatabaseHelper.Store store) {
        String tab = activeTab.getOrDefault(store.id, "list");
        return "images".equals(tab) ? makePhotoGrid(store) : makeProductList(store);
    }

    private View makeProductList(DatabaseHelper.Store store) {
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.ProductRecord> products = db.listProductsForStore(store.id);
        if (products.isEmpty()) {
            TextView empty = text("商品データはまだありません\n撮影画像からのOCR登録は次段階で追加できます", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            list.addView(empty);
            return list;
        }
        for (DatabaseHelper.ProductRecord p : products) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(10), dp(10), dp(10));
            TextView n = text(p.rawName, 15, WHITE, false);
            TextView price = text(p.priceYen == null ? "—" : yen(p.priceYen), 15, WHITE, true);
            row.addView(n, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(price);
            list.addView(row);
        }
        return list;
    }

    private View makePhotoGrid(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
        if (photos.isEmpty()) {
            TextView empty = text("撮影画像はまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }

        LinearLayout currentRow = null;
        for (int i = 0; i < photos.size(); i++) {
            if (i % 3 == 0) {
                currentRow = new LinearLayout(this);
                currentRow.setGravity(Gravity.TOP);
                outer.addView(currentRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            DatabaseHelper.Photo photo = photos.get(i);
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setPadding(dp(3), dp(3), dp(3), dp(6));
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(DGRAY);
            Bitmap bmp = loadBitmap(Uri.parse(photo.uri), 360, 360);
            if (bmp != null) image.setImageBitmap(bmp);
            tile.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));
            TextView tag = text(photo.tagName == null ? "タグなし" : photo.tagName, 12, SECONDARY, false);
            tag.setGravity(Gravity.CENTER);
            tag.setSingleLine(true);
            tile.addView(tag, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
            tile.setOnClickListener(v -> showPhotoDetail(photo, store));
            LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            currentRow.addView(tile, tileLp);
        }
        return outer;
    }

    private void showAddStoreDialog() {
        EditText input = dialogInput("店舗名");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗追加")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("追加", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("店舗名を入力"); return; }
            long id = db.addStore(name);
            if (id > 0) {
                expandedStoreId = id;
                DiagLog.write(this, "ADD_STORE id=" + id + " name=" + name);
                dialog.dismiss();
                reloadStores();
            }
        }));
        dialog.show();
    }

    private void showStoreMenu(DatabaseHelper.Store store) {
        new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setItems(new String[]{"店舗名変更", "店舗削除"}, (d, which) -> {
                    if (which == 0) showRenameStoreDialog(store);
                    else showDeleteStoreDialog(store);
                })
                .show();
    }

    private void showRenameStoreDialog(DatabaseHelper.Store store) {
        EditText input = dialogInput("店舗名");
        input.setText(store.name);
        input.setSelection(input.length());
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗名変更")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("変更", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("店舗名を入力"); return; }
            db.renameStore(store.id, name);
            DiagLog.write(this, "RENAME_STORE id=" + store.id + " name=" + name);
            dialog.dismiss();
            reloadStores();
        }));
        dialog.show();
    }

    private void showDeleteStoreDialog(DatabaseHelper.Store store) {
        new AlertDialog.Builder(this)
                .setTitle("店舗削除")
                .setMessage("「" + store.name + "」と、この店舗に紐づく撮影画像を削除します。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    for (DatabaseHelper.Photo p : db.listPhotos(store.id)) {
                        try { getContentResolver().delete(Uri.parse(p.uri), null, null); } catch (Exception ignored) { }
                    }
                    db.deleteStore(store.id);
                    if (expandedStoreId == store.id) expandedStoreId = -1L;
                    DiagLog.write(this, "DELETE_STORE id=" + store.id + " name=" + store.name);
                    reloadStores();
                }).show();
    }

    private void showTagManager() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));

        for (DatabaseHelper.Tag tag : db.listTags()) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = text(tag.name, 16, Color.BLACK, false);
            TextView del = text("削除", 14, Color.parseColor("#AA2211"), true);
            del.setGravity(Gravity.CENTER);
            del.setPadding(dp(12), dp(10), dp(12), dp(10));
            del.setOnClickListener(v -> confirmDeleteTag(tag));
            row.addView(name, new LinearLayout.LayoutParams(0, dp(48), 1f));
            row.addView(del, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
            content.addView(row);
        }

        LinearLayout addRow = new LinearLayout(this);
        addRow.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = dialogInput("新しいタグ");
        TextView add = text("追加", 15, Color.parseColor("#223355"), true);
        add.setGravity(Gravity.CENTER);
        add.setPadding(dp(12), dp(10), dp(12), dp(10));
        addRow.addView(input, new LinearLayout.LayoutParams(0, dp(50), 1f));
        addRow.addView(add, new LinearLayout.LayoutParams(dp(64), dp(50)));
        content.addView(addRow);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ管理")
                .setView(scroll)
                .setNegativeButton("閉じる", null)
                .create();
        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            long id = db.addTag(name);
            if (id < 0) {
                input.setError("同じタグがあります");
                return;
            }
            DiagLog.write(this, "ADD_TAG id=" + id + " name=" + name);
            dialog.dismiss();
            reloadStores();
            showTagManager();
        });
        dialog.show();
    }

    private void confirmDeleteTag(DatabaseHelper.Tag tag) {
        new AlertDialog.Builder(this)
                .setTitle("タグ削除")
                .setMessage("「" + tag.name + "」を削除します。\nこのタグが付いている画像は「タグなし」になります。画像自体は削除しません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    db.deleteTag(tag.id);
                    DiagLog.write(this, "DELETE_TAG id=" + tag.id + " name=" + tag.name);
                    reloadStores();
                }).show();
    }

    private void showPhotoDetail(DatabaseHelper.Photo photo, DatabaseHelper.Store store) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(10), dp(14), dp(6));

        ImageView image = new ImageView(this);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        Bitmap bmp = loadBitmap(Uri.parse(photo.uri), 1600, 1600);
        if (bmp != null) image.setImageBitmap(bmp);
        content.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320)));

        TextView meta = text(store.name + "\n" + dateFormat.format(new Date(photo.createdAt)), 14, Color.DKGRAY, false);
        meta.setPadding(0, dp(8), 0, dp(8));
        content.addView(meta);

        TextView tagLabel = text("タグ変更", 14, Color.DKGRAY, true);
        content.addView(tagLabel);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        LinearLayout tags = new LinearLayout(this);
        TextView noTag = dialogChip("タグなし", photo.tagId == null);
        noTag.setOnClickListener(v -> {
            db.updatePhotoTag(photo.id, null);
            DiagLog.write(this, "PHOTO_TAG photo=" + photo.id + " tag=null");
            reloadStores();
            Toast.makeText(this, "タグを変更しました", Toast.LENGTH_SHORT).show();
        });
        tags.addView(noTag);
        for (DatabaseHelper.Tag tag : db.listTags()) {
            TextView chip = dialogChip(tag.name, photo.tagId != null && photo.tagId == tag.id);
            chip.setOnClickListener(v -> {
                db.updatePhotoTag(photo.id, tag.id);
                DiagLog.write(this, "PHOTO_TAG photo=" + photo.id + " tag=" + tag.id + " name=" + tag.name);
                reloadStores();
                Toast.makeText(this, "タグを変更しました", Toast.LENGTH_SHORT).show();
            });
            tags.addView(chip);
        }
        hsv.addView(tags);
        content.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        TextView delete = text("画像を削除", 14, Color.parseColor("#AA2211"), true);
        delete.setGravity(Gravity.CENTER);
        delete.setPadding(dp(8), dp(12), dp(8), dp(12));
        content.addView(delete);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("撮影画像")
                .setView(scroll)
                .setNegativeButton("閉じる", null)
                .create();
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("画像削除")
                .setMessage("この撮影画像を削除します。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    try { getContentResolver().delete(Uri.parse(photo.uri), null, null); } catch (Exception ignored) { }
                    db.deletePhoto(photo.id);
                    DiagLog.write(this, "DELETE_PHOTO id=" + photo.id);
                    dialog.dismiss();
                    reloadStores();
                }).show());
        dialog.show();
    }

    private void takePhoto(DatabaseHelper.Store store) {
        try {
            long selected = selectedTagForStore(store.id);
            pendingTagId = selected < 0 ? null : selected;
            pendingStoreId = store.id;
            pendingStoreName = store.name;

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "PriceRec_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/PriceRec/" + safeFolder(store.name));
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            pendingPhotoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingPhotoUri == null) throw new IllegalStateException("MediaStore insert returned null");

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingPhotoUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            DiagLog.write(this, "CAMERA_START store=" + pendingStoreId + " tag=" + pendingTagId + " uri=" + pendingPhotoUri);
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception e) {
            DiagLog.write(this, "CAMERA_START_ERROR " + e);
            cleanupPendingPhoto();
            Toast.makeText(this, "カメラを起動できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAMERA) return;
        if (pendingPhotoUri == null) {
            DiagLog.write(this, "CAMERA_RESULT missing_pending_uri result=" + resultCode);
            return;
        }

        if (resultCode == RESULT_OK) {
            try {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(pendingPhotoUri, done, null, null);
                long photoId = db.addPhoto(pendingStoreId, pendingTagId, pendingPhotoUri.toString());
                DiagLog.write(this, "CAMERA_OK photo=" + photoId + " store=" + pendingStoreId + " tag=" + pendingTagId);
                expandedStoreId = pendingStoreId;
                activeTab.put(pendingStoreId, "images");
            } catch (Exception e) {
                DiagLog.write(this, "CAMERA_SAVE_ERROR " + e);
                Toast.makeText(this, "画像の登録に失敗しました", Toast.LENGTH_LONG).show();
            }
        } else {
            DiagLog.write(this, "CAMERA_CANCEL result=" + resultCode);
            try { getContentResolver().delete(pendingPhotoUri, null, null); } catch (Exception ignored) { }
        }
        clearPendingPhotoState();
        reloadStores();
    }

    private void cleanupPendingPhoto() {
        if (pendingPhotoUri != null) {
            try { getContentResolver().delete(pendingPhotoUri, null, null); } catch (Exception ignored) { }
        }
        clearPendingPhotoState();
    }

    private void clearPendingPhotoState() {
        pendingPhotoUri = null;
        pendingStoreId = -1L;
        pendingTagId = null;
        pendingStoreName = null;
    }

    private void runSearch(String raw) {
        String q = raw.trim();
        if (q.isEmpty()) return;
        List<DatabaseHelper.ProductRecord> results = db.searchProducts(q);
        if (results.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("検索: " + q)
                    .setMessage("該当する商品データはまだありません。\nOCR商品登録を追加すると、ここに全店舗の最安値順で表示できます。")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        StringBuilder message = new StringBuilder();
        int rank = 1;
        for (DatabaseHelper.ProductRecord p : results) {
            message.append(rank++).append(". ")
                    .append(p.rawName)
                    .append("  ")
                    .append(p.priceYen == null ? "—" : yen(p.priceYen))
                    .append("\n   ")
                    .append(p.storeName == null ? "" : p.storeName);
            if (p.tagName != null) message.append("  [").append(p.tagName).append("]");
            message.append("\n\n");
        }
        new AlertDialog.Builder(this)
                .setTitle("検索: " + q)
                .setMessage(message.toString())
                .setPositiveButton("閉じる", null)
                .show();
    }

    private void showDiagnosticLog() {
        String log = DiagLog.read(this);
        ScrollView scroll = new ScrollView(this);
        TextView body = text(log, 12, Color.DKGRAY, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(12), dp(8), dp(12), dp(8));
        scroll.addView(body);
        new AlertDialog.Builder(this)
                .setTitle("PriceRec diagnostic report")
                .setView(scroll)
                .setNegativeButton("閉じる", null)
                .setPositiveButton("コピー", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("PriceRec diagnostic", log));
                    Toast.makeText(this, "コピーしました", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private long selectedTagForStore(long storeId) {
        long id = getPreferences(MODE_PRIVATE).getLong("selected_tag_" + storeId, Long.MIN_VALUE);
        if (id == -1L) return -1L;
        if (id != Long.MIN_VALUE && db.tagExists(id)) return id;
        List<DatabaseHelper.Tag> tags = db.listTags();
        return tags.isEmpty() ? -1L : tags.get(0).id;
    }

    private void saveSelectedTag(long storeId, long tagId) {
        getPreferences(MODE_PRIVATE).edit().putLong("selected_tag_" + storeId, tagId).apply();
    }

    private String safeFolder(String name) {
        String s = name.replace('/', '_').replace('\\', '_').trim();
        return s.isEmpty() ? "Store" : s;
    }

    private Bitmap loadBitmap(Uri uri, int targetW, int targetH) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int sample = 1;
            while (bounds.outWidth / sample > targetW * 2 || bounds.outHeight / sample > targetH * 2) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = Math.max(1, sample);
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, opts);
            }
        } catch (Exception e) {
            DiagLog.write(this, "IMAGE_LOAD_ERROR uri=" + uri + " err=" + e);
            return null;
        }
    }

    private String yen(int price) {
        return "¥" + NumberFormat.getIntegerInstance(Locale.JAPAN).format(price);
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView button(String value, int color, float sp) {
        TextView t = text(value, sp, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundRect(color, 16, 0, 0));
        return t;
    }

    private TextView chip(String value, boolean selected) {
        return chip(value, selected, false);
    }

    private TextView chip(String value, boolean selected, boolean secondary) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? (secondary ? ORANGE : LBLUE) : DGRAY, 16, LGRAY, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView dialogChip(String value, boolean selected) {
        TextView t = text(value, 14, selected ? Color.WHITE : Color.DKGRAY, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? LBLUE : Color.parseColor("#EEEEEE"), 16, Color.parseColor("#AAAAAA"), 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private EditText dialogInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setPadding(dp(16), 0, dp(16), 0);
        return input;
    }

    private GradientDrawable roundRect(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
