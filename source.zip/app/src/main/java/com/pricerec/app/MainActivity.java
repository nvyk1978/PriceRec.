package com.pricerec.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Insets;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.GestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.core.content.FileProvider;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;

import org.json.JSONArray;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends ComponentActivity {
    private static final int REQ_CAMERA = 4101;

    private static final int BG = Color.parseColor("#303030");
    private static final int DGRAY = Color.parseColor("#252020");
    private static final int GRAY = Color.parseColor("#454040");
    private static final int LGRAY = Color.parseColor("#656060");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int LBLUE = Color.parseColor("#4D6B99");
    private static final int RED = Color.parseColor("#441100");
    private static final int LRED = Color.parseColor("#882211");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int DORANGE = Color.parseColor("#553300");
    private static final int CSV_GREEN = Color.parseColor("#2E7D32");
    private static final int WHITE = Color.WHITE;
    private static final int NWHITE = Color.parseColor("#A9A999");
    private static final int SECONDARY = Color.parseColor("#C9C4C4");
    private static final int THUMB_RADIUS_DP = 6;

    private DatabaseHelper db;
    private LinearLayout storeContainer;
    private ScrollView storeScroll;
    private EditText searchInput;
    private LinearLayout searchCandidateRow;
    private LinearLayout searchCandidateChips;
    private TextView searchCandidateDelete;
    private boolean searchCandidateSelectionMode = false;
    private final Set<String> selectedSearchCandidates = new HashSet<>();
    private static final String PREF_SEARCH_CANDIDATES = "search_candidates_v1";
    private long expandedStoreId = -1L; // last-opened store, kept for backward state compatibility
    private final Set<Long> expandedStoreIds = new HashSet<>();
    private final Map<Long, String> activeTab = new HashMap<>();
    private final Map<Long, LinearLayout> storeCardViews = new HashMap<>();
    private final Map<Long, LinearLayout> storeDetailViews = new HashMap<>();
    private View draggingStoreCard;
    private long draggingStoreId = -1L;
    private int draggingStoreSourceIndex = -1;
    private int draggingStoreTargetIndex = -1;
    private float draggingStoreGrabOffsetY = 0f;
    private int draggingStoreSlotHeight = 0;
    private boolean draggingStoreDropCommitted = false;

    private Uri pendingPhotoUri;
    private String pendingCameraTempPath;
    private long pendingStoreId = -1L;
    private Long pendingTagId = null;

    private long pendingImportStoreId = -1L;
    private Long pendingImportTagId = null;

    private long shareSelectionStoreId = -1L;
    private final Set<Long> shareSelectedPhotoIds = new HashSet<>();

    private long productSelectionStoreId = -1L;
    private final Set<Long> selectedProductIds = new HashSet<>();

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);

    private final ExecutorService thumbnailExecutor = Executors.newFixedThreadPool(2);

    private final LruCache<String, Bitmap> thumbnailCache = new LruCache<String, Bitmap>(16 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) {
            return value == null ? 0 : value.getByteCount();
        }
    };

    private final ActivityResultLauncher<PickVisualMediaRequest> photoPicker =
            registerForActivityResult(new ActivityResultContracts.PickMultipleVisualMedia(100), this::handlePhotoPickerUris);

    private final ActivityResultLauncher<String[]> csvPicker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::handleCsvPicked);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DatabaseHelper(this);
        DiagLog.write(this, "APP_START version=" + DiagLog.versionName(this));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        if (state != null) {
            String uri = state.getString("pending_uri");
            if (uri != null) pendingPhotoUri = Uri.parse(uri);
            pendingCameraTempPath = state.getString("pending_camera_temp_path");
            pendingStoreId = state.getLong("pending_store", -1L);
            long tag = state.getLong("pending_tag", Long.MIN_VALUE);
            pendingTagId = tag == Long.MIN_VALUE ? null : tag;
            pendingImportStoreId = state.getLong("pending_import_store", -1L);
            long importTag = state.getLong("pending_import_tag", Long.MIN_VALUE);
            pendingImportTagId = importTag == Long.MIN_VALUE ? null : importTag;
            expandedStoreId = state.getLong("expanded_store", -1L);
            long[] expandedIds = state.getLongArray("expanded_store_ids");
            if (expandedIds != null) {
                for (long id : expandedIds) expandedStoreIds.add(id);
            } else if (expandedStoreId >= 0) {
                expandedStoreIds.add(expandedStoreId);
            }
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                top = bars.top;
                bottom = Math.max(bars.bottom, ime.bottom);
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(14), top + dp(8), dp(14), bottom + dp(8));
            return insets;
        });

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(dp(4), dp(2), 0, dp(10));

        TextView title = text("PRICE REC.", 25, NWHITE, true);
        title.setLetterSpacing(0.08f);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setIncludeFontPadding(false);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1f));

        TagManageIconView tagManage = new TagManageIconView(this);
        tagManage.setBackground(circle(GRAY));
        tagManage.setContentDescription("タグ管理");
        tagManage.setOnClickListener(v -> showTagManager());
        LinearLayout.LayoutParams tagManageLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        tagManageLp.rightMargin = dp(8);
        titleRow.addView(tagManage, tagManageLp);

        TextView appMenu = text("⋮", 26, WHITE, true);
        appMenu.setGravity(Gravity.CENTER);
        appMenu.setIncludeFontPadding(false);
        appMenu.setBackground(circle(DGRAY));
        appMenu.setContentDescription("アプリメニュー");
        appMenu.setOnClickListener(v -> showAppMenu());
        titleRow.addView(appMenu, new LinearLayout.LayoutParams(dp(44), dp(44)));
        root.addView(titleRow);

        storeScroll = new ScrollView(this);
        storeScroll.setFillViewport(true);
        storeContainer = new LinearLayout(this);
        storeContainer.setOrientation(LinearLayout.VERTICAL);
        storeScroll.addView(storeContainer, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        storeScroll.setOnDragListener(this::handleStoreScrollDrag);
        root.addView(storeScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(makeBottomBar());
        setContentView(root);
        root.requestApplyInsets();
        reloadStores();
        handleIncomingCsvIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingCsvIntent(intent);
    }

    @Override
    protected void onDestroy() {
        thumbnailExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            if (searchCandidateSelectionMode && !isTouchInside(event, searchCandidateRow)) {
                exitSearchCandidateSelection();
            }
            if (shareSelectionStoreId >= 0) {
                View selectionCard = storeCardViews.get(shareSelectionStoreId);
                if (selectionCard == null || !isTouchInside(event, selectionCard)) {
                    long exitingStore = shareSelectionStoreId;
                    int count = shareSelectedPhotoIds.size();
                    shareSelectionStoreId = -1L;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_END_OUTSIDE store=" + exitingStore + " selected=" + count);
                    reloadStores();
                }
            }
            View focused = getCurrentFocus();
            if (focused instanceof EditText) {
                EditText touchedInput = findEditTextAt(getWindow().getDecorView(), event.getRawX(), event.getRawY());
                if (touchedInput == null) {
                    focused.clearFocus();
                    hideKeyboard(focused);
                }
            }
        }
        return super.dispatchTouchEvent(event);
    }

    private EditText findEditTextAt(View root, float rawX, float rawY) {
        if (root == null || root.getVisibility() != View.VISIBLE) return null;
        if (!pointInsideView(root, rawX, rawY)) return null;
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = group.getChildCount() - 1; i >= 0; i--) {
                EditText found = findEditTextAt(group.getChildAt(i), rawX, rawY);
                if (found != null) return found;
            }
        }
        return root instanceof EditText ? (EditText) root : null;
    }

    private boolean pointInsideView(View view, float rawX, float rawY) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        return rawX >= location[0] && rawX <= location[0] + view.getWidth()
                && rawY >= location[1] && rawY <= location[1] + view.getHeight();
    }

    private boolean isTouchInside(MotionEvent event, View view) {
        if (view == null || view.getVisibility() != View.VISIBLE) return false;
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        float x = event.getRawX();
        float y = event.getRawY();
        return x >= location[0] && x <= location[0] + view.getWidth()
                && y >= location[1] && y <= location[1] + view.getHeight();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (pendingPhotoUri != null) out.putString("pending_uri", pendingPhotoUri.toString());
        if (pendingCameraTempPath != null) out.putString("pending_camera_temp_path", pendingCameraTempPath);
        out.putLong("pending_store", pendingStoreId);
        out.putLong("pending_tag", pendingTagId == null ? Long.MIN_VALUE : pendingTagId);
        out.putLong("pending_import_store", pendingImportStoreId);
        out.putLong("pending_import_tag", pendingImportTagId == null ? Long.MIN_VALUE : pendingImportTagId);
        out.putLong("expanded_store", expandedStoreId);
        long[] expandedIds = new long[expandedStoreIds.size()];
        int expandedIndex = 0;
        for (Long id : expandedStoreIds) expandedIds[expandedIndex++] = id;
        out.putLongArray("expanded_store_ids", expandedIds);
    }

    private View makeBottomBar() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(6), 0, 0);

        searchCandidateRow = new LinearLayout(this);
        searchCandidateRow.setGravity(Gravity.CENTER_VERTICAL);
        searchCandidateRow.setPadding(0, 0, 0, dp(6));

        HorizontalScrollView candidateScroll = new HorizontalScrollView(this);
        candidateScroll.setHorizontalScrollBarEnabled(false);
        candidateScroll.setFillViewport(false);
        searchCandidateChips = new LinearLayout(this);
        searchCandidateChips.setOrientation(LinearLayout.HORIZONTAL);
        searchCandidateChips.setGravity(Gravity.CENTER_VERTICAL);
        candidateScroll.addView(searchCandidateChips, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));
        searchCandidateRow.addView(candidateScroll, new LinearLayout.LayoutParams(0, dp(36), 1f));

        searchCandidateDelete = button("削除", RED, 13);
        searchCandidateDelete.setVisibility(View.GONE);
        searchCandidateDelete.setOnClickListener(v -> deleteSelectedSearchCandidates());
        LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(dp(72), dp(36));
        deleteLp.leftMargin = dp(8);
        searchCandidateRow.addView(searchCandidateDelete, deleteLp);
        box.addView(searchCandidateRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(DGRAY);
        searchInput.setTextSize(16);
        searchInput.setHint("商品名検索");
        searchInput.setHintTextColor(GRAY);
        searchInput.setGravity(Gravity.CENTER_VERTICAL);
        searchInput.setIncludeFontPadding(false);
        searchInput.setPadding(dp(16), 0, dp(16), 0);
        searchInput.setBackground(roundRect(NWHITE, 999));
        applyDarkInputCursor(searchInput);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setOnFocusChangeListener((v, focused) -> searchInput.setBackground(roundRect(NWHITE, 999)));
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        searchLp.rightMargin = dp(12);
        row.addView(productSearchInputHolder(searchInput), searchLp);

        TextView add = text("＋", 24, WHITE, true);
        add.setGravity(Gravity.CENTER);
        add.setBackground(circle(LBLUE));
        add.setContentDescription("新規店舗");
        add.setOnClickListener(v -> showAddStoreDialog());
        row.addView(add, new LinearLayout.LayoutParams(dp(48), dp(48)));
        box.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        refreshSearchCandidates();
        return box;
    }

    private List<String> loadSearchCandidates() {
        ArrayList<String> out = new ArrayList<>();
        String raw = getPreferences(MODE_PRIVATE).getString(PREF_SEARCH_CANDIDATES, "");
        if (raw == null || raw.isEmpty()) return out;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i, "").trim();
                if (!value.isEmpty() && !out.contains(value)) out.add(value);
            }
        } catch (Exception e) {
            DiagLog.write(this, "SEARCH_CANDIDATE_LOAD_ERROR " + e);
        }
        return out;
    }

    private void saveSearchCandidates(List<String> values) {
        JSONArray array = new JSONArray();
        for (String value : values) array.put(value);
        getPreferences(MODE_PRIVATE).edit()
                .putString(PREF_SEARCH_CANDIDATES, array.toString())
                .apply();
    }

    private void rememberSearchCandidate(String query) {
        String q = query == null ? "" : query.trim();
        if (q.isEmpty()) return;
        List<String> values = loadSearchCandidates();
        for (int i = values.size() - 1; i >= 0; i--) {
            if (values.get(i).equalsIgnoreCase(q)) values.remove(i);
        }
        values.add(0, q);
        saveSearchCandidates(values);
        refreshSearchCandidates();
        DiagLog.write(this, "SEARCH_CANDIDATE_SAVE q=" + q + " total=" + values.size());
    }

    private void refreshSearchCandidates() {
        if (searchCandidateRow == null || searchCandidateChips == null) return;
        List<String> values = loadSearchCandidates();
        searchCandidateChips.removeAllViews();
        for (String value : values) {
            boolean selected = selectedSearchCandidates.contains(value);
            TextView candidate = chip(value, selected, false);
            candidate.setTag(value);
            attachSearchCandidateGesture(candidate, value);
            candidate.setOnClickListener(v -> {
                if (searchCandidateSelectionMode) {
                    if (!selectedSearchCandidates.add(value)) selectedSearchCandidates.remove(value);
                    DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_TOGGLE q=" + value + " selected="
                            + selectedSearchCandidates.contains(value) + " count=" + selectedSearchCandidates.size());
                    refreshSearchCandidates();
                } else {
                    searchInput.setText(value);
                    searchInput.setSelection(searchInput.length());
                    runSearch(value);
                }
            });
            searchCandidateChips.addView(candidate);
        }
        searchCandidateDelete.setVisibility(searchCandidateSelectionMode ? View.VISIBLE : View.GONE);
        searchCandidateDelete.setAlpha(selectedSearchCandidates.isEmpty() ? 0.45f : 1f);
        searchCandidateRow.setVisibility(values.isEmpty() && !searchCandidateSelectionMode ? View.GONE : View.VISIBLE);
    }

    private void deleteSelectedSearchCandidates() {
        if (selectedSearchCandidates.isEmpty()) return;
        List<String> values = loadSearchCandidates();
        int before = values.size();
        values.removeIf(selectedSearchCandidates::contains);
        int removed = before - values.size();
        saveSearchCandidates(values);
        DiagLog.write(this, "SEARCH_CANDIDATE_DELETE count=" + removed);
        exitSearchCandidateSelection();
    }

    private void exitSearchCandidateSelection() {
        if (!searchCandidateSelectionMode && selectedSearchCandidates.isEmpty()) return;
        searchCandidateSelectionMode = false;
        selectedSearchCandidates.clear();
        refreshSearchCandidates();
        DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_CANCEL");
    }

    private void attachSearchCandidateGesture(TextView candidate, String value) {
        final boolean[] armed = {false};
        final boolean[] dragging = {false};
        final float[] downRawX = {0f};
        final int[] sourceIndex = {-1};
        final int[] targetIndex = {-1};

        candidate.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX[0] = event.getRawX();
                    sourceIndex[0] = searchCandidateChips.indexOfChild(v);
                    targetIndex[0] = sourceIndex[0];
                    armed[0] = false;
                    dragging[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (!armed[0]) return false;
                    float dx = event.getRawX() - downRawX[0];
                    if (!dragging[0] && Math.abs(dx) < dp(10)) return true;
                    dragging[0] = true;
                    v.setTranslationX(dx);
                    v.setTranslationY(0f);
                    int target = nearestChildIndexByRawX(searchCandidateChips, event.getRawX(), false);
                    if (target >= 0 && target != targetIndex[0]) {
                        targetIndex[0] = target;
                        animateHorizontalReorderPreview(searchCandidateChips, v, sourceIndex[0], targetIndex[0], false);
                        DiagLog.write(this, "SEARCH_CANDIDATE_REORDER_MOVE q=" + value + " index=" + target);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!armed[0]) return false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    boolean wasDragging = dragging[0];
                    int from = sourceIndex[0];
                    int to = targetIndex[0];
                    resetHorizontalReorderPreview(searchCandidateChips, v);
                    v.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(130).setInterpolator(new DecelerateInterpolator()).start();
                    if (commit) {
                        if (wasDragging && from >= 0 && to >= 0 && from != to) {
                            List<String> ordered = loadSearchCandidates();
                            moveListItem(ordered, from, to);
                            saveSearchCandidates(ordered);
                            DiagLog.write(this, "SEARCH_CANDIDATE_REORDER_SAVE from=" + from + " to=" + to + " total=" + ordered.size());
                            searchCandidateChips.postDelayed(this::refreshSearchCandidates, 120);
                        } else if (!wasDragging) {
                            if (!searchCandidateSelectionMode) {
                                searchCandidateSelectionMode = true;
                                selectedSearchCandidates.clear();
                            }
                            selectedSearchCandidates.add(value);
                            DiagLog.write(this, "SEARCH_CANDIDATE_SELECT_START q=" + value);
                            refreshSearchCandidates();
                        }
                    }
                    armed[0] = false;
                    dragging[0] = false;
                    sourceIndex[0] = -1;
                    targetIndex[0] = -1;
                    return true;
                default:
                    return armed[0];
            }
        });

        candidate.setOnLongClickListener(v -> {
            armed[0] = true;
            dragging[0] = false;
            sourceIndex[0] = searchCandidateChips.indexOfChild(v);
            targetIndex[0] = sourceIndex[0];
            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            v.animate().scaleX(1.04f).scaleY(1.04f).alpha(0.86f).setDuration(80).start();
            DiagLog.write(this, "SEARCH_CANDIDATE_REORDER_ARM q=" + value);
            return true;
        });
    }

    private int nearestChildIndexByRawX(LinearLayout row, float rawX, boolean tagOnly) {
        int best = -1;
        float bestDistance = Float.MAX_VALUE;
        int[] rowLoc = new int[2];
        row.getLocationOnScreen(rowLoc);
        float localX = rawX - rowLoc[0];
        for (int i = 0; i < row.getChildCount(); i++) {
            View child = row.getChildAt(i);
            if (tagOnly && !(child.getTag() instanceof Long)) continue;
            float center = child.getLeft() + child.getWidth() / 2f;
            float distance = Math.abs(localX - center);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = i;
            }
        }
        return best;
    }

    private int horizontalOuterSize(View view) {
        int size = view.getWidth();
        ViewGroup.LayoutParams lp = view.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
            size += mlp.leftMargin + mlp.rightMargin;
        }
        return Math.max(dp(1), size);
    }

    private void animateHorizontalReorderPreview(LinearLayout row, View dragged, int sourceIndex, int targetIndex, boolean tagOnly) {
        if (sourceIndex < 0 || targetIndex < 0) return;
        int shift = horizontalOuterSize(dragged);
        for (int i = 0; i < row.getChildCount(); i++) {
            View child = row.getChildAt(i);
            if (child == dragged) continue;
            if (tagOnly && !(child.getTag() instanceof Long)) continue;
            float tx = 0f;
            if (targetIndex > sourceIndex && i > sourceIndex && i <= targetIndex) {
                tx = -shift;
            } else if (targetIndex < sourceIndex && i >= targetIndex && i < sourceIndex) {
                tx = shift;
            }
            child.animate().translationX(tx).translationY(0f).setDuration(135)
                    .setInterpolator(new DecelerateInterpolator(1.5f)).start();
        }
    }

    private void resetHorizontalReorderPreview(LinearLayout row, View dragged) {
        for (int i = 0; i < row.getChildCount(); i++) {
            View child = row.getChildAt(i);
            if (child == dragged) continue;
            child.animate().translationX(0f).translationY(0f).setDuration(120)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private <T> void moveListItem(List<T> list, int from, int to) {
        if (from < 0 || to < 0 || from >= list.size() || to >= list.size() || from == to) return;
        T item = list.remove(from);
        list.add(to, item);
    }

    private void reloadStores() {
        if (storeContainer == null) return;
        storeCardViews.clear();
        storeDetailViews.clear();
        storeContainer.removeAllViews();
        List<DatabaseHelper.Store> stores = db.listStores();
        if (stores.isEmpty()) {
            TextView empty = text("右下の＋から店舗を追加", 16, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(80), 0, 0);
            storeContainer.addView(empty);
            return;
        }
        for (DatabaseHelper.Store store : stores) storeContainer.addView(makeStoreCard(store));
    }

    private View makeStoreCard(DatabaseHelper.Store store) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundRect(GRAY, 18));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(12);
        card.setLayoutParams(cardLp);
        storeCardViews.put(store.id, card);
        card.setTag(Long.valueOf(store.id));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(6), dp(8), dp(6), dp(8));

        TextView handle = text("☰", 22, SECONDARY, false);
        handle.setGravity(Gravity.CENTER);
        handle.setContentDescription("店舗を並べ替え");
        final float[] handleTouchY = {dp(24)};
        handle.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                handleTouchY[0] = event.getY();
            }
            return false;
        });
        handle.setOnLongClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            draggingStoreCard = card;
            draggingStoreId = store.id;
            draggingStoreSourceIndex = storeContainer.indexOfChild(card);
            draggingStoreTargetIndex = draggingStoreSourceIndex;
            draggingStoreGrabOffsetY = header.getTop() + handle.getTop() + handleTouchY[0];
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) card.getLayoutParams();
            draggingStoreSlotHeight = card.getHeight() + mlp.topMargin + mlp.bottomMargin;
            draggingStoreDropCommitted = false;
            card.setElevation(dp(12));
            card.animate().scaleX(1.015f).scaleY(1.015f).alpha(0.94f).setDuration(90).start();
            DragPayload payload = new DragPayload("store", store.id);
            ClipData data = ClipData.newPlainText("store_id", String.valueOf(store.id));
            DiagLog.write(this, "STORE_DRAG_START id=" + store.id + " name=" + store.name + " axis=y");
            v.startDragAndDrop(data, new InvisibleDragShadowBuilder(v), payload, 0);
            return true;
        });

        TextView name = text(store.name, 18, store.enabled ? WHITE : LGRAY, true);
        name.setGravity(Gravity.CENTER_VERTICAL);

        header.addView(handle, new LinearLayout.LayoutParams(dp(48), dp(48)));
        header.addView(name, new LinearLayout.LayoutParams(0, dp(48), 1f));

        FrameLayout toggleHit = new FrameLayout(this);
        toggleHit.setClickable(true);
        toggleHit.setFocusable(true);
        toggleHit.setClipChildren(false);
        toggleHit.setClipToPadding(false);
        toggleHit.setContentDescription(store.enabled ? "Nトグル オン" : "Nトグル オフ");
        NToggleSwitch nToggle = new NToggleSwitch(this);
        nToggle.setChecked(store.enabled);
        nToggle.setNColors(ORANGE, WHITE);
        nToggle.setContentDescription(store.enabled ? "Nトグル オン" : "Nトグル オフ");
        nToggle.setOnCheckedChangeListener((buttonView, checked) -> {
            if (checked == store.enabled) return;
            db.setStoreEnabled(store.id, checked);
            buttonView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            DiagLog.write(this, "STORE_N_TOGGLE id=" + store.id + " enabled=" + checked);
            buttonView.postDelayed(this::reloadStores, 130L);
        });
        FrameLayout.LayoutParams switchLp = new FrameLayout.LayoutParams(dp(44), dp(26), Gravity.CENTER);
        toggleHit.addView(nToggle, switchLp);
        toggleHit.setOnClickListener(v -> nToggle.performClick());
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(dp(58), dp(48));
        toggleLp.leftMargin = dp(8);
        header.addView(toggleHit, toggleLp);

        View.OnLongClickListener storeMenuLongPress = v -> {
            if (draggingStoreId >= 0) return true;
            card.setBackground(roundRect(LGRAY, 18));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                card.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            } else {
                card.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            }
            DiagLog.write(this, "STORE_MENU_LONG_PRESS id=" + store.id + " name=" + store.name);
            showStoreMenu(store, card);
            return true;
        };
        header.setOnLongClickListener(storeMenuLongPress);
        card.setOnLongClickListener(storeMenuLongPress);
        card.addView(header);

        if (expandedStoreIds.contains(store.id)) {
            LinearLayout details = buildStoreDetails(store);
            card.addView(details);
            storeDetailViews.put(store.id, details);
        }

        header.setOnClickListener(v -> {
            if (draggingStoreId >= 0) return;
            if (expandedStoreIds.contains(store.id)) {
                if (shareSelectionStoreId == store.id) {
                    shareSelectionStoreId = -1L;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_END_COLLAPSE store=" + store.id);
                }
                animateCollapseStore(store.id, null);
            } else {
                animateExpandStore(store, card);
            }
        });
        return card;
    }

    private LinearLayout buildStoreDetails(DatabaseHelper.Store store) {
        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(12), 0, dp(12), dp(12));
        details.addView(makeActionRow(store));
        details.addView(makePhotoGrid(store));
        return details;
    }

    private void animateExpandStore(DatabaseHelper.Store store, LinearLayout card) {
        if (expandedStoreIds.contains(store.id) && storeDetailViews.containsKey(store.id)) return;
        expandedStoreIds.add(store.id);
        expandedStoreId = store.id;
        DiagLog.write(this, "STORE_EXPAND id=" + store.id + " mode=lightweight");
        LinearLayout details = buildStoreDetails(store);
        storeDetailViews.put(store.id, details);
        details.setAlpha(0f);
        details.setTranslationY(-dp(5));
        card.addView(details, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        details.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(145)
                .setInterpolator(new DecelerateInterpolator(1.4f))
                .start();
    }

    private void animateCollapseStore(long storeId, Runnable after) {
        LinearLayout card = storeCardViews.get(storeId);
        LinearLayout details = storeDetailViews.get(storeId);
        if (card == null || details == null) {
            expandedStoreIds.remove(storeId);
            if (expandedStoreId == storeId) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
            if (after != null) after.run();
            return;
        }
        details.animate()
                .alpha(0f)
                .translationY(-dp(5))
                .setDuration(120)
                .setInterpolator(new DecelerateInterpolator(1.25f))
                .withEndAction(() -> {
                    card.removeView(details);
                    storeDetailViews.remove(storeId);
                    expandedStoreIds.remove(storeId);
                    if (expandedStoreId == storeId) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
                    DiagLog.write(MainActivity.this, "STORE_COLLAPSE id=" + storeId + " mode=lightweight");
                    if (after != null) after.run();
                })
                .start();
    }

    private void refreshExpandedStoreDetails(DatabaseHelper.Store store) {
        if (store == null) return;
        LinearLayout card = storeCardViews.get(store.id);
        LinearLayout oldDetails = storeDetailViews.get(store.id);
        if (card == null || oldDetails == null || !expandedStoreIds.contains(store.id)) {
            reloadStores();
            return;
        }
        int index = card.indexOfChild(oldDetails);
        if (index < 0) {
            reloadStores();
            return;
        }
        LinearLayout fresh = buildStoreDetails(store);
        card.removeViewAt(index);
        card.addView(fresh, index, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        storeDetailViews.put(store.id, fresh);
    }

    private boolean handleStoreScrollDrag(View targetView, DragEvent event) {
        Object local = event.getLocalState();
        if (!(local instanceof DragPayload) || !"store".equals(((DragPayload) local).type)) {
            return event.getAction() != DragEvent.ACTION_DRAG_STARTED;
        }
        ScrollView scroll = targetView instanceof ScrollView ? (ScrollView) targetView : storeScroll;
        switch (event.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_LOCATION:
                if (draggingStoreCard == null || draggingStoreId < 0 || scroll == null) return true;
                float localY = event.getY();
                int edge = dp(72);
                int step = dp(24);
                if (localY < edge) scroll.scrollBy(0, -step);
                else if (localY > scroll.getHeight() - edge) scroll.scrollBy(0, step);
                float contentY = scroll.getScrollY() + localY;
                float translationY = contentY - draggingStoreCard.getTop() - draggingStoreGrabOffsetY;
                draggingStoreCard.setTranslationX(0f);
                draggingStoreCard.setTranslationY(translationY);
                float draggedCenterY = draggingStoreCard.getTop() + translationY + draggingStoreCard.getHeight() / 2f;
                int nextTarget = computeStoreDragTargetIndex(draggedCenterY);
                if (nextTarget != draggingStoreTargetIndex) {
                    draggingStoreTargetIndex = nextTarget;
                    animateStoreDragSlots(nextTarget);
                    DiagLog.write(this, "STORE_DRAG_TARGET id=" + draggingStoreId + " index=" + nextTarget);
                }
                return true;
            case DragEvent.ACTION_DROP:
                // ACTION_DRAG_ENDED follows immediately; mark the drop handled even when the
                // final index is unchanged so the settle animation is not started twice.
                draggingStoreDropCommitted = true;
                finishStoreDrag(true);
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                if (!draggingStoreDropCommitted) finishStoreDrag(false);
                return true;
            default:
                return true;
        }
    }

    private int computeStoreDragTargetIndex(float draggedCenterY) {
        int count = storeContainer.getChildCount();
        int candidate = 0;
        for (int i = 0; i < count; i++) {
            if (i == draggingStoreSourceIndex) continue;
            View child = storeContainer.getChildAt(i);
            float mid = child.getTop() + child.getHeight() / 2f;
            if (draggedCenterY > mid) candidate++;
        }
        return Math.max(0, Math.min(count - 1, candidate));
    }

    private void animateStoreDragSlots(int targetIndex) {
        if (draggingStoreCard == null || draggingStoreSourceIndex < 0) return;
        for (int i = 0; i < storeContainer.getChildCount(); i++) {
            View child = storeContainer.getChildAt(i);
            if (child == draggingStoreCard) continue;
            float targetY = 0f;
            if (targetIndex > draggingStoreSourceIndex && i > draggingStoreSourceIndex && i <= targetIndex) {
                targetY = -draggingStoreSlotHeight;
            } else if (targetIndex < draggingStoreSourceIndex && i >= targetIndex && i < draggingStoreSourceIndex) {
                targetY = draggingStoreSlotHeight;
            }
            child.animate()
                    .translationY(targetY)
                    .setDuration(150)
                    .setInterpolator(new DecelerateInterpolator(1.55f))
                    .start();
        }
    }

    private void finishStoreDrag(boolean commit) {
        if (draggingStoreCard == null || draggingStoreId < 0) return;
        final View source = draggingStoreCard;
        final long sourceId = draggingStoreId;
        final int sourceIndex = draggingStoreSourceIndex;
        final int targetIndex = draggingStoreTargetIndex;
        if (commit && targetIndex >= 0 && targetIndex < storeContainer.getChildCount() && targetIndex != sourceIndex) {
            View targetView = storeContainer.getChildAt(targetIndex);
            Object tag = targetView.getTag();
            if (tag instanceof Long) {
                long targetId = (Long) tag;
                boolean after = targetIndex > sourceIndex;
                db.moveStore(sourceId, targetId, after);
                DiagLog.write(this, "STORE_REORDER dragged=" + sourceId + " target=" + targetId + " after=" + after);
                draggingStoreDropCommitted = true;
                float settleY = targetView.getTop() - source.getTop();
                source.animate()
                        .translationX(0f)
                        .translationY(settleY)
                        .scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(145)
                        .setInterpolator(new DecelerateInterpolator(1.6f))
                        .withEndAction(() -> {
                            clearStoreDragState();
                            reloadStores();
                        })
                        .start();
                return;
            }
        }
        for (int i = 0; i < storeContainer.getChildCount(); i++) {
            View child = storeContainer.getChildAt(i);
            if (child == source) continue;
            child.animate().translationY(0f).setDuration(130).setInterpolator(new DecelerateInterpolator()).start();
        }
        source.animate()
                .translationX(0f).translationY(0f)
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(145)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(this::clearStoreDragState)
                .start();
    }

    private void clearStoreDragState() {
        if (draggingStoreCard != null) draggingStoreCard.setElevation(0f);
        draggingStoreCard = null;
        draggingStoreId = -1L;
        draggingStoreSourceIndex = -1;
        draggingStoreTargetIndex = -1;
        draggingStoreGrabOffsetY = 0f;
        draggingStoreSlotHeight = 0;
        draggingStoreDropCommitted = false;
    }

    private static final class InvisibleDragShadowBuilder extends View.DragShadowBuilder {
        InvisibleDragShadowBuilder(View view) { super(view); }
        @Override public void onProvideShadowMetrics(android.graphics.Point size, android.graphics.Point touch) {
            size.set(1, 1);
            touch.set(0, 0);
        }
        @Override public void onDrawShadow(Canvas canvas) { }
    }

    private View makeTagSelector(DatabaseHelper.Store store) {
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(0, 0, 0, dp(4));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setFillViewport(false);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        boolean photoSelecting = shareSelectionStoreId == store.id && !shareSelectedPhotoIds.isEmpty();
        long selected = photoSelecting ? commonSelectedPhotoTagId(store.id) : selectedTagForStore(store.id);
        for (DatabaseHelper.Tag tag : db.listTags()) {
            TextView chip = chip(tag.name, selected == tag.id, false);
            chip.setTag(tag.id);
            if (store.enabled) {
                attachInlineTagReorderGesture(chip, row, tag);
                chip.setOnClickListener(v -> {
                    if (shareSelectionStoreId == store.id && !shareSelectedPhotoIds.isEmpty()) {
                        applyTagToSelectedPhotos(store, tag.id);
                    } else {
                        saveSelectedTag(store.id, tag.id);
                        reloadStores();
                    }
                });
            } else {
                chip.setAlpha(0.62f);
                chip.setEnabled(false);
            }
            row.addView(chip);
        }
        TextView none = chip("タグなし", selected == -1L, true);
        if (store.enabled) {
            none.setOnClickListener(v -> {
                if (shareSelectionStoreId == store.id && !shareSelectedPhotoIds.isEmpty()) {
                    applyTagToSelectedPhotos(store, null);
                } else {
                    saveSelectedTag(store.id, -1L);
                    reloadStores();
                }
            });
        } else {
            none.setAlpha(0.62f);
            none.setEnabled(false);
        }
        row.addView(none);
        hsv.addView(row);
        line.addView(hsv, new LinearLayout.LayoutParams(0, dp(42), 1f));

        TextView manage = text("＋", 22, WHITE, true);
        manage.setGravity(Gravity.CENTER);
        manage.setBackground(circle(LBLUE));
        manage.setContentDescription("タグ管理");
        if (store.enabled) {
            manage.setOnClickListener(v -> showTagManager());
        } else {
            manage.setEnabled(false);
            manage.setAlpha(0.38f);
        }
        LinearLayout.LayoutParams plusLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        plusLp.leftMargin = dp(8);
        line.addView(manage, plusLp);
        return line;
    }

    private long commonSelectedPhotoTagId(long storeId) {
        boolean found = false;
        long common = Long.MIN_VALUE;
        for (DatabaseHelper.Photo photo : db.listPhotos(storeId)) {
            if (!shareSelectedPhotoIds.contains(photo.id)) continue;
            long value = photo.tagId == null ? -1L : photo.tagId;
            if (!found) {
                common = value;
                found = true;
            } else if (common != value) {
                return Long.MIN_VALUE;
            }
        }
        return found ? common : Long.MIN_VALUE;
    }

    private void applyTagToSelectedPhotos(DatabaseHelper.Store store, Long tagId) {
        if (!store.enabled) {
            Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            return;
        }
        if (shareSelectionStoreId != store.id || shareSelectedPhotoIds.isEmpty()) return;
        int changed = 0;
        for (Long photoId : new ArrayList<>(shareSelectedPhotoIds)) {
            if (photoId == null) continue;
            db.updatePhotoTag(photoId, tagId);
            changed++;
        }
        DiagLog.write(this, "PHOTO_MULTI_TAG store=" + store.id + " tag=" + tagId + " count=" + changed);
        reloadStores();
    }

    private Set<Long> commonSelectedPhotoTagIds(long storeId) {
        Set<Long> common = null;
        for (DatabaseHelper.Photo photo : db.listPhotos(storeId)) {
            if (!shareSelectedPhotoIds.contains(photo.id)) continue;
            Set<Long> current = new HashSet<>(photo.tagIds);
            if (common == null) common = current;
            else common.retainAll(current);
        }
        return common == null ? new HashSet<>() : common;
    }

    private ArrayList<Long> orderedTagIds(Set<Long> tagIds) {
        ArrayList<Long> ordered = new ArrayList<>();
        if (tagIds == null || tagIds.isEmpty()) return ordered;
        for (DatabaseHelper.Tag tag : db.listTags()) {
            if (tagIds.contains(tag.id)) ordered.add(tag.id);
        }
        return ordered;
    }

    private void applyTagsToSelectedPhotos(DatabaseHelper.Store store, Set<Long> tagIds) {
        if (!store.enabled) {
            Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            return;
        }
        if (shareSelectionStoreId != store.id || shareSelectedPhotoIds.isEmpty()) return;
        ArrayList<Long> ids = new ArrayList<>(shareSelectedPhotoIds);
        ArrayList<Long> tags = orderedTagIds(tagIds);
        db.updatePhotosTags(ids, tags);
        DiagLog.write(this, "PHOTO_MULTI_TAGS store=" + store.id + " tags=" + tags + " count=" + ids.size());
        reloadStores();
    }

    private interface TagSelectionListener {
        void onChanged(Set<Long> selectedTags);
    }

    private View makeCommonTagSelectionArea(Set<Long> selectedTags, boolean multiSelect,
                                            boolean editable, TagSelectionListener listener) {
        LinearLayout host = new LinearLayout(this);
        host.setGravity(Gravity.CENTER_VERTICAL);
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            host.removeAllViews();
            HorizontalScrollView hsv = new HorizontalScrollView(this);
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.setFillViewport(false);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            for (DatabaseHelper.Tag tag : db.listTags()) {
                boolean selected = selectedTags.contains(tag.id);
                TextView tagChip = chip(tag.name, selected, false);
                tagChip.setTag(tag.id);
                if (editable) {
                    tagChip.setOnClickListener(v -> {
                        if (multiSelect) {
                            if (!selectedTags.add(tag.id)) selectedTags.remove(tag.id);
                        } else {
                            selectedTags.clear();
                            selectedTags.add(tag.id);
                        }
                        if (listener != null) listener.onChanged(new HashSet<>(selectedTags));
                        render[0].run();
                    });
                } else {
                    tagChip.setEnabled(false);
                    tagChip.setAlpha(0.62f);
                }
                row.addView(tagChip);
            }
            TextView none = chip("タグなし", selectedTags.isEmpty(), true);
            if (editable) {
                none.setOnClickListener(v -> {
                    selectedTags.clear();
                    if (listener != null) listener.onChanged(new HashSet<>(selectedTags));
                    render[0].run();
                });
            } else {
                none.setEnabled(false);
                none.setAlpha(0.62f);
            }
            row.addView(none);
            hsv.addView(row);
            host.addView(hsv, new LinearLayout.LayoutParams(0, dp(42), 1f));

            TextView plus = text("＋", 22, WHITE, true);
            plus.setGravity(Gravity.CENTER);
            plus.setBackground(circle(LBLUE));
            plus.setContentDescription("タグ管理");
            if (editable) {
                plus.setOnClickListener(v -> showTagManager(render[0]));
            } else {
                plus.setEnabled(false);
                plus.setAlpha(0.38f);
            }
            LinearLayout.LayoutParams plusLp = new LinearLayout.LayoutParams(dp(38), dp(38));
            plusLp.leftMargin = dp(8);
            host.addView(plus, plusLp);
        };
        render[0].run();
        return host;
    }


    private View makeStoreFilterArea(Set<Long> selectedStoreIds, Runnable onChanged) {
        LinearLayout host = new LinearLayout(this);
        host.setGravity(Gravity.CENTER_VERTICAL);
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            host.removeAllViews();
            HorizontalScrollView hsv = new HorizontalScrollView(this);
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.setFillViewport(false);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView all = chip("全カード", selectedStoreIds.isEmpty(), false);
            all.setOnClickListener(v -> {
                if (!selectedStoreIds.isEmpty()) {
                    selectedStoreIds.clear();
                    DiagLog.write(this, "PRODUCT_FILTER_STORE all=true");
                    render[0].run();
                    if (onChanged != null) onChanged.run();
                }
            });
            row.addView(all);

            for (DatabaseHelper.Store store : db.listStores()) {
                if (!store.enabled) continue;
                TextView storeChip = chip(store.name, selectedStoreIds.contains(store.id), false);
                storeChip.setTag(store.id);
                storeChip.setOnClickListener(v -> {
                    if (!selectedStoreIds.add(store.id)) selectedStoreIds.remove(store.id);
                    // Empty means "全カード", so removing the final individual choice restores it automatically.
                    DiagLog.write(this, "PRODUCT_FILTER_STORE ids=" + selectedStoreIds);
                    render[0].run();
                    if (onChanged != null) onChanged.run();
                });
                row.addView(storeChip);
            }
            hsv.addView(row);
            host.addView(hsv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        };
        render[0].run();
        return host;
    }

    private View makeProductTagFilterArea(Set<Long> selectedTagIds, Runnable onChanged) {
        LinearLayout host = new LinearLayout(this);
        host.setGravity(Gravity.CENTER_VERTICAL);
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            host.removeAllViews();
            HorizontalScrollView hsv = new HorizontalScrollView(this);
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.setFillViewport(false);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);

            for (DatabaseHelper.Tag tag : db.listTags()) {
                TextView tagChip = chip(tag.name, selectedTagIds.contains(tag.id), false);
                tagChip.setTag(tag.id);
                tagChip.setOnClickListener(v -> {
                    if (!selectedTagIds.add(tag.id)) selectedTagIds.remove(tag.id);
                    DiagLog.write(this, "PRODUCT_FILTER_TAG ids=" + selectedTagIds);
                    render[0].run();
                    if (onChanged != null) onChanged.run();
                });
                row.addView(tagChip);
            }

            TextView none = chip("タグなし", selectedTagIds.contains(-1L), true);
            none.setOnClickListener(v -> {
                if (!selectedTagIds.add(-1L)) selectedTagIds.remove(-1L);
                DiagLog.write(this, "PRODUCT_FILTER_TAG ids=" + selectedTagIds);
                render[0].run();
                if (onChanged != null) onChanged.run();
            });
            row.addView(none);

            hsv.addView(row);
            host.addView(hsv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        };
        render[0].run();
        return host;
    }

    private void attachInlineTagReorderGesture(TextView chip, LinearLayout row, DatabaseHelper.Tag tag) {
        final boolean[] armed = {false};
        final boolean[] dragging = {false};
        final float[] downRawX = {0f};
        final int[] sourceIndex = {-1};
        final int[] targetIndex = {-1};

        chip.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX[0] = event.getRawX();
                    sourceIndex[0] = row.indexOfChild(v);
                    targetIndex[0] = sourceIndex[0];
                    armed[0] = false;
                    dragging[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (!armed[0]) return false;
                    float dx = event.getRawX() - downRawX[0];
                    if (!dragging[0] && Math.abs(dx) < dp(10)) return true;
                    dragging[0] = true;
                    v.setTranslationX(dx);
                    v.setTranslationY(0f);
                    int target = nearestChildIndexByRawX(row, event.getRawX(), true);
                    if (target >= 0 && target != targetIndex[0]) {
                        targetIndex[0] = target;
                        animateHorizontalReorderPreview(row, v, sourceIndex[0], targetIndex[0], true);
                        DiagLog.write(this, "TAG_INLINE_REORDER_MOVE id=" + tag.id + " index=" + target);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!armed[0]) return false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    int from = sourceIndex[0];
                    int to = targetIndex[0];
                    boolean wasDragging = dragging[0];
                    resetHorizontalReorderPreview(row, v);
                    v.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(130).setInterpolator(new DecelerateInterpolator()).start();
                    if (commit && wasDragging && from >= 0 && to >= 0 && from != to) {
                        ArrayList<Long> ordered = new ArrayList<>();
                        for (DatabaseHelper.Tag t : db.listTags()) ordered.add(t.id);
                        int logicalFrom = ordered.indexOf(tag.id);
                        int logicalTo = logicalTagIndexForChild(row, to);
                        if (logicalFrom >= 0 && logicalTo >= 0) {
                            moveListItem(ordered, logicalFrom, logicalTo);
                            db.setTagOrder(ordered);
                            DiagLog.write(this, "TAG_INLINE_REORDER_SAVE id=" + tag.id + " from=" + logicalFrom + " to=" + logicalTo);
                            row.postDelayed(this::reloadStores, 120);
                        }
                    }
                    armed[0] = false;
                    dragging[0] = false;
                    sourceIndex[0] = -1;
                    targetIndex[0] = -1;
                    return true;
                default:
                    return armed[0];
            }
        });

        chip.setOnLongClickListener(v -> {
            armed[0] = true;
            dragging[0] = false;
            sourceIndex[0] = row.indexOfChild(v);
            targetIndex[0] = sourceIndex[0];
            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            v.animate().scaleX(1.04f).scaleY(1.04f).alpha(0.86f).setDuration(80).start();
            DiagLog.write(this, "TAG_INLINE_REORDER_ARM id=" + tag.id + " name=" + tag.name);
            return true;
        });
    }

    private int logicalTagIndexForChild(LinearLayout row, int childIndex) {
        int logical = -1;
        for (int i = 0; i <= childIndex && i < row.getChildCount(); i++) {
            if (row.getChildAt(i).getTag() instanceof Long) logical++;
        }
        return Math.max(0, logical);
    }

    private View makeActionRow(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(0, dp(8), 0, dp(8));

        LinearLayout row1 = new LinearLayout(this);
        TextView camera = button("撮影", BLUE, 16);
        TextView addImage = button("画像追加", BLUE, 15);
        if (store.enabled) {
            camera.setOnClickListener(v -> takePhoto(store));
            addImage.setOnClickListener(v -> importImages(store));
        } else {
            camera.setEnabled(false);
            addImage.setEnabled(false);
            camera.setAlpha(0.38f);
            addImage.setAlpha(0.38f);
        }
        LinearLayout.LayoutParams r1a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r1a.rightMargin = dp(4);
        LinearLayout.LayoutParams r1b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r1b.leftMargin = dp(4);
        row1.addView(camera, r1a);
        row1.addView(addImage, r1b);
        outer.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setPadding(0, dp(8), 0, 0);
        TextView list = button("リスト", DGRAY, 15);
        list.setOnClickListener(v -> showProductTableDialog(store.name + " カード内商品リスト", store.id, ""));
        TextView csv = button("CSV一覧", DGRAY, 15);
        csv.setOnClickListener(v -> showImportHistoryDialog(store.id));
        LinearLayout.LayoutParams r2a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r2a.rightMargin = dp(4);
        LinearLayout.LayoutParams r2b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        r2b.leftMargin = dp(4);
        row2.addView(list, r2a);
        row2.addView(csv, r2b);
        outer.addView(row2);
        return outer;
    }

    private View makeTabs(DatabaseHelper.Store store) {
        String tab = activeTab.getOrDefault(store.id, "list");
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, 0, 0, dp(8));
        TextView list = button("リスト", "list".equals(tab) ? LBLUE : DGRAY, 15);
        list.setOnClickListener(v -> { activeTab.put(store.id, "list"); reloadStores(); });
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp1.rightMargin = dp(4);
        row.addView(list, lp1);
        TextView images = button("画像", "images".equals(tab) ? LBLUE : DGRAY, 15);
        images.setOnClickListener(v -> { activeTab.put(store.id, "images"); reloadStores(); });
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp2.leftMargin = dp(4);
        row.addView(images, lp2);
        return row;
    }

    private View makeStoreBody(DatabaseHelper.Store store) {
        return "images".equals(activeTab.getOrDefault(store.id, "list")) ? makePhotoGrid(store) : makeProductSheet(store);
    }

    private View makeProductSheet(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.ProductRecord> products = db.listProductsForStore(store.id);
        boolean selecting = productSelectionStoreId == store.id;

        if (!selecting) {
            LinearLayout bar = new LinearLayout(this);
            bar.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            bar.setPadding(dp(4), 0, dp(4), dp(8));
            TextView select = button("選択", DGRAY, 13);
            select.setOnClickListener(v -> {
                productSelectionStoreId = store.id;
                selectedProductIds.clear();
                DiagLog.write(this, "PRODUCT_SELECT_START store=" + store.id + " source=button");
                reloadStores();
            });
            bar.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
            outer.addView(bar);
        }

        if (selecting) {
            LinearLayout bar = new LinearLayout(this);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setPadding(dp(4), 0, dp(4), dp(8));

            TextView count = text(selectedProductIds.size() + "件選択", 14, SECONDARY, true);
            bar.addView(count, new LinearLayout.LayoutParams(0, dp(40), 1f));

            TextView delete = button("削除", selectedProductIds.isEmpty() ? DGRAY : RED, 13);
            delete.setAlpha(selectedProductIds.isEmpty() ? 0.45f : 1f);
            delete.setOnClickListener(v -> {
                if (!selectedProductIds.isEmpty()) {
                    confirmDeleteProducts(new ArrayList<>(selectedProductIds), () -> {
                        cancelProductSelection();
                        reloadStores();
                    });
                }
            });
            LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(72), dp(38));
            delLp.rightMargin = dp(6);
            bar.addView(delete, delLp);

            TextView same = button("同一商品", selectedProductIds.size() < 2 ? DGRAY : ORANGE, 13);
            same.setAlpha(selectedProductIds.size() < 2 ? 0.45f : 1f);
            same.setOnClickListener(v -> {
                if (selectedProductIds.size() >= 2) {
                    showUnifyProductsDialog(new ArrayList<>(selectedProductIds), () -> {
                        cancelProductSelection();
                        reloadStores();
                    });
                }
            });
            LinearLayout.LayoutParams sameLp = new LinearLayout.LayoutParams(dp(92), dp(38));
            sameLp.leftMargin = dp(6);
            bar.addView(same, sameLp);

            TextView cancel = button("キャンセル", DGRAY, 13);
            cancel.setOnClickListener(v -> {
                cancelProductSelection();
                reloadStores();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(88), dp(38));
            cp.leftMargin = dp(6);
            bar.addView(cancel, cp);

            TextView move = button("タグ編集", selectedProductIds.isEmpty() ? DGRAY : BLUE, 13);
            move.setAlpha(selectedProductIds.isEmpty() ? 0.45f : 1f);
            move.setOnClickListener(v -> {
                if (!selectedProductIds.isEmpty()) {
                    showMoveProductsTagDialog(new ArrayList<>(selectedProductIds), () -> {
                        cancelProductSelection();
                        reloadStores();
                    });
                }
            });
            LinearLayout.LayoutParams moveLp = new LinearLayout.LayoutParams(dp(92), dp(38));
            moveLp.leftMargin = dp(6);
            bar.addView(move, moveLp);
            outer.addView(bar);
        }

        if (products.isEmpty()) {
            TextView empty = text("商品データはまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.addView(sheetHeader(new String[]{"商品名", "価格", "容量", "タグ", "比較"}, new int[]{240, 100, 90, 100, 70}));
        for (DatabaseHelper.ProductRecord p : products) {
            LinearLayout row = sheetRow(new String[]{p.rawName, p.priceYen == null ? "—" : yen(p.priceYen),
                            formatVolumeDisplay(p.volume), p.tagDisplay(), "比較"},
                    new int[]{240, 100, 90, 100, 70});
            TextView compareCell = (TextView) row.getChildAt(4);
            compareCell.setTextColor(BLUE);
            compareCell.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            compareCell.setGravity(Gravity.CENTER);
            compareCell.setOnClickListener(v -> {
                if (productSelectionStoreId == store.id) {
                    toggleProductSelection(p.id);
                    reloadStores();
                } else {
                    showSameProductPrices(p.productKey == null ? p.rawName : p.productKey);
                }
            });
            if (selecting && selectedProductIds.contains(p.id)) row.setBackgroundColor(BLUE);
            row.setOnClickListener(v -> {
                if (productSelectionStoreId == store.id) {
                    toggleProductSelection(p.id);
                    reloadStores();
                } else {
                    DatabaseHelper.ProductRecord fresh = db.getProduct(p.id);
                    showProductEditor(fresh == null ? p : fresh, this::reloadStores);
                }
            });
            row.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                if (productSelectionStoreId != store.id) {
                    productSelectionStoreId = store.id;
                    selectedProductIds.clear();
                    selectedProductIds.add(p.id);
                    DiagLog.write(this, "PRODUCT_SELECT_START store=" + store.id + " product=" + p.id + " source=long_press");
                } else {
                    toggleProductSelection(p.id);
                }
                reloadStores();
                return true;
            });
            sheet.addView(row);
        }
        outer.addView(wrapHorizontal(sheet));
        return outer;
    }

    private void toggleProductSelection(long productId) {
        boolean selected;
        if (selectedProductIds.contains(productId)) {
            selectedProductIds.remove(productId);
            selected = false;
        } else {
            selectedProductIds.add(productId);
            selected = true;
        }
        DiagLog.write(this, "PRODUCT_SELECT_TOGGLE product=" + productId + " selected=" + selected + " count=" + selectedProductIds.size());
        // Match photo selection: clearing the final selected row is the same as Cancel.
        if (!selected && selectedProductIds.isEmpty()) {
            long storeId = productSelectionStoreId;
            cancelProductSelection();
            DiagLog.write(this, "PRODUCT_SELECT_END_EMPTY store=" + storeId);
        }
    }

    private void cancelProductSelection() {
        if (productSelectionStoreId >= 0) {
            DiagLog.write(this, "PRODUCT_SELECT_CANCEL store=" + productSelectionStoreId + " count=" + selectedProductIds.size());
        }
        productSelectionStoreId = -1L;
        selectedProductIds.clear();
    }

    private View makePhotoGrid(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);

        boolean selecting = shareSelectionStoreId == store.id;
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), 0, dp(4), dp(8));
        if (selecting) {
            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.CENTER_VERTICAL);

            boolean canEdit = store.enabled && !shareSelectedPhotoIds.isEmpty();
            TextView delete = button("削除", canEdit ? RED : DGRAY, 12);
            delete.setEnabled(canEdit);
            delete.setAlpha(canEdit ? 1f : 0.38f);
            delete.setOnClickListener(v -> {
                if (canEdit) confirmDeleteSelectedPhotos(store);
            });
            actions.addView(delete, new LinearLayout.LayoutParams(0, dp(38), 1f));

            TextView share = button("共有", shareSelectedPhotoIds.isEmpty() ? DGRAY : ORANGE, 12);
            share.setEnabled(!shareSelectedPhotoIds.isEmpty());
            share.setAlpha(shareSelectedPhotoIds.isEmpty() ? 0.38f : 1f);
            share.setOnClickListener(v -> { if (!shareSelectedPhotoIds.isEmpty()) shareSelectedPhotos(store); });
            LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            shareLp.leftMargin = dp(5);
            actions.addView(share, shareLp);

            TextView cancel = button("キャンセル", DGRAY, 12);
            cancel.setOnClickListener(v -> {
                shareSelectionStoreId = -1L;
                shareSelectedPhotoIds.clear();
                DiagLog.write(this, "SHARE_SELECT_CANCEL store=" + store.id + " source=card");
                refreshExpandedStoreDetails(store);
            });
            LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            cancelLp.leftMargin = dp(5);
            actions.addView(cancel, cancelLp);

            TextView tagEdit = button("タグ編集", canEdit ? BLUE : DGRAY, 12);
            tagEdit.setEnabled(canEdit);
            tagEdit.setAlpha(canEdit ? 1f : 0.38f);
            tagEdit.setOnClickListener(v -> {
                if (canEdit) showSelectedPhotoTagEditor(store);
            });
            LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            tagLp.leftMargin = dp(5);
            actions.addView(tagEdit, tagLp);

            bar.addView(actions, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        } else {
            bar.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            bar.addView(new View(this), new LinearLayout.LayoutParams(0, dp(38), 1f));
            TextView select = button("選択", DGRAY, 13);
            select.setOnClickListener(v -> {
                if (photos.isEmpty()) {
                    Toast.makeText(this, "共有する画像がありません", Toast.LENGTH_SHORT).show();
                    return;
                }
                shareSelectionStoreId = store.id;
                shareSelectedPhotoIds.clear();
                DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" + photos.size() + " source=card_button");
                refreshExpandedStoreDetails(store);
            });
            bar.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
        }
        outer.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        if (photos.isEmpty()) {
            TextView empty = text("画像はまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }

        // The card only ever shows two rows. Building every historical thumbnail here made
        // expand/collapse progressively heavier as images accumulated, so render just six.
        List<DatabaseHelper.Photo> previewPhotos = photos.size() > 6
                ? new ArrayList<>(photos.subList(0, 6)) : photos;
        LinearLayout grid = buildPhotoGridRows(previewPhotos, store, selecting,
                () -> refreshExpandedStoreDetails(store), true);
        CardPhotoScrollView scroll = new CardPhotoScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(grid, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        outer.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Stable mirror footer. The selection count and "全て表示" occupy the same 92dp
        // slot from opposite edges so neither mode changes thumbnail geometry.
        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(0, dp(4), 0, 0);
        TextView count = text(selecting ? (shareSelectedPhotoIds.size() + "枚選択") : "", 13, SECONDARY, true);
        count.setGravity(Gravity.CENTER);
        count.setVisibility(selecting ? View.VISIBLE : View.INVISIBLE);
        footer.addView(count, new LinearLayout.LayoutParams(dp(92), dp(54)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(54), 1f));
        TextView all = makeDialogAction("全て表示");
        all.setGravity(Gravity.CENTER);
        all.setOnClickListener(v -> showAllPhotosDialog(store));
        footer.addView(all, new LinearLayout.LayoutParams(dp(92), dp(54)));
        outer.addView(footer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        return outer;
    }

    private LinearLayout buildPhotoGridRows(List<DatabaseHelper.Photo> photos, DatabaseHelper.Store store,
                                            boolean selecting, Runnable selectionRefresh, boolean allowLongSelect) {
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < photos.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                row.setGravity(Gravity.TOP | Gravity.START);
                grid.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            DatabaseHelper.Photo photo = photos.get(i);
            boolean selected = shareSelectedPhotoIds.contains(photo.id);
            LinearLayout tile = makePhotoTile(photo, store, selecting, selected, allowLongSelect, selectionRefresh);
            row.addView(tile, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        int remainder = photos.size() % 3;
        if (row != null && remainder != 0) {
            for (int i = remainder; i < 3; i++) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(1), 1f));
            }
        }
        return grid;
    }

    private LinearLayout makePhotoTile(DatabaseHelper.Photo photo, DatabaseHelper.Store store,
                                       boolean selecting, boolean selected, boolean allowLongSelect) {
        return makePhotoTile(photo, store, selecting, selected, allowLongSelect, null);
    }

    private LinearLayout makePhotoTile(DatabaseHelper.Photo photo, DatabaseHelper.Store store,
                                       boolean selecting, boolean selected, boolean allowLongSelect, Runnable selectionRefresh) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(3), dp(3), dp(3), dp(5));

        SquareFrameLayout imageFrame = new SquareFrameLayout(this);
        imageFrame.setBackground(roundRect(DGRAY, THUMB_RADIUS_DP));
        imageFrame.setClipToOutline(true);
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundColor(DGRAY);
        bindThumbnailAsync(image, Uri.parse(photo.uri), 360, 360);
        imageFrame.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        if (photo.csvImported) {
            View imported = new StraightCheckBadgeView(this);
            imported.setContentDescription("CSV取り込み済み");
            FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP | Gravity.END);
            badgeLp.topMargin = dp(5);
            badgeLp.rightMargin = dp(5);
            imageFrame.addView(imported, badgeLp);
        }
        tile.addView(imageFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String label = photo.tagNames == null || photo.tagNames.trim().isEmpty() ? "タグなし" : photo.tagNames;
        LinearLayout textPanel = new LinearLayout(this);
        textPanel.setOrientation(LinearLayout.VERTICAL);
        textPanel.setGravity(Gravity.CENTER);
        textPanel.setBackground(roundRect(selecting && selected ? LBLUE : Color.TRANSPARENT, THUMB_RADIUS_DP));

        FrameLayout tagRow = new FrameLayout(this);
        TextView tag = text(label, 12, selected ? WHITE : SECONDARY, selected);
        tag.setGravity(Gravity.CENTER);
        tag.setSingleLine(true);
        tagRow.addView(tag, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(24), Gravity.CENTER));
        if (selecting && selected) {
            View check = new StraightSelectionCheckView(this);
            FrameLayout.LayoutParams checkLp = new FrameLayout.LayoutParams(dp(14), dp(14), Gravity.START | Gravity.CENTER_VERTICAL);
            checkLp.leftMargin = dp(5);
            tagRow.addView(check, checkLp);
        }
        textPanel.addView(tagRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        TextView added = text(dateFormat.format(new Date(photo.createdAt)), 10, SECONDARY, false);
        added.setGravity(Gravity.CENTER);
        added.setSingleLine(true);
        textPanel.addView(added, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(20)));

        LinearLayout.LayoutParams textPanelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        textPanelLp.topMargin = dp(6);
        tile.addView(textPanel, textPanelLp);

        tile.setOnClickListener(v -> {
            if (shareSelectionStoreId == store.id) {
                boolean selectedNow;
                if (shareSelectedPhotoIds.contains(photo.id)) {
                    shareSelectedPhotoIds.remove(photo.id);
                    selectedNow = false;
                } else {
                    shareSelectedPhotoIds.add(photo.id);
                    selectedNow = true;
                }
                DiagLog.write(this, "SHARE_SELECT_TOGGLE store=" + store.id + " photo=" + photo.id +
                        " selected=" + selectedNow + " total=" + shareSelectedPhotoIds.size());
                if (!selectedNow && shareSelectedPhotoIds.isEmpty()) {
                    shareSelectionStoreId = -1L;
                    DiagLog.write(this, "SHARE_SELECT_END_EMPTY store=" + store.id);
                }
                if (selectionRefresh != null) selectionRefresh.run(); else reloadStores();
            } else {
                showPhotoDetail(photo, store);
            }
        });
        if (allowLongSelect) {
            tile.setOnLongClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                if (shareSelectionStoreId != store.id) {
                    shareSelectionStoreId = store.id;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" +
                            db.listPhotos(store.id).size() + " source=long_press");
                }
                shareSelectedPhotoIds.add(photo.id);
                DiagLog.write(this, "SHARE_SELECT_TOGGLE store=" + store.id + " photo=" + photo.id +
                        " selected=true total=" + shareSelectedPhotoIds.size());
                if (selectionRefresh != null) selectionRefresh.run(); else reloadStores();
                return true;
            });
        }
        return tile;
    }

    private void confirmDeleteSelectedPhotos(DatabaseHelper.Store store) {
        confirmDeleteSelectedPhotos(store, null);
    }

    private void confirmDeleteSelectedPhotos(DatabaseHelper.Store store, Runnable afterDelete) {
        if (!store.enabled || shareSelectionStoreId != store.id || shareSelectedPhotoIds.isEmpty()) return;
        int count = shareSelectedPhotoIds.size();
        AlertDialog confirm = new AlertDialog.Builder(this)
                .setTitle("画像削除")
                .setMessage("選択した" + count + "枚を削除します。\n撮影画像は端末から削除し、追加画像はPrice Rec.からのみ外します。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    int deleted = 0;
                    for (DatabaseHelper.Photo photo : db.listPhotos(store.id)) {
                        if (!shareSelectedPhotoIds.contains(photo.id)) continue;
                        Uri uri = Uri.parse(photo.uri);
                        if (photo.managed) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                        } else {
                            releaseImportedPermission(uri);
                        }
                        db.deletePhoto(photo.id);
                        deleted++;
                    }
                    DiagLog.write(this, "PHOTO_MULTI_DELETE store=" + store.id + " count=" + deleted);
                    shareSelectionStoreId = -1L;
                    shareSelectedPhotoIds.clear();
                    Toast.makeText(this, deleted + "枚削除しました", Toast.LENGTH_SHORT).show();
                    if (afterDelete != null) afterDelete.run(); else reloadStores();
                })
                .create();
        showRoundedDialog(confirm);
    }

    private void showSelectedPhotoTagEditor(DatabaseHelper.Store store) {
        showSelectedPhotoTagEditor(store, null);
    }

    private void showSelectedPhotoTagEditor(DatabaseHelper.Store store, Runnable afterClose) {
        if (!store.enabled || shareSelectionStoreId != store.id || shareSelectedPhotoIds.isEmpty()) return;
        Set<Long> selectedTags = commonSelectedPhotoTagIds(store.id);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(6), dp(10), dp(6));
        content.addView(makeCommonTagSelectionArea(selectedTags, true, true, chosen ->
                applyTagsToSelectedPhotos(store, chosen)),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ編集")
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        dialog.setOnDismissListener(d -> { reloadStores(); if (afterClose != null) afterClose.run(); });
        showRoundedDialog(dialog);
    }

    private void showAllPhotosDialog(DatabaseHelper.Store store) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(10), dp(10), dp(6));

        TextView dialogTitle = text(store.name + " 画像", 22, WHITE, false);
        dialogTitle.setGravity(Gravity.CENTER_VERTICAL);
        dialogTitle.setIncludeFontPadding(false);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        titleLp.leftMargin = dp(10);
        titleLp.bottomMargin = dp(10);
        content.addView(dialogTitle, titleLp);

        LinearLayout topHost = new LinearLayout(this);
        topHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        LinearLayout.LayoutParams topHostLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        topHostLp.bottomMargin = dp(10);
        content.addView(topHost, topHostLp);

        FrameLayout photoHost = new FrameLayout(this);
        content.addView(photoHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(520)));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView footerSelectionCount = text("", 13, SECONDARY, true);
        footerSelectionCount.setGravity(Gravity.CENTER);
        footer.addView(footerSelectionCount, new LinearLayout.LayoutParams(dp(92), dp(48)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView closeAction = makeDialogAction("閉じる");
        closeAction.setGravity(Gravity.CENTER);
        footer.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        footerLp.topMargin = dp(6);
        content.addView(footer, footerLp);

        final AlertDialog[] dialogHolder = new AlertDialog[1];
        final ScrollView[] photoScroll = {null};
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            int keepY = photoScroll[0] == null ? 0 : photoScroll[0].getScrollY();
            List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
            boolean selecting = shareSelectionStoreId == store.id;

            topHost.removeAllViews();
            topHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            if (selecting) {
                LinearLayout actions = new LinearLayout(this);
                actions.setGravity(Gravity.CENTER_VERTICAL);
                boolean canEdit = store.enabled && !shareSelectedPhotoIds.isEmpty();
                TextView delete = button("削除", canEdit ? RED : DGRAY, 12);
                delete.setEnabled(canEdit);
                delete.setAlpha(canEdit ? 1f : 0.38f);
                delete.setOnClickListener(v -> {
                    if (canEdit) confirmDeleteSelectedPhotos(store, render[0]);
                });
                actions.addView(delete, new LinearLayout.LayoutParams(0, dp(38), 1f));

                TextView share = button("共有", shareSelectedPhotoIds.isEmpty() ? DGRAY : ORANGE, 12);
                share.setEnabled(!shareSelectedPhotoIds.isEmpty());
                share.setAlpha(shareSelectedPhotoIds.isEmpty() ? 0.38f : 1f);
                share.setOnClickListener(v -> {
                    if (shareSelectedPhotoIds.isEmpty()) return;
                    if (dialogHolder[0] != null) dialogHolder[0].dismiss();
                    shareSelectedPhotos(store);
                });
                LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
                shareLp.leftMargin = dp(5);
                actions.addView(share, shareLp);

                TextView cancel = button("キャンセル", DGRAY, 12);
                cancel.setOnClickListener(v -> {
                    shareSelectionStoreId = -1L;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_CANCEL store=" + store.id + " source=all_photos");
                    render[0].run();
                    refreshExpandedStoreDetails(store);
                });
                LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
                cancelLp.leftMargin = dp(5);
                actions.addView(cancel, cancelLp);

                TextView tagEdit = button("タグ編集", canEdit ? BLUE : DGRAY, 12);
                tagEdit.setEnabled(canEdit);
                tagEdit.setAlpha(canEdit ? 1f : 0.38f);
                tagEdit.setOnClickListener(v -> {
                    if (canEdit) showSelectedPhotoTagEditor(store, render[0]);
                });
                LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
                tagLp.leftMargin = dp(5);
                actions.addView(tagEdit, tagLp);
                topHost.addView(actions, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
            } else {
                TextView select = button("選択", DGRAY, 13);
                select.setOnClickListener(v -> {
                    shareSelectionStoreId = store.id;
                    shareSelectedPhotoIds.clear();
                    DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" + photos.size() + " source=all_photos_button");
                    render[0].run();
                });
                topHost.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
            }

            footerSelectionCount.setText(selecting ? (shareSelectedPhotoIds.size() + "枚選択") : "");
            footerSelectionCount.setVisibility(selecting ? View.VISIBLE : View.INVISIBLE);

            photoHost.removeAllViews();
            if (photos.isEmpty()) {
                TextView empty = text("画像はまだありません", 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                photoHost.addView(empty, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                photoScroll[0] = null;
                return;
            }

            LinearLayout grid = buildPhotoGridRows(photos, store, selecting, render[0], true);
            ScrollView scroll = new ScrollView(this);
            scroll.setFillViewport(false);
            scroll.addView(grid);
            photoScroll[0] = scroll;
            photoHost.addView(withFastScroll(scroll), new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            if (keepY > 0) scroll.post(() -> scroll.scrollTo(0, keepY));
        };

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(content)
                .create();
        dialogHolder[0] = dialog;
        closeAction.setOnClickListener(v -> {
            if (shareSelectionStoreId == store.id) {
                shareSelectionStoreId = -1L;
                shareSelectedPhotoIds.clear();
                DiagLog.write(this, "SHARE_SELECT_END_OUTSIDE store=" + store.id + " source=all_photos_close");
                refreshExpandedStoreDetails(store);
            }
            dialog.dismiss();
        });
        dialog.setOnCancelListener(d -> {
            if (shareSelectionStoreId == store.id) {
                shareSelectionStoreId = -1L;
                shareSelectedPhotoIds.clear();
                DiagLog.write(this, "SHARE_SELECT_END_OUTSIDE store=" + store.id + " source=all_photos_outside");
                refreshExpandedStoreDetails(store);
            }
        });
        render[0].run();
        showRoundedDialog(dialog, true);
    }

    private void beginShareSelection(DatabaseHelper.Store store) {
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
        if (photos.isEmpty()) {
            Toast.makeText(this, "共有する画像がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        shareSelectionStoreId = store.id;
        shareSelectedPhotoIds.clear();
        DiagLog.write(this, "SHARE_SELECT_START store=" + store.id + " available=" + photos.size() + " source=button");
        refreshExpandedStoreDetails(store);
    }

    private void cancelShareSelection() {
        long storeId = shareSelectionStoreId;
        if (storeId >= 0) DiagLog.write(this, "SHARE_SELECT_CANCEL store=" + storeId + " selected=" + shareSelectedPhotoIds.size());
        shareSelectionStoreId = -1L;
        shareSelectedPhotoIds.clear();
        DatabaseHelper.Store store = storeId >= 0 ? db.getStore(storeId) : null;
        if (store != null) refreshExpandedStoreDetails(store); else reloadStores();
    }

    private void shareSelectedPhotos(DatabaseHelper.Store store) {
        ArrayList<DatabaseHelper.Photo> selected = new ArrayList<>();
        for (DatabaseHelper.Photo photo : db.listPhotos(store.id)) {
            if (shareSelectedPhotoIds.contains(photo.id)) selected.add(photo);
        }
        if (selected.isEmpty()) {
            Toast.makeText(this, "画像を選択してください", Toast.LENGTH_SHORT).show();
            return;
        }
        shareSelectionStoreId = -1L;
        shareSelectedPhotoIds.clear();
        sharePhotosWithChatGpt(store, selected, commonTagLabel(selected));
        reloadStores();
    }

    private String commonTagLabel(List<DatabaseHelper.Photo> photos) {
        String common = null;
        for (DatabaseHelper.Photo p : photos) {
            String tag = p.tagName == null ? "タグなし" : p.tagName;
            if (common == null) common = tag;
            else if (!common.equals(tag)) return "複数タグ";
        }
        return common == null ? "タグなし" : common;
    }

    private void showAddStoreDialog() {
        boolean imeWasVisible = isImeVisible();
        EditText input = dialogInput("店舗名");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("カード追加")
                .setView(storeNameInputHolder(input, 14))
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("追加", null)
                .create();
        if (imeWasVisible) {
            input.requestFocus();
            Window preShowWindow = dialog.getWindow();
            if (preShowWindow != null) {
                preShowWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE |
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED);
            }
        }
        dialog.setOnShowListener(d -> {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { input.setError("店舗名を入力"); return; }
                long id = db.addStore(name);
                if (id > 0) {
                    expandedStoreId = id;
                    expandedStoreIds.add(id);
                    DiagLog.write(this, "ADD_STORE id=" + id + " name=" + name);
                    dialog.dismiss();
                    reloadStores();
                }
            });
            focusDialogInput(input, dialog, imeWasVisible);
        });
        showRoundedDialog(dialog);
    }

    private void showStoreMenu(DatabaseHelper.Store store, View card) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setItems(new String[]{"カード内商品リスト", "カード名変更", "カード削除"}, (d, which) -> {
                    if (which == 0) {
                        showProductTableDialog(store.name + " カード内商品リスト", store.id, "");
                    } else if (!store.enabled) {
                        Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
                    } else if (which == 1) {
                        showRenameStoreDialog(store);
                    } else {
                        showDeleteStoreDialog(store);
                    }
                })
                .create();
        dialog.setOnDismissListener(d -> {
            View current = storeCardViews.get(store.id);
            if (current != null) current.setBackground(roundRect(GRAY, 18));
        });
        showRoundedDialog(dialog);
    }

    private void showRenameStoreDialog(DatabaseHelper.Store store) {
        EditText nameInput = dialogInput("カード名");
        nameInput.setText(store.name);
        nameInput.setSelection(nameInput.length());

        EditText keyInput = dialogInput("store_key");
        keyInput.setText(store.storeKey == null ? DatabaseHelper.buildStoreKey(store.name) : store.storeKey);
        keyInput.setSelection(keyInput.length());

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(14), dp(20), dp(4));
        TextView nameLabel = text("カード名", 12, SECONDARY, true);
        nameLabel.setPadding(dp(4), 0, 0, dp(6));
        panel.addView(nameLabel);
        panel.addView(nameInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        TextView keyLabel = text("store_key", 12, SECONDARY, true);
        keyLabel.setPadding(dp(4), dp(14), 0, dp(6));
        panel.addView(keyLabel);
        panel.addView(keyInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("カード名変更")
                .setView(panel)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("変更", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String requestedKey = keyInput.getText().toString().trim();
            if (name.isEmpty()) { nameInput.setError("カード名を入力"); return; }
            if (requestedKey.isEmpty()) { keyInput.setError("store_keyを入力"); return; }
            String finalKey = db.updateStoreIdentity(store.id, name, requestedKey);
            DiagLog.write(this, "UPDATE_STORE_IDENTITY id=" + store.id + " name=" + name + " store_key=" + finalKey);
            if (!finalKey.equals(requestedKey) && !finalKey.equals("str." + requestedKey)) {
                Toast.makeText(this, "store_key衝突のため " + finalKey + " に変更しました", Toast.LENGTH_LONG).show();
            }
            dialog.dismiss();
            reloadStores();
        }));
        showRoundedDialog(dialog);
    }

    private void showDeleteStoreDialog(DatabaseHelper.Store store) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("カード削除")
                .setMessage("「" + store.name + "」と、この店舗に紐づく登録データを削除します。\n撮影した画像は端末からも削除します。追加した既存画像の元ファイルは削除しません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    for (DatabaseHelper.Photo p : db.listPhotos(store.id)) {
                        if (p.managed) {
                            try { getContentResolver().delete(Uri.parse(p.uri), null, null); } catch (Exception ignored) { }
                        } else releaseImportedPermission(Uri.parse(p.uri));
                    }
                    db.deleteStore(store.id);
                    expandedStoreIds.remove(store.id);
                    if (expandedStoreId == store.id) expandedStoreId = expandedStoreIds.isEmpty() ? -1L : expandedStoreIds.iterator().next();
                    DiagLog.write(this, "DELETE_STORE id=" + store.id + " name=" + store.name);
                    reloadStores();
                }).create();
        showRoundedDialog(dialog);
    }

    private void showTagManager() {
        showTagManager(null);
    }

    private void showTagManager(Runnable afterClose) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(10));

        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        content.addView(rows);
        populateTagManagerRows(rows);

        LinearLayout addRow = new LinearLayout(this);
        addRow.setGravity(Gravity.CENTER_VERTICAL);
        addRow.setPadding(0, dp(10), 0, 0);

        EditText input = dialogInput("新しいタグ");
        TextView add = text("＋", 24, WHITE, true);
        add.setGravity(Gravity.CENTER);
        add.setIncludeFontPadding(false);
        add.setBackground(circle(LBLUE));
        add.setContentDescription("タグ追加");
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        inputLp.rightMargin = dp(8);
        addRow.addView(input, inputLp);
        addRow.addView(add, new LinearLayout.LayoutParams(dp(48), dp(48)));
        content.addView(addRow);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ管理")
                .setView(scroll)
                .setNegativeButton("閉じる", null)
                .create();

        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            long id = db.addTag(name);
            if (id < 0) { input.setError("同じタグがあります"); return; }
            DiagLog.write(this, "ADD_TAG id=" + id + " name=" + name);
            input.setText("");
            populateTagManagerRows(rows);
            reloadStores();
        });
        dialog.setOnDismissListener(d -> {
            reloadStores();
            if (afterClose != null) afterClose.run();
        });
        showRoundedDialog(dialog);
    }

    private void populateTagManagerRows(LinearLayout container) {
        container.removeAllViews();
        for (DatabaseHelper.Tag tag : db.listTags()) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6), dp(4), dp(8), dp(4));
            row.setBackground(roundRect(DGRAY, 14));
            row.setElevation(dp(2));
            row.setTag(tag.id);

            TextView handle = text("☰", 22, SECONDARY, false);
            handle.setGravity(Gravity.CENTER);
            handle.setContentDescription(tag.name + "を並べ替え");

            TextView name = text(tag.name, 16, WHITE, false);
            name.setGravity(Gravity.CENTER_VERTICAL);
            name.setIncludeFontPadding(false);

            FrameLayout deleteSlot = new FrameLayout(this);
            deleteSlot.setContentDescription(tag.name + "を削除");
            View del = new TagDeleteIconView(this);
            deleteSlot.addView(del, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            deleteSlot.setOnClickListener(v -> {
                AlertDialog confirm = new AlertDialog.Builder(this)
                        .setTitle("タグ削除")
                        .setMessage("「" + tag.name + "」を削除します。画像自体は削除されません。")
                        .setNegativeButton("キャンセル", null)
                        .setPositiveButton("削除", (d, w) -> {
                            db.deleteTag(tag.id);
                            DiagLog.write(this, "DELETE_TAG id=" + tag.id + " name=" + tag.name);
                            populateTagManagerRows(container);
                            reloadStores();
                        }).create();
                showRoundedDialog(confirm);
            });

            row.addView(handle, new LinearLayout.LayoutParams(dp(48), dp(52)));
            row.addView(name, new LinearLayout.LayoutParams(0, dp(52), 1f));
            row.addView(deleteSlot, new LinearLayout.LayoutParams(dp(48), dp(52)));

            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dp(7);
            container.addView(row, rowLp);

            attachTagManagerReorderGesture(handle, row, container, tag);
        }
    }

    private void attachTagManagerReorderGesture(TextView handle, View row, LinearLayout container, DatabaseHelper.Tag tag) {
        final boolean[] armed = {false};
        final boolean[] dragging = {false};
        final float[] downRawY = {0f};
        final int[] sourceIndex = {-1};
        final int[] targetIndex = {-1};

        handle.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawY[0] = event.getRawY();
                    sourceIndex[0] = container.indexOfChild(row);
                    targetIndex[0] = sourceIndex[0];
                    armed[0] = false;
                    dragging[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (!armed[0]) return false;
                    float dy = event.getRawY() - downRawY[0];
                    if (!dragging[0] && Math.abs(dy) < dp(6)) return true;
                    dragging[0] = true;
                    row.setTranslationX(0f);
                    row.setTranslationY(dy);
                    int target = nearestChildIndexByRawY(container, event.getRawY());
                    if (target >= 0 && target != targetIndex[0]) {
                        targetIndex[0] = target;
                        animateVerticalReorderPreview(container, row, sourceIndex[0], targetIndex[0]);
                        DiagLog.write(this, "TAG_DRAG_TARGET id=" + tag.id + " index=" + target);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!armed[0]) return false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    int from = sourceIndex[0];
                    int to = targetIndex[0];
                    boolean wasDragging = dragging[0];
                    resetVerticalReorderPreview(container, row);
                    row.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(145).setInterpolator(new DecelerateInterpolator()).start();
                    row.setElevation(dp(2));
                    if (commit && wasDragging && from >= 0 && to >= 0 && from != to) {
                        ArrayList<Long> ordered = new ArrayList<>();
                        for (DatabaseHelper.Tag t : db.listTags()) ordered.add(t.id);
                        int logicalFrom = ordered.indexOf(tag.id);
                        if (logicalFrom >= 0) {
                            moveListItem(ordered, logicalFrom, Math.max(0, Math.min(to, ordered.size() - 1)));
                            db.setTagOrder(ordered);
                            DiagLog.write(this, "TAG_REORDER_SAVE id=" + tag.id + " from=" + logicalFrom + " to=" + to);
                            container.postDelayed(() -> {
                                populateTagManagerRows(container);
                                reloadStores();
                            }, 130);
                        }
                    }
                    armed[0] = false;
                    dragging[0] = false;
                    sourceIndex[0] = -1;
                    targetIndex[0] = -1;
                    return true;
                default:
                    return armed[0];
            }
        });

        handle.setOnLongClickListener(v -> {
            armed[0] = true;
            dragging[0] = false;
            sourceIndex[0] = container.indexOfChild(row);
            targetIndex[0] = sourceIndex[0];
            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            row.setTranslationX(0f);
            row.setElevation(dp(12));
            row.animate().scaleX(1.025f).scaleY(1.025f).alpha(0.84f).setDuration(85).start();
            DiagLog.write(this, "TAG_DRAG_START id=" + tag.id + " name=" + tag.name + " axis=y");
            return true;
        });
    }

    private int nearestChildIndexByRawY(LinearLayout column, float rawY) {
        int[] loc = new int[2];
        column.getLocationOnScreen(loc);
        float localY = rawY - loc[1];
        int best = -1;
        float bestDistance = Float.MAX_VALUE;
        for (int i = 0; i < column.getChildCount(); i++) {
            View child = column.getChildAt(i);
            float center = child.getTop() + child.getHeight() / 2f;
            float distance = Math.abs(localY - center);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = i;
            }
        }
        return best;
    }

    private int verticalOuterSize(View view) {
        int size = view.getHeight();
        ViewGroup.LayoutParams lp = view.getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
            size += mlp.topMargin + mlp.bottomMargin;
        }
        return Math.max(dp(1), size);
    }

    private void animateVerticalReorderPreview(LinearLayout column, View dragged, int sourceIndex, int targetIndex) {
        if (sourceIndex < 0 || targetIndex < 0) return;
        int shift = verticalOuterSize(dragged);
        for (int i = 0; i < column.getChildCount(); i++) {
            View child = column.getChildAt(i);
            if (child == dragged) continue;
            float ty = 0f;
            if (targetIndex > sourceIndex && i > sourceIndex && i <= targetIndex) {
                ty = -shift;
            } else if (targetIndex < sourceIndex && i >= targetIndex && i < sourceIndex) {
                ty = shift;
            }
            child.animate().translationX(0f).translationY(ty).setDuration(145)
                    .setInterpolator(new DecelerateInterpolator(1.55f)).start();
        }
    }

    private void resetVerticalReorderPreview(LinearLayout column, View dragged) {
        for (int i = 0; i < column.getChildCount(); i++) {
            View child = column.getChildAt(i);
            if (child == dragged) continue;
            child.animate().translationX(0f).translationY(0f).setDuration(125)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private void showPhotoDetail(DatabaseHelper.Photo photo, DatabaseHelper.Store store) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(8));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        image.setBackgroundColor(DGRAY);
        Bitmap bmp = loadBitmap(Uri.parse(photo.uri), 1200, 900);
        if (bmp != null) image.setImageBitmap(bmp);
        image.setContentDescription("原寸表示");
        image.setOnClickListener(v -> showOriginalPhoto(photo));
        content.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280)));

        TextView meta = text(dateFormat.format(new Date(photo.createdAt)), 13, SECONDARY, false);
        meta.setPadding(dp(4), dp(8), 0, dp(4));
        content.addView(meta);

        Set<Long> photoTags = new HashSet<>(photo.tagIds);
        View tagArea = makeCommonTagSelectionArea(photoTags, true, store.enabled, chosen -> {
            db.updatePhotoTags(photo.id, orderedTagIds(chosen));
            DiagLog.write(this, "PHOTO_TAGS photo=" + photo.id + " tags=" + chosen);
            reloadStores();
        });
        LinearLayout.LayoutParams tagAreaLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        tagAreaLp.bottomMargin = dp(8);
        content.addView(tagArea, tagAreaLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView delete = button("削除", store.enabled ? RED : DGRAY, 13);
        delete.setEnabled(store.enabled);
        delete.setAlpha(store.enabled ? 1f : 0.38f);
        actions.addView(delete, new LinearLayout.LayoutParams(0, dp(38), 1f));

        TextView share = button("共有", ORANGE, 13);
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        shareLp.leftMargin = dp(5);
        actions.addView(share, shareLp);

        TextView cancel = button("キャンセル", DGRAY, 13);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        cancelLp.leftMargin = dp(5);
        actions.addView(cancel, cancelLp);

        TextView edit = button("商品リスト", BLUE, 13);
        LinearLayout.LayoutParams editLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        editLp.leftMargin = dp(5);
        actions.addView(edit, editLp);

        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        actionsLp.topMargin = dp(6);
        content.addView(actions, actionsLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setView(content)
                .create();

        delete.setOnClickListener(v -> {
            if (!store.enabled) return;
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("画像削除")
                    .setMessage(photo.managed ? "この撮影画像を端末から削除します。" : "この画像をPrice Rec.から外します。元の画像ファイルは削除しません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (d, w) -> {
                        Uri uri = Uri.parse(photo.uri);
                        if (photo.managed) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                        } else releaseImportedPermission(uri);
                        db.deletePhoto(photo.id);
                        DiagLog.write(this, "DELETE_PHOTO id=" + photo.id + " managed=" + photo.managed);
                        dialog.dismiss();
                        reloadStores();
                    }).create();
            showRoundedDialog(confirm);
        });

        share.setOnClickListener(v -> {
            ArrayList<DatabaseHelper.Photo> one = new ArrayList<>();
            one.add(photo);
            dialog.dismiss();
            DiagLog.write(this, "PHOTO_SHARE_SINGLE photo=" + photo.id + " store=" + store.id);
            sharePhotosWithChatGpt(store, one, commonTagLabel(one));
        });

        cancel.setOnClickListener(v -> dialog.dismiss());

        edit.setOnClickListener(v -> {
            dialog.dismiss();
            DiagLog.write(this, "PHOTO_PRODUCT_LIST_OPEN photo=" + photo.id + " store=" + store.id);
            showProductTableDialog(store.name + " / 商品リスト", store.id, photo.id, "");
        });
        showRoundedDialog(dialog);
    }

    private boolean showOriginalPhoto(DatabaseHelper.Photo photo) {
        Uri uri = Uri.parse(photo.uri);
        Bitmap original = loadOriginalBitmap(uri);
        if (original == null) {
            Toast.makeText(this, "原寸画像を開けませんでした", Toast.LENGTH_LONG).show();
            return false;
        }

        ZoomImageView zoom = new ZoomImageView(this);
        zoom.setBackgroundColor(Color.BLACK);
        zoom.setImageBitmap(original);
        zoom.setContentDescription("原寸画像。ピンチでズーム、ドラッグで移動");

        LinearLayout holder = new LinearLayout(this);
        holder.setPadding(dp(4), dp(4), dp(4), dp(4));
        holder.addView(zoom, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(620)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(holder)
                .setNegativeButton("閉じる", null)
                .create();
        dialog.setOnDismissListener(d -> zoom.setImageDrawable(null));
        showRoundedDialog(dialog, true);
        DiagLog.write(this, "PHOTO_ORIGINAL_OPEN photo=" + photo.id +
                " size=" + original.getWidth() + "x" + original.getHeight());
        return true;
    }

    private Bitmap loadOriginalBitmap(Uri uri) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source, (decoder, info, src) ->
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        } catch (Exception e) {
            DiagLog.write(this, "IMAGE_ORIGINAL_LOAD_ERROR uri=" + uri + " err=" + e);
            return null;
        }
    }

    private String tagNameById(long id) {
        for (DatabaseHelper.Tag tag : db.listTags()) if (tag.id == id) return tag.name;
        return "タグなし";
    }

    private void sharePhotosWithChatGpt(DatabaseHelper.Store store, List<DatabaseHelper.Photo> photos, String tagName) {
        if (photos == null || photos.isEmpty()) return;
        final long started = SystemClock.elapsedRealtime();
        ArrayList<Uri> uris = new ArrayList<>();
        for (DatabaseHelper.Photo photo : photos) {
            try {
                Uri uri = Uri.parse(photo.uri);
                if (uri != null) uris.add(uri);
            } catch (Exception e) {
                DiagLog.write(this, "SHARE_SOURCE_URI_ERROR photo=" + photo.id + " err=" + e);
            }
        }
        if (uris.isEmpty()) {
            Toast.makeText(this, "共有できる画像がありません", Toast.LENGTH_SHORT).show();
            return;
        }

        saveLastShareMap(photos);
        String prompt = buildChatGptPrompt(store, photos, tagName);
        DiagLog.write(this, "SHARE_PREP_LIGHT sources=" + photos.size() + " attachments=" + uris.size() +
                " promptChars=" + prompt.length() + " prepMs=" + (SystemClock.elapsedRealtime() - started));
        launchChatGptShare(store, tagName, uris, prompt, started);
    }

    private void launchChatGptShare(DatabaseHelper.Store store, String tagName, ArrayList<Uri> uris,
                                    String prompt, long started) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Price Rec. 解析指示", prompt));
                DiagLog.write(this, "SHARE_CLIPBOARD_OK chars=" + prompt.length());
            }
        } catch (Exception e) {
            DiagLog.write(this, "SHARE_CLIPBOARD_ERROR " + e);
        }

        Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
        share.setType("image/*");
        share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        share.putExtra(Intent.EXTRA_TEXT, prompt);
        share.putExtra(Intent.EXTRA_TITLE, "Price Rec. 商品価格解析");
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        ClipData clip = ClipData.newUri(getContentResolver(), "Price Rec. source images", uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        share.setClipData(clip);

        boolean direct = false;
        try {
            Intent chatGpt = new Intent(share);
            chatGpt.setPackage("com.openai.chatgpt");
            boolean directAvailable = getPackageManager().resolveActivity(chatGpt, 0) != null;
            DiagLog.write(this, "SHARE_DIRECT_CHECK available=" + directAvailable);
            if (directAvailable) {
                direct = true;
                for (Uri uri : uris) {
                    try {
                        grantUriPermission("com.openai.chatgpt", uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception e) {
                        DiagLog.write(this, "SHARE_URI_GRANT_ERROR uri=" + uri + " err=" + e);
                    }
                }
                startActivity(chatGpt);
            } else {
                Intent chooser = Intent.createChooser(share, "画像を共有");
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(chooser);
            }
            DiagLog.write(this, "CHATGPT_SHARE_START store=" + store.id + " attachments=" + uris.size() +
                    " tag=" + tagName + " textChars=" + prompt.length() + " direct=" + direct +
                    " totalMs=" + (SystemClock.elapsedRealtime() - started));
        } catch (Exception e) {
            DiagLog.write(this, "SHARE_INTENT_ERROR elapsedMs=" + (SystemClock.elapsedRealtime() - started) + " err=" + e);
            Toast.makeText(this, "共有を開始できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void saveLastShareMap(List<DatabaseHelper.Photo> photos) {
        android.content.SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        int oldCount = prefs.getInt("last_share_count", 0);
        android.content.SharedPreferences.Editor editor = prefs.edit();
        for (int i = 1; i <= oldCount; i++) editor.remove("last_share_image_" + i);
        editor.putInt("last_share_count", photos.size());
        editor.putLong("last_share_at", System.currentTimeMillis());
        for (int i = 0; i < photos.size(); i++) editor.putLong("last_share_image_" + (i + 1), photos.get(i).id);
        editor.apply();
    }

    private String buildChatGptPrompt(DatabaseHelper.Store store, List<DatabaseHelper.Photo> photos, String tagName) {
        String csvFileName = "PriceRec_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.JAPAN).format(new Date()) + ".csv";
        SimpleDateFormat shareDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);
        StringBuilder b = new StringBuilder();
        b.append("Price Rec.用の商品価格解析です。\n");
        b.append("店舗: ").append(store.name).append('\n');
        b.append("選択画像数: ").append(photos.size()).append("枚\n\n");

        b.append("Recognition protocol (important):\n");
        b.append("- Use BOTH OCR/transcription and visual product recognition on the original images. Do not identify a product from OCR text alone.\n");
        b.append("- Use label/logo design, colors, typography, bottle/can/package shape, label layout, emblems, age statements, cap/neck design and other visual cues as independent evidence.\n");
        b.append("- For blurred, crushed, compressed, partially hidden or low-resolution characters, compare character shapes with the surrounding label structure and the product's other visible visual cues. You may conservatively reconstruct unclear characters only when multiple independent cues converge on the same reading.\n");
        b.append("- Be relatively proactive about product identity when brand, label design and packaging cues strongly converge, even if OCR is imperfect. However, distinguish close variants such as age, edition, flavor, proof and volume; do not invent a variant that is not visually supported.\n");
        b.append("- Product names may be normalized to the commonly used Japanese product name when the identity is visually well supported.\n");
        b.append("- Price is different: never infer a price from product identity, memory, typical market price or nearby products. Read the actual visible shelf label/POP. If the digits remain ambiguous, leave price blank.\n");
        b.append("- Do not mistake descriptive copy, awards, tasting notes, JAN codes, discount conditions or shelf POP prose for the product name.\n\n");

        b.append("添付画像に写っている商品の商品名と販売価格を、OCRと画像全体の視覚的特徴を組み合わせて抽出してください。\n");
        b.append("同じ商品が複数画像に重複している場合は、同一店舗・同一価格なら重複行をまとめてください。\n");
        b.append("商品名は複数の根拠が一致する場合は積極的に特定して構いません。一方、価格・容量・年数・版違いなど根拠が弱い項目は推測で埋めないでください。\n\n");

        b.append("Price Rec.取込用CSVファイルをUTF-8で作成してください。\n");
        b.append("列順は必ず次の通りです。\n");
        b.append("store,tag,product_name,product_key,price,volume,price_type,captured_at,source_image\n");
        b.append("storeは『").append(store.name).append("』を入れてください。\n");
        b.append("product_keyは同一商品判定用の内部キーです。必ず『prd.』で開始し、以降は日本語・全角文字を使用して構いません。意味の区切りはピリオドを使ってください。例: prd.アサヒスーパードライ.350\n");
        b.append("同じ商品は店舗が違っても同じproduct_keyを使ってください。単なる重複では連番を付けないでください。\n");
        b.append("実際には別商品なのに同じキーになる場合だけ、末尾へ .001 / .002 の3桁連番を付けて分離してください。商品名自体にピリオドが含まれていても問題ありません。\n");
        b.append("priceは円の整数のみ、volumeは判読できる場合のみ。volumeはml換算した整数のみを入れ、ml等の単位文字は付けないでください（例: 700ml→700、1L→1000）。\n");
        b.append("price_typeは画像内に税込／税抜の明記がある場合はその表記を最優先してください。明記がない場合は、各画像に指定した『表示なし』ルールに従って『税込』または『税抜』を入れてください。\n");
        b.append("tag / captured_at / source_image / 表示なしルール は、各画像について下記の値をそのまま使ってください。\n");
        for (int i = 0; i < photos.size(); i++) {
            DatabaseHelper.Photo p = photos.get(i);
            String tag = p.tagName == null ? "タグなし" : p.tagName;
            b.append("image_").append(i + 1)
                    .append(" => source_image=photo_").append(p.id)
                    .append(", tag=").append(tag)
                    .append(", captured_at=").append(shareDateFormat.format(new Date(p.createdAt)))
                    .append(", 表示なし=").append(p.defaultTaxExcluded ? "税抜" : "税込").append('\n');
        }
        b.append("source_imageには image_N ではなく、必ず対応する photo_<番号> を入れてください。\n");
        b.append("\n最終結果はMarkdown表だけでなく、ダウンロード可能なCSVファイルとして作成してください。\n");
        b.append("CSVファイル名は必ず「").append(csvFileName).append("」にしてください。");
        return b.toString();
    }

    private void showAddImagesConfirmation(DatabaseHelper.Store store, List<PendingImage> items) {
        if (store == null || items == null || items.isEmpty()) return;
        final Set<String> selectedUris = new HashSet<>();
        for (PendingImage item : items) if (item != null && item.uri != null) selectedUris.add(item.uri.toString());
        final Set<Long> selectedTags = new HashSet<>();
        final boolean[] defaultTaxExcluded = {true};
        final boolean[] committed = {false};

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(4), dp(10), dp(8));

        ScrollView imageScroll = new ScrollView(this);
        imageScroll.setFillViewport(false);
        imageScroll.setVerticalScrollBarEnabled(true);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        imageScroll.addView(grid, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Multi-image confirmation gets a little more vertical room so the second-row
        // selection band is fully visible. Extra images scroll only inside this area.
        int previewHeight;
        if (items.size() == 1) previewHeight = 300;
        else if (items.size() <= 3) previewHeight = 205;
        else previewHeight = 380;
        content.addView(imageScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(previewHeight)));

        TextView count = text(selectedUris.size() + "枚選択", 13, SECONDARY, true);
        count.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);

        if (items.size() == 1) {
            PendingImage item = items.get(0);
            FrameLayout singleFrame = new FrameLayout(this);
            singleFrame.setBackground(roundRect(DGRAY, THUMB_RADIUS_DP));
            singleFrame.setClipToOutline(true);
            ImageView singleImage = new ImageView(this);
            singleImage.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            singleImage.setBackgroundColor(DGRAY);
            Bitmap bmp = loadBitmap(item.uri, 1200, 900);
            if (bmp != null) singleImage.setImageBitmap(bmp);
            singleFrame.addView(singleImage, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            LinearLayout.LayoutParams singleLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(280));
            singleLp.setMargins(dp(3), dp(3), dp(3), dp(6));
            grid.addView(singleFrame, singleLp);
        } else {
            LinearLayout row = null;
            for (int i = 0; i < items.size(); i++) {
                if (i % 3 == 0) {
                    row = new LinearLayout(this);
                    row.setGravity(Gravity.TOP | Gravity.START);
                    grid.addView(row, new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                }
                PendingImage item = items.get(i);
                if (item == null || item.uri == null) continue;
                final String key = item.uri.toString();

                LinearLayout tile = new LinearLayout(this);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setPadding(dp(3), dp(3), dp(3), dp(5));

                SquareFrameLayout frame = new SquareFrameLayout(this);
                frame.setBackground(roundRect(DGRAY, THUMB_RADIUS_DP));
                frame.setClipToOutline(true);
                ImageView image = new ImageView(this);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                image.setBackgroundColor(DGRAY);
                Bitmap bmp = loadCachedBitmap(item.uri, 360, 360);
                if (bmp != null) image.setImageBitmap(bmp);
                frame.addView(image, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                tile.addView(frame, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                LinearLayout selectedPanel = new LinearLayout(this);
                selectedPanel.setGravity(Gravity.CENTER);
                View check = new StraightSelectionCheckView(this);
                LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(dp(14), dp(14));
                checkLp.rightMargin = dp(5);
                selectedPanel.addView(check, checkLp);
                TextView state = text("", 11, WHITE, true);
                state.setGravity(Gravity.CENTER);
                selectedPanel.addView(state, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, dp(26)));
                LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
                panelLp.topMargin = dp(6);
                tile.addView(selectedPanel, panelLp);

                Runnable updateSelectionVisual = () -> {
                    boolean selected = selectedUris.contains(key);
                    selectedPanel.setBackground(roundRect(selected ? LBLUE : Color.TRANSPARENT, THUMB_RADIUS_DP));
                    check.setVisibility(selected ? View.VISIBLE : View.GONE);
                    state.setText(selected ? "選択済み" : "除外");
                    state.setTextColor(selected ? WHITE : SECONDARY);
                    state.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
                };
                updateSelectionVisual.run();

                tile.setOnClickListener(v -> {
                    long started = SystemClock.elapsedRealtime();
                    if (!selectedUris.add(key)) selectedUris.remove(key);
                    count.setText(selectedUris.size() + "枚選択");
                    // Local visual update only: no full grid rebuild and no image re-decode.
                    updateSelectionVisual.run();
                    DiagLog.write(this, "PHOTO_CONFIRM_TOGGLE_FAST selected=" + selectedUris.contains(key) +
                            " total=" + selectedUris.size() + " elapsedMs=" +
                            (SystemClock.elapsedRealtime() - started));
                });
                row.addView(tile, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            }
            int remainder = items.size() % 3;
            if (row != null && remainder != 0) {
                for (int i = remainder; i < 3; i++) {
                    row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(1), 1f));
                }
            }
        }

        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        tagLp.topMargin = dp(6);
        content.addView(makeCommonTagSelectionArea(selectedTags, true, store.enabled, chosen -> { }), tagLp);

        // Selection count stays at the lower-left, immediately above the bottom controls.
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        countLp.topMargin = dp(2);
        content.addView(count, countLp);

        // Tax fallback N toggle: right aligned, label to its left, vertically centered.
        // ON (default) = unspecified prices are tax-excluded.
        LinearLayout taxRow = new LinearLayout(this);
        taxRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        taxRow.addView(new View(this), new LinearLayout.LayoutParams(0, dp(36), 1f));
        TextView taxLabel = text("表示なしは税抜", 12, WHITE, true);
        taxLabel.setIncludeFontPadding(false);
        taxLabel.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams taxTextLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
        taxTextLp.rightMargin = dp(8);
        taxRow.addView(taxLabel, taxTextLp);
        NToggleSwitch taxToggle = new NToggleSwitch(this);
        taxToggle.setChecked(true);
        taxToggle.setNColors(ORANGE, WHITE);
        taxToggle.setOnCheckedChangeListener((buttonView, checked) -> {
            defaultTaxExcluded[0] = checked;
            taxLabel.setText(checked ? "表示なしは税抜" : "表示なしは税込");
            buttonView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            DiagLog.write(this, "PHOTO_CONFIRM_TAX_DEFAULT excluded=" + checked);
        });
        taxRow.addView(taxToggle, new LinearLayout.LayoutParams(dp(44), dp(26)));
        LinearLayout.LayoutParams taxRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        taxRowLp.topMargin = dp(2);
        content.addView(taxRow, taxRowLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView cancel = button("キャンセル", DGRAY, 14);
        TextView add = button("画像追加", BLUE, 14);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        cancelLp.rightMargin = dp(5);
        actions.addView(cancel, cancelLp);
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        addLp.leftMargin = dp(5);
        actions.addView(add, addLp);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        actionsLp.topMargin = dp(6);
        content.addView(actions, actionsLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("画像追加")
                .setView(content)
                .create();

        add.setOnClickListener(v -> {
            if (selectedUris.isEmpty()) {
                Toast.makeText(this, "追加する画像を選択してください", Toast.LENGTH_SHORT).show();
                return;
            }
            int added = 0;
            ArrayList<Long> tags = orderedTagIds(selectedTags);
            for (PendingImage item : items) {
                if (item == null || item.uri == null) continue;
                boolean selected = selectedUris.contains(item.uri.toString());
                if (!selected) {
                    cleanupPendingImage(item);
                    continue;
                }
                try {
                    Uri finalUri = item.uri;
                    boolean finalManaged = item.managed;
                    if (item.cameraTempPath != null) {
                        finalUri = commitCameraTempToMediaStore(item, store);
                        finalManaged = true;
                        if (finalUri == null) {
                            DiagLog.write(this, "PHOTO_CONFIRM_ADD_ERROR temp=" + item.cameraTempPath + " err=commit_failed");
                            continue;
                        }
                    } else if (!item.managed) {
                        try {
                            getContentResolver().takePersistableUriPermission(
                                    item.uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (Exception e) {
                            DiagLog.write(this, "PHOTO_PICKER_PERMISSION_WARN uri=" + item.uri + " err=" + e);
                        }
                    }
                    long photoId = db.addPhoto(store.id, null, finalUri.toString(), finalManaged);
                    if (photoId > 0) {
                        db.updatePhotoTags(photoId, tags);
                        db.setPhotoDefaultTaxExcluded(photoId, defaultTaxExcluded[0]);
                        added++;
                        DiagLog.write(this, "PHOTO_CONFIRM_ADD photo=" + photoId + " store=" + store.id +
                                " tags=" + tags + " managed=" + finalManaged +
                                " defaultTaxExcluded=" + defaultTaxExcluded[0]);
                    }
                } catch (Exception e) {
                    DiagLog.write(this, "PHOTO_CONFIRM_ADD_ERROR uri=" + item.uri + " err=" + e);
                }
            }
            committed[0] = true;
            expandedStoreId = store.id;
            expandedStoreIds.add(store.id);
            activeTab.put(store.id, "images");
            Toast.makeText(this, added + "枚追加しました", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
            reloadStores();
        });
        cancel.setOnClickListener(v -> dialog.cancel());
        dialog.setOnDismissListener(d -> {
            if (committed[0]) return;
            for (PendingImage item : items) cleanupPendingImage(item);
            DiagLog.write(this, "PHOTO_CONFIRM_CANCEL store=" + store.id + " count=" + items.size());
        });
        showRoundedDialog(dialog, true);
        DiagLog.write(this, "PHOTO_CONFIRM_OPEN store=" + store.id + " count=" + items.size() +
                " previewHeightDp=" + previewHeight);
    }

    private void importImages(DatabaseHelper.Store store) {
        pendingImportStoreId = store.id;
        pendingImportTagId = null;
        try {
            PickVisualMediaRequest request = new PickVisualMediaRequest.Builder()
                    .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                    .build();
            DiagLog.write(this, "PHOTO_PICKER_START store=" + store.id);
            photoPicker.launch(request);
        } catch (Exception e) {
            clearPendingImportState();
            DiagLog.write(this, "PHOTO_PICKER_ERROR " + e);
            Toast.makeText(this, "画像を選択できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void handlePhotoPickerUris(List<Uri> uris) {
        if (pendingImportStoreId < 0) return;
        if (uris == null || uris.isEmpty()) {
            DiagLog.write(this, "PHOTO_PICKER_CANCEL");
            clearPendingImportState();
            return;
        }
        long storeId = pendingImportStoreId;
        DatabaseHelper.Store store = findStore(storeId);
        ArrayList<PendingImage> pending = new ArrayList<>();
        for (Uri uri : uris) if (uri != null) pending.add(new PendingImage(uri, false, null));
        clearPendingImportState();
        if (store == null) return;
        showAddImagesConfirmation(store, pending);
    }

    private DatabaseHelper.Store findStore(long id) {
        for (DatabaseHelper.Store s : db.listStores()) if (s.id == id) return s;
        return null;
    }

    private void clearPendingImportState() {
        pendingImportStoreId = -1L;
        pendingImportTagId = null;
    }

    private void releaseImportedPermission(Uri uri) {
        try { getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
    }

    private void takePhoto(DatabaseHelper.Store store) {
        try {
            pendingTagId = null;
            pendingStoreId = store.id;
            File base = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (base == null) base = getFilesDir();
            File tempDir = new File(base, "camera_tmp");
            if (!tempDir.exists() && !tempDir.mkdirs()) throw new IllegalStateException("camera temp mkdir failed");
            File temp = new File(tempDir, "PriceRec_capture_" + System.currentTimeMillis() + ".jpg");
            pendingCameraTempPath = temp.getAbsolutePath();
            pendingPhotoUri = FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", temp);

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingPhotoUri);
            intent.setClipData(ClipData.newRawUri("PriceRec camera output", pendingPhotoUri));
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            DiagLog.write(this, "CAMERA_START store=" + pendingStoreId +
                    " uri=" + pendingPhotoUri + " temp=" + pendingCameraTempPath);
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception e) {
            DiagLog.write(this, "CAMERA_START_ERROR " + e);
            cleanupPendingPhoto();
            Toast.makeText(this, "カメラを起動できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAMERA) return;
        if (pendingPhotoUri == null) return;
        Uri capturedUri = pendingPhotoUri;
        String tempPath = pendingCameraTempPath;
        long storeId = pendingStoreId;
        if (resultCode == RESULT_OK) {
            File temp = tempPath == null ? null : new File(tempPath);
            long bytes = temp != null && temp.exists() ? temp.length() : 0L;
            DiagLog.write(this, "CAMERA_RESULT_OK store=" + storeId + " bytes=" + bytes + " temp=" + tempPath);
            if (bytes <= 0L) {
                DiagLog.write(this, "CAMERA_TEMP_FILE_ERROR temp=" + tempPath + " bytes=" + bytes);
                cleanupPendingPhoto();
                Toast.makeText(this, "撮影画像を保存できませんでした", Toast.LENGTH_LONG).show();
                reloadStores();
                return;
            }
            DatabaseHelper.Store store = findStore(storeId);
            clearPendingPhotoState();
            if (store != null) {
                ArrayList<PendingImage> pending = new ArrayList<>();
                pending.add(new PendingImage(capturedUri, true, tempPath));
                showAddImagesConfirmation(store, pending);
                return;
            }
            deleteFileQuietly(tempPath);
        } else {
            DiagLog.write(this, "CAMERA_CANCEL result=" + resultCode + " temp=" + tempPath);
            deleteFileQuietly(tempPath);
        }
        clearPendingPhotoState();
        reloadStores();
    }

    private Uri commitCameraTempToMediaStore(PendingImage item, DatabaseHelper.Store store) {
        if (item == null || item.cameraTempPath == null) return item == null ? null : item.uri;
        File source = new File(item.cameraTempPath);
        if (!source.exists() || source.length() <= 0L) {
            DiagLog.write(this, "CAMERA_COMMIT_FAIL temp=" + item.cameraTempPath + " reason=missing_or_empty");
            return null;
        }
        Uri dest = null;
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "PriceRec_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/PriceRec/" + safeFolder(store.name));
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            dest = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (dest == null) throw new IllegalStateException("MediaStore insert returned null");
            try (FileInputStream in = new FileInputStream(source);
                 OutputStream out = getContentResolver().openOutputStream(dest, "w")) {
                if (out == null) throw new IllegalStateException("MediaStore output stream null");
                byte[] buffer = new byte[128 * 1024];
                int n;
                while ((n = in.read(buffer)) >= 0) {
                    if (n > 0) out.write(buffer, 0, n);
                }
                out.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(dest, done, null, null);
            long bytes = source.length();
            deleteFileQuietly(item.cameraTempPath);
            DiagLog.write(this, "CAMERA_MEDIASTORE_COMMIT uri=" + dest + " bytes=" + bytes);
            return dest;
        } catch (Exception e) {
            if (dest != null) {
                try { getContentResolver().delete(dest, null, null); } catch (Exception ignored) { }
            }
            DiagLog.write(this, "CAMERA_COMMIT_FAIL temp=" + item.cameraTempPath + " err=" + e);
            return null;
        }
    }

    private void cleanupPendingImage(PendingImage item) {
        if (item == null) return;
        if (item.cameraTempPath != null) {
            deleteFileQuietly(item.cameraTempPath);
            return;
        }
        if (item.managed && item.uri != null) {
            try { getContentResolver().delete(item.uri, null, null); } catch (Exception ignored) { }
        }
    }

    private void deleteFileQuietly(String path) {
        if (path == null || path.isEmpty()) return;
        try {
            File file = new File(path);
            if (file.exists() && !file.delete()) file.deleteOnExit();
        } catch (Exception ignored) { }
    }

    private void cleanupPendingPhoto() {
        if (pendingCameraTempPath != null) {
            deleteFileQuietly(pendingCameraTempPath);
        } else if (pendingPhotoUri != null) {
            try { getContentResolver().delete(pendingPhotoUri, null, null); } catch (Exception ignored) { }
        }
        clearPendingPhotoState();
    }

    private void clearPendingPhotoState() {
        pendingPhotoUri = null;
        pendingCameraTempPath = null;
        pendingStoreId = -1L;
        pendingTagId = null;
    }

    private void showOcrSheet(long photoId, String title) {
        DatabaseHelper.Photo photo = db.getPhoto(photoId);
        List<DatabaseHelper.ProductRecord> existing = db.listProductsForPhoto(photoId);
        LinearLayout editors = new LinearLayout(this);
        editors.setOrientation(LinearLayout.VERTICAL);
        ArrayList<OcrEditorRow> rowEditors = new ArrayList<>();
        editors.addView(sheetHeader(new String[]{"商品名", "価格", ""}, new int[]{260, 110, 50}));
        for (DatabaseHelper.ProductRecord p : existing) addOcrEditorRow(editors, rowEditors, p.rawName, p.priceYen);
        if (existing.isEmpty()) addOcrEditorRow(editors, rowEditors, "", null);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.addView(editors);
        ScrollView vsv = new ScrollView(this);
        vsv.addView(hsv);
        content.addView(vsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));
        TextView add = text("＋ 商品", 15, BLUE, true);
        add.setGravity(Gravity.CENTER_VERTICAL);
        add.setPadding(dp(8), dp(10), dp(8), dp(8));
        add.setOnClickListener(v -> addOcrEditorRow(editors, rowEditors, "", null));
        content.addView(add);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            ArrayList<DatabaseHelper.ProductInput> rows = new ArrayList<>();
            for (OcrEditorRow r : rowEditors) {
                if (r.row.getParent() == null) continue;
                String name = r.name.getText().toString().trim();
                if (name.isEmpty()) continue;
                Integer price = parsePriceInput(r.price.getText().toString());
                rows.add(new DatabaseHelper.ProductInput(name, price, null));
            }
            db.replaceProductsForPhoto(photoId, rows, photo == null ? null : photo.ocrRaw);
            DiagLog.write(this, "PRODUCT_EDIT_SAVE photo=" + photoId + " rows=" + rows.size());
            dialog.dismiss();
            reloadStores();
        }));
        showRoundedDialog(dialog, true);
    }

    private void addOcrEditorRow(LinearLayout container, ArrayList<OcrEditorRow> list, String nameValue, Integer priceValue) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(2));
        EditText name = sheetEdit(nameValue, false);
        EditText price = sheetEdit(priceValue == null ? "" : String.valueOf(priceValue), true);
        TextView del = text("×", 22, LRED, true);
        del.setGravity(Gravity.CENTER);
        row.addView(name, new LinearLayout.LayoutParams(dp(260), dp(46)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(110), dp(46)); pp.leftMargin = dp(4);
        row.addView(price, pp);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(dp(50), dp(46)); dpv.leftMargin = dp(4);
        row.addView(del, dpv);
        OcrEditorRow editor = new OcrEditorRow(row, name, price);
        list.add(editor);
        del.setOnClickListener(v -> container.removeView(row));
        container.addView(row);
    }

    private Integer parsePriceInput(String s) {
        String digits = s == null ? "" : s.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return null;
        try { return Integer.parseInt(digits); } catch (NumberFormatException e) { return null; }
    }

    private void runSearch(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) return;
        hideKeyboard(searchInput);
        List<DatabaseHelper.ProductRecord> hits = db.searchProducts(q);
        if (!hits.isEmpty()) rememberSearchCandidate(q);
        DiagLog.write(this, "SEARCH q=" + q + " hits=" + hits.size());
        showProductTableDialog("検索", null, q);
    }

    private void showAppMenu() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setItems(new String[]{"全商品リスト表示", "CSVインポート", "診断ログ"}, (d, which) -> {
                    if (which == 0) showAllList();
                    else if (which == 1) startCsvImportPicker();
                    else showDiagnosticLog();
                }).create();
        showRoundedDialog(dialog);
    }

    private void startCsvImportPicker() {
        try {
            DiagLog.write(this, "CSV_PICKER_START");
            csvPicker.launch(new String[]{"text/csv", "text/comma-separated-values", "application/csv", "application/vnd.ms-excel", "text/plain"});
        } catch (Exception e) {
            DiagLog.write(this, "CSV_PICKER_ERROR " + e);
            Toast.makeText(this, "CSVファイルを選択できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void handleCsvPicked(Uri uri) {
        if (uri == null) {
            DiagLog.write(this, "CSV_PICKER_CANCEL");
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        loadCsvAndPreview(uri, "picker");
    }

    private void handleIncomingCsvIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            Uri uri = intent.getData();
            if (uri == null) return;
            intent.setAction(null);
            DiagLog.write(this, "CSV_VIEW_INTENT uri=" + uri + " type=" + intent.getType());
            storeContainer.post(() -> loadCsvAndPreview(uri, "view_intent"));
            return;
        }
        if (Intent.ACTION_SEND.equals(action)) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri == null && intent.getClipData() != null && intent.getClipData().getItemCount() > 0) {
                uri = intent.getClipData().getItemAt(0).getUri();
            }
            if (uri == null) {
                DiagLog.write(this, "CSV_SHARE_INTENT_REJECT reason=no_uri type=" + intent.getType());
                return;
            }
            intent.setAction(null);
            Uri finalUri = uri;
            DiagLog.write(this, "CSV_SHARE_INTENT uri=" + uri + " type=" + intent.getType());
            storeContainer.post(() -> loadCsvAndPreview(finalUri, "share_intent"));
            return;
        }
        if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (uris == null || uris.size() != 1) {
                DiagLog.write(this, "CSV_SHARE_MULTIPLE_REJECT count=" + (uris == null ? 0 : uris.size()));
                storeContainer.post(() -> Toast.makeText(this, "CSVは1ファイルずつ共有してください", Toast.LENGTH_LONG).show());
                return;
            }
            intent.setAction(null);
            Uri uri = uris.get(0);
            DiagLog.write(this, "CSV_SHARE_INTENT uri=" + uri + " type=" + intent.getType() + " multiple=true");
            storeContainer.post(() -> loadCsvAndPreview(uri, "share_intent"));
        }
    }

    private void loadCsvAndPreview(Uri uri, String source) {
        long started = SystemClock.elapsedRealtime();
        DiagLog.write(this, "CSV_READ_START source=" + source + " uri=" + uri);
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("openInputStream returned null");
            CsvImporter.Result parsed = CsvImporter.parse(in);
            ArrayList<ImportPreviewRow> preview = buildImportPreview(parsed.rows);
            String sourceName = displayNameForUri(uri);
            DiagLog.write(this, "CSV_READ_OK rows=" + preview.size() + " warnings=" + parsed.warnings.size() +
                    " bytes=" + parsed.byteCount + " file=" + sourceName + " ms=" + (SystemClock.elapsedRealtime() - started));
            showCsvImportPreview(uri, sourceName, preview, parsed.warnings, parsed.rawText);
        } catch (Exception e) {
            DiagLog.write(this, "CSV_READ_ERROR uri=" + uri + " ms=" + (SystemClock.elapsedRealtime() - started) + " err=" + e);
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("CSVインポート")
                    .setMessage("CSVを読み込めませんでした。\n\n" + e.getMessage())
                    .setPositiveButton("閉じる", null).create();
            showRoundedDialog(dialog);
        }
    }

    private ArrayList<ImportPreviewRow> buildImportPreview(List<CsvImporter.Row> rows) {
        ArrayList<ImportPreviewRow> out = new ArrayList<>();
        for (CsvImporter.Row row : rows) {
            ImportPreviewRow p = new ImportPreviewRow(row);
            if (row.store.isEmpty() || row.productName.isEmpty()) {
                p.status = "必須項目不足";
                p.action = ImportPreviewRow.SKIP;
            } else {
                DatabaseHelper.Store store = db.findStoreByName(row.store);
                p.resolvedProductKey = store == null
                        ? DatabaseHelper.ensureProductKeyPrefix(row.productKey, row.productName)
                        : db.resolveProductKeyForStore(store.id, row.productKey, row.productName, row.volume);
                DatabaseHelper.ProductRecord existing = store == null ? null : db.findLatestProductInStore(store.id, p.resolvedProductKey);
                p.existingProductId = existing == null ? -1L : existing.id;
                if (existing == null) {
                    p.status = "新規";
                    p.action = ImportPreviewRow.ADD;
                } else if (sameInteger(existing.priceYen, row.priceYen)) {
                    p.action = ImportPreviewRow.SKIP;
                    if (existing.referenceMissing) {
                        p.status = "参照画像更新";
                        p.refreshReference = true;
                    } else {
                        p.status = "重複";
                    }
                } else {
                    p.status = "価格変更";
                    p.action = ImportPreviewRow.UPDATE;
                }
            }
            out.add(p);
        }
        return out;
    }

    private boolean sameInteger(Integer a, Integer b) {
        return a == null ? b == null : a.equals(b);
    }

    private void showCsvImportPreview(Uri uri, String sourceName, ArrayList<ImportPreviewRow> preview, List<String> warnings, String rawCsv) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));

        int addCount = 0, updateCount = 0, skipCount = 0;
        for (ImportPreviewRow p : preview) {
            if (ImportPreviewRow.ADD.equals(p.action)) addCount++;
            else if (ImportPreviewRow.UPDATE.equals(p.action)) updateCount++;
            else skipCount++;
        }
        TextView summary = text("全" + preview.size() + "行  /  追加" + addCount + "  更新" + updateCount + "  スキップ" + skipCount +
                (warnings.isEmpty() ? "" : "  /  注意" + warnings.size()), 13, SECONDARY, false);
        summary.setPadding(dp(6), dp(4), dp(6), dp(8));
        content.addView(summary);

        if (!warnings.isEmpty()) {
            TextView warning = text(warnings.get(0) + (warnings.size() > 1 ? " ほか" + (warnings.size() - 1) + "件" : ""), 12, LRED, false);
            warning.setPadding(dp(6), 0, dp(6), dp(8));
            content.addView(warning);
        }

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        int[] widths = {240, 170, 100, 105, 100};
        sheet.addView(sheetHeader(new String[]{"商品名", "店舗", "価格", "判定", "動作"}, widths));
        for (ImportPreviewRow p : preview) sheet.addView(makeCsvPreviewRow(p, widths));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.addView(sheet);
        ScrollView vsv = new ScrollView(this);
        vsv.addView(hsv);
        content.addView(vsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        TextView hint = text("動作セルをタップすると 追加 → 更新 → スキップ を切り替えられます。", 12, SECONDARY, false);
        hint.setPadding(dp(6), dp(8), dp(6), dp(2));
        content.addView(hint);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("CSVインポート確認")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("インポート", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            importCsvRows(uri, sourceName, preview, rawCsv, true);
            dialog.dismiss();
        }));
        showRoundedDialog(dialog, true);
    }

    private View makeCsvPreviewRow(ImportPreviewRow p, int[] widths) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(1), 0, dp(1));
        String price = p.row.priceYen == null ? (p.row.priceRaw.isEmpty() ? "—" : p.row.priceRaw) : yen(p.row.priceYen);
        TextView product = csvCell(p.row.productName, widths[0], WHITE, false);
        TextView store = csvCell(p.row.store, widths[1], WHITE, false);
        TextView priceCell = csvCell(price, widths[2], WHITE, false);
        TextView status = csvCell(p.status, widths[3], "必須項目不足".equals(p.status) ? LRED : SECONDARY, false);
        TextView action = csvCell(p.action, widths[4], actionColor(p.action), true);
        action.setGravity(Gravity.CENTER);
        action.setBackground(roundRect(DGRAY, 8));
        action.setOnClickListener(v -> {
            p.action = nextImportAction(p.action);
            action.setText(p.action);
            action.setTextColor(actionColor(p.action));
        });
        row.addView(product); row.addView(store); row.addView(priceCell); row.addView(status); row.addView(action);
        return row;
    }

    private TextView csvCell(String value, int widthDp, int color, boolean bold) {
        TextView cell = text(value == null ? "" : value, 13, color, bold);
        cell.setGravity(Gravity.CENTER_VERTICAL);
        cell.setSingleLine(true);
        cell.setPadding(dp(8), 0, dp(8), 0);
        cell.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), dp(44)));
        return cell;
    }

    private int actionColor(String action) {
        if (ImportPreviewRow.ADD.equals(action)) return LBLUE;
        if (ImportPreviewRow.UPDATE.equals(action)) return ORANGE;
        return SECONDARY;
    }

    private String nextImportAction(String current) {
        if (ImportPreviewRow.ADD.equals(current)) return ImportPreviewRow.UPDATE;
        if (ImportPreviewRow.UPDATE.equals(current)) return ImportPreviewRow.SKIP;
        return ImportPreviewRow.ADD;
    }

    private int scoreCsvQuality(List<ImportPreviewRow> preview) {
        if (preview == null || preview.isEmpty()) return 0;
        int total = 0;
        Set<String> sourceImages = new HashSet<>();
        for (ImportPreviewRow p : preview) {
            CsvImporter.Row row = p.row;
            int score = 20; // store + product_name are validated before import
            if (row.priceYen != null) score += 25;
            if (row.productKey != null && !row.productKey.trim().isEmpty()) score += 5;
            if (row.sourceImage != null && !row.sourceImage.trim().isEmpty()) {
                score += 20;
                sourceImages.add(row.sourceImage.trim());
            }
            if (row.capturedAtRaw != null && !row.capturedAtRaw.trim().isEmpty()) score += 10;
            String priceType = row.priceType == null ? "" : row.priceType.trim();
            if (priceTaxMarker(priceType).length() > 0) score += 8;
            if (row.volume != null && !row.volume.trim().isEmpty()) score += 7;
            if (row.tag != null && !row.tag.trim().isEmpty()) score += 5;
            total += Math.min(100, score);
        }
        int average = total / Math.max(1, preview.size());
        if (!sourceImages.isEmpty()) {
            float rowsPerImage = (float) preview.size() / (float) sourceImages.size();
            if (rowsPerImage >= 10f) average += 10;
            else if (rowsPerImage >= 6f) average += 4;
            else if (rowsPerImage >= 3f) average -= 6;
            else average -= 16;
        } else {
            average -= 12;
        }
        return Math.max(0, Math.min(100, average));
    }

    private void importCsvRows(Uri uri, String sourceName, List<ImportPreviewRow> preview, String rawCsv, boolean showResultDialog) {
        long started = SystemClock.elapsedRealtime();
        int added = 0, updated = 0, refreshed = 0, skipped = 0, failed = 0;
        HashMap<String, Long> virtualPhotos = new HashMap<>();
        int qualityScore = scoreCsvQuality(preview);
        long batchId = db.createImportBatch(sourceName, uri == null ? null : uri.toString(), rawCsv, qualityScore, preview.size());
        DiagLog.write(this, "CSV_IMPORT_START uri=" + uri + " file=" + sourceName + " batch=" + batchId +
                " rows=" + preview.size() + " quality=" + qualityScore);
        for (ImportPreviewRow p : preview) {
            CsvImporter.Row row = p.row;
            if (row.store.isEmpty() || row.productName.isEmpty()) {
                skipped++;
                continue;
            }
            if (ImportPreviewRow.SKIP.equals(p.action)) {
                if (p.refreshReference && p.existingProductId > 0) {
                    try {
                        DatabaseHelper.Store store = db.findStoreByName(row.store);
                        long storeId = store == null ? -1L : store.id;
                        long newPhotoId = storeId < 0 ? -1L : resolveSourcePhotoId(row.sourceImage, storeId);
                        DatabaseHelper.Photo newPhoto = newPhotoId > 0 ? db.getPhoto(newPhotoId) : null;
                        if (newPhoto != null && !db.isVirtualImportPhoto(newPhoto)) {
                            db.restoreProductReference(p.existingProductId, newPhotoId, row.sourceImage);
                            refreshed++;
                            DiagLog.write(this, "PRODUCT_REFERENCE_RESTORED product=" + p.existingProductId +
                                    " photo=" + newPhotoId + " line=" + row.lineNumber);
                            continue;
                        }
                    } catch (Exception e) {
                        DiagLog.write(this, "PRODUCT_REFERENCE_RESTORE_ERROR product=" + p.existingProductId +
                                " line=" + row.lineNumber + " err=" + e);
                    }
                }
                skipped++;
                continue;
            }
            try {
                long storeId = db.ensureStore(row.store);
                if (storeId < 0) throw new IllegalStateException("店舗を作成できません: " + row.store);
                if (!db.isStoreEnabled(storeId)) {
                    throw new IllegalStateException("NトグルOFFのカードにはCSVを取り込めません: " + row.store);
                }
                Long tagId = db.ensureTag(row.tag);
                long photoId = resolveImportPhoto(row, storeId, tagId, virtualPhotos);
                String resolvedProductKey = db.resolveProductKeyForStore(storeId, row.productKey, row.productName, row.volume);
                if (!resolvedProductKey.equals(DatabaseHelper.ensureProductKeyPrefix(row.productKey, row.productName))) {
                    DiagLog.write(this, "PRODUCT_KEY_COLLISION line=" + row.lineNumber + " base=" + row.productKey + " resolved=" + resolvedProductKey);
                }
                if (ImportPreviewRow.UPDATE.equals(p.action)) {
                    DatabaseHelper.ProductRecord existing = db.findLatestProductInStore(storeId, resolvedProductKey);
                    if (existing != null) {
                        db.recordImportUpdated(batchId, existing);
                        db.updateImportedProduct(existing.id, photoId, storeId, tagId, row.productName, resolvedProductKey, row.priceYen,
                                row.volume, row.priceType, row.sourceImage);
                        db.updateImportSnapshot(batchId, existing.id);
                        updated++;
                    } else {
                        long productId = db.insertImportedProduct(photoId, storeId, tagId, row.productName, resolvedProductKey, row.priceYen,
                                row.volume, row.priceType, row.sourceImage);
                        if (productId < 0) throw new IllegalStateException("商品を追加できません");
                        db.recordImportAdded(batchId, productId, storeId, row.store);
                        added++;
                    }
                } else {
                    long productId = db.insertImportedProduct(photoId, storeId, tagId, row.productName, resolvedProductKey, row.priceYen,
                            row.volume, row.priceType, row.sourceImage);
                    if (productId < 0) throw new IllegalStateException("商品を追加できません");
                    db.recordImportAdded(batchId, productId, storeId, row.store);
                    added++;
                }
            } catch (Exception e) {
                failed++;
                DiagLog.write(this, "CSV_IMPORT_ROW_ERROR line=" + row.lineNumber + " action=" + p.action + " batch=" + batchId + " err=" + e);
            }
        }
        db.deleteImportBatchIfEmpty(batchId);
        DiagLog.write(this, "CSV_IMPORT_OK batch=" + batchId + " added=" + added + " updated=" + updated + " reference_refreshed=" + refreshed + " skipped=" + skipped +
                " failed=" + failed + " ms=" + (SystemClock.elapsedRealtime() - started));
        reloadStores();
        if (showResultDialog) {
            AlertDialog result = new AlertDialog.Builder(this)
                    .setTitle("CSVインポート完了")
                    .setMessage("追加: " + added + "\n更新: " + updated +
                            (refreshed == 0 ? "" : "\n参照画像更新: " + refreshed) + "\nスキップ: " + skipped +
                            (failed == 0 ? "" : "\n失敗: " + failed) +
                            ((added + updated) > 0 ? "\n\nこの取込は「全CSV一覧」または店舗の「CSV一覧」から後で取り消せます。" : ""))
                    .setPositiveButton("閉じる", null).create();
            showRoundedDialog(result);
        }
    }

    private String displayNameForUri(Uri uri) {
        if (uri == null) return "CSV";
        try (android.database.Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) {
                String name = c.getString(0);
                if (name != null && !name.trim().isEmpty()) return name.trim();
            }
        } catch (Exception ignored) { }
        String last = uri.getLastPathSegment();
        return last == null || last.trim().isEmpty() ? "CSV" : last;
    }

    private long resolveImportPhoto(CsvImporter.Row row, long storeId, Long tagId, Map<String, Long> virtualPhotos) {
        long mapped = resolveSourcePhotoId(row.sourceImage, storeId);
        if (mapped > 0) return mapped;
        String key = storeId + "|" + (tagId == null ? "null" : tagId) + "|" + row.sourceImage + "|" + row.capturedAt;
        Long existing = virtualPhotos.get(key);
        if (existing != null) return existing;
        long id = db.createVirtualImportPhoto(storeId, tagId, row.capturedAt, row.sourceImage);
        if (id < 0) throw new IllegalStateException("CSV用データ行を作成できません");
        virtualPhotos.put(key, id);
        return id;
    }

    private long resolveSourcePhotoId(String sourceImage, long storeId) {
        if (sourceImage == null) return -1L;
        String source = sourceImage.trim().toLowerCase(Locale.ROOT);
        long photoId = -1L;
        try {
            if (source.matches("photo_[0-9]+")) {
                photoId = Long.parseLong(source.substring("photo_".length()));
            } else if (source.matches("image_[0-9]+")) {
                int index = Integer.parseInt(source.substring("image_".length()));
                photoId = getPreferences(MODE_PRIVATE).getLong("last_share_image_" + index, -1L);
            }
        } catch (Exception ignored) { }
        if (photoId <= 0) return -1L;
        DatabaseHelper.Photo photo = db.getPhoto(photoId);
        if (photo == null || photo.storeId != storeId) return -1L;
        return photoId;
    }

    private void showAllList() {
        showProductTableDialog("全商品リスト", null, "");
    }

    private void showProductTableDialog(String title, Long fixedStoreId, String initialQuery) {
        showProductTableDialog(title, fixedStoreId, null, initialQuery);
    }

    private void showProductTableDialog(String title, Long fixedStoreId, Long fixedPhotoId, String initialQuery) {
        final Set<Long> selected = new HashSet<>();
        final boolean[] selecting = {false};
        // Empty store filter means the default "全カード" state.
        final Set<Long> storeFilters = new HashSet<>();
        // Empty tag filter means all tags. -1 represents "タグなし" and can coexist with tag ids.
        final Set<Long> tagFilters = new HashSet<>();
        final String[] query = {initialQuery == null ? "" : initialQuery.trim()};
        final String selectionScope = fixedPhotoId == null ? "list" : ("photo:" + fixedPhotoId);
        final boolean readOnly = fixedStoreId != null && !db.isStoreEnabled(fixedStoreId);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(6), dp(10), dp(6));

        if (fixedPhotoId == null) {
            LinearLayout topActions = new LinearLayout(this);
            topActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            TextView history = makeDialogAction(fixedStoreId == null ? "全CSV一覧" : "CSV一覧");
            history.setOnClickListener(v -> {
                DiagLog.write(this, "CSV_HISTORY_OPEN_FROM_LIST scope=" + (fixedStoreId == null ? "all" : ("store:" + fixedStoreId)));
                showImportHistoryDialog(fixedStoreId);
            });
            topActions.addView(history, new LinearLayout.LayoutParams(dp(fixedStoreId == null ? 112 : 96), dp(42)));
            panel.addView(topActions);
        }

        Runnable filterChanged = () -> {
            selected.clear();
            selecting[0] = false;
            Object tag = panel.getTag();
            if (tag instanceof Runnable) ((Runnable) tag).run();
        };

        // 全商品リストだけ店舗選択を表示。カード内商品リストは店舗が固定なので店舗選択欄を持たない。
        if (fixedStoreId == null) {
            View storeFilterArea = makeStoreFilterArea(storeFilters, filterChanged);
            LinearLayout.LayoutParams storeFilterLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
            storeFilterLp.bottomMargin = dp(4);
            panel.addView(storeFilterArea, storeFilterLp);
        }

        // 店舗カードと同じチップ式タグUI。リスト側には＋アイコンを付けない。
        View tagFilterArea = makeProductTagFilterArea(tagFilters, filterChanged);
        LinearLayout.LayoutParams tagFilterLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        tagFilterLp.bottomMargin = dp(6);
        panel.addView(tagFilterArea, tagFilterLp);

        EditText q = dialogInput("商品名検索");
        q.setText(query[0]);
        q.setTextSize(15);
        panel.addView(productSearchInputHolder(q), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        // Keep this slot at a fixed height so entering/exiting selection never shifts the list.
        LinearLayout selectionHost = new LinearLayout(this);
        selectionHost.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams selectionHostLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        selectionHostLp.topMargin = dp(4);
        panel.addView(selectionHost, selectionHostLp);

        LinearLayout listHost = new LinearLayout(this);
        listHost.setOrientation(LinearLayout.VERTICAL);
        int listHeight = fixedStoreId == null ? 420 : 452;
        LinearLayout.LayoutParams hostLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(listHeight));
        panel.addView(listHost, hostLp);

        // Bottom-most dialog line: selection count stays on the same line as "閉じる".
        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setPadding(dp(4), dp(4), dp(4), 0);
        TextView footerSelectionCount = text("", 14, SECONDARY, true);
        footerSelectionCount.setGravity(Gravity.CENTER);
        // Mirror the 92dp "閉じる" text-link slot from the left edge.
        footer.addView(footerSelectionCount, new LinearLayout.LayoutParams(dp(92), dp(48)));
        footer.addView(new View(this), new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView closeAction = makeDialogAction("閉じる");
        footer.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        panel.addView(footer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        final ScrollView[] verticalScroll = {null};
        final HorizontalScrollView[] horizontalScroll = {null};
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            final int keepY = verticalScroll[0] == null ? 0 : verticalScroll[0].getScrollY();
            final int keepX = horizontalScroll[0] == null ? 0 : horizontalScroll[0].getScrollX();

            selectionHost.removeAllViews();
            selectionHost.setPadding(dp(4), 0, dp(4), dp(4));
            footerSelectionCount.setText(selecting[0] ? (selected.size() + "件選択") : "");
            footerSelectionCount.setVisibility(selecting[0] ? View.VISIBLE : View.INVISIBLE);
            if (readOnly) {
                selectionHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                TextView mode = text("閲覧モード", 13, SECONDARY, true);
                mode.setGravity(Gravity.CENTER);
                mode.setBackground(roundRect(DGRAY, 999));
                selectionHost.addView(mode, new LinearLayout.LayoutParams(dp(96), dp(38)));
            } else if (!selecting[0]) {
                selectionHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                TextView select = button("選択", DGRAY, 13);
                select.setOnClickListener(v -> {
                    selecting[0] = true;
                    selected.clear();
                    DiagLog.write(this, "PRODUCT_SELECT_START scope=" + selectionScope + " source=button_bar");
                    render[0].run();
                });
                selectionHost.addView(select, new LinearLayout.LayoutParams(dp(96), dp(38)));
            } else {
                selectionHost.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);

                TextView delete = button("削除", selected.isEmpty() ? DGRAY : RED, 13);
                delete.setAlpha(selected.isEmpty() ? 0.45f : 1f);
                delete.setOnClickListener(v -> {
                    if (!selected.isEmpty()) {
                        confirmDeleteProducts(new ArrayList<>(selected), () -> {
                            selected.clear();
                            selecting[0] = false;
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(72), dp(38));
                delLp.rightMargin = dp(6);
                selectionHost.addView(delete, delLp);

                TextView same = button("同一商品", selected.size() < 2 ? DGRAY : ORANGE, 13);
                same.setAlpha(selected.size() < 2 ? 0.45f : 1f);
                same.setOnClickListener(v -> {
                    if (selected.size() >= 2) {
                        showUnifyProductsDialog(new ArrayList<>(selected), () -> {
                            selected.clear();
                            selecting[0] = false;
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                LinearLayout.LayoutParams sameLp = new LinearLayout.LayoutParams(dp(92), dp(38));
                sameLp.leftMargin = dp(6);
                selectionHost.addView(same, sameLp);

                TextView cancel = button("キャンセル", DGRAY, 13);
                cancel.setOnClickListener(v -> {
                    selected.clear();
                    selecting[0] = false;
                    render[0].run();
                });
                LinearLayout.LayoutParams canLp = new LinearLayout.LayoutParams(dp(88), dp(38));
                canLp.leftMargin = dp(6);
                selectionHost.addView(cancel, canLp);

                TextView move = button("タグ編集", selected.isEmpty() ? DGRAY : BLUE, 13);
                move.setAlpha(selected.isEmpty() ? 0.45f : 1f);
                move.setOnClickListener(v -> {
                    if (!selected.isEmpty()) {
                        showMoveProductsTagDialog(new ArrayList<>(selected), () -> {
                            selected.clear();
                            selecting[0] = false;
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                LinearLayout.LayoutParams moveLp = new LinearLayout.LayoutParams(dp(92), dp(38));
                moveLp.leftMargin = dp(6);
                selectionHost.addView(move, moveLp);
            }

            listHost.removeAllViews();
            ArrayList<DatabaseHelper.ProductRecord> products = new ArrayList<>();
            String normalizedQuery = query[0] == null ? "" : query[0].trim().toLowerCase(Locale.ROOT);
            List<DatabaseHelper.ProductRecord> baseProducts = fixedStoreId == null
                    ? db.listAllProducts() : db.listProductsForStore(fixedStoreId);
            for (DatabaseHelper.ProductRecord p : baseProducts) {
                if (fixedPhotoId != null && p.photoId != fixedPhotoId) continue;
                if (fixedStoreId == null && !storeFilters.isEmpty() && !storeFilters.contains(p.storeId)) continue;

                if (!tagFilters.isEmpty()) {
                    boolean tagMatch = false;
                    if (tagFilters.contains(-1L) && p.tagIds.isEmpty() && p.tagId == null) tagMatch = true;
                    if (!tagMatch) {
                        for (Long tagId : tagFilters) {
                            if (tagId != null && tagId >= 0 && p.hasTag(tagId)) {
                                tagMatch = true;
                                break;
                            }
                        }
                    }
                    if (!tagMatch) continue;
                }

                if (!normalizedQuery.isEmpty()) {
                    String hay = ((p.rawName == null ? "" : p.rawName) + " " +
                            (p.productKey == null ? "" : p.productKey) + " " +
                            (p.storeName == null ? "" : p.storeName) + " " +
                            p.tagDisplay()).toLowerCase(Locale.ROOT);
                    if (!hay.contains(normalizedQuery)) continue;
                }
                products.add(p);
            }

            if (products.isEmpty()) {
                TextView empty = text(fixedPhotoId == null ? "条件に一致する商品がありません。" : "この画像から登録された商品はありません。",
                        14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(dp(16), dp(28), dp(16), dp(28));
                listHost.addView(empty, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                verticalScroll[0] = null;
                horizontalScroll[0] = null;
                return;
            }

            LinearLayout sheet = new LinearLayout(this);
            sheet.setOrientation(LinearLayout.VERTICAL);
            boolean storeWholeList = fixedStoreId != null;
            ArrayList<String> columnOrder = loadProductColumnOrder(storeWholeList);
            sheet.addView(makeReorderableProductHeader(columnOrder, storeWholeList, render[0]));
            String last = null;
            for (DatabaseHelper.ProductRecord p : products) {
                String key = p.normalizedName == null ? p.rawName : p.normalizedName;
                String productCell = key != null && key.equals(last) ? "" : p.rawName;
                last = key;
                LinearLayout row = makeProductDataRow(columnOrder, p, productCell);
                View compareIcon = row.findViewWithTag("product_compare_icon");
                if (compareIcon != null) {
                    compareIcon.setOnClickListener(v -> {
                        if (selecting[0]) {
                            boolean wasSelected = selected.remove(p.id);
                            if (!wasSelected) selected.add(p.id);
                            DiagLog.write(this, "PRODUCT_SELECT_TOGGLE scope=" + selectionScope + " product=" + p.id +
                                    " selected=" + selected.contains(p.id) + " count=" + selected.size());
                            if (wasSelected && selected.isEmpty()) {
                                selecting[0] = false;
                                DiagLog.write(this, "PRODUCT_SELECT_END_EMPTY scope=" + selectionScope + " source=compare");
                            }
                            render[0].run();
                        } else {
                            showSameProductPrices(p.productKey == null ? p.rawName : p.productKey);
                        }
                    });
                }
                if (selecting[0] && selected.contains(p.id)) row.setBackgroundColor(BLUE);
                row.setOnClickListener(v -> {
                    if (selecting[0]) {
                        boolean wasSelected = selected.remove(p.id);
                        if (!wasSelected) selected.add(p.id);
                        DiagLog.write(this, "PRODUCT_SELECT_TOGGLE scope=" + selectionScope + " product=" + p.id +
                                " selected=" + selected.contains(p.id) + " count=" + selected.size());
                        if (wasSelected && selected.isEmpty()) {
                            selecting[0] = false;
                            DiagLog.write(this, "PRODUCT_SELECT_END_EMPTY scope=" + selectionScope + " source=row");
                        }
                        render[0].run();
                    } else if (!readOnly) {
                        DatabaseHelper.ProductRecord fresh = db.getProduct(p.id);
                        showProductEditor(fresh == null ? p : fresh, () -> {
                            render[0].run();
                            reloadStores();
                        });
                    }
                });
                row.setOnLongClickListener(v -> {
                    if (readOnly) return true;
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    if (!selecting[0]) {
                        selecting[0] = true;
                        selected.clear();
                        selected.add(p.id);
                        DiagLog.write(this, "PRODUCT_SELECT_START scope=" + selectionScope + " product=" + p.id + " source=long_press");
                    } else {
                        boolean wasSelected = selected.remove(p.id);
                        if (!wasSelected) selected.add(p.id);
                        if (wasSelected && selected.isEmpty()) {
                            selecting[0] = false;
                            DiagLog.write(this, "PRODUCT_SELECT_END_EMPTY scope=" + selectionScope + " source=long_press");
                        }
                    }
                    render[0].run();
                    return true;
                });
                sheet.addView(row);
            }

            HorizontalScrollView hsv = new HorizontalScrollView(this);
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.addView(sheet);
            ScrollView vsv = new ScrollView(this);
            vsv.addView(hsv);
            horizontalScroll[0] = hsv;
            verticalScroll[0] = vsv;
            listHost.addView(withFastScroll(vsv), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            vsv.post(() -> {
                vsv.scrollTo(0, keepY);
                hsv.scrollTo(keepX, 0);
            });
        };

        panel.setTag(render[0]);

        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                query[0] = s == null ? "" : s.toString();
                selected.clear();
                selecting[0] = false;
                render[0].run();
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        render[0].run();
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(panel)
                .create();
        closeAction.setOnClickListener(v -> dialog.dismiss());
        showRoundedDialog(dialog, true);
    }

    private String storeNameForId(long storeId) {
        DatabaseHelper.Store s = db.getStore(storeId);
        return s == null ? "不明" : s.name;
    }

    private void showImportHistoryDialog(Long storeId) {
        DiagLog.write(this, "CSV_HISTORY_OPEN scope=" + (storeId == null ? "all" : ("store:" + storeId)));
        final boolean storeReadOnly = storeId != null && !db.isStoreEnabled(storeId);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(8), dp(14), dp(8));

        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(rows);
        content.addView(withFastScroll(scroll), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(470)));

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            rows.removeAllViews();
            List<DatabaseHelper.ImportBatch> batches = db.listImportBatches(storeId);
            if (batches.isEmpty()) {
                TextView empty = text("CSV取込はまだありません。", 14, SECONDARY, false);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(dp(12), dp(30), dp(12), dp(30));
                rows.addView(empty);
                return;
            }
            for (DatabaseHelper.ImportBatch batch : batches) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(14), dp(10), dp(10), dp(8));
                card.setBackground(roundRect(DGRAY, 14));

                TextView date = text(dateFormat.format(new Date(batch.importedAt)), 14, WHITE, true);
                card.addView(date, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26)));

                TextView file = text(batch.fileName, 13, SECONDARY, false);
                file.setSingleLine(true);
                card.addView(file, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

                String stores = batch.storeNames == null || batch.storeNames.trim().isEmpty() ? "" : "  /  " + batch.storeNames;
                TextView meta = text(batch.qualityLabel() + "  " + batch.displayCount() + "件（追加" + batch.addCount + " / 更新" + batch.updateCount + "）" + stores,
                        12, SECONDARY, false);
                card.addView(meta, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

                card.setOnClickListener(v -> showImportBatchContents(batch));

                boolean batchReadOnly = storeReadOnly || db.importBatchHasDisabledStore(batch.id);
                LinearLayout batchActions = new LinearLayout(this);
                batchActions.setGravity(Gravity.CENTER_VERTICAL);
                if (batchReadOnly) {
                    TextView mode = text("閲覧モード", 13, SECONDARY, true);
                    mode.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                    batchActions.addView(mode, new LinearLayout.LayoutParams(0, dp(42), 1f));
                } else {
                    TextView reload = makeDialogAction("再読み込み");
                    reload.setTextColor(LBLUE);
                    reload.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                    reload.setOnClickListener(v -> confirmReloadImportBatch(batch, () -> {
                        reloadStores();
                        render[0].run();
                    }));
                    batchActions.addView(reload, new LinearLayout.LayoutParams(0, dp(42), 1f));

                    TextView undo = makeDialogAction("このCSVを消去");
                    undo.setTextColor(LBLUE);
                    undo.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
                    undo.setOnClickListener(v -> {
                        AlertDialog confirm = new AlertDialog.Builder(this)
                                .setTitle("CSV消去")
                                .setMessage(dateFormat.format(new Date(batch.importedAt)) + "\n" + batch.fileName +
                                        "\n\nこのCSVで追加した商品は削除し、更新した商品は取込前の状態へ戻します。" +
                                        "\n店舗・タグ・元画像は削除しません。")
                                .setNegativeButton("キャンセル", null)
                                .setPositiveButton("消去", (d, which) -> {
                                    DatabaseHelper.RollbackResult result = db.rollbackImportBatch(batch.id);
                                    DiagLog.write(this, "CSV_BATCH_ROLLBACK batch=" + batch.id +
                                            " deleted=" + result.deleted + " restored=" + result.restored + " missing=" + result.missing);
                                    Toast.makeText(this, "削除 " + result.deleted + " / 復元 " + result.restored +
                                            (result.missing == 0 ? "" : " / 対象なし " + result.missing), Toast.LENGTH_LONG).show();
                                    reloadStores();
                                    render[0].run();
                                })
                                .create();
                        showRoundedDialog(confirm);
                    });
                    batchActions.addView(undo, new LinearLayout.LayoutParams(dp(132), dp(42)));
                }
                card.addView(batchActions, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.bottomMargin = dp(8);
                rows.addView(card, lp);
            }
        };

        render[0].run();
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(storeId == null ? "全CSV一覧" : storeNameForId(storeId) + " CSV一覧")
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        showRoundedDialog(dialog, true);
    }

    private void confirmReloadImportBatch(DatabaseHelper.ImportBatch batch, Runnable afterReload) {
        if (batch == null) return;
        AlertDialog confirm = new AlertDialog.Builder(this)
                .setTitle("CSV再読み込み")
                .setMessage("編集したデータは削除されます。\n\n" + batch.fileName + " を元のCSV内容で再読み込みしますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("再読み込み", (d, which) -> reloadImportBatch(batch, afterReload))
                .create();
        showRoundedDialog(confirm);
    }

    private void reloadImportBatch(DatabaseHelper.ImportBatch batch, Runnable afterReload) {
        long started = SystemClock.elapsedRealtime();
        DiagLog.write(this, "CSV_BATCH_RELOAD_START batch=" + batch.id + " file=" + batch.fileName);
        try {
            CsvImporter.Result parsed;
            Uri sourceUri = null;
            if (batch.rawCsv != null && !batch.rawCsv.isEmpty()) {
                parsed = CsvImporter.parseText(batch.rawCsv);
                if (batch.sourceUri != null && !batch.sourceUri.isEmpty()) sourceUri = Uri.parse(batch.sourceUri);
            } else if (batch.sourceUri != null && !batch.sourceUri.isEmpty()) {
                sourceUri = Uri.parse(batch.sourceUri);
                try (InputStream in = getContentResolver().openInputStream(sourceUri)) {
                    if (in == null) throw new IllegalStateException("元CSVを開けません");
                    parsed = CsvImporter.parse(in);
                }
            } else {
                throw new IllegalStateException("元CSVを保持していないため再読み込みできません");
            }

            DatabaseHelper.RollbackResult rollback = db.rollbackImportBatch(batch.id);
            DiagLog.write(this, "CSV_BATCH_RELOAD_ROLLBACK batch=" + batch.id +
                    " deleted=" + rollback.deleted + " restored=" + rollback.restored + " missing=" + rollback.missing);
            ArrayList<ImportPreviewRow> preview = buildImportPreview(parsed.rows);
            importCsvRows(sourceUri, batch.fileName, preview, parsed.rawText, false);
            DiagLog.write(this, "CSV_BATCH_RELOAD_OK oldBatch=" + batch.id +
                    " rows=" + preview.size() + " ms=" + (SystemClock.elapsedRealtime() - started));
            Toast.makeText(this, "CSVを再読み込みしました", Toast.LENGTH_LONG).show();
            if (afterReload != null) afterReload.run();
        } catch (Exception e) {
            DiagLog.write(this, "CSV_BATCH_RELOAD_ERROR batch=" + batch.id + " err=" + e);
            AlertDialog error = new AlertDialog.Builder(this)
                    .setTitle("CSV再読み込み")
                    .setMessage("再読み込みできませんでした。\n\n" + e.getMessage())
                    .setPositiveButton("閉じる", null)
                    .create();
            showRoundedDialog(error);
        }
    }

    private void showImportBatchContents(DatabaseHelper.ImportBatch batch) {
        if (batch == null) return;
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(4), dp(10), dp(8));

        TextView meta = text(dateFormat.format(new Date(batch.importedAt)) + "  /  " + batch.qualityLabel() + "  " + batch.displayCount() + "件\n" + batch.fileName,
                12, SECONDARY, false);
        meta.setPadding(dp(4), dp(2), dp(4), dp(8));
        content.addView(meta);

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        int[] widths = {90, 240, 170, 100, 90, 110, 150};
        sheet.addView(sheetHeader(new String[]{"動作", "商品名", "店舗", "価格", "容量", "タグ", "source_image"}, widths));
        List<DatabaseHelper.ImportBatchRow> rows = db.listImportBatchRows(batch.id);
        for (DatabaseHelper.ImportBatchRow row : rows) {
            sheet.addView(sheetRow(new String[]{row.actionLabel(), row.productName, row.storeName,
                    row.priceYen == null ? "—" : yen(row.priceYen), formatVolumeDisplay(row.volume),
                    row.tagName == null ? "—" : row.tagName, row.sourceImage == null ? "—" : row.sourceImage}, widths));
        }
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(sheet);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(hsv);
        content.addView(withFastScroll(scroll), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(500)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("CSV内容")
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        showRoundedDialog(dialog, true);
    }

    private void showProductEditor(DatabaseHelper.ProductRecord product, Runnable afterSave) {
        if (product == null) return;
        if (!db.isStoreEnabled(product.storeId)) {
            Toast.makeText(this, "NトグルOFF中は編集できません", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(0, dp(8), 0, dp(10));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), 0, dp(20), 0);
        panel.addView(form, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final long[] selectedStore = {product.storeId};
        TextView storeButton = button("店舗: " + product.storeName, DGRAY, 14);
        storeButton.setOnClickListener(v -> showStoreChoiceForEditor(selectedStore, storeButton));
        LinearLayout.LayoutParams storeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        storeLp.bottomMargin = dp(8);
        form.addView(storeButton, storeLp);

        EditText name = dialogInput("商品名");
        name.setText(product.rawName == null ? "" : product.rawName);
        addProductEditField(form, "商品名", name);

        EditText price = dialogInput("価格");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        price.setText(product.priceYen == null ? "" : String.valueOf(product.priceYen));
        addProductEditField(form, "価格（円）", price);

        EditText volume = dialogInput("数字のみ");
        volume.setInputType(InputType.TYPE_CLASS_NUMBER);
        volume.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789"));
        volume.setText(normalizeVolumeForStorage(product.volume));
        addProductEditField(form, "容量（ml）", volume);

        EditText productKey = dialogInput("product_key");
        productKey.setText(product.productKey == null ? product.rawName : product.productKey);
        addProductEditField(form, "product_key", productKey);

        final String[] selectedPriceType = {normalizePriceTypeForEditor(product.priceType)};
        TextView priceType = button(selectedPriceType[0], DGRAY, 14);
        priceType.setOnClickListener(v -> showPriceTypeChoice(selectedPriceType, priceType));
        addProductEditControl(form, "価格種別", priceType);

        final Set<Long> selectedTags = new HashSet<>(product.tagIds);
        View tagArea = makeCommonTagSelectionArea(selectedTags, true, true, chosen -> { });
        addProductEditControl(form, "タグ", tagArea);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, 0, 0, 0);

        TextView deleteButton = button("削除", RED, 13);
        TextView referenceButton = button("参照画像", ORANGE, 13);
        TextView cancelButton = button("キャンセル", DGRAY, 13);
        TextView saveButton = button("保存", BLUE, 13);

        LinearLayout.LayoutParams actionLp1 = new LinearLayout.LayoutParams(dp(92), dp(38));
        actions.addView(deleteButton, actionLp1);
        LinearLayout.LayoutParams actionLp2 = new LinearLayout.LayoutParams(dp(92), dp(38));
        actionLp2.leftMargin = dp(2);
        actions.addView(referenceButton, actionLp2);
        LinearLayout.LayoutParams actionLp3 = new LinearLayout.LayoutParams(dp(92), dp(38));
        actionLp3.leftMargin = dp(2);
        actions.addView(cancelButton, actionLp3);
        LinearLayout.LayoutParams actionLp4 = new LinearLayout.LayoutParams(dp(92), dp(38));
        actionLp4.leftMargin = dp(2);
        actions.addView(saveButton, actionLp4);

        LinearLayout.LayoutParams actionRowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        actionRowLp.topMargin = dp(10);
        panel.addView(actions, actionRowLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("商品編集")
                .setView(panel)
                .create();

        deleteButton.setOnClickListener(v -> {
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("商品削除")
                    .setMessage("「" + product.rawName + "」を削除しますか？\n元画像は削除されません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (dd, which) -> {
                        db.deleteProduct(product.id);
                        DiagLog.write(this, "PRODUCT_DELETE id=" + product.id + " source=editor");
                        dialog.dismiss();
                        if (afterSave != null) afterSave.run();
                    })
                    .create();
            showRoundedDialog(confirm);
        });

        referenceButton.setOnClickListener(v -> showProductReferenceImage(product));
        cancelButton.setOnClickListener(v -> dialog.dismiss());

        saveButton.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { name.setError("商品名を入力"); return; }
            Integer priceValue = null;
            String priceText = price.getText().toString().trim();
            if (!priceText.isEmpty()) {
                try { priceValue = Integer.parseInt(priceText); }
                catch (NumberFormatException ex) { price.setError("整数で入力"); return; }
            }
            if (db.getStore(selectedStore[0]) == null) {
                Toast.makeText(this, "店舗を選択してください", Toast.LENGTH_SHORT).show();
                return;
            }
            db.updateProductDetails(product.id, n, productKey.getText().toString(), priceValue,
                    normalizeVolumeForStorage(volume.getText().toString()), selectedPriceType[0], new ArrayList<>(selectedTags), selectedStore[0]);
            DiagLog.write(this, "PRODUCT_EDIT id=" + product.id + " store=" + selectedStore[0] +
                    " tags=" + selectedTags);
            dialog.dismiss();
            if (afterSave != null) afterSave.run();
        });

        showRoundedDialog(dialog, true);
    }

    private void showProductReferenceImage(DatabaseHelper.ProductRecord product) {
        if (product == null) return;
        DatabaseHelper.Photo photo = db.getPhoto(product.photoId);
        if (product.referenceMissing || photo == null || db.isVirtualImportPhoto(photo) || photo.uri == null || photo.uri.trim().isEmpty()) {
            if (!product.referenceMissing) db.markProductReferenceMissing(product.id);
            Toast.makeText(this, "参照画像がありません", Toast.LENGTH_SHORT).show();
            DiagLog.write(this, "PRODUCT_REFERENCE_IMAGE_MISSING product=" + product.id + " photo=" + product.photoId);
            return;
        }
        DiagLog.write(this, "PRODUCT_REFERENCE_IMAGE_OPEN product=" + product.id + " photo=" + photo.id);
        if (!showOriginalPhoto(photo)) {
            db.markProductReferenceMissing(product.id);
            Toast.makeText(this, "参照画像がありません", Toast.LENGTH_SHORT).show();
            DiagLog.write(this, "PRODUCT_REFERENCE_IMAGE_MARK_MISSING product=" + product.id + " photo=" + photo.id);
        }
    }

    private void addProductEditField(LinearLayout panel, String label, EditText input) {
        addProductEditControl(panel, label, input);
    }

    private void addProductEditControl(LinearLayout panel, String label, View control) {
        TextView l = text(label, 12, SECONDARY, false);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24));
        llp.topMargin = dp(4);
        panel.addView(l, llp);
        panel.addView(control, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
    }

    private void showPriceTypeChoice(String[] selectedPriceType, TextView button) {
        String[] values = {"税抜", "税込", "不明"};
        int checked = 2;
        if ("税抜".equals(selectedPriceType[0])) checked = 0;
        else if ("税込".equals(selectedPriceType[0])) checked = 1;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("価格種別")
                .setSingleChoiceItems(values, checked, (d, which) -> {
                    selectedPriceType[0] = values[which];
                    button.setText(values[which]);
                    d.dismiss();
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private String normalizePriceTypeForEditor(String value) {
        if (value == null) return "不明";
        String s = value.trim().toLowerCase(Locale.ROOT);
        if (s.contains("税抜") || s.contains("税別") || s.equals("抜") || s.contains("tax excluded") || s.contains("excl")) return "税抜";
        if (s.contains("税込") || s.equals("込") || s.contains("tax included") || s.contains("incl")) return "税込";
        return "不明";
    }

    private String normalizeVolumeForStorage(String value) {
        if (value == null) return "";
        String raw = value.trim();
        if (raw.isEmpty()) return "";
        String normalized = raw.replace('０', '0').replace('１', '1').replace('２', '2')
                .replace('３', '3').replace('４', '4').replace('５', '5').replace('６', '6')
                .replace('７', '7').replace('８', '8').replace('９', '9')
                .replace('．', '.').replace('，', ',').toLowerCase(Locale.ROOT);
        normalized = normalized.replace(",", "").replace(" ", "");
        try {
            if (normalized.matches("[0-9]+(?:\\.[0-9]+)?l")) {
                double liters = Double.parseDouble(normalized.substring(0, normalized.length() - 1));
                return String.valueOf(Math.round(liters * 1000.0));
            }
            if (normalized.matches("[0-9]+(?:\\.[0-9]+)?(?:ml|ｍｌ)")) {
                String number = normalized.replaceAll("(?:ml|ｍｌ)$", "");
                return String.valueOf(Math.round(Double.parseDouble(number)));
            }
            if (normalized.matches("[0-9]+")) return normalized;
        } catch (Exception ignored) { }
        String digits = normalized.replaceAll("[^0-9]", "");
        return digits;
    }

    private String formatVolumeDisplay(String value) {
        String normalized = normalizeVolumeForStorage(value);
        return normalized.isEmpty() ? "—" : normalized + "ml";
    }

    private void showStoreChoiceForEditor(long[] selectedStore, TextView button) {
        List<DatabaseHelper.Store> stores = db.listStores();
        if (stores.isEmpty()) {
            Toast.makeText(this, "店舗がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[stores.size()];
        for (int i = 0; i < stores.size(); i++) names[i] = stores.get(i).name;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗を選択")
                .setItems(names, (d, which) -> {
                    DatabaseHelper.Store store = stores.get(which);
                    selectedStore[0] = store.id;
                    button.setText("店舗: " + store.name);
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private void showTagChoiceForEditor(Long[] selectedTag, TextView button) {
        List<DatabaseHelper.Tag> tags = db.listTags();
        String[] names = new String[tags.size() + 2];
        names[0] = "タグなし";
        for (int i = 0; i < tags.size(); i++) names[i + 1] = tags.get(i).name;
        names[names.length - 1] = "＋ 新しいタグ";

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグを選択")
                .setItems(names, (d, which) -> {
                    if (which == names.length - 1) {
                        showCreateTagForEditor(selectedTag, button);
                    } else if (which == 0) {
                        selectedTag[0] = null;
                        button.setText("タグ: タグなし");
                    } else {
                        DatabaseHelper.Tag tag = tags.get(which - 1);
                        selectedTag[0] = tag.id;
                        button.setText("タグ: " + tag.name);
                    }
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(dialog);
    }

    private void showCreateTagForEditor(Long[] selectedTag, TextView button) {
        EditText input = dialogInput("新しいタグ");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新しいタグ")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("追加", null)
                .create();
        dialog.setOnShowListener(d -> {
            focusAndShowKeyboard(input, dialog);
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
                Long tagId = db.ensureTag(name);
                if (tagId == null) { input.setError("タグを作成できませんでした"); return; }
                selectedTag[0] = tagId;
                button.setText("タグ: " + name);
                DiagLog.write(this, "ADD_TAG_FROM_PRODUCT tag=" + tagId + " name=" + name);
                dialog.dismiss();
                reloadStores();
            });
        });
        showRoundedDialog(dialog);
    }

    private void showSameProductPrices(String productKey) {
        List<DatabaseHelper.ProductRecord> rows = db.listSameProductAcrossStores(productKey);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(6), dp(10), dp(6));

        if (rows.isEmpty()) {
            TextView empty = text("他店舗の価格データはありません。", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(16), dp(26), dp(16), dp(26));
            content.addView(empty);
        } else {
            LinearLayout sheet = new LinearLayout(this);
            sheet.setOrientation(LinearLayout.VERTICAL);
            int[] widths = {190, 120, 100, 120};
            sheet.addView(sheetHeader(new String[]{"店舗", "価格", "容量", "日付"}, widths));
            for (DatabaseHelper.ProductRecord p : rows) {
                sheet.addView(sheetRow(new String[]{p.storeName, p.priceYen == null ? "—" : yen(p.priceYen),
                        formatVolumeDisplay(p.volume), dateFormat.format(new Date(p.photoCreatedAt))}, widths));
            }
            content.addView(wrapHorizontal(sheet));
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(productKey == null || productKey.trim().isEmpty() ? "他店舗価格" : productKey)
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        showRoundedDialog(dialog, true);
    }

    private void showUnifyProductsDialog(List<Long> productIds, Runnable afterApply) {
        if (productIds == null || productIds.size() < 2) return;

        ArrayList<DatabaseHelper.ProductRecord> records = new ArrayList<>();
        for (Long id : productIds) {
            if (id == null) continue;
            DatabaseHelper.ProductRecord p = db.getProduct(id);
            if (p != null) records.add(p);
        }
        if (records.size() < 2) return;
        records.sort((a, b) -> Long.compare(a.id, b.id));

        ArrayList<DatabaseHelper.ProductRecord> candidates = new ArrayList<>();
        HashSet<String> seenNames = new HashSet<>();
        for (DatabaseHelper.ProductRecord p : records) {
            String name = p.rawName == null ? "" : p.rawName.trim();
            if (name.isEmpty() || !seenNames.add(name)) continue;
            candidates.add(p);
        }
        if (candidates.isEmpty()) return;

        String[] labels = new String[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            DatabaseHelper.ProductRecord p = candidates.get(i);
            StringBuilder label = new StringBuilder(p.rawName == null ? "" : p.rawName);
            if (p.volume != null && !p.volume.trim().isEmpty()) label.append("  ").append(formatVolumeDisplay(p.volume));
            if (p.storeName != null && !p.storeName.trim().isEmpty()) label.append("\n").append(p.storeName);
            labels[i] = label.toString();
        }

        AlertDialog choose = new AlertDialog.Builder(this)
                .setTitle("共通の商品名を選択")
                .setItems(labels, (d, which) -> {
                    DatabaseHelper.ProductRecord chosen = candidates.get(which);
                    String commonName = chosen.rawName == null ? "" : chosen.rawName.trim();
                    String commonKey = chosen.productKey == null ? "" : chosen.productKey.trim();

                    HashSet<String> volumes = new HashSet<>();
                    for (DatabaseHelper.ProductRecord p : records) {
                        if (p.volume != null && !p.volume.trim().isEmpty()) volumes.add(p.volume.trim());
                    }
                    boolean mixedVolume = volumes.size() > 1;
                    StringBuilder message = new StringBuilder();
                    if (mixedVolume) {
                        message.append("容量が異なる商品が含まれています。\n\n");
                    }
                    message.append(productIds.size()).append("件を同一商品として扱います。\n")
                            .append("商品名: ").append(commonName).append("\n")
                            .append("product_key: ").append(commonKey.isEmpty() ? "自動生成" : commonKey)
                            .append("\n\n価格・店舗・容量・タグ・画像情報は変更しません。");

                    AlertDialog confirm = new AlertDialog.Builder(this)
                            .setTitle("同一商品")
                            .setMessage(message.toString())
                            .setNegativeButton("キャンセル", null)
                            .setPositiveButton("適用", (dd, w) -> {
                                db.unifyProductIdentity(productIds, commonName, commonKey);
                                DatabaseHelper.ProductRecord refreshed = db.getProduct(chosen.id);
                                String appliedKey = refreshed == null ? commonKey : refreshed.productKey;
                                DiagLog.write(this, "PRODUCT_UNIFY count=" + productIds.size() +
                                        " name=" + commonName + " key=" + appliedKey + " mixedVolume=" + mixedVolume);
                                Toast.makeText(this, productIds.size() + "件を同一商品にしました", Toast.LENGTH_SHORT).show();
                                if (afterApply != null) afterApply.run();
                            })
                            .create();
                    showRoundedDialog(confirm);
                })
                .setNegativeButton("キャンセル", null)
                .create();
        showRoundedDialog(choose, true);
    }

    private void confirmDeleteProducts(List<Long> productIds, Runnable afterDelete) {
        if (productIds == null || productIds.isEmpty()) return;
        AlertDialog confirm = new AlertDialog.Builder(this)
                .setTitle("商品削除")
                .setMessage(productIds.size() + "件の商品を削除しますか？\n元画像は削除されません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, which) -> {
                    db.deleteProducts(productIds);
                    DiagLog.write(this, "PRODUCT_BULK_DELETE count=" + productIds.size());
                    Toast.makeText(this, productIds.size() + "件削除しました", Toast.LENGTH_SHORT).show();
                    if (afterDelete != null) afterDelete.run();
                })
                .create();
        showRoundedDialog(confirm);
    }

    private void showMoveProductsTagDialog(List<Long> productIds, Runnable afterMove) {
        if (productIds == null || productIds.isEmpty()) return;
        Set<Long> selectedTags = new HashSet<>();
        boolean first = true;
        for (Long productId : productIds) {
            if (productId == null) continue;
            Set<Long> tags = new HashSet<>(db.productTagIds(productId));
            if (first) {
                selectedTags.addAll(tags);
                first = false;
            } else {
                selectedTags.retainAll(tags);
            }
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(8), dp(10), dp(8));
        TextView note = text("選択したタグ構成を" + productIds.size() + "件すべてに適用", 12, SECONDARY, false);
        note.setPadding(dp(2), 0, dp(2), dp(8));
        content.addView(note);
        content.addView(makeCommonTagSelectionArea(selectedTags, true, true, chosen -> { }),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ編集")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("適用", (d, which) -> {
                    db.updateProductsTags(productIds, new ArrayList<>(selectedTags));
                    DiagLog.write(this, "PRODUCT_TAG_MULTI_APPLY count=" + productIds.size() + " tags=" + selectedTags);
                    if (afterMove != null) afterMove.run();
                })
                .create();
        showRoundedDialog(dialog);
    }

    private void showDiagnosticLog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(16), dp(20), dp(10));

        TextView title = text("診断ログ", 21, WHITE, true);
        panel.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        TextView body = text(DiagLog.report(this), 11, WHITE, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(10), dp(8), dp(10), dp(8));
        body.setBackground(roundRect(DGRAY, 10));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(withFastScroll(scroll), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(8), 0, 0);

        TextView clearAction = makeDialogAction("ログ消去");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);

        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));

        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .create();

        clearAction.setOnClickListener(v -> {
            DiagLog.clear(this);
            body.setText(DiagLog.report(this));
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        copyAction.setOnClickListener(v -> {
            String report = DiagLog.report(this);
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("PriceRec diagnostic", report));
            Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
        });
        closeAction.setOnClickListener(v -> dialog.dismiss());

        showRoundedDialog(dialog, true);
    }

    private long selectedTagForStore(long storeId) {
        long id = getPreferences(MODE_PRIVATE).getLong("selected_tag_" + storeId, Long.MIN_VALUE);
        if (id == -1L) return -1L;
        if (id != Long.MIN_VALUE && db.tagExists(id)) return id;
        List<DatabaseHelper.Tag> tags = db.listTags();
        return tags.isEmpty() ? -1L : tags.get(0).id;
    }

    private void saveSelectedTag(long storeId, long tagId) {
        getPreferences(MODE_PRIVATE).edit().putLong("selected_tag_" + storeId, tagId).apply();
    }

    private String safeFolder(String name) {
        String s = name.replace('/', '_').replace('\\', '_').trim();
        return s.isEmpty() ? "Store" : s;
    }

    private String ocrStatusLabel(String s) {
        if (s == null || "pending".equals(s)) return "未解析";
        if ("processing".equals(s)) return "解析中";
        if ("done".equals(s)) return "完了";
        if ("no_results".equals(s)) return "候補なし";
        if ("error".equals(s)) return "エラー";
        return s;
    }

    private void bindThumbnailAsync(ImageView image, Uri uri, int targetW, int targetH) {
        if (image == null || uri == null) return;
        String key = uri.toString() + "@" + targetW + "x" + targetH;
        image.setTag(key);
        Bitmap cached;
        synchronized (thumbnailCache) {
            cached = thumbnailCache.get(key);
        }
        if (cached != null && !cached.isRecycled()) {
            image.setImageBitmap(cached);
            return;
        }
        image.setImageDrawable(null);
        thumbnailExecutor.execute(() -> {
            Bitmap decoded = loadBitmap(uri, targetW, targetH);
            if (decoded == null) return;
            synchronized (thumbnailCache) {
                thumbnailCache.put(key, decoded);
            }
            runOnUiThread(() -> {
                Object currentTag = image.getTag();
                if (key.equals(currentTag) && !decoded.isRecycled()) image.setImageBitmap(decoded);
            });
        });
    }

    private Bitmap loadCachedBitmap(Uri uri, int targetW, int targetH) {
        if (uri == null) return null;
        String key = uri.toString() + "@" + targetW + "x" + targetH;
        Bitmap cached;
        synchronized (thumbnailCache) {
            cached = thumbnailCache.get(key);
        }
        if (cached != null && !cached.isRecycled()) return cached;
        Bitmap decoded = loadBitmap(uri, targetW, targetH);
        if (decoded != null) {
            synchronized (thumbnailCache) {
                thumbnailCache.put(key, decoded);
            }
        }
        return decoded;
    }

    private Bitmap loadBitmap(Uri uri, int targetW, int targetH) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
                int w = info.getSize().getWidth();
                int h = info.getSize().getHeight();
                if (w <= 0 || h <= 0) return;
                double scale = Math.min(1.0, Math.min((double) targetW / w, (double) targetH / h));
                decoder.setTargetSize(Math.max(1, (int) (w * scale)), Math.max(1, (int) (h * scale)));
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            });
        } catch (Exception e) {
            DiagLog.write(this, "IMAGE_LOAD_ERROR uri=" + uri + " err=" + e);
            return null;
        }
    }

    private String yen(int price) {
        return "¥" + NumberFormat.getIntegerInstance(Locale.JAPAN).format(price);
    }

    private View wrapHorizontal(View child) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(child);
        return hsv;
    }

    private ArrayList<String> loadProductColumnOrder(boolean storeWholeList) {
        // v2 intentionally starts from the new compact list layout while preserving future user changes.
        String prefKey = storeWholeList ? "product_columns_store_v2" : "product_columns_all_v2";
        String defaultOrder = storeWholeList
                ? "price,volume,tag,date,store"
                : "price,store,volume,tag,date";
        String saved = getPreferences(MODE_PRIVATE).getString(prefKey, defaultOrder);
        String[] allowed = {"store", "price", "volume", "tag", "date"};
        ArrayList<String> nonProduct = new ArrayList<>();
        if (saved != null) {
            for (String part : saved.split(",")) {
                String key = part.trim();
                for (String a : allowed) {
                    if (a.equals(key) && !nonProduct.contains(key)) {
                        nonProduct.add(key);
                        break;
                    }
                }
            }
        }
        for (String a : allowed) if (!nonProduct.contains(a)) nonProduct.add(a);
        if (storeWholeList) {
            nonProduct.remove("store");
            nonProduct.add("store");
        }
        ArrayList<String> out = new ArrayList<>();
        out.add("product");
        out.addAll(nonProduct);
        return out;
    }

    private void saveProductColumnOrder(List<String> order, boolean storeWholeList) {
        ArrayList<String> nonProduct = new ArrayList<>();
        for (String key : order) if (!"product".equals(key)) nonProduct.add(key);
        if (storeWholeList) {
            nonProduct.remove("store");
            nonProduct.add("store");
        }
        getPreferences(MODE_PRIVATE).edit()
                .putString(storeWholeList ? "product_columns_store_v2" : "product_columns_all_v2", String.join(",", nonProduct))
                .apply();
        DiagLog.write(this, "PRODUCT_COLUMNS_SAVE scope=" + (storeWholeList ? "store" : "all") +
                " order=" + String.join(",", nonProduct));
    }

    private LinearLayout makeReorderableProductHeader(ArrayList<String> order, boolean storeWholeList, Runnable rerender) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(DGRAY);
        final int longPressMs = android.view.ViewConfiguration.getLongPressTimeout();
        final int touchSlop = android.view.ViewConfiguration.get(this).getScaledTouchSlop();
        for (String key : order) {
            TextView cell = text(productColumnLabel(key), 13, SECONDARY, true);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            cell.setLayoutParams(new LinearLayout.LayoutParams(dp(productColumnWidth(key)), dp(38)));
            boolean fixed = "product".equals(key) || (storeWholeList && "store".equals(key));
            if (!fixed) {
                final float[] downX = {0f};
                final float[] downY = {0f};
                final boolean[] longPressed = {false};
                final boolean[] cancelled = {false};
                final Runnable activate = () -> {
                    if (cancelled[0]) return;
                    longPressed[0] = true;
                    cell.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    cell.animate().alpha(0.72f).scaleX(1.03f).scaleY(1.03f).setDuration(90).start();
                    ViewParentDisallow(cell, true);
                    DiagLog.write(this, "PRODUCT_COLUMN_DRAG_START scope=" + (storeWholeList ? "store" : "all") + " column=" + key);
                };
                cell.setOnTouchListener((v, event) -> {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downX[0] = event.getRawX();
                            downY[0] = event.getRawY();
                            cancelled[0] = false;
                            longPressed[0] = false;
                            v.postDelayed(activate, longPressMs);
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getRawX() - downX[0];
                            float dy = event.getRawY() - downY[0];
                            if (!longPressed[0]) {
                                if (Math.hypot(dx, dy) > touchSlop) {
                                    cancelled[0] = true;
                                    v.removeCallbacks(activate);
                                    return false;
                                }
                            } else {
                                v.setTranslationX(dx);
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            v.removeCallbacks(activate);
                            float totalDx = event.getRawX() - downX[0];
                            boolean doMove = longPressed[0] && event.getActionMasked() == MotionEvent.ACTION_UP;
                            v.animate().translationX(0f).alpha(1f).scaleX(1f).scaleY(1f).setDuration(120).start();
                            ViewParentDisallow(v, false);
                            if (doMove) {
                                int from = order.indexOf(key);
                                int min = 1;
                                int max = storeWholeList ? order.size() - 2 : order.size() - 1;
                                int stepWidth = dp(84);
                                int steps = Math.round(totalDx / Math.max(1f, stepWidth));
                                int to = Math.max(min, Math.min(max, from + steps));
                                if (to != from) {
                                    order.remove(from);
                                    order.add(to, key);
                                    saveProductColumnOrder(order, storeWholeList);
                                    v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                                    DiagLog.write(this, "PRODUCT_COLUMN_DRAG_END scope=" + (storeWholeList ? "store" : "all") +
                                            " column=" + key + " from=" + from + " to=" + to);
                                    if (rerender != null) rerender.run();
                                }
                            }
                            longPressed[0] = false;
                            cancelled[0] = true;
                            return true;
                        default:
                            return true;
                    }
                });
            }
            row.addView(cell);
        }
        return row;
    }

    private void ViewParentDisallow(View view, boolean disallow) {
        if (view != null && view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(disallow);
    }

    private String productColumnLabel(String key) {
        switch (key) {
            case "product": return "商品名";
            case "store": return "店舗";
            case "price": return "価格";
            case "volume": return "容量";
            case "tag": return "タグ";
            case "date": return "日付";
            default: return key;
        }
    }

    private int productColumnWidth(String key) {
        switch (key) {
            case "product": return 220;
            case "store": return 135;
            case "price": return 105;
            case "volume": return 95;
            case "tag": return 105;
            case "date": return 145;
            default: return 100;
        }
    }

    private String productColumnValue(String key, DatabaseHelper.ProductRecord p, String productCell) {
        switch (key) {
            case "product": return productCell == null ? "" : productCell;
            case "store": return p.storeName == null ? "—" : p.storeName;
            case "price": return p.priceYen == null ? "—" : yen(p.priceYen) + priceTaxMarker(p.priceType);
            case "volume": return formatVolumeDisplay(p.volume);
            case "tag": return p.tagDisplay();
            case "date": return dateFormat.format(new Date(p.photoCreatedAt));
            default: return "";
        }
    }

    private String priceTaxMarker(String priceType) {
        if (priceType == null) return "";
        String value = priceType.trim().toLowerCase(Locale.ROOT);
        if (value.isEmpty()) return "";
        if (value.contains("税込") || value.equals("込") || value.contains("tax included") || value.contains("incl. tax") || value.contains("incl tax")) return " 込";
        if (value.contains("税抜") || value.equals("抜") || value.contains("税別") || value.contains("tax excluded") || value.contains("excl. tax") || value.contains("excl tax")) return " 抜";
        return "";
    }

    private LinearLayout makeProductDataRow(List<String> order, DatabaseHelper.ProductRecord p, String productCell) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(1), 0, dp(1));
        for (String key : order) {
            int width = productColumnWidth(key);
            if ("product".equals(key)) {
                FrameLayout cell = new FrameLayout(this);
                TextView name = text(productColumnValue(key, p, productCell), 13, WHITE, false);
                name.setGravity(Gravity.CENTER_VERTICAL);
                name.setPadding(dp(10), 0, dp(36), 0);
                cell.addView(name, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

                View magnifier = new MagnifierIconView(this);
                magnifier.setTag("product_compare_icon");
                magnifier.setContentDescription("他店舗価格を比較");
                FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(30), dp(44), Gravity.END | Gravity.CENTER_VERTICAL);
                iconLp.rightMargin = dp(3);
                cell.addView(magnifier, iconLp);
                row.addView(cell, new LinearLayout.LayoutParams(dp(width), dp(44)));
            } else {
                TextView cell = text(productColumnValue(key, p, productCell), 14, WHITE, false);
                cell.setGravity(Gravity.CENTER_VERTICAL);
                cell.setPadding(dp(10), 0, dp(10), 0);
                row.addView(cell, new LinearLayout.LayoutParams(dp(width), dp(44)));
            }
        }
        return row;
    }

    private LinearLayout sheetHeader(String[] values, int[] widthsDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(DGRAY);
        for (int i = 0; i < values.length; i++) {
            TextView cell = text(values[i], 13, SECONDARY, true);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            row.addView(cell, new LinearLayout.LayoutParams(dp(widthsDp[i]), dp(38)));
        }
        return row;
    }

    private LinearLayout sheetRow(String[] values, int[] widthsDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(1), 0, dp(1));
        for (int i = 0; i < values.length; i++) {
            TextView cell = text(values[i] == null ? "" : values[i], 14, WHITE, false);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            row.addView(cell, new LinearLayout.LayoutParams(dp(widthsDp[i]), dp(44)));
        }
        return row;
    }

    private EditText sheetEdit(String value, boolean numeric) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(14);
        e.setTextColor(DGRAY);
        e.setHintTextColor(GRAY);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER_VERTICAL);
        e.setIncludeFontPadding(false);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setBackground(roundRect(NWHITE, 999));
        applyDarkInputCursor(e);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView button(String value, int color, float sp) {
        TextView t = text(value, sp, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundRect(color, 999));
        return t;
    }

    private TextView chip(String value, boolean selected, boolean secondary) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? (secondary ? ORANGE : LBLUE) : DGRAY, 999));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView dialogChip(String value, boolean selected) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? LBLUE : DGRAY, 999));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView makeDialogAction(String value) {
        TextView t = text(value, 14, BLUE, true);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), 0, dp(8), 0);
        t.setBackgroundColor(Color.TRANSPARENT);
        return t;
    }

    private void styleCapsuleDialogButton(TextView button, int color) {
        if (button == null) return;
        button.setTag("capsule_action");
        button.setTextColor(WHITE);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setIncludeFontPadding(false);
        button.setGravity(Gravity.CENTER);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(roundRect(color, 999));
        ViewGroup.LayoutParams rawLp = button.getLayoutParams();
        if (rawLp != null) {
            rawLp.width = dp(92);
            rawLp.height = dp(38);
            if (rawLp instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) rawLp;
                mlp.leftMargin = dp(3);
                mlp.rightMargin = dp(3);
            }
            button.setLayoutParams(rawLp);
        }
        if (button instanceof android.widget.Button) ((android.widget.Button) button).setAllCaps(false);
    }

    private void styleDialogLinkFont(TextView button) {
        if (button == null || "capsule_action".equals(button.getTag())) return;
        button.setTextColor(BLUE);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setIncludeFontPadding(false);
        if (button instanceof android.widget.Button) ((android.widget.Button) button).setAllCaps(false);
    }

    private View productSearchInputHolder(EditText input) {
        FrameLayout holder = new FrameLayout(this);
        holder.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        int left = input.getPaddingLeft();
        int top = input.getPaddingTop();
        int bottom = input.getPaddingBottom();
        input.setPadding(left, top, dp(46), bottom);

        TextView clear = text("×", 24, DGRAY, true);
        clear.setGravity(Gravity.CENTER);
        clear.setContentDescription("検索文字を消去");
        clear.setVisibility(input.length() == 0 ? View.GONE : View.VISIBLE);
        clear.setOnClickListener(v -> {
            input.setText("");
            input.requestFocus();
            DiagLog.write(this, "PRODUCT_SEARCH_CLEAR");
        });
        FrameLayout.LayoutParams clearLp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.END | Gravity.CENTER_VERTICAL);
        clearLp.rightMargin = dp(3);
        holder.addView(clear, clearLp);

        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                clear.setVisibility(s == null || s.length() == 0 ? View.GONE : View.VISIBLE);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        return holder;
    }

    private EditText dialogInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setTextSize(17);
        input.setTextColor(DGRAY);
        input.setHintTextColor(GRAY);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setIncludeFontPadding(false);
        input.setMinHeight(dp(48));
        input.setPadding(dp(16), 0, dp(16), 0);
        input.setBackground(roundRect(NWHITE, 999));
        applyDarkInputCursor(input);
        input.setOnFocusChangeListener((v, hasFocus) -> input.setBackground(roundRect(NWHITE, 999)));
        return input;
    }

    private void applyDarkInputCursor(EditText input) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            GradientDrawable cursor = new GradientDrawable();
            cursor.setColor(DGRAY);
            cursor.setSize(dp(2), dp(28));
            input.setTextCursorDrawable(cursor);
        }
    }

    private View storeNameInputHolder(EditText input) {
        return storeNameInputHolder(input, 0);
    }

    private View storeNameInputHolder(EditText input, int topPaddingDp) {
        LinearLayout holder = new LinearLayout(this);
        holder.setGravity(Gravity.CENTER_VERTICAL);
        holder.setPadding(dp(20), dp(topPaddingDp), dp(20), 0);
        holder.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        return holder;
    }

    private boolean isImeVisible() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsets insets = getWindow().getDecorView().getRootWindowInsets();
            return insets != null && insets.isVisible(WindowInsets.Type.ime());
        }
        return false;
    }

    private void focusDialogInput(EditText input, AlertDialog dialog, boolean imeWasVisible) {
        Window w = dialog.getWindow();
        if (w != null) {
            int state = imeWasVisible ? WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED
                    : WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE;
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | state);
        }
        if (imeWasVisible) {
            // The IME is already on screen: only move focus, do not hide/show it again.
            input.requestFocus();
            input.setSelection(input.length());
        } else {
            input.postDelayed(() -> {
                input.requestFocus();
                input.setSelection(input.length());
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            }, 90);
        }
    }

    private void focusAndShowKeyboard(EditText input, AlertDialog dialog) {
        focusDialogInput(input, dialog, false);
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private FrameLayout withFastScroll(ScrollView scroll) {
        FrameLayout frame = new FrameLayout(this);
        scroll.setVerticalScrollBarEnabled(false);
        frame.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Wider transparent grip area; the visible thumb itself keeps a fixed 12x58dp size.
        FrameLayout grip = new FrameLayout(this);
        grip.setContentDescription("スクロールグリップ");
        grip.setClickable(true);
        grip.setFocusable(true);
        FrameLayout.LayoutParams gripLp = new FrameLayout.LayoutParams(dp(32), dp(58), Gravity.END | Gravity.TOP);
        gripLp.topMargin = dp(4);
        frame.addView(grip, gripLp);

        View thumb = new View(this);
        thumb.setBackground(roundRect(LGRAY, 999));
        thumb.setContentDescription("スクロールサム");
        FrameLayout.LayoutParams thumbLp = new FrameLayout.LayoutParams(dp(12), dp(58), Gravity.CENTER);
        grip.addView(thumb, thumbLp);

        final Runnable[] update = new Runnable[1];
        update[0] = () -> {
            if (scroll.getChildCount() == 0 || frame.getHeight() <= 0) return;
            int range = Math.max(0, scroll.getChildAt(0).getHeight() - scroll.getHeight());
            if (range <= 0) {
                grip.setVisibility(View.GONE);
                return;
            }
            grip.setVisibility(View.VISIBLE);
            int top = dp(4);
            int travel = Math.max(1, frame.getHeight() - grip.getHeight() - dp(8));
            float fraction = Math.max(0f, Math.min(1f, scroll.getScrollY() / (float) range));
            grip.setTranslationY(top + fraction * travel);
        };
        scroll.setOnScrollChangeListener((v, sx, sy, oldSx, oldSy) -> update[0].run());

        final float[] grabOffset = {0f};
        grip.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    grabOffset[0] = event.getY();
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    // Grip feedback is color-only: no scaling, length, thickness, or shape change.
                    thumb.setBackground(roundRect(NWHITE, 999));
                    v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (scroll.getChildCount() == 0) return true;
                    int range = Math.max(0, scroll.getChildAt(0).getHeight() - scroll.getHeight());
                    int top = dp(4);
                    int travel = Math.max(1, frame.getHeight() - grip.getHeight() - dp(8));
                    int[] loc = new int[2];
                    frame.getLocationOnScreen(loc);
                    float wanted = event.getRawY() - loc[1] - grabOffset[0] - top;
                    float fraction = Math.max(0f, Math.min(1f, wanted / travel));
                    scroll.scrollTo(scroll.getScrollX(), Math.round(range * fraction));
                    update[0].run();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    thumb.setBackground(roundRect(LGRAY, 999));
                    return true;
                default:
                    return true;
            }
        });
        frame.post(update[0]);
        return frame;
    }

    private void showRoundedDialog(AlertDialog dialog) {
        showRoundedDialog(dialog, false);
    }

    private void showRoundedDialog(AlertDialog dialog, boolean wide) {
        dialog.show();
        // System dialog buttons and custom text links use the same typography as "全て表示".
        styleDialogLinkFont(dialog.getButton(DialogInterface.BUTTON_NEGATIVE));
        styleDialogLinkFont(dialog.getButton(DialogInterface.BUTTON_NEUTRAL));
        styleDialogLinkFont(dialog.getButton(DialogInterface.BUTTON_POSITIVE));
        Window window = dialog.getWindow();
        if (window == null) return;
        window.setBackgroundDrawable(roundRect(GRAY, 20));
        if (wide) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private GradientDrawable roundRect(int fill, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable circle(int fill) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }


    private final class TagDeleteIconView extends View {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint xPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        TagDeleteIconView(Context context) {
            super(context);
            fillPaint.setColor(RED);
            fillPaint.setStyle(Paint.Style.FILL);
            xPaint.setColor(Color.BLACK);
            xPaint.setStyle(Paint.Style.STROKE);
            xPaint.setStrokeWidth(dp(2));
            xPaint.setStrokeCap(Paint.Cap.SQUARE);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float radius = Math.min(getWidth(), getHeight()) / 2f;
            canvas.drawCircle(cx, cy, radius, fillPaint);
            float half = Math.min(getWidth(), getHeight()) * 0.22f;
            canvas.drawLine(cx - half, cy - half, cx + half, cy + half, xPaint);
            canvas.drawLine(cx + half, cy - half, cx - half, cy + half, xPaint);
        }
    }

    private final class TagManageIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint holePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        TagManageIconView(Context context) {
            super(context);
            paint.setColor(WHITE);
            paint.setStyle(Paint.Style.FILL);
            holePaint.setColor(GRAY);
            holePaint.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * 0.50f;
            float cy = h * 0.50f;

            // Flat 2D tag silhouette. Build it face-on with parallel sides, then rotate as one rigid shape.
            // This keeps the requested mirrored direction without perspective/skew distortion.
            canvas.save();
            canvas.rotate(45f, cx, cy);

            android.graphics.Path path = new android.graphics.Path();
            float left = w * 0.34f;
            float right = w * 0.66f;
            float top = h * 0.20f;
            float bottom = h * 0.80f;
            float r = Math.min(w, h) * 0.12f;

            path.moveTo(left + r, top);
            path.lineTo(right - r, top);
            path.quadTo(right, top, right, top + r);
            path.lineTo(right, bottom - r * 0.55f);
            path.quadTo(right, bottom, right - r * 0.55f, bottom);
            path.lineTo(left + r * 0.55f, bottom);
            path.quadTo(left, bottom, left, bottom - r * 0.55f);
            path.lineTo(left, top + r);
            path.quadTo(left, top, left + r, top);
            path.close();

            canvas.drawPath(path, paint);
            canvas.drawCircle(cx, h * 0.31f, Math.min(w, h) * 0.072f, holePaint);
            canvas.restore();
        }
    }

    private final class CardPhotoScrollView extends ScrollView {
        CardPhotoScrollView(Context context) {
            super(context);
            setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = View.MeasureSpec.getSize(widthMeasureSpec);
            int cellWidth = Math.max(1, width / 3);
            // Tile = square image (cell minus horizontal tile padding) + 6dp gap + 44dp text panel + tile vertical padding.
            int rowHeight = Math.max(dp(1), cellWidth - dp(6) + dp(58));
            int rowCount = 1;
            if (getChildCount() > 0 && getChildAt(0) instanceof ViewGroup) {
                rowCount = Math.max(1, ((ViewGroup) getChildAt(0)).getChildCount());
            }
            // 1-3 photos: one row. 4+ photos: at most two visible rows; overflow scrolls inside.
            int visibleRows = Math.min(2, rowCount);
            int targetHeight = rowHeight * visibleRows;
            int fixedHeight = View.MeasureSpec.makeMeasureSpec(targetHeight, View.MeasureSpec.EXACTLY);
            super.onMeasure(widthMeasureSpec, fixedHeight);
            setMeasuredDimension(getMeasuredWidth(), targetHeight);
        }
    }

    private final class SquareFrameLayout extends FrameLayout {
        SquareFrameLayout(Context context) {
            super(context);
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = View.MeasureSpec.getSize(widthMeasureSpec);
            int square = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
            super.onMeasure(widthMeasureSpec, square);
            setMeasuredDimension(getMeasuredWidth(), getMeasuredWidth());
        }
    }

    private final class MagnifierIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        MagnifierIconView(Context context) {
            super(context);
            paint.setColor(LBLUE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setStrokeCap(Paint.Cap.SQUARE);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * 0.43f;
            float cy = h * 0.45f;
            float r = Math.min(w, h) * 0.16f;
            canvas.drawCircle(cx, cy, r, paint);
            float startX = cx + r * 0.72f;
            float startY = cy + r * 0.72f;
            canvas.drawLine(startX, startY, w * 0.72f, h * 0.68f, paint);
        }
    }

    private final class StraightSelectionCheckView extends View {
        private final Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        StraightSelectionCheckView(Context context) {
            super(context);
            checkPaint.setColor(WHITE);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(dp(2));
            checkPaint.setStrokeCap(Paint.Cap.SQUARE);
            checkPaint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            canvas.drawLine(w * 0.14f, h * 0.52f, w * 0.40f, h * 0.76f, checkPaint);
            canvas.drawLine(w * 0.40f, h * 0.76f, w * 0.86f, h * 0.25f, checkPaint);
        }
    }

    private final class StraightCheckBadgeView extends View {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        StraightCheckBadgeView(Context context) {
            super(context);
            fillPaint.setColor(CSV_GREEN);
            fillPaint.setStyle(Paint.Style.FILL);
            checkPaint.setColor(WHITE);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(dp(2));
            checkPaint.setStrokeCap(Paint.Cap.SQUARE);
            checkPaint.setStrokeJoin(Paint.Join.MITER);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(w, h) / 2f;
            canvas.drawCircle(w / 2f, h / 2f, r, fillPaint);
            canvas.drawLine(w * 0.27f, h * 0.53f, w * 0.44f, h * 0.69f, checkPaint);
            canvas.drawLine(w * 0.44f, h * 0.69f, w * 0.76f, h * 0.34f, checkPaint);
        }
    }

    private final class ZoomImageView extends ImageView {
        private final Matrix zoomMatrix = new Matrix();
        private final ScaleGestureDetector scaleDetector;
        private final GestureDetector gestureDetector;
        private float scale = 1f;
        private float minScale = 0.1f;
        private final float maxScale = 8f;
        private float lastX;
        private float lastY;
        private boolean dragging;

        ZoomImageView(Context context) {
            super(context);
            setScaleType(ScaleType.MATRIX);
            scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float wanted = scale * detector.getScaleFactor();
                    float clamped = Math.max(minScale, Math.min(maxScale, wanted));
                    float factor = clamped / scale;
                    zoomMatrix.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                    scale = clamped;
                    setImageMatrix(zoomMatrix);
                    return true;
                }
            });
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    resetToOriginalPixels();
                    return true;
                }
            });
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            post(this::resetToOriginalPixels);
        }

        private void resetToOriginalPixels() {
            if (getDrawable() == null || getWidth() <= 0 || getHeight() <= 0) return;
            int dw = Math.max(1, getDrawable().getIntrinsicWidth());
            int dh = Math.max(1, getDrawable().getIntrinsicHeight());
            minScale = Math.min(1f, Math.min((float) getWidth() / dw, (float) getHeight() / dh));
            scale = 1f;
            zoomMatrix.reset();
            float dx = (getWidth() - dw) / 2f;
            float dy = (getHeight() - dh) / 2f;
            zoomMatrix.postTranslate(dx, dy);
            setImageMatrix(zoomMatrix);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);
            gestureDetector.onTouchEvent(event);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    dragging = true;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging && !scaleDetector.isInProgress() && event.getPointerCount() == 1) {
                        float dx = event.getX() - lastX;
                        float dy = event.getY() - lastY;
                        zoomMatrix.postTranslate(dx, dy);
                        setImageMatrix(zoomMatrix);
                        lastX = event.getX();
                        lastY = event.getY();
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerCount() - 1 == 1) {
                        int remain = event.getActionIndex() == 0 ? 1 : 0;
                        if (remain < event.getPointerCount()) {
                            lastX = event.getX(remain);
                            lastY = event.getY(remain);
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
                default:
                    return true;
            }
        }
    }

    private static final class DragPayload {
        final String type; final long id;
        DragPayload(String type, long id) { this.type = type; this.id = id; }
    }

    private static final class PendingImage {
        final Uri uri;
        final boolean managed;
        final String cameraTempPath;
        PendingImage(Uri uri, boolean managed, String cameraTempPath) {
            this.uri = uri;
            this.managed = managed;
            this.cameraTempPath = cameraTempPath;
        }
    }

    private static final class ImportPreviewRow {
        static final String ADD = "追加";
        static final String UPDATE = "更新";
        static final String SKIP = "スキップ";
        final CsvImporter.Row row;
        String status = "";
        String action = ADD;
        long existingProductId = -1L;
        boolean refreshReference = false;
        String resolvedProductKey = "";
        ImportPreviewRow(CsvImporter.Row row) { this.row = row; }
    }

    private static final class OcrEditorRow {
        final LinearLayout row; final EditText name; final EditText price;
        OcrEditorRow(LinearLayout row, EditText name, EditText price) { this.row = row; this.name = name; this.price = price; }
    }
}
