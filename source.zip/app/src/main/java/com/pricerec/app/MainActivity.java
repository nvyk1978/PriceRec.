package com.pricerec.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

public final class MainActivity extends ComponentActivity {
    private static final int REQ_CAMERA = 4101;

    private static final int BG = Color.parseColor("#303030");
    private static final int DGRAY = Color.parseColor("#2A2222");
    private static final int GRAY = Color.parseColor("#3A3333");
    private static final int LGRAY = Color.parseColor("#5A5555");
    private static final int BLUE = Color.parseColor("#223355");
    private static final int LBLUE = Color.parseColor("#445577");
    private static final int RED = Color.parseColor("#441100");
    private static final int LRED = Color.parseColor("#882211");
    private static final int ORANGE = Color.parseColor("#775500");
    private static final int WHITE = Color.WHITE;
    private static final int SECONDARY = Color.parseColor("#C9C4C4");

    private DatabaseHelper db;
    private LinearLayout storeContainer;
    private EditText searchInput;
    private long expandedStoreId = -1L;
    private final Map<Long, String> activeTab = new HashMap<>();

    private Uri pendingPhotoUri;
    private long pendingStoreId = -1L;
    private Long pendingTagId = null;

    private long pendingImportStoreId = -1L;
    private Long pendingImportTagId = null;

    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.JAPAN);

    private final ActivityResultLauncher<PickVisualMediaRequest> photoPicker =
            registerForActivityResult(new ActivityResultContracts.PickMultipleVisualMedia(100), this::handlePhotoPickerUris);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DatabaseHelper(this);
        DiagLog.write(this, "APP_START version=" + BuildConfig.VERSION_NAME);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        if (state != null) {
            String uri = state.getString("pending_uri");
            if (uri != null) pendingPhotoUri = Uri.parse(uri);
            pendingStoreId = state.getLong("pending_store", -1L);
            long tag = state.getLong("pending_tag", Long.MIN_VALUE);
            pendingTagId = tag == Long.MIN_VALUE ? null : tag;
            pendingImportStoreId = state.getLong("pending_import_store", -1L);
            long importTag = state.getLong("pending_import_tag", Long.MIN_VALUE);
            pendingImportTagId = importTag == Long.MIN_VALUE ? null : importTag;
            expandedStoreId = state.getLong("expanded_store", -1L);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(10), dp(14), dp(10));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                top = bars.top;
                bottom = Math.max(bars.bottom, ime.bottom);
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(14), top + dp(8), dp(14), bottom + dp(8));
            return insets;
        });

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(dp(4), dp(2), 0, dp(10));

        TextView title = text("PRICE REC.", 25, WHITE, true);
        title.setLetterSpacing(0.08f);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));

        TextView appMenu = text("⋮", 26, SECONDARY, true);
        appMenu.setGravity(Gravity.CENTER);
        appMenu.setContentDescription("アプリメニュー");
        appMenu.setOnClickListener(v -> showAppMenu());
        titleRow.addView(appMenu, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(titleRow);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        storeContainer = new LinearLayout(this);
        storeContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(storeContainer, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(makeBottomBar());
        setContentView(root);
        root.requestApplyInsets();
        reloadStores();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (pendingPhotoUri != null) out.putString("pending_uri", pendingPhotoUri.toString());
        out.putLong("pending_store", pendingStoreId);
        out.putLong("pending_tag", pendingTagId == null ? Long.MIN_VALUE : pendingTagId);
        out.putLong("pending_import_store", pendingImportStoreId);
        out.putLong("pending_import_tag", pendingImportTagId == null ? Long.MIN_VALUE : pendingImportTagId);
        out.putLong("expanded_store", expandedStoreId);
    }

    private View makeBottomBar() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, 0);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(WHITE);
        searchInput.setTextSize(16);
        searchInput.setHint("");
        searchInput.setGravity(Gravity.CENTER_VERTICAL);
        searchInput.setIncludeFontPadding(false);
        searchInput.setPadding(dp(16), 0, dp(16), 0);
        searchInput.setBackground(roundRect(DGRAY, 24));
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setOnFocusChangeListener((v, focused) -> searchInput.setBackground(roundRect(focused ? BLUE : DGRAY, 24)));
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        searchLp.rightMargin = dp(12);
        row.addView(searchInput, searchLp);

        TextView add = text("＋", 24, WHITE, true);
        add.setGravity(Gravity.CENTER);
        add.setBackground(circle(LBLUE));
        add.setContentDescription("新規店舗");
        add.setOnClickListener(v -> showAddStoreDialog());
        row.addView(add, new LinearLayout.LayoutParams(dp(48), dp(48)));
        return row;
    }

    private void reloadStores() {
        if (storeContainer == null) return;
        storeContainer.removeAllViews();
        List<DatabaseHelper.Store> stores = db.listStores();
        if (stores.isEmpty()) {
            TextView empty = text("右下の＋から店舗を追加", 16, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(80), 0, 0);
            storeContainer.addView(empty);
            return;
        }
        for (DatabaseHelper.Store store : stores) storeContainer.addView(makeStoreCard(store));
    }

    private View makeStoreCard(DatabaseHelper.Store store) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundRect(GRAY, 18));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(12);
        card.setLayoutParams(cardLp);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(6), dp(8), dp(6), dp(8));

        TextView handle = text("☰", 22, SECONDARY, false);
        handle.setGravity(Gravity.CENTER);
        handle.setContentDescription("店舗を並べ替え");
        handle.setOnLongClickListener(v -> {
            DragPayload payload = new DragPayload("store", store.id);
            ClipData data = ClipData.newPlainText("store_id", String.valueOf(store.id));
            DiagLog.write(this, "STORE_DRAG_START id=" + store.id + " name=" + store.name);
            v.startDragAndDrop(data, new View.DragShadowBuilder(v), payload, 0);
            return true;
        });

        TextView name = text(store.name, 18, WHITE, true);
        name.setGravity(Gravity.CENTER_VERTICAL);

        TextView menu = text("⋮", 24, SECONDARY, true);
        menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v -> showStoreMenu(store));

        header.addView(handle, new LinearLayout.LayoutParams(dp(48), dp(48)));
        header.addView(name, new LinearLayout.LayoutParams(0, dp(48), 1f));
        header.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(48)));
        header.setOnClickListener(v -> {
            expandedStoreId = expandedStoreId == store.id ? -1L : store.id;
            reloadStores();
        });
        card.setOnDragListener((v, event) -> handleStoreDrag(card, store, event));
        card.addView(header);

        if (expandedStoreId == store.id) {
            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setPadding(dp(12), 0, dp(12), dp(12));
            details.addView(makeTagSelector(store));
            details.addView(makeActionRow(store));
            details.addView(makeTabs(store));
            details.addView(makeStoreBody(store));
            card.addView(details);
        }
        return card;
    }

    private boolean handleStoreDrag(View targetView, DatabaseHelper.Store target, DragEvent event) {
        Object local = event.getLocalState();
        if (!(local instanceof DragPayload) || !"store".equals(((DragPayload) local).type)) {
            return event.getAction() != DragEvent.ACTION_DRAG_STARTED;
        }
        DragPayload payload = (DragPayload) local;
        switch (event.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED: return true;
            case DragEvent.ACTION_DRAG_ENTERED:
                if (payload.id != target.id) targetView.setAlpha(0.72f);
                return true;
            case DragEvent.ACTION_DRAG_EXITED:
                targetView.setAlpha(1f); return true;
            case DragEvent.ACTION_DROP:
                targetView.setAlpha(1f);
                if (payload.id != target.id) {
                    boolean after = event.getY() > targetView.getHeight() / 2f;
                    db.moveStore(payload.id, target.id, after);
                    DiagLog.write(this, "STORE_REORDER dragged=" + payload.id + " target=" + target.id + " after=" + after);
                    targetView.post(this::reloadStores);
                }
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                targetView.setAlpha(1f); return true;
            default: return true;
        }
    }

    private View makeTagSelector(DatabaseHelper.Store store) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView label = text("撮影タグ", 13, SECONDARY, false);
        label.setPadding(dp(4), 0, 0, dp(6));
        box.addView(label);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        long selected = selectedTagForStore(store.id);
        for (DatabaseHelper.Tag tag : db.listTags()) {
            TextView chip = chip(tag.name, selected == tag.id, false);
            chip.setOnClickListener(v -> {
                saveSelectedTag(store.id, tag.id);
                reloadStores();
            });
            row.addView(chip);
        }
        TextView none = chip("タグなし", selected < 0, true);
        none.setOnClickListener(v -> {
            saveSelectedTag(store.id, -1L);
            reloadStores();
        });
        row.addView(none);
        hsv.addView(row);
        box.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        return box;
    }

    private View makeActionRow(DatabaseHelper.Store store) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(8), 0, dp(8));
        TextView camera = button("撮影", BLUE, 16);
        camera.setOnClickListener(v -> takePhoto(store));
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, dp(44), 1f);
        a.rightMargin = dp(5);
        row.addView(camera, a);

        TextView addImage = button("画像追加", BLUE, 15);
        addImage.setOnClickListener(v -> importImages(store));
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, dp(44), 1f);
        b.leftMargin = dp(2); b.rightMargin = dp(5);
        row.addView(addImage, b);

        TextView tags = button("タグ管理", DGRAY, 15);
        tags.setOnClickListener(v -> showTagManager());
        LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(0, dp(44), 1f);
        c.leftMargin = dp(2);
        row.addView(tags, c);
        return row;
    }

    private View makeTabs(DatabaseHelper.Store store) {
        String tab = activeTab.getOrDefault(store.id, "list");
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, 0, 0, dp(8));
        TextView list = button("リスト", "list".equals(tab) ? LBLUE : DGRAY, 15);
        list.setOnClickListener(v -> { activeTab.put(store.id, "list"); reloadStores(); });
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp1.rightMargin = dp(4);
        row.addView(list, lp1);
        TextView images = button("画像", "images".equals(tab) ? LBLUE : DGRAY, 15);
        images.setOnClickListener(v -> { activeTab.put(store.id, "images"); reloadStores(); });
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp2.leftMargin = dp(4);
        row.addView(images, lp2);
        return row;
    }

    private View makeStoreBody(DatabaseHelper.Store store) {
        return "images".equals(activeTab.getOrDefault(store.id, "list")) ? makePhotoGrid(store) : makeProductSheet(store);
    }

    private View makeProductSheet(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.ProductRecord> products = db.listProductsForStore(store.id);
        if (products.isEmpty()) {
            TextView empty = text("商品データはまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }
        outer.addView(sheetHeader(new String[]{"商品名", "価格", "タグ"}, new int[]{240, 100, 100}));
        for (DatabaseHelper.ProductRecord p : products) {
            LinearLayout row = sheetRow(new String[]{p.rawName, p.priceYen == null ? "—" : yen(p.priceYen), p.tagName == null ? "—" : p.tagName},
                    new int[]{240, 100, 100});
            row.setOnClickListener(v -> showOcrSheet(p.photoId, store.name + " / OCR結果"));
            outer.addView(row);
        }
        return wrapHorizontal(outer);
    }

    private View makePhotoGrid(DatabaseHelper.Store store) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        List<DatabaseHelper.Photo> photos = db.listPhotos(store.id);
        if (photos.isEmpty()) {
            TextView empty = text("画像はまだありません", 14, SECONDARY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(22), dp(8), dp(22));
            outer.addView(empty);
            return outer;
        }
        LinearLayout currentRow = null;
        for (int i = 0; i < photos.size(); i++) {
            if (i % 3 == 0) {
                currentRow = new LinearLayout(this);
                currentRow.setGravity(Gravity.TOP);
                outer.addView(currentRow);
            }
            DatabaseHelper.Photo photo = photos.get(i);
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setPadding(dp(3), dp(3), dp(3), dp(6));
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(DGRAY);
            Bitmap bmp = loadBitmap(Uri.parse(photo.uri), 360, 360);
            if (bmp != null) image.setImageBitmap(bmp);
            tile.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));
            String label = photo.tagName == null ? "タグなし" : photo.tagName;
            if ("processing".equals(photo.ocrStatus)) label += "  OCR…";
            TextView tag = text(label, 12, SECONDARY, false);
            tag.setGravity(Gravity.CENTER);
            tag.setSingleLine(true);
            tile.addView(tag, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
            tile.setOnClickListener(v -> showPhotoDetail(photo, store));
            currentRow.addView(tile, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        return outer;
    }

    private void showAddStoreDialog() {
        EditText input = dialogInput("店舗名");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗追加")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("追加", null)
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { input.setError("店舗名を入力"); return; }
                long id = db.addStore(name);
                if (id > 0) {
                    expandedStoreId = id;
                    DiagLog.write(this, "ADD_STORE id=" + id + " name=" + name);
                    dialog.dismiss();
                    reloadStores();
                }
            });
            focusAndShowKeyboard(input, dialog);
        });
        showRoundedDialog(dialog);
    }

    private void showStoreMenu(DatabaseHelper.Store store) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setItems(new String[]{"店舗名変更", "店舗削除"}, (d, which) -> {
                    if (which == 0) showRenameStoreDialog(store); else showDeleteStoreDialog(store);
                })
                .create();
        showRoundedDialog(dialog);
    }

    private void showRenameStoreDialog(DatabaseHelper.Store store) {
        EditText input = dialogInput("店舗名");
        input.setText(store.name);
        input.setSelection(input.length());
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗名変更")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("変更", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("店舗名を入力"); return; }
            db.renameStore(store.id, name);
            DiagLog.write(this, "RENAME_STORE id=" + store.id + " name=" + name);
            dialog.dismiss();
            reloadStores();
        }));
        showRoundedDialog(dialog);
    }

    private void showDeleteStoreDialog(DatabaseHelper.Store store) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("店舗削除")
                .setMessage("「" + store.name + "」と、この店舗に紐づく登録データを削除します。\n撮影した画像は端末からも削除します。追加した既存画像の元ファイルは削除しません。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    for (DatabaseHelper.Photo p : db.listPhotos(store.id)) {
                        if (p.managed) {
                            try { getContentResolver().delete(Uri.parse(p.uri), null, null); } catch (Exception ignored) { }
                        } else releaseImportedPermission(Uri.parse(p.uri));
                    }
                    db.deleteStore(store.id);
                    if (expandedStoreId == store.id) expandedStoreId = -1L;
                    DiagLog.write(this, "DELETE_STORE id=" + store.id + " name=" + store.name);
                    reloadStores();
                }).create();
        showRoundedDialog(dialog);
    }

    private void showTagManager() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        content.addView(rows);
        populateTagManagerRows(rows);

        LinearLayout addRow = new LinearLayout(this);
        addRow.setGravity(Gravity.CENTER_VERTICAL);
        addRow.setPadding(0, dp(8), 0, 0);
        EditText input = dialogInput("新しいタグ");
        TextView add = text("追加", 15, LBLUE, true);
        add.setGravity(Gravity.CENTER);
        addRow.addView(input, new LinearLayout.LayoutParams(0, dp(50), 1f));
        addRow.addView(add, new LinearLayout.LayoutParams(dp(64), dp(50)));
        content.addView(addRow);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("タグ管理")
                .setView(scroll)
                .setNegativeButton("閉じる", null)
                .create();
        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            long id = db.addTag(name);
            if (id < 0) { input.setError("同じタグがあります"); return; }
            DiagLog.write(this, "ADD_TAG id=" + id + " name=" + name);
            input.setText("");
            populateTagManagerRows(rows);
            reloadStores();
        });
        dialog.setOnDismissListener(d -> reloadStores());
        showRoundedDialog(dialog);
    }

    private void populateTagManagerRows(LinearLayout container) {
        container.removeAllViews();
        for (DatabaseHelper.Tag tag : db.listTags()) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(2), 0, dp(2));
            TextView handle = text("☰", 22, SECONDARY, false);
            handle.setGravity(Gravity.CENTER);
            handle.setOnLongClickListener(v -> {
                DragPayload payload = new DragPayload("tag", tag.id);
                v.startDragAndDrop(ClipData.newPlainText("tag_id", String.valueOf(tag.id)), new View.DragShadowBuilder(v), payload, 0);
                return true;
            });
            TextView name = text(tag.name, 16, WHITE, false);
            TextView del = text("削除", 14, LRED, true);
            del.setGravity(Gravity.CENTER);
            del.setOnClickListener(v -> {
                AlertDialog confirm = new AlertDialog.Builder(this)
                        .setTitle("タグ削除")
                        .setMessage("「" + tag.name + "」を削除します。画像自体は削除されません。")
                        .setNegativeButton("キャンセル", null)
                        .setPositiveButton("削除", (d, w) -> {
                            db.deleteTag(tag.id);
                            DiagLog.write(this, "DELETE_TAG id=" + tag.id + " name=" + tag.name);
                            populateTagManagerRows(container);
                            reloadStores();
                        }).create();
                showRoundedDialog(confirm);
            });
            row.addView(handle, new LinearLayout.LayoutParams(dp(48), dp(48)));
            row.addView(name, new LinearLayout.LayoutParams(0, dp(48), 1f));
            row.addView(del, new LinearLayout.LayoutParams(dp(64), dp(48)));
            row.setOnDragListener((v, event) -> handleTagDrag(row, tag, container, event));
            container.addView(row);
        }
    }

    private boolean handleTagDrag(View targetView, DatabaseHelper.Tag target, LinearLayout container, DragEvent event) {
        Object local = event.getLocalState();
        if (!(local instanceof DragPayload) || !"tag".equals(((DragPayload) local).type)) return event.getAction() != DragEvent.ACTION_DRAG_STARTED;
        DragPayload payload = (DragPayload) local;
        switch (event.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED: return true;
            case DragEvent.ACTION_DRAG_ENTERED:
                if (payload.id != target.id) targetView.setAlpha(0.55f); return true;
            case DragEvent.ACTION_DRAG_EXITED:
                targetView.setAlpha(1f); return true;
            case DragEvent.ACTION_DROP:
                targetView.setAlpha(1f);
                if (payload.id != target.id) {
                    boolean after = event.getY() > targetView.getHeight() / 2f;
                    db.moveTag(payload.id, target.id, after);
                    DiagLog.write(this, "TAG_REORDER dragged=" + payload.id + " target=" + target.id + " after=" + after);
                    container.post(() -> populateTagManagerRows(container));
                    reloadStores();
                }
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                targetView.setAlpha(1f); return true;
            default: return true;
        }
    }

    private void showPhotoDetail(DatabaseHelper.Photo photo, DatabaseHelper.Store store) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        image.setBackgroundColor(DGRAY);
        Bitmap bmp = loadBitmap(Uri.parse(photo.uri), 1200, 900);
        if (bmp != null) image.setImageBitmap(bmp);
        content.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280)));

        TextView status = text("OCR: " + ocrStatusLabel(photo.ocrStatus), 13, SECONDARY, false);
        status.setPadding(dp(4), dp(8), 0, dp(4));
        content.addView(status);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout tags = new LinearLayout(this);
        tags.setPadding(0, dp(4), 0, dp(8));
        for (DatabaseHelper.Tag tag : db.listTags()) {
            TextView c = dialogChip(tag.name, photo.tagId != null && photo.tagId == tag.id);
            c.setOnClickListener(v -> {
                db.updatePhotoTag(photo.id, tag.id);
                DiagLog.write(this, "PHOTO_TAG photo=" + photo.id + " tag=" + tag.id);
                reloadStores();
            });
            tags.addView(c);
        }
        TextView none = dialogChip("タグなし", photo.tagId == null);
        none.setOnClickListener(v -> { db.updatePhotoTag(photo.id, null); reloadStores(); });
        tags.addView(none);
        hsv.addView(tags);
        content.addView(hsv);

        LinearLayout actions = new LinearLayout(this);
        TextView result = button("OCR結果", DGRAY, 14);
        result.setOnClickListener(v -> showOcrSheet(photo.id, store.name + " / OCR結果"));
        TextView rerun = button("OCR再解析", BLUE, 14);
        TextView delete = button("削除", RED, 14);
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, dp(42), 1f); p1.rightMargin = dp(4);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(42), 1f); p2.leftMargin = dp(2); p2.rightMargin = dp(4);
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(0, dp(42), 1f); p3.leftMargin = dp(2);
        actions.addView(result, p1); actions.addView(rerun, p2); actions.addView(delete, p3);
        content.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(store.name)
                .setView(content)
                .setNegativeButton("閉じる", null)
                .create();
        rerun.setOnClickListener(v -> {
            dialog.dismiss();
            runOcr(photo.id, Uri.parse(photo.uri), store.name, true);
        });
        delete.setOnClickListener(v -> {
            AlertDialog confirm = new AlertDialog.Builder(this)
                    .setTitle("画像削除")
                    .setMessage(photo.managed ? "この撮影画像を端末から削除します。" : "この画像をPrice Rec.から外します。元の画像ファイルは削除しません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (d, w) -> {
                        Uri uri = Uri.parse(photo.uri);
                        if (photo.managed) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                        } else releaseImportedPermission(uri);
                        db.deletePhoto(photo.id);
                        DiagLog.write(this, "DELETE_PHOTO id=" + photo.id + " managed=" + photo.managed);
                        dialog.dismiss();
                        reloadStores();
                    }).create();
            showRoundedDialog(confirm);
        });
        showRoundedDialog(dialog);
    }

    private void importImages(DatabaseHelper.Store store) {
        long selected = selectedTagForStore(store.id);
        pendingImportStoreId = store.id;
        pendingImportTagId = selected < 0 ? null : selected;
        try {
            PickVisualMediaRequest request = new PickVisualMediaRequest.Builder()
                    .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                    .build();
            DiagLog.write(this, "PHOTO_PICKER_START store=" + store.id + " tag=" + pendingImportTagId);
            photoPicker.launch(request);
        } catch (Exception e) {
            clearPendingImportState();
            DiagLog.write(this, "PHOTO_PICKER_ERROR " + e);
            Toast.makeText(this, "画像を選択できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void handlePhotoPickerUris(List<Uri> uris) {
        if (pendingImportStoreId < 0) return;
        if (uris == null || uris.isEmpty()) {
            DiagLog.write(this, "PHOTO_PICKER_CANCEL");
            clearPendingImportState();
            return;
        }
        DatabaseHelper.Store store = findStore(pendingImportStoreId);
        String storeName = store == null ? "店舗" : store.name;
        long storeId = pendingImportStoreId;
        Long tagId = pendingImportTagId;
        int added = 0;
        for (Uri uri : uris) {
            if (uri == null) continue;
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) {
                DiagLog.write(this, "PHOTO_PICKER_PERMISSION_WARN uri=" + uri + " err=" + e);
            }
            long id = db.addPhoto(storeId, tagId, uri.toString(), false);
            if (id > 0) {
                added++;
                boolean showSheet = uris.size() == 1;
                runOcr(id, uri, storeName, showSheet);
            }
        }
        clearPendingImportState();
        expandedStoreId = storeId;
        activeTab.put(storeId, "images");
        Toast.makeText(this, added + "枚追加しました", Toast.LENGTH_SHORT).show();
        reloadStores();
    }

    private DatabaseHelper.Store findStore(long id) {
        for (DatabaseHelper.Store s : db.listStores()) if (s.id == id) return s;
        return null;
    }

    private void clearPendingImportState() {
        pendingImportStoreId = -1L;
        pendingImportTagId = null;
    }

    private void releaseImportedPermission(Uri uri) {
        try { getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
    }

    private void takePhoto(DatabaseHelper.Store store) {
        try {
            long selected = selectedTagForStore(store.id);
            pendingTagId = selected < 0 ? null : selected;
            pendingStoreId = store.id;
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "PriceRec_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PriceRec/" + safeFolder(store.name));
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            pendingPhotoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingPhotoUri == null) throw new IllegalStateException("MediaStore insert returned null");
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingPhotoUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            DiagLog.write(this, "CAMERA_START store=" + pendingStoreId + " tag=" + pendingTagId + " uri=" + pendingPhotoUri);
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception e) {
            DiagLog.write(this, "CAMERA_START_ERROR " + e);
            cleanupPendingPhoto();
            Toast.makeText(this, "カメラを起動できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAMERA) return;
        if (pendingPhotoUri == null) return;
        if (resultCode == RESULT_OK) {
            try {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(pendingPhotoUri, done, null, null);
                long photoId = db.addPhoto(pendingStoreId, pendingTagId, pendingPhotoUri.toString(), true);
                DatabaseHelper.Store store = findStore(pendingStoreId);
                String storeName = store == null ? "店舗" : store.name;
                DiagLog.write(this, "CAMERA_OK photo=" + photoId + " store=" + pendingStoreId);
                expandedStoreId = pendingStoreId;
                activeTab.put(pendingStoreId, "images");
                Uri uri = pendingPhotoUri;
                clearPendingPhotoState();
                reloadStores();
                if (photoId > 0) runOcr(photoId, uri, storeName, true);
                return;
            } catch (Exception e) {
                DiagLog.write(this, "CAMERA_SAVE_ERROR " + e);
                Toast.makeText(this, "画像の登録に失敗しました", Toast.LENGTH_LONG).show();
            }
        } else {
            try { getContentResolver().delete(pendingPhotoUri, null, null); } catch (Exception ignored) { }
        }
        clearPendingPhotoState();
        reloadStores();
    }

    private void cleanupPendingPhoto() {
        if (pendingPhotoUri != null) {
            try { getContentResolver().delete(pendingPhotoUri, null, null); } catch (Exception ignored) { }
        }
        clearPendingPhotoState();
    }

    private void clearPendingPhotoState() {
        pendingPhotoUri = null;
        pendingStoreId = -1L;
        pendingTagId = null;
    }

    private void runOcr(long photoId, Uri uri, String storeName, boolean showSheet) {
        db.setPhotoOcrState(photoId, "processing", null);
        DiagLog.write(this, "OCR_START photo=" + photoId + " uri=" + uri);
        reloadStores();
        DatabaseHelper.Photo ocrPhoto = db.getPhoto(photoId);
        String ocrTagName = ocrPhoto == null ? null : ocrPhoto.tagName;
        OcrEngine.recognize(this, uri, ocrTagName, new OcrEngine.Callback() {
            @Override
            public void onSuccess(String rawText, List<DatabaseHelper.ProductInput> products) {
                db.replaceProductsForPhoto(photoId, products, rawText);
                DiagLog.write(MainActivity.this, "OCR_OK photo=" + photoId + " products=" + products.size() + " chars=" + rawText.length());
                DatabaseHelper.Photo savedPhoto = db.getPhoto(photoId);
                if (savedPhoto != null) activeTab.put(savedPhoto.storeId, "list");
                reloadStores();
                if (showSheet) showOcrSheet(photoId, storeName + " / OCR結果");
            }

            @Override
            public void onError(Exception error) {
                db.setPhotoOcrState(photoId, "error", null);
                DiagLog.write(MainActivity.this, "OCR_ERROR photo=" + photoId + " err=" + error);
                reloadStores();
                Toast.makeText(MainActivity.this, "OCRに失敗しました", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showOcrSheet(long photoId, String title) {
        DatabaseHelper.Photo photo = db.getPhoto(photoId);
        List<DatabaseHelper.ProductRecord> existing = db.listProductsForPhoto(photoId);
        LinearLayout editors = new LinearLayout(this);
        editors.setOrientation(LinearLayout.VERTICAL);
        ArrayList<OcrEditorRow> rowEditors = new ArrayList<>();
        editors.addView(sheetHeader(new String[]{"商品名", "価格", ""}, new int[]{260, 110, 50}));
        for (DatabaseHelper.ProductRecord p : existing) addOcrEditorRow(editors, rowEditors, p.rawName, p.priceYen);
        if (existing.isEmpty()) addOcrEditorRow(editors, rowEditors, "", null);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(4), dp(8), dp(4));
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.addView(editors);
        ScrollView vsv = new ScrollView(this);
        vsv.addView(hsv);
        content.addView(vsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));
        TextView add = text("＋ 商品", 15, LBLUE, true);
        add.setGravity(Gravity.CENTER_VERTICAL);
        add.setPadding(dp(8), dp(10), dp(8), dp(8));
        add.setOnClickListener(v -> addOcrEditorRow(editors, rowEditors, "", null));
        content.addView(add);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            ArrayList<DatabaseHelper.ProductInput> rows = new ArrayList<>();
            for (OcrEditorRow r : rowEditors) {
                if (r.row.getParent() == null) continue;
                String name = r.name.getText().toString().trim();
                if (name.isEmpty()) continue;
                Integer price = parsePriceInput(r.price.getText().toString());
                rows.add(new DatabaseHelper.ProductInput(name, price, null));
            }
            db.replaceProductsForPhoto(photoId, rows, photo == null ? null : photo.ocrRaw);
            DiagLog.write(this, "OCR_EDIT_SAVE photo=" + photoId + " rows=" + rows.size());
            dialog.dismiss();
            reloadStores();
        }));
        showRoundedDialog(dialog, true);
    }

    private void addOcrEditorRow(LinearLayout container, ArrayList<OcrEditorRow> list, String nameValue, Integer priceValue) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(2));
        EditText name = sheetEdit(nameValue, false);
        EditText price = sheetEdit(priceValue == null ? "" : String.valueOf(priceValue), true);
        TextView del = text("×", 22, LRED, true);
        del.setGravity(Gravity.CENTER);
        row.addView(name, new LinearLayout.LayoutParams(dp(260), dp(46)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(110), dp(46)); pp.leftMargin = dp(4);
        row.addView(price, pp);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(dp(50), dp(46)); dpv.leftMargin = dp(4);
        row.addView(del, dpv);
        OcrEditorRow editor = new OcrEditorRow(row, name, price);
        list.add(editor);
        del.setOnClickListener(v -> container.removeView(row));
        container.addView(row);
    }

    private Integer parsePriceInput(String s) {
        String digits = s == null ? "" : s.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return null;
        try { return Integer.parseInt(digits); } catch (NumberFormatException e) { return null; }
    }

    private void runSearch(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) return;
        hideKeyboard(searchInput);
        List<DatabaseHelper.ProductRecord> results = db.searchProducts(q);
        showProductTableDialog("検索: " + q, results);
    }

    private void showAppMenu() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("PRICE REC.")
                .setItems(new String[]{"全リスト表示", "診断ログ"}, (d, which) -> {
                    if (which == 0) showAllList(); else showDiagnosticLog();
                }).create();
        showRoundedDialog(dialog);
    }

    private void showAllList() {
        showProductTableDialog("全リスト", db.listAllProducts());
    }

    private void showProductTableDialog(String title, List<DatabaseHelper.ProductRecord> products) {
        if (products.isEmpty()) {
            AlertDialog empty = new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage("商品データはまだありません。")
                    .setPositiveButton("閉じる", null).create();
            showRoundedDialog(empty);
            return;
        }
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        int[] widths = {260, 180, 110, 110, 150};
        sheet.addView(sheetHeader(new String[]{"商品名", "店舗", "価格", "タグ", "日付"}, widths));
        String last = null;
        for (DatabaseHelper.ProductRecord p : products) {
            String key = p.normalizedName == null ? p.rawName : p.normalizedName;
            String productCell = key.equals(last) ? "" : p.rawName;
            last = key;
            LinearLayout row = sheetRow(new String[]{productCell, p.storeName, p.priceYen == null ? "—" : yen(p.priceYen),
                    p.tagName == null ? "—" : p.tagName, dateFormat.format(new Date(p.photoCreatedAt))}, widths);
            row.setOnClickListener(v -> showOcrSheet(p.photoId, p.storeName + " / OCR結果"));
            sheet.addView(row);
        }
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.addView(sheet);
        ScrollView vsv = new ScrollView(this);
        vsv.addView(hsv);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(vsv)
                .setNegativeButton("閉じる", null)
                .create();
        showRoundedDialog(dialog, true);
    }

    private void showDiagnosticLog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(16), dp(20), dp(10));

        TextView title = text("診断ログ", 21, WHITE, true);
        panel.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        TextView body = text(DiagLog.report(this), 11, WHITE, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(10), dp(8), dp(10), dp(8));
        body.setBackground(roundRect(DGRAY, 10));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(8), 0, 0);

        TextView clearAction = makeDialogAction("ログ消去");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);

        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));

        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .create();

        clearAction.setOnClickListener(v -> {
            DiagLog.clear(this);
            body.setText(DiagLog.report(this));
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        copyAction.setOnClickListener(v -> {
            String report = DiagLog.report(this);
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("PriceRec diagnostic", report));
            Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
        });
        closeAction.setOnClickListener(v -> dialog.dismiss());

        showRoundedDialog(dialog, true);
    }

    private long selectedTagForStore(long storeId) {
        long id = getPreferences(MODE_PRIVATE).getLong("selected_tag_" + storeId, Long.MIN_VALUE);
        if (id == -1L) return -1L;
        if (id != Long.MIN_VALUE && db.tagExists(id)) return id;
        List<DatabaseHelper.Tag> tags = db.listTags();
        return tags.isEmpty() ? -1L : tags.get(0).id;
    }

    private void saveSelectedTag(long storeId, long tagId) {
        getPreferences(MODE_PRIVATE).edit().putLong("selected_tag_" + storeId, tagId).apply();
    }

    private String safeFolder(String name) {
        String s = name.replace('/', '_').replace('\\', '_').trim();
        return s.isEmpty() ? "Store" : s;
    }

    private String ocrStatusLabel(String s) {
        if (s == null || "pending".equals(s)) return "未解析";
        if ("processing".equals(s)) return "解析中";
        if ("done".equals(s)) return "完了";
        if ("no_results".equals(s)) return "候補なし";
        if ("error".equals(s)) return "エラー";
        return s;
    }

    private Bitmap loadBitmap(Uri uri, int targetW, int targetH) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
                int w = info.getSize().getWidth();
                int h = info.getSize().getHeight();
                if (w <= 0 || h <= 0) return;
                double scale = Math.min(1.0, Math.min((double) targetW / w, (double) targetH / h));
                decoder.setTargetSize(Math.max(1, (int) (w * scale)), Math.max(1, (int) (h * scale)));
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            });
        } catch (Exception e) {
            DiagLog.write(this, "IMAGE_LOAD_ERROR uri=" + uri + " err=" + e);
            return null;
        }
    }

    private String yen(int price) {
        return "¥" + NumberFormat.getIntegerInstance(Locale.JAPAN).format(price);
    }

    private View wrapHorizontal(View child) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(child);
        return hsv;
    }

    private LinearLayout sheetHeader(String[] values, int[] widthsDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(DGRAY);
        for (int i = 0; i < values.length; i++) {
            TextView cell = text(values[i], 13, SECONDARY, true);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            row.addView(cell, new LinearLayout.LayoutParams(dp(widthsDp[i]), dp(38)));
        }
        return row;
    }

    private LinearLayout sheetRow(String[] values, int[] widthsDp) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(1), 0, dp(1));
        for (int i = 0; i < values.length; i++) {
            TextView cell = text(values[i] == null ? "" : values[i], 14, WHITE, false);
            cell.setGravity(Gravity.CENTER_VERTICAL);
            cell.setPadding(dp(10), 0, dp(10), 0);
            row.addView(cell, new LinearLayout.LayoutParams(dp(widthsDp[i]), dp(44)));
        }
        return row;
    }

    private EditText sheetEdit(String value, boolean numeric) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(14);
        e.setTextColor(WHITE);
        e.setHintTextColor(Color.parseColor("#888383"));
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER_VERTICAL);
        e.setIncludeFontPadding(false);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setBackground(roundRect(DGRAY, 8));
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView button(String value, int color, float sp) {
        TextView t = text(value, sp, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundRect(color, 16));
        return t;
    }

    private TextView chip(String value, boolean selected, boolean secondary) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? (secondary ? ORANGE : LBLUE) : DGRAY, 17));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView dialogChip(String value, boolean selected) {
        TextView t = text(value, 14, WHITE, selected);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(roundRect(selected ? LBLUE : DGRAY, 17));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
        lp.rightMargin = dp(7);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView makeDialogAction(String value) {
        TextView t = text(value, 14, LBLUE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), 0, dp(8), 0);
        t.setBackgroundColor(Color.TRANSPARENT);
        return t;
    }

    private EditText dialogInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setTextSize(17);
        input.setTextColor(WHITE);
        input.setHintTextColor(Color.parseColor("#9E9999"));
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setIncludeFontPadding(false);
        input.setMinHeight(dp(48));
        input.setPadding(dp(16), 0, dp(16), 0);
        input.setBackground(roundRect(DGRAY, 10));
        input.setOnFocusChangeListener((v, hasFocus) -> input.setBackground(roundRect(hasFocus ? BLUE : DGRAY, 10)));
        return input;
    }

    private void focusAndShowKeyboard(EditText input, AlertDialog dialog) {
        Window w = dialog.getWindow();
        if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        input.postDelayed(() -> {
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }, 120);
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private void showRoundedDialog(AlertDialog dialog) {
        showRoundedDialog(dialog, false);
    }

    private void showRoundedDialog(AlertDialog dialog, boolean wide) {
        dialog.show();
        Window window = dialog.getWindow();
        if (window == null) return;
        window.setBackgroundDrawable(roundRect(GRAY, 20));
        if (wide) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private GradientDrawable roundRect(int fill, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable circle(int fill) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class DragPayload {
        final String type; final long id;
        DragPayload(String type, long id) { this.type = type; this.id = id; }
    }

    private static final class OcrEditorRow {
        final LinearLayout row; final EditText name; final EditText price;
        OcrEditorRow(LinearLayout row, EditText name, EditText price) { this.row = row; this.name = name; this.price = price; }
    }
}
