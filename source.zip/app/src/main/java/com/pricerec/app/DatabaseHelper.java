package com.pricerec.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public final class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "price_rec.db";
    private static final int DB_VERSION = 2;

    DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE stores (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "sort_order INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE tags (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL UNIQUE COLLATE NOCASE," +
                "sort_order INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE photos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "store_id INTEGER NOT NULL," +
                "tag_id INTEGER," +
                "uri TEXT NOT NULL UNIQUE," +
                "managed INTEGER NOT NULL DEFAULT 1," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE," +
                "FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE SET NULL)");

        db.execSQL("CREATE TABLE products (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "photo_id INTEGER NOT NULL," +
                "raw_name TEXT NOT NULL," +
                "normalized_name TEXT," +
                "price_yen INTEGER," +
                "confidence REAL," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(photo_id) REFERENCES photos(id) ON DELETE CASCADE)");

        long now = System.currentTimeMillis();
        insertTagInternal(db, "酒", 0, now);
        insertTagInternal(db, "肉", 1, now + 1);
        insertTagInternal(db, "調味料", 2, now + 2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE stores ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE tags ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE photos ADD COLUMN managed INTEGER NOT NULL DEFAULT 1");
            normalizeOrder(db, "stores", "created_at ASC, id ASC");
            normalizeOrder(db, "tags", "created_at ASC, id ASC");
        }
    }

    private static void insertTagInternal(SQLiteDatabase db, String name, int sortOrder, long createdAt) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("sort_order", sortOrder);
        v.put("created_at", createdAt);
        db.insert("tags", null, v);
    }

    private static int nextSortOrder(SQLiteDatabase db, String table) {
        try (Cursor c = db.rawQuery("SELECT COALESCE(MAX(sort_order), -1) + 1 FROM " + table, null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private static void normalizeOrder(SQLiteDatabase db, String table, String initialOrder) {
        ArrayList<Long> ids = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT id FROM " + table + " ORDER BY " + initialOrder, null)) {
            while (c.moveToNext()) ids.add(c.getLong(0));
        }
        updateOrder(db, table, ids);
    }

    private static void updateOrder(SQLiteDatabase db, String table, List<Long> ids) {
        for (int i = 0; i < ids.size(); i++) {
            ContentValues v = new ContentValues();
            v.put("sort_order", i);
            db.update(table, v, "id=?", new String[]{String.valueOf(ids.get(i))});
        }
    }

    private void moveItem(String table, long draggedId, long targetId, boolean after) {
        if (draggedId == targetId) return;
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            ArrayList<Long> ids = new ArrayList<>();
            try (Cursor c = writable.rawQuery(
                    "SELECT id FROM " + table + " ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
                while (c.moveToNext()) ids.add(c.getLong(0));
            }
            if (!ids.remove(draggedId)) return;
            int targetIndex = ids.indexOf(targetId);
            if (targetIndex < 0) return;
            int insertIndex = after ? targetIndex + 1 : targetIndex;
            if (insertIndex < 0) insertIndex = 0;
            if (insertIndex > ids.size()) insertIndex = ids.size();
            ids.add(insertIndex, draggedId);
            updateOrder(writable, table, ids);
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    long addStore(String name) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("sort_order", nextSortOrder(writable, "stores"));
        v.put("created_at", System.currentTimeMillis());
        return writable.insert("stores", null, v);
    }

    void renameStore(long id, String name) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        getWritableDatabase().update("stores", v, "id=?", new String[]{String.valueOf(id)});
    }

    void deleteStore(long id) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.delete("stores", "id=?", new String[]{String.valueOf(id)});
        normalizeOrder(writable, "stores", "sort_order ASC, created_at ASC, id ASC");
    }

    void moveStore(long draggedId, long targetId, boolean after) {
        moveItem("stores", draggedId, targetId, after);
    }

    List<Store> listStores() {
        ArrayList<Store> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order FROM stores ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
            while (c.moveToNext()) {
                out.add(new Store(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3)));
            }
        }
        return out;
    }

    long addTag(String name) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("sort_order", nextSortOrder(writable, "tags"));
        v.put("created_at", System.currentTimeMillis());
        return writable.insertWithOnConflict("tags", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    }

    void deleteTag(long id) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.delete("tags", "id=?", new String[]{String.valueOf(id)});
        normalizeOrder(writable, "tags", "sort_order ASC, created_at ASC, id ASC");
    }

    void moveTag(long draggedId, long targetId, boolean after) {
        moveItem("tags", draggedId, targetId, after);
    }

    boolean tagExists(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM tags WHERE id=? LIMIT 1",
                new String[]{String.valueOf(id)})) {
            return c.moveToFirst();
        }
    }

    List<Tag> listTags() {
        ArrayList<Tag> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order FROM tags ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
            while (c.moveToNext()) {
                out.add(new Tag(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3)));
            }
        }
        return out;
    }

    long addPhoto(long storeId, Long tagId, String uri, boolean managed) {
        ContentValues v = new ContentValues();
        v.put("store_id", storeId);
        if (tagId == null) v.putNull("tag_id"); else v.put("tag_id", tagId);
        v.put("uri", uri);
        v.put("managed", managed ? 1 : 0);
        v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("photos", null, v);
    }

    void updatePhotoTag(long photoId, Long tagId) {
        ContentValues v = new ContentValues();
        if (tagId == null) v.putNull("tag_id"); else v.put("tag_id", tagId);
        getWritableDatabase().update("photos", v, "id=?", new String[]{String.valueOf(photoId)});
    }

    void deletePhoto(long photoId) {
        getWritableDatabase().delete("photos", "id=?", new String[]{String.valueOf(photoId)});
    }

    List<Photo> listPhotos(long storeId) {
        ArrayList<Photo> out = new ArrayList<>();
        String sql = "SELECT p.id,p.store_id,p.tag_id,p.uri,p.created_at,t.name,p.managed " +
                "FROM photos p LEFT JOIN tags t ON t.id=p.tag_id " +
                "WHERE p.store_id=? ORDER BY p.created_at DESC, p.id DESC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(storeId)})) {
            while (c.moveToNext()) {
                Long tagId = c.isNull(2) ? null : c.getLong(2);
                String tagName = c.isNull(5) ? null : c.getString(5);
                out.add(new Photo(c.getLong(0), c.getLong(1), tagId, c.getString(3), c.getLong(4), tagName, c.getInt(6) != 0));
            }
        }
        return out;
    }

    List<ProductRecord> listProductsForStore(long storeId) {
        ArrayList<ProductRecord> out = new ArrayList<>();
        String sql = "SELECT pr.id,pr.raw_name,pr.normalized_name,pr.price_yen,ph.id,ph.uri,t.name,pr.created_at " +
                "FROM products pr JOIN photos ph ON ph.id=pr.photo_id " +
                "LEFT JOIN tags t ON t.id=ph.tag_id WHERE ph.store_id=? " +
                "ORDER BY pr.raw_name COLLATE NOCASE ASC, pr.price_yen ASC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(storeId)})) {
            while (c.moveToNext()) {
                Integer price = c.isNull(3) ? null : c.getInt(3);
                out.add(new ProductRecord(c.getLong(0), c.getString(1), c.getString(2), price,
                        c.getLong(4), c.getString(5), c.isNull(6) ? null : c.getString(6), c.getLong(7), null));
            }
        }
        return out;
    }

    List<ProductRecord> searchProducts(String query) {
        ArrayList<ProductRecord> out = new ArrayList<>();
        String like = "%" + query + "%";
        String sql = "SELECT pr.id,pr.raw_name,pr.normalized_name,pr.price_yen,ph.id,ph.uri,t.name,pr.created_at,s.name " +
                "FROM products pr JOIN photos ph ON ph.id=pr.photo_id " +
                "JOIN stores s ON s.id=ph.store_id LEFT JOIN tags t ON t.id=ph.tag_id " +
                "WHERE pr.raw_name LIKE ? OR pr.normalized_name LIKE ? " +
                "ORDER BY CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC, s.name ASC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{like, like})) {
            while (c.moveToNext()) {
                Integer price = c.isNull(3) ? null : c.getInt(3);
                out.add(new ProductRecord(c.getLong(0), c.getString(1), c.getString(2), price,
                        c.getLong(4), c.getString(5), c.isNull(6) ? null : c.getString(6), c.getLong(7), c.getString(8)));
            }
        }
        return out;
    }

    static final class Store {
        final long id;
        final String name;
        final long createdAt;
        final int sortOrder;
        Store(long id, String name, long createdAt, int sortOrder) {
            this.id = id; this.name = name; this.createdAt = createdAt; this.sortOrder = sortOrder;
        }
    }

    static final class Tag {
        final long id;
        final String name;
        final long createdAt;
        final int sortOrder;
        Tag(long id, String name, long createdAt, int sortOrder) {
            this.id = id; this.name = name; this.createdAt = createdAt; this.sortOrder = sortOrder;
        }
    }

    static final class Photo {
        final long id;
        final long storeId;
        final Long tagId;
        final String uri;
        final long createdAt;
        final String tagName;
        final boolean managed;
        Photo(long id, long storeId, Long tagId, String uri, long createdAt, String tagName, boolean managed) {
            this.id = id; this.storeId = storeId; this.tagId = tagId; this.uri = uri; this.createdAt = createdAt;
            this.tagName = tagName; this.managed = managed;
        }
    }

    static final class ProductRecord {
        final long id;
        final String rawName;
        final String normalizedName;
        final Integer priceYen;
        final long photoId;
        final String photoUri;
        final String tagName;
        final long createdAt;
        final String storeName;
        ProductRecord(long id, String rawName, String normalizedName, Integer priceYen, long photoId,
                      String photoUri, String tagName, long createdAt, String storeName) {
            this.id = id; this.rawName = rawName; this.normalizedName = normalizedName; this.priceYen = priceYen;
            this.photoId = photoId; this.photoUri = photoUri; this.tagName = tagName; this.createdAt = createdAt; this.storeName = storeName;
        }
    }
}
