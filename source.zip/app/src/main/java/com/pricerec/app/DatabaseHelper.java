package com.pricerec.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public final class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "price_rec.db";
    private static final int DB_VERSION = 5;
    private static final String VIRTUAL_IMPORT_PREFIX = "pricerec://import/";

    DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE stores (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "sort_order INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE tags (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL UNIQUE COLLATE NOCASE," +
                "sort_order INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE photos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "store_id INTEGER NOT NULL," +
                "tag_id INTEGER," +
                "uri TEXT NOT NULL UNIQUE," +
                "managed INTEGER NOT NULL DEFAULT 1," +
                "ocr_raw TEXT," +
                "ocr_status TEXT NOT NULL DEFAULT 'pending'," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE," +
                "FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE SET NULL)");

        db.execSQL("CREATE TABLE products (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "photo_id INTEGER NOT NULL," +
                "raw_name TEXT NOT NULL," +
                "normalized_name TEXT," +
                "price_yen INTEGER," +
                "confidence REAL," +
                "product_key TEXT," +
                "volume TEXT," +
                "price_type TEXT," +
                "source_image TEXT," +
                "tag_id INTEGER," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(photo_id) REFERENCES photos(id) ON DELETE CASCADE)");

        long now = System.currentTimeMillis();
        insertTagInternal(db, "酒", 0, now);
        insertTagInternal(db, "肉", 1, now + 1);
        insertTagInternal(db, "調味料", 2, now + 2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE stores ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE tags ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE photos ADD COLUMN managed INTEGER NOT NULL DEFAULT 1");
            normalizeOrder(db, "stores", "created_at ASC, id ASC");
            normalizeOrder(db, "tags", "created_at ASC, id ASC");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE photos ADD COLUMN ocr_raw TEXT");
            db.execSQL("ALTER TABLE photos ADD COLUMN ocr_status TEXT NOT NULL DEFAULT 'pending'");
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE products ADD COLUMN product_key TEXT");
            db.execSQL("ALTER TABLE products ADD COLUMN volume TEXT");
            db.execSQL("ALTER TABLE products ADD COLUMN price_type TEXT");
            db.execSQL("ALTER TABLE products ADD COLUMN source_image TEXT");
            db.execSQL("UPDATE products SET product_key=raw_name WHERE product_key IS NULL");
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE products ADD COLUMN tag_id INTEGER");
            db.execSQL("UPDATE products SET tag_id=(SELECT tag_id FROM photos WHERE photos.id=products.photo_id) WHERE tag_id IS NULL");
        }
    }

    private static void insertTagInternal(SQLiteDatabase db, String name, int sortOrder, long createdAt) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("sort_order", sortOrder);
        v.put("created_at", createdAt);
        db.insert("tags", null, v);
    }

    private static int nextSortOrder(SQLiteDatabase db, String table) {
        try (Cursor c = db.rawQuery("SELECT COALESCE(MAX(sort_order), -1) + 1 FROM " + table, null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private static void normalizeOrder(SQLiteDatabase db, String table, String initialOrder) {
        ArrayList<Long> ids = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT id FROM " + table + " ORDER BY " + initialOrder, null)) {
            while (c.moveToNext()) ids.add(c.getLong(0));
        }
        updateOrder(db, table, ids);
    }

    private static void updateOrder(SQLiteDatabase db, String table, List<Long> ids) {
        for (int i = 0; i < ids.size(); i++) {
            ContentValues v = new ContentValues();
            v.put("sort_order", i);
            db.update(table, v, "id=?", new String[]{String.valueOf(ids.get(i))});
        }
    }

    private void moveItem(String table, long draggedId, long targetId, boolean after) {
        if (draggedId == targetId) return;
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            ArrayList<Long> ids = new ArrayList<>();
            try (Cursor c = writable.rawQuery(
                    "SELECT id FROM " + table + " ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
                while (c.moveToNext()) ids.add(c.getLong(0));
            }
            if (!ids.remove(draggedId)) return;
            int targetIndex = ids.indexOf(targetId);
            if (targetIndex < 0) return;
            int insertIndex = after ? targetIndex + 1 : targetIndex;
            if (insertIndex < 0) insertIndex = 0;
            if (insertIndex > ids.size()) insertIndex = ids.size();
            ids.add(insertIndex, draggedId);
            updateOrder(writable, table, ids);
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    long addStore(String name) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("sort_order", nextSortOrder(writable, "stores"));
        v.put("created_at", System.currentTimeMillis());
        return writable.insert("stores", null, v);
    }

    long ensureStore(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) return -1L;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM stores WHERE name=? COLLATE NOCASE ORDER BY id ASC LIMIT 1", new String[]{n})) {
            if (c.moveToFirst()) return c.getLong(0);
        }
        return addStore(n);
    }

    Store findStoreByName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) return null;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order FROM stores WHERE name=? COLLATE NOCASE ORDER BY id ASC LIMIT 1", new String[]{n})) {
            if (!c.moveToFirst()) return null;
            return new Store(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3));
        }
    }

    Store getStore(long id) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order FROM stores WHERE id=?", new String[]{String.valueOf(id)})) {
            if (!c.moveToFirst()) return null;
            return new Store(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3));
        }
    }

    void renameStore(long id, String name) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        getWritableDatabase().update("stores", v, "id=?", new String[]{String.valueOf(id)});
    }

    void deleteStore(long id) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.delete("stores", "id=?", new String[]{String.valueOf(id)});
        normalizeOrder(writable, "stores", "sort_order ASC, created_at ASC, id ASC");
    }

    void moveStore(long draggedId, long targetId, boolean after) {
        moveItem("stores", draggedId, targetId, after);
    }

    List<Store> listStores() {
        ArrayList<Store> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order FROM stores ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
            while (c.moveToNext()) out.add(new Store(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3)));
        }
        return out;
    }

    long addTag(String name) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("sort_order", nextSortOrder(writable, "tags"));
        v.put("created_at", System.currentTimeMillis());
        return writable.insertWithOnConflict("tags", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    }

    Long ensureTag(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || "タグなし".equals(n) || "—".equals(n) || "-".equals(n)) return null;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM tags WHERE name=? COLLATE NOCASE LIMIT 1", new String[]{n})) {
            if (c.moveToFirst()) return c.getLong(0);
        }
        long id = addTag(n);
        if (id > 0) return id;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM tags WHERE name=? COLLATE NOCASE LIMIT 1", new String[]{n})) {
            return c.moveToFirst() ? c.getLong(0) : null;
        }
    }

    void deleteTag(long id) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues clear = new ContentValues();
        clear.putNull("tag_id");
        writable.update("products", clear, "tag_id=?", new String[]{String.valueOf(id)});
        writable.delete("tags", "id=?", new String[]{String.valueOf(id)});
        normalizeOrder(writable, "tags", "sort_order ASC, created_at ASC, id ASC");
    }

    void moveTag(long draggedId, long targetId, boolean after) {
        moveItem("tags", draggedId, targetId, after);
    }

    boolean tagExists(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM tags WHERE id=? LIMIT 1", new String[]{String.valueOf(id)})) {
            return c.moveToFirst();
        }
    }

    List<Tag> listTags() {
        ArrayList<Tag> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order FROM tags ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
            while (c.moveToNext()) out.add(new Tag(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3)));
        }
        return out;
    }

    long addPhoto(long storeId, Long tagId, String uri, boolean managed) {
        return addPhotoAt(storeId, tagId, uri, managed, System.currentTimeMillis(), "pending");
    }

    long addPhotoAt(long storeId, Long tagId, String uri, boolean managed, long createdAt, String status) {
        ContentValues v = new ContentValues();
        v.put("store_id", storeId);
        if (tagId == null) v.putNull("tag_id"); else v.put("tag_id", tagId);
        v.put("uri", uri);
        v.put("managed", managed ? 1 : 0);
        v.put("ocr_status", status == null ? "pending" : status);
        v.put("created_at", createdAt > 0 ? createdAt : System.currentTimeMillis());
        return getWritableDatabase().insert("photos", null, v);
    }

    long createVirtualImportPhoto(long storeId, Long tagId, long capturedAt, String sourceImage) {
        String safe = sourceImage == null ? "unknown" : sourceImage.replaceAll("[^0-9A-Za-z._-]", "_");
        String uri = VIRTUAL_IMPORT_PREFIX + System.currentTimeMillis() + "/" + storeId + "/" + safe + "/" + Math.abs((long) (Math.random() * Long.MAX_VALUE));
        return addPhotoAt(storeId, tagId, uri, false, capturedAt, "imported");
    }

    boolean isVirtualImportPhoto(Photo photo) {
        return photo != null && photo.uri != null && photo.uri.startsWith(VIRTUAL_IMPORT_PREFIX);
    }

    void updatePhotoTag(long photoId, Long tagId) {
        ContentValues v = new ContentValues();
        if (tagId == null) v.putNull("tag_id"); else v.put("tag_id", tagId);
        getWritableDatabase().update("photos", v, "id=?", new String[]{String.valueOf(photoId)});
    }

    void setPhotoOcrState(long photoId, String status, String rawText) {
        ContentValues v = new ContentValues();
        v.put("ocr_status", status);
        if (rawText == null) v.putNull("ocr_raw"); else v.put("ocr_raw", rawText);
        getWritableDatabase().update("photos", v, "id=?", new String[]{String.valueOf(photoId)});
    }

    void replaceProductsForPhoto(long photoId, List<ProductInput> products, String rawText) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            writable.delete("products", "photo_id=?", new String[]{String.valueOf(photoId)});
            long now = System.currentTimeMillis();
            Long photoTagId = tagIdForPhoto(writable, photoId);
            for (ProductInput p : products) {
                if (p.name == null || p.name.trim().isEmpty()) continue;
                ContentValues v = productValues(photoId, p.name, p.name, p.priceYen, null, null, null, now++);
                putNullableLong(v, "tag_id", photoTagId);
                if (p.confidence == null) v.putNull("confidence"); else v.put("confidence", p.confidence);
                writable.insert("products", null, v);
            }
            ContentValues photo = new ContentValues();
            photo.put("ocr_raw", rawText);
            photo.put("ocr_status", products.isEmpty() ? "no_results" : "done");
            writable.update("photos", photo, "id=?", new String[]{String.valueOf(photoId)});
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    private static ContentValues productValues(long photoId, String name, String productKey, Integer priceYen,
                                                String volume, String priceType, String sourceImage, long createdAt) {
        String displayName = name == null ? "" : name.trim();
        String key = productKey == null || productKey.trim().isEmpty() ? displayName : productKey.trim();
        ContentValues v = new ContentValues();
        v.put("photo_id", photoId);
        v.put("raw_name", displayName);
        v.put("normalized_name", normalizeName(key));
        if (priceYen == null) v.putNull("price_yen"); else v.put("price_yen", priceYen);
        v.putNull("confidence");
        v.put("product_key", key);
        if (volume == null || volume.trim().isEmpty()) v.putNull("volume"); else v.put("volume", volume.trim());
        if (priceType == null || priceType.trim().isEmpty()) v.putNull("price_type"); else v.put("price_type", priceType.trim());
        if (sourceImage == null || sourceImage.trim().isEmpty()) v.putNull("source_image"); else v.put("source_image", sourceImage.trim());
        v.put("created_at", createdAt > 0 ? createdAt : System.currentTimeMillis());
        return v;
    }

    long insertImportedProduct(long photoId, String name, String productKey, Integer priceYen,
                               String volume, String priceType, String sourceImage) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = productValues(photoId, name, productKey, priceYen, volume, priceType, sourceImage, System.currentTimeMillis());
        putNullableLong(v, "tag_id", tagIdForPhoto(writable, photoId));
        return writable.insert("products", null, v);
    }

    void updateImportedProduct(long productId, long photoId, String name, String productKey, Integer priceYen,
                               String volume, String priceType, String sourceImage) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = productValues(photoId, name, productKey, priceYen, volume, priceType, sourceImage, System.currentTimeMillis());
        putNullableLong(v, "tag_id", tagIdForPhoto(writable, photoId));
        writable.update("products", v, "id=?", new String[]{String.valueOf(productId)});
    }

    private static void putNullableLong(ContentValues v, String key, Long value) {
        if (value == null) v.putNull(key); else v.put(key, value);
    }

    private static Long tagIdForPhoto(SQLiteDatabase db, long photoId) {
        try (Cursor c = db.rawQuery("SELECT tag_id FROM photos WHERE id=?", new String[]{String.valueOf(photoId)})) {
            if (!c.moveToFirst() || c.isNull(0)) return null;
            return c.getLong(0);
        }
    }

    ProductRecord findLatestProductInStore(long storeId, String productKey) {
        String normalized = normalizeName(productKey);
        if (normalized.isEmpty()) return null;
        List<ProductRecord> found = queryProducts("WHERE s.id=? AND pr.normalized_name=?",
                new String[]{String.valueOf(storeId), normalized}, "ORDER BY ph.created_at DESC, pr.id DESC LIMIT 1");
        return found.isEmpty() ? null : found.get(0);
    }

    void updateProduct(long id, String name, Integer priceYen) {
        ContentValues v = new ContentValues();
        v.put("raw_name", name.trim());
        v.put("normalized_name", normalizeName(name));
        v.put("product_key", name.trim());
        if (priceYen == null) v.putNull("price_yen"); else v.put("price_yen", priceYen);
        getWritableDatabase().update("products", v, "id=?", new String[]{String.valueOf(id)});
    }

    void updateProductDetails(long id, String name, String productKey, Integer priceYen,
                              String volume, String priceType, Long tagId) {
        String displayName = name == null ? "" : name.trim();
        String key = productKey == null || productKey.trim().isEmpty() ? displayName : productKey.trim();
        ContentValues v = new ContentValues();
        v.put("raw_name", displayName);
        v.put("normalized_name", normalizeName(key));
        v.put("product_key", key);
        if (priceYen == null) v.putNull("price_yen"); else v.put("price_yen", priceYen);
        if (volume == null || volume.trim().isEmpty()) v.putNull("volume"); else v.put("volume", volume.trim());
        if (priceType == null || priceType.trim().isEmpty()) v.putNull("price_type"); else v.put("price_type", priceType.trim());
        putNullableLong(v, "tag_id", tagId);
        getWritableDatabase().update("products", v, "id=?", new String[]{String.valueOf(id)});
    }

    void updateProductsTag(List<Long> ids, Long tagId) {
        if (ids == null || ids.isEmpty()) return;
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            putNullableLong(v, "tag_id", tagId);
            for (Long id : ids) {
                if (id != null) writable.update("products", v, "id=?", new String[]{String.valueOf(id)});
            }
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    void deleteProducts(List<Long> ids) {
        if (ids == null || ids.isEmpty()) return;
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            for (Long id : ids) {
                if (id != null) writable.delete("products", "id=?", new String[]{String.valueOf(id)});
            }
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    void deleteProduct(long id) {
        getWritableDatabase().delete("products", "id=?", new String[]{String.valueOf(id)});
    }

    void deletePhoto(long photoId) {
        getWritableDatabase().delete("photos", "id=?", new String[]{String.valueOf(photoId)});
    }

    Photo getPhoto(long photoId) {
        String sql = "SELECT p.id,p.store_id,p.tag_id,p.uri,p.created_at,t.name,p.managed,p.ocr_raw,p.ocr_status " +
                "FROM photos p LEFT JOIN tags t ON t.id=p.tag_id WHERE p.id=?";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(photoId)})) {
            if (!c.moveToFirst()) return null;
            return photoFromCursor(c);
        }
    }

    List<Photo> listPhotos(long storeId) {
        ArrayList<Photo> out = new ArrayList<>();
        String sql = "SELECT p.id,p.store_id,p.tag_id,p.uri,p.created_at,t.name,p.managed,p.ocr_raw,p.ocr_status " +
                "FROM photos p LEFT JOIN tags t ON t.id=p.tag_id WHERE p.store_id=? AND p.uri NOT LIKE ? " +
                "ORDER BY p.created_at DESC, p.id DESC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(storeId), VIRTUAL_IMPORT_PREFIX + "%"})) {
            while (c.moveToNext()) out.add(photoFromCursor(c));
        }
        return out;
    }

    private static Photo photoFromCursor(Cursor c) {
        Long tagId = c.isNull(2) ? null : c.getLong(2);
        String tagName = c.isNull(5) ? null : c.getString(5);
        return new Photo(c.getLong(0), c.getLong(1), tagId, c.getString(3), c.getLong(4), tagName,
                c.getInt(6) != 0, c.isNull(7) ? null : c.getString(7), c.getString(8));
    }

    List<ProductRecord> listProductsForStore(long storeId) {
        return queryProducts("WHERE ph.store_id=?", new String[]{String.valueOf(storeId)},
                "ORDER BY pr.normalized_name COLLATE NOCASE ASC, CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC");
    }

    List<ProductRecord> listProductsForPhoto(long photoId) {
        return queryProducts("WHERE ph.id=?", new String[]{String.valueOf(photoId)}, "ORDER BY pr.id ASC");
    }

    List<ProductRecord> listAllProducts() {
        return queryProducts("", null,
                "ORDER BY pr.normalized_name COLLATE NOCASE ASC, pr.raw_name COLLATE NOCASE ASC, " +
                        "CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC, s.sort_order ASC");
    }

    List<ProductRecord> searchProducts(String query) {
        String like = "%" + query + "%";
        return queryProducts("WHERE pr.raw_name LIKE ? OR pr.normalized_name LIKE ? OR pr.product_key LIKE ?",
                new String[]{like, like, like},
                "ORDER BY CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC, s.sort_order ASC");
    }

    private List<ProductRecord> queryProducts(String where, String[] args, String order) {
        ArrayList<ProductRecord> out = new ArrayList<>();
        String sql = "SELECT pr.id,pr.raw_name,pr.normalized_name,pr.price_yen,ph.id,ph.uri,pr.tag_id,t.name,pr.created_at," +
                "s.name,s.id,ph.created_at,pr.product_key,pr.volume,pr.price_type,pr.source_image FROM products pr " +
                "JOIN photos ph ON ph.id=pr.photo_id JOIN stores s ON s.id=ph.store_id " +
                "LEFT JOIN tags t ON t.id=pr.tag_id " + where + " " + order;
        try (Cursor c = getReadableDatabase().rawQuery(sql, args)) {
            while (c.moveToNext()) {
                Integer price = c.isNull(3) ? null : c.getInt(3);
                Long tagId = c.isNull(6) ? null : c.getLong(6);
                out.add(new ProductRecord(c.getLong(0), c.getString(1), c.getString(2), price,
                        c.getLong(4), c.getString(5), tagId, c.isNull(7) ? null : c.getString(7), c.getLong(8),
                        c.getString(9), c.getLong(10), c.getLong(11), c.isNull(12) ? null : c.getString(12),
                        c.isNull(13) ? null : c.getString(13), c.isNull(14) ? null : c.getString(14),
                        c.isNull(15) ? null : c.getString(15)));
            }
        }
        return out;
    }

    static String normalizeName(String input) {
        if (input == null) return "";
        return input.toLowerCase()
                .replace('　', ' ')
                .replaceAll("[\\s\\-‐‑–—_・･/／]+", "")
                .replaceAll("[^0-9a-zぁ-んァ-ヶ一-龠々ー]", "");
    }

    static final class Store {
        final long id; final String name; final long createdAt; final int sortOrder;
        Store(long id, String name, long createdAt, int sortOrder) {
            this.id = id; this.name = name; this.createdAt = createdAt; this.sortOrder = sortOrder;
        }
    }

    static final class Tag {
        final long id; final String name; final long createdAt; final int sortOrder;
        Tag(long id, String name, long createdAt, int sortOrder) {
            this.id = id; this.name = name; this.createdAt = createdAt; this.sortOrder = sortOrder;
        }
    }

    static final class Photo {
        final long id; final long storeId; final Long tagId; final String uri; final long createdAt;
        final String tagName; final boolean managed; final String ocrRaw; final String ocrStatus;
        Photo(long id, long storeId, Long tagId, String uri, long createdAt, String tagName,
              boolean managed, String ocrRaw, String ocrStatus) {
            this.id = id; this.storeId = storeId; this.tagId = tagId; this.uri = uri; this.createdAt = createdAt;
            this.tagName = tagName; this.managed = managed; this.ocrRaw = ocrRaw; this.ocrStatus = ocrStatus;
        }
    }

    static final class ProductInput {
        final String name; final Integer priceYen; final Float confidence;
        ProductInput(String name, Integer priceYen, Float confidence) {
            this.name = name; this.priceYen = priceYen; this.confidence = confidence;
        }
    }

    static final class ProductRecord {
        final long id; final String rawName; final String normalizedName; final Integer priceYen;
        final long photoId; final String photoUri; final Long tagId; final String tagName; final long createdAt;
        final String storeName; final long storeId; final long photoCreatedAt;
        final String productKey; final String volume; final String priceType; final String sourceImage;
        ProductRecord(long id, String rawName, String normalizedName, Integer priceYen, long photoId,
                      String photoUri, Long tagId, String tagName, long createdAt, String storeName, long storeId, long photoCreatedAt,
                      String productKey, String volume, String priceType, String sourceImage) {
            this.id = id; this.rawName = rawName; this.normalizedName = normalizedName; this.priceYen = priceYen;
            this.photoId = photoId; this.photoUri = photoUri; this.tagId = tagId; this.tagName = tagName; this.createdAt = createdAt;
            this.storeName = storeName; this.storeId = storeId; this.photoCreatedAt = photoCreatedAt;
            this.productKey = productKey; this.volume = volume; this.priceType = priceType; this.sourceImage = sourceImage;
        }
    }
}
