package com.pricerec.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public final class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "price_rec.db";
    private static final int DB_VERSION = 12;
    private static final String VIRTUAL_IMPORT_PREFIX = "pricerec://import/";

    DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE stores (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "sort_order INTEGER NOT NULL DEFAULT 0," +
                "enabled INTEGER NOT NULL DEFAULT 1," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE tags (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL UNIQUE COLLATE NOCASE," +
                "sort_order INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE photos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "store_id INTEGER NOT NULL," +
                "tag_id INTEGER," +
                "uri TEXT NOT NULL UNIQUE," +
                "managed INTEGER NOT NULL DEFAULT 1," +
                "ocr_raw TEXT," +
                "ocr_status TEXT NOT NULL DEFAULT 'pending'," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE," +
                "FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE SET NULL)");

        db.execSQL("CREATE TABLE products (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "photo_id INTEGER NOT NULL," +
                "store_id INTEGER," +
                "raw_name TEXT NOT NULL," +
                "normalized_name TEXT," +
                "price_yen INTEGER," +
                "confidence REAL," +
                "product_key TEXT," +
                "volume TEXT," +
                "price_type TEXT," +
                "source_image TEXT," +
                "tag_id INTEGER," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(photo_id) REFERENCES photos(id) ON DELETE CASCADE)");

        createProductTagsTable(db);
        createPhotoTagsTable(db);
        createImportHistoryTables(db);

        long now = System.currentTimeMillis();
        insertTagInternal(db, "酒", 0, now);
        insertTagInternal(db, "肉", 1, now + 1);
        insertTagInternal(db, "調味料", 2, now + 2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE stores ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE tags ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE photos ADD COLUMN managed INTEGER NOT NULL DEFAULT 1");
            normalizeOrder(db, "stores", "created_at ASC, id ASC");
            normalizeOrder(db, "tags", "created_at ASC, id ASC");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE photos ADD COLUMN ocr_raw TEXT");
            db.execSQL("ALTER TABLE photos ADD COLUMN ocr_status TEXT NOT NULL DEFAULT 'pending'");
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE products ADD COLUMN product_key TEXT");
            db.execSQL("ALTER TABLE products ADD COLUMN volume TEXT");
            db.execSQL("ALTER TABLE products ADD COLUMN price_type TEXT");
            db.execSQL("ALTER TABLE products ADD COLUMN source_image TEXT");
            db.execSQL("UPDATE products SET product_key=raw_name WHERE product_key IS NULL");
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE products ADD COLUMN tag_id INTEGER");
            db.execSQL("UPDATE products SET tag_id=(SELECT tag_id FROM photos WHERE photos.id=products.photo_id) WHERE tag_id IS NULL");
        }
        if (oldVersion < 6) {
            db.execSQL("ALTER TABLE products ADD COLUMN store_id INTEGER");
            db.execSQL("UPDATE products SET store_id=(SELECT store_id FROM photos WHERE photos.id=products.photo_id) WHERE store_id IS NULL");
            createImportHistoryTables(db);
            reconstructLegacyImportBatches(db);
        }
        if (oldVersion < 7) {
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_store_name TEXT");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_raw_name TEXT");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_product_key TEXT");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_price_yen INTEGER");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_volume TEXT");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_price_type TEXT");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_tag_id INTEGER");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_tag_name TEXT");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_source_image TEXT");
            db.execSQL("ALTER TABLE import_batch_items ADD COLUMN imported_created_at INTEGER");
            backfillImportSnapshots(db);
        }
        if (oldVersion >= 6 && oldVersion < 8) {
            db.execSQL("ALTER TABLE import_batches ADD COLUMN raw_csv TEXT");
        }
        if (oldVersion >= 6 && oldVersion < 9) {
            db.execSQL("ALTER TABLE import_batches ADD COLUMN quality_score INTEGER NOT NULL DEFAULT 50");
            db.execSQL("ALTER TABLE import_batches ADD COLUMN row_count INTEGER NOT NULL DEFAULT 0");
        }
        if (oldVersion < 10) {
            db.execSQL("ALTER TABLE stores ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1");
        }
        if (oldVersion < 11) {
            createProductTagsTable(db);
            db.execSQL("INSERT OR IGNORE INTO product_tags(product_id,tag_id) " +
                    "SELECT id,tag_id FROM products WHERE tag_id IS NOT NULL");
        }
        if (oldVersion < 12) {
            createPhotoTagsTable(db);
            db.execSQL("INSERT OR IGNORE INTO photo_tags(photo_id,tag_id) " +
                    "SELECT id,tag_id FROM photos WHERE tag_id IS NOT NULL");
        }
    }

    private static void createProductTagsTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS product_tags (" +
                "product_id INTEGER NOT NULL," +
                "tag_id INTEGER NOT NULL," +
                "PRIMARY KEY(product_id,tag_id)," +
                "FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE," +
                "FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_product_tags_tag ON product_tags(tag_id)");
    }

    private static void createPhotoTagsTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS photo_tags (" +
                "photo_id INTEGER NOT NULL," +
                "tag_id INTEGER NOT NULL," +
                "PRIMARY KEY(photo_id,tag_id)," +
                "FOREIGN KEY(photo_id) REFERENCES photos(id) ON DELETE CASCADE," +
                "FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_photo_tags_tag ON photo_tags(tag_id)");
    }

    private static void createImportHistoryTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS import_batches (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "file_name TEXT," +
                "source_uri TEXT," +
                "raw_csv TEXT," +
                "quality_score INTEGER NOT NULL DEFAULT 50," +
                "row_count INTEGER NOT NULL DEFAULT 0," +
                "imported_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS import_batch_items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "batch_id INTEGER NOT NULL," +
                "product_id INTEGER NOT NULL," +
                "action TEXT NOT NULL," +
                "store_id INTEGER," +
                "store_name TEXT," +
                "prev_photo_id INTEGER," +
                "prev_store_id INTEGER," +
                "prev_raw_name TEXT," +
                "prev_product_key TEXT," +
                "prev_price_yen INTEGER," +
                "prev_volume TEXT," +
                "prev_price_type TEXT," +
                "prev_tag_id INTEGER," +
                "prev_source_image TEXT," +
                "prev_created_at INTEGER," +
                "imported_store_name TEXT," +
                "imported_raw_name TEXT," +
                "imported_product_key TEXT," +
                "imported_price_yen INTEGER," +
                "imported_volume TEXT," +
                "imported_price_type TEXT," +
                "imported_tag_id INTEGER," +
                "imported_tag_name TEXT," +
                "imported_source_image TEXT," +
                "imported_created_at INTEGER," +
                "FOREIGN KEY(batch_id) REFERENCES import_batches(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_import_items_batch ON import_batch_items(batch_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_import_items_store ON import_batch_items(store_id)");
    }

    private static void reconstructLegacyImportBatches(SQLiteDatabase db) {
        ArrayList<Long> buckets = new ArrayList<>();
        try (Cursor c = db.rawQuery(
                "SELECT DISTINCT (created_at/60000)*60000 AS bucket FROM products " +
                        "WHERE source_image IS NOT NULL AND TRIM(source_image)<>'' ORDER BY bucket ASC", null)) {
            while (c.moveToNext()) buckets.add(c.getLong(0));
        }
        for (Long bucket : buckets) {
            ContentValues batch = new ContentValues();
            batch.put("file_name", "移行前CSV");
            batch.putNull("source_uri");
            batch.put("imported_at", bucket);
            long batchId = db.insert("import_batches", null, batch);
            if (batchId < 0) continue;

            try (Cursor c = db.rawQuery(
                    "SELECT pr.id,COALESCE(pr.store_id,ph.store_id),s.name " +
                            "FROM products pr JOIN photos ph ON ph.id=pr.photo_id " +
                            "LEFT JOIN stores s ON s.id=COALESCE(pr.store_id,ph.store_id) " +
                            "WHERE pr.source_image IS NOT NULL AND TRIM(pr.source_image)<>'' " +
                            "AND (pr.created_at/60000)*60000=?",
                    new String[]{String.valueOf(bucket)})) {
                while (c.moveToNext()) {
                    ContentValues item = new ContentValues();
                    item.put("batch_id", batchId);
                    item.put("product_id", c.getLong(0));
                    item.put("action", "ADD");
                    item.put("store_id", c.getLong(1));
                    item.put("store_name", c.isNull(2) ? "" : c.getString(2));
                    db.insert("import_batch_items", null, item);
                }
            }
        }
    }

    private static void backfillImportSnapshots(SQLiteDatabase db) {
        db.execSQL("UPDATE import_batch_items SET " +
                "imported_store_name=COALESCE((SELECT s.name FROM products pr LEFT JOIN stores s ON s.id=pr.store_id WHERE pr.id=import_batch_items.product_id),store_name)," +
                "imported_raw_name=COALESCE((SELECT pr.raw_name FROM products pr WHERE pr.id=import_batch_items.product_id),prev_raw_name)," +
                "imported_product_key=COALESCE((SELECT pr.product_key FROM products pr WHERE pr.id=import_batch_items.product_id),prev_product_key)," +
                "imported_price_yen=(SELECT pr.price_yen FROM products pr WHERE pr.id=import_batch_items.product_id)," +
                "imported_volume=(SELECT pr.volume FROM products pr WHERE pr.id=import_batch_items.product_id)," +
                "imported_price_type=(SELECT pr.price_type FROM products pr WHERE pr.id=import_batch_items.product_id)," +
                "imported_tag_id=(SELECT pr.tag_id FROM products pr WHERE pr.id=import_batch_items.product_id)," +
                "imported_tag_name=(SELECT t.name FROM products pr LEFT JOIN tags t ON t.id=pr.tag_id WHERE pr.id=import_batch_items.product_id)," +
                "imported_source_image=(SELECT pr.source_image FROM products pr WHERE pr.id=import_batch_items.product_id)," +
                "imported_created_at=COALESCE((SELECT pr.created_at FROM products pr WHERE pr.id=import_batch_items.product_id),prev_created_at) " +
                "WHERE imported_raw_name IS NULL");
    }

    private static void insertTagInternal(SQLiteDatabase db, String name, int sortOrder, long createdAt) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("sort_order", sortOrder);
        v.put("created_at", createdAt);
        db.insert("tags", null, v);
    }

    private static int nextSortOrder(SQLiteDatabase db, String table) {
        try (Cursor c = db.rawQuery("SELECT COALESCE(MAX(sort_order), -1) + 1 FROM " + table, null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private static void normalizeOrder(SQLiteDatabase db, String table, String initialOrder) {
        ArrayList<Long> ids = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT id FROM " + table + " ORDER BY " + initialOrder, null)) {
            while (c.moveToNext()) ids.add(c.getLong(0));
        }
        updateOrder(db, table, ids);
    }

    private static void updateOrder(SQLiteDatabase db, String table, List<Long> ids) {
        for (int i = 0; i < ids.size(); i++) {
            ContentValues v = new ContentValues();
            v.put("sort_order", i);
            db.update(table, v, "id=?", new String[]{String.valueOf(ids.get(i))});
        }
    }

    private void moveItem(String table, long draggedId, long targetId, boolean after) {
        if (draggedId == targetId) return;
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            ArrayList<Long> ids = new ArrayList<>();
            try (Cursor c = writable.rawQuery(
                    "SELECT id FROM " + table + " ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
                while (c.moveToNext()) ids.add(c.getLong(0));
            }
            if (!ids.remove(draggedId)) return;
            int targetIndex = ids.indexOf(targetId);
            if (targetIndex < 0) return;
            int insertIndex = after ? targetIndex + 1 : targetIndex;
            if (insertIndex < 0) insertIndex = 0;
            if (insertIndex > ids.size()) insertIndex = ids.size();
            ids.add(insertIndex, draggedId);
            updateOrder(writable, table, ids);
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    long addStore(String name) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("sort_order", nextSortOrder(writable, "stores"));
        v.put("created_at", System.currentTimeMillis());
        return writable.insert("stores", null, v);
    }

    long ensureStore(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) return -1L;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM stores WHERE name=? COLLATE NOCASE ORDER BY id ASC LIMIT 1", new String[]{n})) {
            if (c.moveToFirst()) return c.getLong(0);
        }
        return addStore(n);
    }

    Store findStoreByName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) return null;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order,enabled FROM stores WHERE name=? COLLATE NOCASE ORDER BY id ASC LIMIT 1", new String[]{n})) {
            if (!c.moveToFirst()) return null;
            return new Store(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3), c.getInt(4) != 0);
        }
    }

    Store getStore(long id) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order,enabled FROM stores WHERE id=?", new String[]{String.valueOf(id)})) {
            if (!c.moveToFirst()) return null;
            return new Store(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3), c.getInt(4) != 0);
        }
    }

    void renameStore(long id, String name) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        getWritableDatabase().update("stores", v, "id=?", new String[]{String.valueOf(id)});
    }

    void setStoreEnabled(long id, boolean enabled) {
        ContentValues v = new ContentValues();
        v.put("enabled", enabled ? 1 : 0);
        getWritableDatabase().update("stores", v, "id=?", new String[]{String.valueOf(id)});
    }

    boolean isStoreEnabled(long id) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT enabled FROM stores WHERE id=?", new String[]{String.valueOf(id)})) {
            return !c.moveToFirst() || c.getInt(0) != 0;
        }
    }

    void deleteStore(long id) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.delete("products", "store_id=?", new String[]{String.valueOf(id)});
        writable.delete("stores", "id=?", new String[]{String.valueOf(id)});
        normalizeOrder(writable, "stores", "sort_order ASC, created_at ASC, id ASC");
    }

    void moveStore(long draggedId, long targetId, boolean after) {
        moveItem("stores", draggedId, targetId, after);
    }

    List<Store> listStores() {
        ArrayList<Store> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order,enabled FROM stores ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
            while (c.moveToNext()) out.add(new Store(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3), c.getInt(4) != 0));
        }
        return out;
    }

    long addTag(String name) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("sort_order", nextSortOrder(writable, "tags"));
        v.put("created_at", System.currentTimeMillis());
        return writable.insertWithOnConflict("tags", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    }

    Long ensureTag(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || "タグなし".equals(n) || "—".equals(n) || "-".equals(n)) return null;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM tags WHERE name=? COLLATE NOCASE LIMIT 1", new String[]{n})) {
            if (c.moveToFirst()) return c.getLong(0);
        }
        long id = addTag(n);
        if (id > 0) return id;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM tags WHERE name=? COLLATE NOCASE LIMIT 1", new String[]{n})) {
            return c.moveToFirst() ? c.getLong(0) : null;
        }
    }

    void deleteTag(long id) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            writable.delete("product_tags", "tag_id=?", new String[]{String.valueOf(id)});
            writable.execSQL("UPDATE products SET tag_id=(SELECT pt.tag_id FROM product_tags pt " +
                    "JOIN tags t ON t.id=pt.tag_id WHERE pt.product_id=products.id " +
                    "ORDER BY t.sort_order ASC,t.id ASC LIMIT 1) WHERE tag_id=?", new Object[]{id});
            writable.delete("photo_tags", "tag_id=?", new String[]{String.valueOf(id)});
            writable.execSQL("UPDATE photos SET tag_id=(SELECT pt.tag_id FROM photo_tags pt " +
                    "JOIN tags t ON t.id=pt.tag_id WHERE pt.photo_id=photos.id " +
                    "ORDER BY t.sort_order ASC,t.id ASC LIMIT 1) WHERE tag_id=?", new Object[]{id});
            writable.delete("tags", "id=?", new String[]{String.valueOf(id)});
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
        normalizeOrder(writable, "tags", "sort_order ASC, created_at ASC, id ASC");
    }

    void moveTag(long draggedId, long targetId, boolean after) {
        moveItem("tags", draggedId, targetId, after);
    }

    void setTagOrder(List<Long> orderedIds) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            ArrayList<Long> remaining = new ArrayList<>();
            try (Cursor c = writable.rawQuery(
                    "SELECT id FROM tags ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
                while (c.moveToNext()) remaining.add(c.getLong(0));
            }
            ArrayList<Long> finalOrder = new ArrayList<>();
            if (orderedIds != null) {
                for (Long id : orderedIds) {
                    if (id != null && remaining.remove(id)) finalOrder.add(id);
                }
            }
            finalOrder.addAll(remaining);
            updateOrder(writable, "tags", finalOrder);
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    boolean tagExists(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM tags WHERE id=? LIMIT 1", new String[]{String.valueOf(id)})) {
            return c.moveToFirst();
        }
    }

    List<Tag> listTags() {
        ArrayList<Tag> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at,sort_order FROM tags ORDER BY sort_order ASC, created_at ASC, id ASC", null)) {
            while (c.moveToNext()) out.add(new Tag(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3)));
        }
        return out;
    }

    long addPhoto(long storeId, Long tagId, String uri, boolean managed) {
        return addPhotoAt(storeId, tagId, uri, managed, System.currentTimeMillis(), "pending");
    }

    long addPhotoAt(long storeId, Long tagId, String uri, boolean managed, long createdAt, String status) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("store_id", storeId);
        if (tagId == null) v.putNull("tag_id"); else v.put("tag_id", tagId);
        v.put("uri", uri);
        v.put("managed", managed ? 1 : 0);
        v.put("ocr_status", status == null ? "pending" : status);
        v.put("created_at", createdAt > 0 ? createdAt : System.currentTimeMillis());
        long photoId = writable.insert("photos", null, v);
        if (photoId > 0 && tagId != null) {
            setPhotoTagsInternal(writable, photoId, java.util.Collections.singletonList(tagId));
        }
        return photoId;
    }

    long createVirtualImportPhoto(long storeId, Long tagId, long capturedAt, String sourceImage) {
        String safe = sourceImage == null ? "unknown" : sourceImage.replaceAll("[^0-9A-Za-z._-]", "_");
        String uri = VIRTUAL_IMPORT_PREFIX + System.currentTimeMillis() + "/" + storeId + "/" + safe + "/" + Math.abs((long) (Math.random() * Long.MAX_VALUE));
        return addPhotoAt(storeId, tagId, uri, false, capturedAt, "imported");
    }

    boolean isVirtualImportPhoto(Photo photo) {
        return photo != null && photo.uri != null && photo.uri.startsWith(VIRTUAL_IMPORT_PREFIX);
    }

    void updatePhotoTag(long photoId, Long tagId) {
        updatePhotoTags(photoId, tagId == null
                ? java.util.Collections.emptyList()
                : java.util.Collections.singletonList(tagId));
    }

    void updatePhotoTags(long photoId, List<Long> tagIds) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            Long primary = firstValidTagId(tagIds);
            ContentValues v = new ContentValues();
            putNullableLong(v, "tag_id", primary);
            writable.update("photos", v, "id=?", new String[]{String.valueOf(photoId)});
            setPhotoTagsInternal(writable, photoId, tagIds);
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    void updatePhotosTags(List<Long> photoIds, List<Long> tagIds) {
        if (photoIds == null || photoIds.isEmpty()) return;
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            Long primary = firstValidTagId(tagIds);
            ContentValues v = new ContentValues();
            putNullableLong(v, "tag_id", primary);
            for (Long photoId : photoIds) {
                if (photoId == null) continue;
                writable.update("photos", v, "id=?", new String[]{String.valueOf(photoId)});
                setPhotoTagsInternal(writable, photoId, tagIds);
            }
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    private static void setPhotoTagsInternal(SQLiteDatabase db, long photoId, List<Long> tagIds) {
        db.delete("photo_tags", "photo_id=?", new String[]{String.valueOf(photoId)});
        if (tagIds == null) return;
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        for (Long tagId : tagIds) {
            if (tagId == null || tagId < 0 || !seen.add(tagId)) continue;
            ContentValues link = new ContentValues();
            link.put("photo_id", photoId);
            link.put("tag_id", tagId);
            db.insertWithOnConflict("photo_tags", null, link, SQLiteDatabase.CONFLICT_IGNORE);
        }
    }

    List<Long> photoTagIds(long photoId) {
        ArrayList<Long> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT pt.tag_id FROM photo_tags pt JOIN tags t ON t.id=pt.tag_id " +
                        "WHERE pt.photo_id=? ORDER BY t.sort_order ASC,t.id ASC",
                new String[]{String.valueOf(photoId)})) {
            while (c.moveToNext()) out.add(c.getLong(0));
        }
        return out;
    }

    void setPhotoOcrState(long photoId, String status, String rawText) {
        ContentValues v = new ContentValues();
        v.put("ocr_status", status);
        if (rawText == null) v.putNull("ocr_raw"); else v.put("ocr_raw", rawText);
        getWritableDatabase().update("photos", v, "id=?", new String[]{String.valueOf(photoId)});
    }

    void replaceProductsForPhoto(long photoId, List<ProductInput> products, String rawText) {
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            writable.delete("products", "photo_id=?", new String[]{String.valueOf(photoId)});
            long now = System.currentTimeMillis();
            Long photoTagId = tagIdForPhoto(writable, photoId);
            for (ProductInput p : products) {
                if (p.name == null || p.name.trim().isEmpty()) continue;
                ContentValues v = productValues(photoId, p.name, p.name, p.priceYen, null, null, null, now++);
                v.put("store_id", storeIdForPhoto(writable, photoId));
                putNullableLong(v, "tag_id", photoTagId);
                if (p.confidence == null) v.putNull("confidence"); else v.put("confidence", p.confidence);
                long productId = writable.insert("products", null, v);
                if (productId > 0 && photoTagId != null) {
                    setProductTagsInternal(writable, productId, java.util.Collections.singletonList(photoTagId));
                }
            }
            ContentValues photo = new ContentValues();
            photo.put("ocr_raw", rawText);
            photo.put("ocr_status", products.isEmpty() ? "no_results" : "done");
            writable.update("photos", photo, "id=?", new String[]{String.valueOf(photoId)});
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    private static ContentValues productValues(long photoId, String name, String productKey, Integer priceYen,
                                                String volume, String priceType, String sourceImage, long createdAt) {
        String displayName = name == null ? "" : name.trim();
        String key = productKey == null || productKey.trim().isEmpty() ? displayName : productKey.trim();
        ContentValues v = new ContentValues();
        v.put("photo_id", photoId);
        v.put("raw_name", displayName);
        v.put("normalized_name", normalizeName(key));
        if (priceYen == null) v.putNull("price_yen"); else v.put("price_yen", priceYen);
        v.putNull("confidence");
        v.put("product_key", key);
        if (volume == null || volume.trim().isEmpty()) v.putNull("volume"); else v.put("volume", volume.trim());
        if (priceType == null || priceType.trim().isEmpty()) v.putNull("price_type"); else v.put("price_type", priceType.trim());
        if (sourceImage == null || sourceImage.trim().isEmpty()) v.putNull("source_image"); else v.put("source_image", sourceImage.trim());
        v.put("created_at", createdAt > 0 ? createdAt : System.currentTimeMillis());
        return v;
    }

    long insertImportedProduct(long photoId, long storeId, Long tagId, String name, String productKey, Integer priceYen,
                               String volume, String priceType, String sourceImage) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = productValues(photoId, name, productKey, priceYen, volume, priceType, sourceImage, System.currentTimeMillis());
        v.put("store_id", storeId);
        putNullableLong(v, "tag_id", tagId);
        long productId = writable.insert("products", null, v);
        if (productId > 0) {
            setProductTagsInternal(writable, productId,
                    tagId == null ? java.util.Collections.emptyList() : java.util.Collections.singletonList(tagId));
        }
        return productId;
    }

    void updateImportedProduct(long productId, long photoId, long storeId, Long tagId, String name, String productKey, Integer priceYen,
                               String volume, String priceType, String sourceImage) {
        SQLiteDatabase writable = getWritableDatabase();
        ContentValues v = productValues(photoId, name, productKey, priceYen, volume, priceType, sourceImage, System.currentTimeMillis());
        v.put("store_id", storeId);
        putNullableLong(v, "tag_id", tagId);
        writable.update("products", v, "id=?", new String[]{String.valueOf(productId)});
        setProductTagsInternal(writable, productId,
                tagId == null ? java.util.Collections.emptyList() : java.util.Collections.singletonList(tagId));
    }

    private static void putNullableLong(ContentValues v, String key, Long value) {
        if (value == null) v.putNull(key); else v.put(key, value);
    }

    private static Long tagIdForPhoto(SQLiteDatabase db, long photoId) {
        try (Cursor c = db.rawQuery("SELECT tag_id FROM photos WHERE id=?", new String[]{String.valueOf(photoId)})) {
            if (!c.moveToFirst() || c.isNull(0)) return null;
            return c.getLong(0);
        }
    }

    private static long storeIdForPhoto(SQLiteDatabase db, long photoId) {
        try (Cursor c = db.rawQuery("SELECT store_id FROM photos WHERE id=?", new String[]{String.valueOf(photoId)})) {
            if (!c.moveToFirst()) return -1L;
            return c.getLong(0);
        }
    }

    ProductRecord findLatestProductInStore(long storeId, String productKey) {
        String normalized = normalizeName(productKey);
        if (normalized.isEmpty()) return null;
        List<ProductRecord> found = queryProducts("WHERE COALESCE(pr.store_id,ph.store_id)=CAST(? AS INTEGER) AND pr.normalized_name=?",
                new String[]{String.valueOf(storeId), normalized}, "ORDER BY ph.created_at DESC, pr.id DESC LIMIT 1");
        return found.isEmpty() ? null : found.get(0);
    }

    void updateProduct(long id, String name, Integer priceYen) {
        ContentValues v = new ContentValues();
        v.put("raw_name", name.trim());
        v.put("normalized_name", normalizeName(name));
        v.put("product_key", name.trim());
        if (priceYen == null) v.putNull("price_yen"); else v.put("price_yen", priceYen);
        getWritableDatabase().update("products", v, "id=?", new String[]{String.valueOf(id)});
    }

    void updateProductDetails(long id, String name, String productKey, Integer priceYen,
                              String volume, String priceType, List<Long> tagIds, long storeId) {
        String displayName = name == null ? "" : name.trim();
        String key = productKey == null || productKey.trim().isEmpty() ? displayName : productKey.trim();
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("raw_name", displayName);
            v.put("normalized_name", normalizeName(key));
            v.put("product_key", key);
            if (priceYen == null) v.putNull("price_yen"); else v.put("price_yen", priceYen);
            if (volume == null || volume.trim().isEmpty()) v.putNull("volume"); else v.put("volume", volume.trim());
            if (priceType == null || priceType.trim().isEmpty()) v.putNull("price_type"); else v.put("price_type", priceType.trim());
            Long primary = firstValidTagId(tagIds);
            putNullableLong(v, "tag_id", primary);
            v.put("store_id", storeId);
            writable.update("products", v, "id=?", new String[]{String.valueOf(id)});
            setProductTagsInternal(writable, id, tagIds);
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    void updateProductsTags(List<Long> ids, List<Long> tagIds) {
        if (ids == null || ids.isEmpty()) return;
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            Long primary = firstValidTagId(tagIds);
            ContentValues v = new ContentValues();
            putNullableLong(v, "tag_id", primary);
            for (Long id : ids) {
                if (id == null) continue;
                writable.update("products", v, "id=?", new String[]{String.valueOf(id)});
                setProductTagsInternal(writable, id, tagIds);
            }
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    private static Long firstValidTagId(List<Long> tagIds) {
        if (tagIds == null) return null;
        for (Long tagId : tagIds) if (tagId != null && tagId >= 0) return tagId;
        return null;
    }

    private static void setProductTagsInternal(SQLiteDatabase db, long productId, List<Long> tagIds) {
        db.delete("product_tags", "product_id=?", new String[]{String.valueOf(productId)});
        if (tagIds == null) return;
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        for (Long tagId : tagIds) {
            if (tagId == null || tagId < 0 || !seen.add(tagId)) continue;
            ContentValues link = new ContentValues();
            link.put("product_id", productId);
            link.put("tag_id", tagId);
            db.insertWithOnConflict("product_tags", null, link, SQLiteDatabase.CONFLICT_IGNORE);
        }
    }

    List<Long> productTagIds(long productId) {
        ArrayList<Long> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT pt.tag_id FROM product_tags pt JOIN tags t ON t.id=pt.tag_id " +
                        "WHERE pt.product_id=? ORDER BY t.sort_order ASC,t.id ASC",
                new String[]{String.valueOf(productId)})) {
            while (c.moveToNext()) out.add(c.getLong(0));
        }
        return out;
    }

    void deleteProducts(List<Long> ids) {
        if (ids == null || ids.isEmpty()) return;
        SQLiteDatabase writable = getWritableDatabase();
        writable.beginTransaction();
        try {
            for (Long id : ids) {
                if (id != null) writable.delete("products", "id=?", new String[]{String.valueOf(id)});
            }
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
    }

    void deleteProduct(long id) {
        getWritableDatabase().delete("products", "id=?", new String[]{String.valueOf(id)});
    }

    void deletePhoto(long photoId) {
        getWritableDatabase().delete("photos", "id=?", new String[]{String.valueOf(photoId)});
    }

    private static String photoSelectSql(String where) {
        return "SELECT p.id,p.store_id,p.tag_id,p.uri,p.created_at,t.name,p.managed,p.ocr_raw,p.ocr_status," +
                "EXISTS(SELECT 1 FROM import_batch_items ibi JOIN products pr ON pr.id=ibi.product_id WHERE pr.photo_id=p.id)," +
                "(SELECT GROUP_CONCAT(x.tag_id, ',') FROM (SELECT pt.tag_id AS tag_id FROM photo_tags pt " +
                "JOIN tags tx ON tx.id=pt.tag_id WHERE pt.photo_id=p.id ORDER BY tx.sort_order ASC,tx.id ASC) x)," +
                "(SELECT GROUP_CONCAT(x.name, ' / ') FROM (SELECT tx.name AS name FROM photo_tags pt " +
                "JOIN tags tx ON tx.id=pt.tag_id WHERE pt.photo_id=p.id ORDER BY tx.sort_order ASC,tx.id ASC) x) " +
                "FROM photos p LEFT JOIN tags t ON t.id=p.tag_id " + where;
    }

    Photo getPhoto(long photoId) {
        String sql = photoSelectSql("WHERE p.id=?");
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(photoId)})) {
            if (!c.moveToFirst()) return null;
            return photoFromCursor(c);
        }
    }

    List<Photo> listPhotos(long storeId) {
        ArrayList<Photo> out = new ArrayList<>();
        String sql = photoSelectSql("WHERE p.store_id=? AND p.uri NOT LIKE ? ") +
                "ORDER BY p.created_at DESC, p.id DESC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(storeId), VIRTUAL_IMPORT_PREFIX + "%"})) {
            while (c.moveToNext()) out.add(photoFromCursor(c));
        }
        return out;
    }

    private static Photo photoFromCursor(Cursor c) {
        Long tagId = c.isNull(2) ? null : c.getLong(2);
        String tagName = c.isNull(5) ? null : c.getString(5);
        ArrayList<Long> tagIds = new ArrayList<>();
        String tagIdCsv = c.isNull(10) ? "" : c.getString(10);
        if (tagIdCsv != null && !tagIdCsv.trim().isEmpty()) {
            for (String part : tagIdCsv.split(",")) {
                try { tagIds.add(Long.parseLong(part.trim())); } catch (Exception ignored) { }
            }
        }
        if (tagIds.isEmpty() && tagId != null) tagIds.add(tagId);
        String tagNames = c.isNull(11) ? null : c.getString(11);
        if ((tagNames == null || tagNames.trim().isEmpty()) && tagName != null) tagNames = tagName;
        return new Photo(c.getLong(0), c.getLong(1), tagId, c.getString(3), c.getLong(4), tagName, tagIds, tagNames,
                c.getInt(6) != 0, c.isNull(7) ? null : c.getString(7), c.getString(8), c.getInt(9) != 0);
    }

    List<ProductRecord> listProductsForStore(long storeId) {
        return queryProducts("WHERE COALESCE(pr.store_id,ph.store_id)=CAST(? AS INTEGER)", new String[]{String.valueOf(storeId)},
                "ORDER BY pr.normalized_name COLLATE NOCASE ASC, CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC");
    }

    List<ProductRecord> listProductsForPhoto(long photoId) {
        return queryProducts("WHERE ph.id=?", new String[]{String.valueOf(photoId)}, "ORDER BY pr.id ASC");
    }

    List<ProductRecord> listAllProducts() {
        return queryProducts("WHERE s.enabled=1", null,
                "ORDER BY pr.normalized_name COLLATE NOCASE ASC, pr.raw_name COLLATE NOCASE ASC, " +
                        "CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC, s.sort_order ASC");
    }

    List<ProductRecord> searchProducts(String query) {
        String like = "%" + query + "%";
        return queryProducts("WHERE s.enabled=1 AND (pr.raw_name LIKE ? OR pr.normalized_name LIKE ? OR pr.product_key LIKE ?)",
                new String[]{like, like, like},
                "ORDER BY CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC, s.sort_order ASC");
    }

    private List<ProductRecord> queryProducts(String where, String[] args, String order) {
        ArrayList<ProductRecord> out = new ArrayList<>();
        String sql = "SELECT pr.id,pr.raw_name,pr.normalized_name,pr.price_yen,ph.id,ph.uri,pr.tag_id,t.name,pr.created_at," +
                "s.name,s.id,ph.created_at,pr.product_key,pr.volume,pr.price_type,pr.source_image," +
                "(SELECT GROUP_CONCAT(x.tag_id, ',') FROM (SELECT pt.tag_id AS tag_id FROM product_tags pt " +
                "JOIN tags tx ON tx.id=pt.tag_id WHERE pt.product_id=pr.id ORDER BY tx.sort_order ASC,tx.id ASC) x)," +
                "(SELECT GROUP_CONCAT(x.name, ' / ') FROM (SELECT tx.name AS name FROM product_tags pt " +
                "JOIN tags tx ON tx.id=pt.tag_id WHERE pt.product_id=pr.id ORDER BY tx.sort_order ASC,tx.id ASC) x) " +
                "FROM products pr JOIN photos ph ON ph.id=pr.photo_id JOIN stores s ON s.id=COALESCE(pr.store_id,ph.store_id) " +
                "LEFT JOIN tags t ON t.id=pr.tag_id " + where + " " + order;
        try (Cursor c = getReadableDatabase().rawQuery(sql, args)) {
            while (c.moveToNext()) {
                Integer price = c.isNull(3) ? null : c.getInt(3);
                Long tagId = c.isNull(6) ? null : c.getLong(6);
                out.add(new ProductRecord(c.getLong(0), c.getString(1), c.getString(2), price,
                        c.getLong(4), c.getString(5), tagId, c.isNull(7) ? null : c.getString(7), c.getLong(8),
                        c.getString(9), c.getLong(10), c.getLong(11), c.isNull(12) ? null : c.getString(12),
                        c.isNull(13) ? null : c.getString(13), c.isNull(14) ? null : c.getString(14),
                        c.isNull(15) ? null : c.getString(15), parseTagIds(c.isNull(16) ? null : c.getString(16)),
                        c.isNull(17) ? null : c.getString(17)));
            }
        }
        return out;
    }

    private static List<Long> parseTagIds(String csv) {
        ArrayList<Long> out = new ArrayList<>();
        if (csv == null || csv.trim().isEmpty()) return out;
        for (String part : csv.split(",")) {
            try { out.add(Long.parseLong(part.trim())); } catch (Exception ignored) { }
        }
        return out;
    }

    ProductRecord getProduct(long productId) {
        List<ProductRecord> found = queryProducts("WHERE pr.id=?", new String[]{String.valueOf(productId)}, "LIMIT 1");
        return found.isEmpty() ? null : found.get(0);
    }

    List<ProductRecord> listSameProductAcrossStores(String productKey) {
        String normalized = normalizeName(productKey);
        if (normalized.isEmpty()) return new ArrayList<>();
        return queryProducts("WHERE s.enabled=1 AND pr.normalized_name=?", new String[]{normalized},
                "ORDER BY CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC, s.sort_order ASC");
    }

    long createImportBatch(String fileName, String sourceUri, String rawCsv, int qualityScore, int rowCount) {
        ContentValues v = new ContentValues();
        if (fileName == null || fileName.trim().isEmpty()) v.put("file_name", "CSV");
        else v.put("file_name", fileName.trim());
        if (sourceUri == null) v.putNull("source_uri"); else v.put("source_uri", sourceUri);
        if (rawCsv == null) v.putNull("raw_csv"); else v.put("raw_csv", rawCsv);
        v.put("quality_score", Math.max(0, Math.min(100, qualityScore)));
        v.put("row_count", Math.max(0, rowCount));
        v.put("imported_at", System.currentTimeMillis());
        return getWritableDatabase().insert("import_batches", null, v);
    }

    boolean importBatchHasDisabledStore(long batchId) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT 1 FROM import_batch_items ibi JOIN stores s ON s.id=ibi.store_id " +
                        "WHERE ibi.batch_id=? AND s.enabled=0 LIMIT 1",
                new String[]{String.valueOf(batchId)})) {
            return c.moveToFirst();
        }
    }

    void recordImportAdded(long batchId, long productId, long storeId, String storeName) {
        ContentValues v = new ContentValues();
        v.put("batch_id", batchId);
        v.put("product_id", productId);
        v.put("action", "ADD");
        v.put("store_id", storeId);
        v.put("store_name", storeName == null ? "" : storeName);
        ProductRecord current = getProduct(productId);
        putImportedSnapshot(v, current);
        getWritableDatabase().insert("import_batch_items", null, v);
    }

    void recordImportUpdated(long batchId, ProductRecord previous) {
        if (previous == null) return;
        ContentValues v = new ContentValues();
        v.put("batch_id", batchId);
        v.put("product_id", previous.id);
        v.put("action", "UPDATE");
        v.put("store_id", previous.storeId);
        v.put("store_name", previous.storeName == null ? "" : previous.storeName);
        v.put("prev_photo_id", previous.photoId);
        v.put("prev_store_id", previous.storeId);
        v.put("prev_raw_name", previous.rawName);
        v.put("prev_product_key", previous.productKey);
        if (previous.priceYen == null) v.putNull("prev_price_yen"); else v.put("prev_price_yen", previous.priceYen);
        if (previous.volume == null) v.putNull("prev_volume"); else v.put("prev_volume", previous.volume);
        if (previous.priceType == null) v.putNull("prev_price_type"); else v.put("prev_price_type", previous.priceType);
        putNullableLong(v, "prev_tag_id", previous.tagId);
        if (previous.sourceImage == null) v.putNull("prev_source_image"); else v.put("prev_source_image", previous.sourceImage);
        v.put("prev_created_at", previous.createdAt);
        getWritableDatabase().insert("import_batch_items", null, v);
    }

    private static void putImportedSnapshot(ContentValues v, ProductRecord current) {
        if (current == null) return;
        v.put("imported_store_name", current.storeName == null ? "" : current.storeName);
        v.put("imported_raw_name", current.rawName == null ? "" : current.rawName);
        v.put("imported_product_key", current.productKey == null ? current.rawName : current.productKey);
        if (current.priceYen == null) v.putNull("imported_price_yen"); else v.put("imported_price_yen", current.priceYen);
        if (current.volume == null) v.putNull("imported_volume"); else v.put("imported_volume", current.volume);
        if (current.priceType == null) v.putNull("imported_price_type"); else v.put("imported_price_type", current.priceType);
        putNullableLong(v, "imported_tag_id", current.tagId);
        if (current.tagName == null) v.putNull("imported_tag_name"); else v.put("imported_tag_name", current.tagName);
        if (current.sourceImage == null) v.putNull("imported_source_image"); else v.put("imported_source_image", current.sourceImage);
        v.put("imported_created_at", current.createdAt);
    }

    void updateImportSnapshot(long batchId, long productId) {
        ProductRecord current = getProduct(productId);
        if (current == null) return;
        ContentValues v = new ContentValues();
        putImportedSnapshot(v, current);
        getWritableDatabase().update("import_batch_items", v, "batch_id=? AND product_id=?",
                new String[]{String.valueOf(batchId), String.valueOf(productId)});
    }

    void deleteImportBatchIfEmpty(long batchId) {
        SQLiteDatabase writable = getWritableDatabase();
        try (Cursor c = writable.rawQuery("SELECT COUNT(*) FROM import_batch_items WHERE batch_id=?",
                new String[]{String.valueOf(batchId)})) {
            if (c.moveToFirst() && c.getInt(0) == 0) {
                writable.delete("import_batches", "id=?", new String[]{String.valueOf(batchId)});
            }
        }
    }

    List<ImportBatch> listImportBatches(Long storeId) {
        ArrayList<ImportBatch> out = new ArrayList<>();
        String where = storeId == null ? "" : " WHERE i.store_id=? ";
        String[] args = storeId == null ? null : new String[]{String.valueOf(storeId)};
        String sql = "SELECT b.id,b.file_name,b.imported_at,COUNT(i.id)," +
                "SUM(CASE WHEN i.action='ADD' THEN 1 ELSE 0 END)," +
                "SUM(CASE WHEN i.action='UPDATE' THEN 1 ELSE 0 END)," +
                "GROUP_CONCAT(DISTINCT i.store_name),b.source_uri,b.raw_csv,b.quality_score,b.row_count " +
                "FROM import_batches b JOIN import_batch_items i ON i.batch_id=b.id " + where +
                "GROUP BY b.id,b.file_name,b.imported_at,b.source_uri,b.raw_csv,b.quality_score,b.row_count ORDER BY b.imported_at DESC,b.id DESC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, args)) {
            while (c.moveToNext()) {
                out.add(new ImportBatch(c.getLong(0), c.isNull(1) ? "CSV" : c.getString(1), c.getLong(2),
                        c.getInt(3), c.getInt(4), c.getInt(5), c.isNull(6) ? "" : c.getString(6),
                        c.isNull(7) ? null : c.getString(7), c.isNull(8) ? null : c.getString(8), c.getInt(9), c.getInt(10)));
            }
        }
        return out;
    }

    List<ImportBatchRow> listImportBatchRows(long batchId) {
        ArrayList<ImportBatchRow> out = new ArrayList<>();
        String sql = "SELECT action," +
                "COALESCE(imported_store_name,store_name,'')," +
                "COALESCE(imported_raw_name,prev_raw_name,'')," +
                "COALESCE(imported_product_key,prev_product_key,imported_raw_name,prev_raw_name,'')," +
                "imported_price_yen,imported_volume,imported_price_type,imported_tag_name,imported_source_image,imported_created_at " +
                "FROM import_batch_items WHERE batch_id=? ORDER BY id ASC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(batchId)})) {
            while (c.moveToNext()) {
                out.add(new ImportBatchRow(c.getString(0), c.getString(1), c.getString(2), c.getString(3),
                        c.isNull(4) ? null : c.getInt(4), c.isNull(5) ? null : c.getString(5),
                        c.isNull(6) ? null : c.getString(6), c.isNull(7) ? null : c.getString(7),
                        c.isNull(8) ? null : c.getString(8), c.isNull(9) ? 0L : c.getLong(9)));
            }
        }
        return out;
    }

    RollbackResult rollbackImportBatch(long batchId) {
        SQLiteDatabase writable = getWritableDatabase();
        int deleted = 0;
        int restored = 0;
        int missing = 0;
        writable.beginTransaction();
        try {
            try (Cursor c = writable.rawQuery(
                    "SELECT action,product_id,prev_photo_id,prev_store_id,prev_raw_name,prev_product_key,prev_price_yen," +
                            "prev_volume,prev_price_type,prev_tag_id,prev_source_image,prev_created_at " +
                            "FROM import_batch_items WHERE batch_id=? ORDER BY id DESC",
                    new String[]{String.valueOf(batchId)})) {
                while (c.moveToNext()) {
                    String action = c.getString(0);
                    long productId = c.getLong(1);
                    if ("ADD".equals(action)) {
                        int n = writable.delete("products", "id=?", new String[]{String.valueOf(productId)});
                        if (n > 0) deleted += n; else missing++;
                    } else if ("UPDATE".equals(action)) {
                        ContentValues v = new ContentValues();
                        if (c.isNull(2)) { missing++; continue; }
                        long photoId = c.getLong(2);
                        long storeId = c.isNull(3) ? storeIdForPhoto(writable, photoId) : c.getLong(3);
                        String name = c.isNull(4) ? "" : c.getString(4);
                        String key = c.isNull(5) || c.getString(5).trim().isEmpty() ? name : c.getString(5);
                        v.put("photo_id", photoId);
                        v.put("store_id", storeId);
                        v.put("raw_name", name);
                        v.put("product_key", key);
                        v.put("normalized_name", normalizeName(key));
                        if (c.isNull(6)) v.putNull("price_yen"); else v.put("price_yen", c.getInt(6));
                        if (c.isNull(7)) v.putNull("volume"); else v.put("volume", c.getString(7));
                        if (c.isNull(8)) v.putNull("price_type"); else v.put("price_type", c.getString(8));
                        if (c.isNull(9)) v.putNull("tag_id"); else v.put("tag_id", c.getLong(9));
                        if (c.isNull(10)) v.putNull("source_image"); else v.put("source_image", c.getString(10));
                        if (c.isNull(11)) v.put("created_at", System.currentTimeMillis()); else v.put("created_at", c.getLong(11));
                        int n = writable.update("products", v, "id=?", new String[]{String.valueOf(productId)});
                        if (n > 0) {
                            Long restoredTag = c.isNull(9) ? null : c.getLong(9);
                            setProductTagsInternal(writable, productId,
                                    restoredTag == null ? java.util.Collections.emptyList() : java.util.Collections.singletonList(restoredTag));
                            restored += n;
                        } else missing++;
                    }
                }
            }
            writable.delete("import_batches", "id=?", new String[]{String.valueOf(batchId)});
            cleanupOrphanVirtualPhotos(writable);
            writable.setTransactionSuccessful();
        } finally {
            writable.endTransaction();
        }
        return new RollbackResult(deleted, restored, missing);
    }

    private static void cleanupOrphanVirtualPhotos(SQLiteDatabase db) {
        db.delete("photos", "uri LIKE ? AND id NOT IN (SELECT DISTINCT photo_id FROM products)",
                new String[]{VIRTUAL_IMPORT_PREFIX + "%"});
    }

    static String normalizeName(String input) {
        if (input == null) return "";
        return input.toLowerCase()
                .replace('　', ' ')
                .replaceAll("[\\s\\-‐‑–—_・･/／]+", "")
                .replaceAll("[^0-9a-zぁ-んァ-ヶ一-龠々ー]", "");
    }

    static final class Store {
        final long id; final String name; final long createdAt; final int sortOrder; final boolean enabled;
        Store(long id, String name, long createdAt, int sortOrder, boolean enabled) {
            this.id = id; this.name = name; this.createdAt = createdAt; this.sortOrder = sortOrder; this.enabled = enabled;
        }
    }

    static final class Tag {
        final long id; final String name; final long createdAt; final int sortOrder;
        Tag(long id, String name, long createdAt, int sortOrder) {
            this.id = id; this.name = name; this.createdAt = createdAt; this.sortOrder = sortOrder;
        }
    }

    static final class Photo {
        final long id; final long storeId; final Long tagId; final String uri; final long createdAt;
        final String tagName; final List<Long> tagIds; final String tagNames;
        final boolean managed; final String ocrRaw; final String ocrStatus; final boolean csvImported;
        Photo(long id, long storeId, Long tagId, String uri, long createdAt, String tagName,
              List<Long> tagIds, String tagNames, boolean managed, String ocrRaw, String ocrStatus, boolean csvImported) {
            this.id = id; this.storeId = storeId; this.tagId = tagId; this.uri = uri; this.createdAt = createdAt;
            this.tagName = tagName; this.tagIds = tagIds == null ? new ArrayList<>() : tagIds; this.tagNames = tagNames;
            this.managed = managed; this.ocrRaw = ocrRaw; this.ocrStatus = ocrStatus; this.csvImported = csvImported;
        }
    }

    static final class ImportBatch {
        final long id;
        final String fileName;
        final long importedAt;
        final int itemCount;
        final int addCount;
        final int updateCount;
        final String storeNames;
        final String sourceUri;
        final String rawCsv;
        final int qualityScore;
        final int rowCount;
        ImportBatch(long id, String fileName, long importedAt, int itemCount, int addCount, int updateCount,
                    String storeNames, String sourceUri, String rawCsv, int qualityScore, int rowCount) {
            this.id = id;
            this.fileName = fileName;
            this.importedAt = importedAt;
            this.itemCount = itemCount;
            this.addCount = addCount;
            this.updateCount = updateCount;
            this.storeNames = storeNames;
            this.sourceUri = sourceUri;
            this.rawCsv = rawCsv;
            this.qualityScore = qualityScore;
            this.rowCount = rowCount;
        }
        int displayCount() { return rowCount > 0 ? rowCount : itemCount; }
        String qualityLabel() {
            if (qualityScore >= 80) return "良好";
            if (qualityScore >= 55) return "普通";
            return "粗悪";
        }
    }

    static final class ImportBatchRow {
        final String action;
        final String storeName;
        final String productName;
        final String productKey;
        final Integer priceYen;
        final String volume;
        final String priceType;
        final String tagName;
        final String sourceImage;
        final long createdAt;
        ImportBatchRow(String action, String storeName, String productName, String productKey, Integer priceYen,
                       String volume, String priceType, String tagName, String sourceImage, long createdAt) {
            this.action = action;
            this.storeName = storeName;
            this.productName = productName;
            this.productKey = productKey;
            this.priceYen = priceYen;
            this.volume = volume;
            this.priceType = priceType;
            this.tagName = tagName;
            this.sourceImage = sourceImage;
            this.createdAt = createdAt;
        }
        String actionLabel() { return "UPDATE".equals(action) ? "更新" : "追加"; }
    }

    static final class RollbackResult {
        final int deleted;
        final int restored;
        final int missing;
        RollbackResult(int deleted, int restored, int missing) {
            this.deleted = deleted;
            this.restored = restored;
            this.missing = missing;
        }
    }

    static final class ProductInput {
        final String name; final Integer priceYen; final Float confidence;
        ProductInput(String name, Integer priceYen, Float confidence) {
            this.name = name; this.priceYen = priceYen; this.confidence = confidence;
        }
    }

    static final class ProductRecord {
        final long id; final String rawName; final String normalizedName; final Integer priceYen;
        final long photoId; final String photoUri; final Long tagId; final String tagName; final long createdAt;
        final String storeName; final long storeId; final long photoCreatedAt;
        final String productKey; final String volume; final String priceType; final String sourceImage;
        final List<Long> tagIds; final String tagNames;
        ProductRecord(long id, String rawName, String normalizedName, Integer priceYen, long photoId,
                      String photoUri, Long tagId, String tagName, long createdAt, String storeName, long storeId, long photoCreatedAt,
                      String productKey, String volume, String priceType, String sourceImage, List<Long> tagIds, String tagNames) {
            this.id = id; this.rawName = rawName; this.normalizedName = normalizedName; this.priceYen = priceYen;
            this.photoId = photoId; this.photoUri = photoUri; this.tagId = tagId; this.tagName = tagName; this.createdAt = createdAt;
            this.storeName = storeName; this.storeId = storeId; this.photoCreatedAt = photoCreatedAt;
            this.productKey = productKey; this.volume = volume; this.priceType = priceType; this.sourceImage = sourceImage;
            this.tagIds = tagIds == null ? new ArrayList<>() : tagIds;
            this.tagNames = tagNames == null || tagNames.trim().isEmpty() ? tagName : tagNames;
        }
        boolean hasTag(long tagId) { return tagIds.contains(tagId) || (this.tagId != null && this.tagId == tagId); }
        String tagDisplay() { return tagNames == null || tagNames.trim().isEmpty() ? "タグなし" : tagNames; }
    }
}
