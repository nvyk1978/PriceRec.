package com.pricerec.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public final class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "price_rec.db";
    private static final int DB_VERSION = 1;

    DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE stores (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE tags (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL UNIQUE COLLATE NOCASE," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE photos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "store_id INTEGER NOT NULL," +
                "tag_id INTEGER," +
                "uri TEXT NOT NULL UNIQUE," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE," +
                "FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE SET NULL)");

        db.execSQL("CREATE TABLE products (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "photo_id INTEGER NOT NULL," +
                "raw_name TEXT NOT NULL," +
                "normalized_name TEXT," +
                "price_yen INTEGER," +
                "confidence REAL," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(photo_id) REFERENCES photos(id) ON DELETE CASCADE)");

        long now = System.currentTimeMillis();
        insertTagInternal(db, "酒", now);
        insertTagInternal(db, "肉", now + 1);
        insertTagInternal(db, "調味料", now + 2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Initial schema. Future migrations go here.
    }

    private static void insertTagInternal(SQLiteDatabase db, String name, long createdAt) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("created_at", createdAt);
        db.insert("tags", null, v);
    }

    long addStore(String name) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("stores", null, v);
    }

    void renameStore(long id, String name) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        getWritableDatabase().update("stores", v, "id=?", new String[]{String.valueOf(id)});
    }

    void deleteStore(long id) {
        getWritableDatabase().delete("stores", "id=?", new String[]{String.valueOf(id)});
    }

    List<Store> listStores() {
        ArrayList<Store> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at FROM stores ORDER BY created_at ASC", null)) {
            while (c.moveToNext()) {
                out.add(new Store(c.getLong(0), c.getString(1), c.getLong(2)));
            }
        }
        return out;
    }

    long addTag(String name) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insertWithOnConflict("tags", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    }

    void deleteTag(long id) {
        getWritableDatabase().delete("tags", "id=?", new String[]{String.valueOf(id)});
    }

    boolean tagExists(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM tags WHERE id=? LIMIT 1",
                new String[]{String.valueOf(id)})) {
            return c.moveToFirst();
        }
    }

    List<Tag> listTags() {
        ArrayList<Tag> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,name,created_at FROM tags ORDER BY created_at ASC", null)) {
            while (c.moveToNext()) {
                out.add(new Tag(c.getLong(0), c.getString(1), c.getLong(2)));
            }
        }
        return out;
    }

    long addPhoto(long storeId, Long tagId, String uri) {
        ContentValues v = new ContentValues();
        v.put("store_id", storeId);
        if (tagId == null) v.putNull("tag_id"); else v.put("tag_id", tagId);
        v.put("uri", uri);
        v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("photos", null, v);
    }

    void updatePhotoTag(long photoId, Long tagId) {
        ContentValues v = new ContentValues();
        if (tagId == null) v.putNull("tag_id"); else v.put("tag_id", tagId);
        getWritableDatabase().update("photos", v, "id=?", new String[]{String.valueOf(photoId)});
    }

    void deletePhoto(long photoId) {
        getWritableDatabase().delete("photos", "id=?", new String[]{String.valueOf(photoId)});
    }

    List<Photo> listPhotos(long storeId) {
        ArrayList<Photo> out = new ArrayList<>();
        String sql = "SELECT p.id,p.store_id,p.tag_id,p.uri,p.created_at,t.name " +
                "FROM photos p LEFT JOIN tags t ON t.id=p.tag_id " +
                "WHERE p.store_id=? ORDER BY p.created_at DESC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(storeId)})) {
            while (c.moveToNext()) {
                Long tagId = c.isNull(2) ? null : c.getLong(2);
                String tagName = c.isNull(5) ? null : c.getString(5);
                out.add(new Photo(c.getLong(0), c.getLong(1), tagId, c.getString(3), c.getLong(4), tagName));
            }
        }
        return out;
    }

    List<ProductRecord> listProductsForStore(long storeId) {
        ArrayList<ProductRecord> out = new ArrayList<>();
        String sql = "SELECT pr.id,pr.raw_name,pr.normalized_name,pr.price_yen,ph.id,ph.uri,t.name,pr.created_at " +
                "FROM products pr JOIN photos ph ON ph.id=pr.photo_id " +
                "LEFT JOIN tags t ON t.id=ph.tag_id WHERE ph.store_id=? " +
                "ORDER BY pr.raw_name COLLATE NOCASE ASC, pr.price_yen ASC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(storeId)})) {
            while (c.moveToNext()) {
                Integer price = c.isNull(3) ? null : c.getInt(3);
                out.add(new ProductRecord(c.getLong(0), c.getString(1), c.getString(2), price,
                        c.getLong(4), c.getString(5), c.isNull(6) ? null : c.getString(6), c.getLong(7), null));
            }
        }
        return out;
    }

    List<ProductRecord> searchProducts(String query) {
        ArrayList<ProductRecord> out = new ArrayList<>();
        String like = "%" + query + "%";
        String sql = "SELECT pr.id,pr.raw_name,pr.normalized_name,pr.price_yen,ph.id,ph.uri,t.name,pr.created_at,s.name " +
                "FROM products pr JOIN photos ph ON ph.id=pr.photo_id " +
                "JOIN stores s ON s.id=ph.store_id LEFT JOIN tags t ON t.id=ph.tag_id " +
                "WHERE pr.raw_name LIKE ? OR pr.normalized_name LIKE ? " +
                "ORDER BY CASE WHEN pr.price_yen IS NULL THEN 1 ELSE 0 END, pr.price_yen ASC, s.name ASC";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{like, like})) {
            while (c.moveToNext()) {
                Integer price = c.isNull(3) ? null : c.getInt(3);
                out.add(new ProductRecord(c.getLong(0), c.getString(1), c.getString(2), price,
                        c.getLong(4), c.getString(5), c.isNull(6) ? null : c.getString(6), c.getLong(7), c.getString(8)));
            }
        }
        return out;
    }

    static final class Store {
        final long id;
        final String name;
        final long createdAt;
        Store(long id, String name, long createdAt) { this.id = id; this.name = name; this.createdAt = createdAt; }
    }

    static final class Tag {
        final long id;
        final String name;
        final long createdAt;
        Tag(long id, String name, long createdAt) { this.id = id; this.name = name; this.createdAt = createdAt; }
    }

    static final class Photo {
        final long id;
        final long storeId;
        final Long tagId;
        final String uri;
        final long createdAt;
        final String tagName;
        Photo(long id, long storeId, Long tagId, String uri, long createdAt, String tagName) {
            this.id = id; this.storeId = storeId; this.tagId = tagId; this.uri = uri; this.createdAt = createdAt; this.tagName = tagName;
        }
    }

    static final class ProductRecord {
        final long id;
        final String rawName;
        final String normalizedName;
        final Integer priceYen;
        final long photoId;
        final String photoUri;
        final String tagName;
        final long createdAt;
        final String storeName;
        ProductRecord(long id, String rawName, String normalizedName, Integer priceYen, long photoId,
                      String photoUri, String tagName, long createdAt, String storeName) {
            this.id = id; this.rawName = rawName; this.normalizedName = normalizedName; this.priceYen = priceYen;
            this.photoId = photoId; this.photoUri = photoUri; this.tagName = tagName; this.createdAt = createdAt; this.storeName = storeName;
        }
    }
}
