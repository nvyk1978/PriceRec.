package com.pricerec.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class DiagLog {
    private static final String FILE_NAME = "pricerec-diagnostic.log";
    private static final SimpleDateFormat FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.JAPAN);

    static synchronized void write(Context context, String message) {
        try (FileWriter w = new FileWriter(new File(context.getFilesDir(), FILE_NAME), true)) {
            w.write(FORMAT.format(new Date()) + " " + message + "\n");
        } catch (Exception ignored) { }
    }

    static synchronized String read(Context context) {
        File f = new File(context.getFilesDir(), FILE_NAME);
        if (!f.exists()) return "ログはまだありません。\n";
        StringBuilder out = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null) out.append(line).append('\n');
        } catch (Exception e) {
            return "ログ読込エラー: " + e + "\n";
        }
        return out.toString();
    }

    static synchronized void clear(Context context) {
        File f = new File(context.getFilesDir(), FILE_NAME);
        if (f.exists()) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }

    static synchronized String report(Context context) {
        String versionName = BuildConfig.VERSION_NAME;
        long versionCode = BuildConfig.VERSION_CODE;
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            if (info.versionName != null) versionName = info.versionName;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) versionCode = info.getLongVersionCode();
            else versionCode = info.versionCode;
        } catch (Exception ignored) { }

        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String model = Build.MODEL == null ? "" : Build.MODEL.trim();
        String device = (manufacturer + " " + model).trim();
        if (device.isEmpty()) device = "unknown";

        return "PriceRec diagnostic report\n"
                + "Generated: " + FORMAT.format(new Date()) + "\n"
                + "Device: " + device + "\n"
                + "Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n"
                + "App: " + versionName + " (" + versionCode + ")\n"
                + "\n--- LOG ---\n"
                + read(context);
    }
}
