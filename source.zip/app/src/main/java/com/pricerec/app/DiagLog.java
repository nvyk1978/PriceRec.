package com.pricerec.app;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class DiagLog {
    private static final String FILE_NAME = "pricerec-diagnostic.log";
    private static final SimpleDateFormat FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.JAPAN);

    static synchronized void write(Context context, String message) {
        try (FileWriter w = new FileWriter(new File(context.getFilesDir(), FILE_NAME), true)) {
            w.write(FORMAT.format(new Date()) + " " + message + "\n");
        } catch (Exception ignored) { }
    }

    static synchronized String read(Context context) {
        File f = new File(context.getFilesDir(), FILE_NAME);
        if (!f.exists()) return "ログはまだありません。";
        StringBuilder out = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null) out.append(line).append('\n');
        } catch (Exception e) {
            return "ログ読込エラー: " + e;
        }
        return out.toString();
    }
}
