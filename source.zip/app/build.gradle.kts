plugins {
    id("com.android.application")
}

android {
    namespace = "com.pricerec.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.pricerec.app"
        minSdk = 29
        targetSdk = 36
        versionCode = 72
        versionName = "0.1.71"
    }

    signingConfigs {
        create("stableDebug") {
            storeFile = file("pricerec-debug.jks")
            storePassword = "pricerec"
            keyAlias = "pricerec"
            keyPassword = "pricerec"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDebug")
            isDebuggable = true
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("stableDebug")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}


dependencies {
    implementation("androidx.activity:activity:1.12.4")
}
